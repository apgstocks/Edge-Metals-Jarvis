// ── config.js ─────────────────────────────────────────────────────────────────
// Single source of truth: paths, constants, env, dynamic settings.
// No cloud SDKs. Everything reads from ./data (gitignored) or env.

require('dotenv').config();
const path = require('path');
const fs   = require('fs');

// Display name used ONLY by the Loads/Yard feature (mobile app + the
// nightly yard report) — per the owner 2026-08-16: first said rename
// everywhere, then corrected to "no. just in mobile app and yard, it is
// sample yard co trading." Everything else (WhatsApp bot menu/persona, price lists,
// outbound email sign-offs) stays "Sample Yard Co Metals" — that rename was reverted,
// see workflow/brain.js, workflow/actions.js, helpers/pricelist.js. Only
// scheduler.js's buildYardReportText/eodYardReport reads this constant;
// mobile-app/www/index.html has no access to this file so its two
// "Sample Yard Co Trading" instances (title, login tagline) are hardcoded by hand.
const COMPANY_NAME = 'Sample Yard Co Trading';

// ── Paths ─────────────────────────────────────────────────────────────────────
const ROOT     = __dirname;
const DATA_DIR = process.env.DATA_DIR || path.join(ROOT, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

// Memory lives in its own subfolder — deliberately separate from facts.json.
// facts.json = corrections/standing instructions (accuracy for data answers).
// memory/    = session continuity + rolling conversation summaries + durable
//              business-context notes (ongoing situations, not corrections).
const MEMORY_DIR = path.join(DATA_DIR, 'memory');
if (!fs.existsSync(MEMORY_DIR)) fs.mkdirSync(MEMORY_DIR, { recursive: true });
const LOGS_DIR = path.join(DATA_DIR, 'logs');
if (!fs.existsSync(LOGS_DIR)) fs.mkdirSync(LOGS_DIR, { recursive: true });
const FILES = {
    BOOKINGS_FILE    : path.join(DATA_DIR, 'bookings.json'),
    // Destination import rules for scrap, each with its source and the date
    // it was last verified — see helpers/exportRules.js. Under DATA_DIR like
    // every other store, so a test that sets DATA_DIR is isolated by default.
    EXPORT_RULES_FILE: path.join(DATA_DIR, 'export-rules.json'),
    // The California junk-dealer record requirements, once a PERSON has
    // confirmed each statute. helpers/sellerRecord.js falls back to
    // seeds/seller-record-laws.json, where every row is unverified, so an
    // absent file reports "nobody has checked this" rather than "compliant".
    SELLER_RECORD_LAWS_FILE: path.join(DATA_DIR, 'seller-record-laws.json'),
    WORKFLOW_FILE    : path.join(DATA_DIR, 'workflow.json'),
    TASKS_FILE       : path.join(DATA_DIR, 'tasks.json'),
    TASKS_HISTORY_FILE: path.join(DATA_DIR, 'tasks_history.json'),
    HISTORY_FILE     : path.join(DATA_DIR, 'history.json'),
    TRUCKERS_FILE    : path.join(DATA_DIR, 'truckers.json'),
    SUPPLIERS_FILE   : path.join(DATA_DIR, 'suppliers.json'),
    BRAIN_FILE       : path.join(DATA_DIR, 'brain.json'),
    ALERTS_FILE      : path.join(DATA_DIR, 'alerts.json'),
    SETTINGS_FILE    : path.join(DATA_DIR, 'settings.json'),
    // ── EVERY SCHEDULED JOB'S PULSE (2026-10-08) ─────────────────────────
    // the owner: "if something is broke - i should know". 31 cron jobs ran in
    // this process and exactly ONE of them recorded that it had run
    // (gmail_watcher_last_run), and that one read null. A job that dies is
    // invisible, because its only symptom is an ABSENCE.
    //
    // Its OWN FILE, deliberately not settings.json: settings is written by
    // many paths and has eaten fields before (see the saveStore allowlist
    // scars in workflow/replyWatch.js). A pulse written every minute does
    // not belong in the same file as her configuration.
    HEARTBEAT_FILE   : path.join(DATA_DIR, 'heartbeat.json'),
    // ── WHAT JARVIS DECIDED, AND WHAT SHE THEN DID (2026-10-08) ──────────
    // the owner: "make it learn everything". Jarvis records what it DECIDED and
    // never what HAPPENED, so every correction she makes -- "this can be
    // ignored", "they just asked for booking, why is it on WhatsApp" -- is a
    // labelled training example that currently exists only in a chat log
    // nothing reads.
    //
    // APPEND-ONLY, and that is the whole design. Every data-loss scar in this
    // repo is a write clobbering another write: saveStore's field allowlist
    // has silently eaten six fields, mutateJson contends on a lock. A log
    // that is only ever appended to cannot clobber anything, needs no lock,
    // and survives two processes writing at once.
    OUTCOMES_FILE    : path.join(DATA_DIR, 'outcomes.jsonl'),
    TRANSCRIPTS_FILE : path.join(DATA_DIR, 'transcripts.json'),
    FACTS_FILE       : path.join(DATA_DIR, 'facts.json'),
    TRUST_LEDGER_FILE: path.join(DATA_DIR, 'trust_ledger.json'),
    // Review & Generate screen's edit-state history, per container — NOT
    // the saved PDF archive (see helpers/documentsSaved.js for that, a
    // different thing: the finished file vs. the form fields that produced
    // it). Added per the owner's "Load previous edits" mockup — every real
    // Generate & Download saves the full form state here so a returning
    // visit to the same container can restore it instead of starting blank.
    INVOICE_VERSIONS_FILE: path.join(DATA_DIR, 'invoice_versions.json'),
    MEMORY_SESSIONS_FILE: path.join(MEMORY_DIR, 'sessions.json'),
    MEMORY_CONTEXT_FILE : path.join(MEMORY_DIR, 'business_context.json'),
    MEMORY_EMBEDDINGS_FILE: path.join(MEMORY_DIR, 'embeddings.json'),
    // Saved name→email directory for draft_email/reply_email — see
    // helpers/emailContacts.js. Added 2026-08-03.
    EMAIL_CONTACTS_FILE: path.join(DATA_DIR, 'email_contacts.json'),
    // helpers/pricelist.js's loadContacts()/addContact()/removeContact() have
    // referenced cfg.PRICELIST_CONTACTS_FILE since that file was written, but
    // this constant never actually existed here — confirmed via GitHub audit
    // (grep -c "PRICELIST_CONTACTS_FILE" config.js on main → 0) while
    // building the email-contacts feature alongside it. Real bug, not
    // hypothetical: loadContacts() silently returned [] (loadJson catches
    // the resulting fs.existsSync(undefined) throw), but addContact()/
    // removeContact() would hard-crash on ensureFile(undefined, ...), which
    // sits outside mutateJson's own try/catch. Combined with api.js having
    // NO /api/pricelist/contacts routes at all (also fixed alongside this),
    // the dashboard's "Price list contacts" tab has been fully non-functional
    // in production — added here to close the gap.
    PRICELIST_CONTACTS_FILE: path.join(DATA_DIR, 'price_contacts.json'),
    // THIRD instance of the same missing-constant bug, found 2026-08-03
    // while wiring the pricelist send-city/webhook API routes: pricelist.js's
    // checkForChangesAndNotify() has referenced cfg.PRICELIST_SNAPSHOT_FILE
    // since it was written, and that function has ALREADY been running
    // daily via scheduler.js's pricelistFallback cron (0 6 * * *) since this
    // whole feature was deployed — meaning it has been silently
    // crash-failing every single morning (ensureFile(undefined, ...) throws
    // outside mutateJson's own try/catch, caught one level up by
    // pricelistFallback's try/catch, logged as "[SCHED] pricelist fallback
    // failed" and otherwise invisible). No snapshot has ever actually been
    // established, so real price changes have never once been detected by
    // this safety net. Same root-cause pattern as PRICELIST_CONTACTS_FILE
    // above — fixed together for the same reason.
    PRICELIST_SNAPSHOT_FILE: path.join(DATA_DIR, 'price_snapshot.json'),
    // Structured yard "load" records — date/seller/item table/gross-tare-net
    // weight, created via the dashboard's Add New Load form (camera-captured
    // weights, not WhatsApp). Separate from SCALE_TICKETS_FILE on purpose: that
    // one is a quick single-photo capture from WhatsApp, this is the full
    // structured record with line items and a generated PDF. Revisit merging
    // them later if that turns out to be wanted — kept apart for now since the
    // shapes and entry points are genuinely different.
    LOADS_FILE: path.join(DATA_DIR, 'loads.json'),
    // Outbound loads — the MIRROR of LOADS_FILE above (2026-08-16, per
    // the owner: "loads sent to Eccomelt... how many loads for this month,
    // item wise, how much amount spent"). LOADS_FILE tracks INBOUND scrap
    // purchases at the yard (seller = outside party, buyer = fixed "Sample
    // Trading" constant — see helpers/loads.js's field-mapping note).
    // OUTBOUND_LOADS_FILE tracks the reverse: Sample Yard Co Trading SELLING/shipping
    // material OUT to a real buyer (Eccomelt, or anyone else — general-
    // purpose per the owner, not Eccomelt-specific). Deliberately its own
    // store, not a `direction` flag bolted onto loads.json — LOADS_FILE's
    // whole schema, validation, PDF/Drive integration, and inventory report
    // all hard-assume buyer is the fixed constant; reusing it here would
    // mean either breaking that assumption for every existing caller or
    // special-casing around it everywhere, for zero benefit over a
    // deliberately separate, much simpler store.
    OUTBOUND_LOADS_FILE: path.join(DATA_DIR, 'outbound_loads.json'),
    // Unfinished loads — per the owner 2026-08-28: "draft needs to be saved and
    // can be edited later." A load being typed is autosaved here once two
    // items carry real content, and can be reopened and finished from any
    // device rather than only the browser it was started in.
    //
    // Its OWN store, for the same reason OUTBOUND_LOADS_FILE is: a `draft`
    // flag on loads.json would put half-finished loads one forgotten filter
    // away from the day's totals, the yard report, the inventory netting and
    // the seller statements. A separate file makes that leak impossible
    // rather than merely unlikely — nothing that reads loads.json can see a
    // draft, because it is not in there. A draft is DELETED, not converted,
    // when the real load is saved.
    LOAD_DRAFTS_FILE: path.join(DATA_DIR, 'load_drafts.json'),
    // Payments against a load — per the owner 2026-08-28. A load can be settled
    // in instalments, so this is a LEDGER of payments keyed by load, not a
    // paid/unpaid flag on the load itself.
    //
    // Its own store for the same reason as the two above, plus one specific
    // to money: a payment must never be silently rewritten by a load edit.
    // Loads are re-saved wholesale on every edit (see editLoad in
    // helpers/loads.js, which rebuilds the record), so a payments array living
    // on the load would be one dropped field away from erasing a receipt.
    // Keeping payments outside that write path means editing a weight cannot
    // touch what was paid.
    PAYMENTS_FILE: path.join(DATA_DIR, 'payments.json'),
    // ── BANKS SHE HAS TYPED UNDER "OTHERS" ────────────────────────────────
    // the owner, 2026-09-09, choosing this over a Banks screen: "Fixed three, but
    // Others text is remembered." So the first Wells Fargo wire is typed once
    // and offered ever after.
    //
    // ITS OWN FILE, not a key on settings: it is written from the payment
    // write path, which runs while she is paying somebody, and settings.json
    // is rewritten wholesale by the Settings tab. One save from that tab
    // during a payment would drop whichever the other had just added.
    //
    // NOT SENSITIVE — a list of bank NAMES, no account numbers, nothing that
    // identifies an account. So unlike bank-item.json it is not excluded from
    // the nightly Drive backup; losing it would mean retyping her own banks.
    BANKS_FILE: path.join(DATA_DIR, 'banks.json'),
    // ── PURCHASE BILLS, SAMPLE YARD CO METALS SIDE ──────────────────────────────────
    // the owner, 2026-09-09, opening with "This is for sample yard co metals not for edge
    // yard": a bill per container against a booking — weights off the
    // weighbridge, the supplier's price, what the haulier charged, what has
    // been advanced.
    //
    // ITS OWN FILE, beside PAYMENTS_FILE and for the same reason written
    // there: bookings are re-saved wholesale by several paths, and a bill
    // hanging off a booking would be one dropped field away from losing a
    // weighbridge figure nobody can reconstruct.
    //
    // NOT trucker_bills.json, which is the YARD owing its hauliers. Two
    // stores with "bill" in the name is a hurried afternoon away from a
    // mistake, so the distinction is written here as well as in each file.
    BILLS_FILE: path.join(DATA_DIR, 'bills.json'),
    // The other half of the Sample Yard Co Metals pair: what a container SOLD for.
    // Deliberately not the yard's kind:'sale' loads, which stay in loads.json
    // — see helpers/sales.js's header for why ocean paperwork does not belong
    // on a weighbridge ticket.
    SALES_FILE: path.join(DATA_DIR, 'sales.json'),
    // Payments against Sample Yard Co Metals bills, and supplier advances. Separate
    // from PAYMENTS_FILE (the yard's money ledger) because one of these can
    // cover several containers at once and an advance covers none yet — see
    // helpers/billPayments.js. Every row here ALSO writes one row to
    // PAYMENTS_FILE so the spend report still sees the money.
    BILL_PAYMENTS_FILE: path.join(DATA_DIR, 'bill_payments.json'),
    // Money IN from customers. A separate store from BILL_PAYMENTS_FILE and
    // from PAYMENTS_FILE because it flows the other way — see the header of
    // helpers/salesReceipts.js for why it writes no row to the spend ledger.
    SALES_RECEIPTS_FILE: path.join(DATA_DIR, 'sales_receipts.json'),

    // ── THE FIELDS BEHIND A BILL OF LADING (2026-09-16) ──────────────────
    // the owner: "Edit Bol option also needed". The BOL shipped saving only the
    // rendered PDF (documents_saved/bol/<date>/<file>.pdf), which is where
    // the typing ENDED — there was nothing to reopen. This holds what she
    // filled in, so a BOL can be corrected and reissued. See helpers/bols.js.
    BOLS_FILE: path.join(DATA_DIR, 'bols.json'),
    // The per-customer, per-year BOL sequence (2026-09-16, "include year in
    // bol number as in 26ECC001"). A SEPARATE FILE from bols.json on purpose:
    // deleting a BOL must not hand its number to the next document, and a
    // counter living inside the list it counts would do exactly that.
    BOL_COUNTERS_FILE: path.join(DATA_DIR, 'bol_counters.json'),
    // Purchase-order numbers handed out by Print PO on a load/sale (helpers/poNumbers.js).
    PO_COUNTERS_FILE: path.join(DATA_DIR, 'po_counters.json'),

    // ── WHICH FIELDS EACH CUSTOMER'S BOL CARRIES (2026-09-16) ────────────
    // the owner: "For different customer,i can have different field in bol".
    // Per-customer field order and show/hide — see helpers/bolLayouts.js.
    // Server-side rather than in the browser because she chose one layout
    // for both the website and the app; a layout the phone cannot read
    // means one BOL number and two different documents.
    BOL_LAYOUTS_FILE: path.join(DATA_DIR, 'bol_layouts.json'),

    // ── PACKING LISTS (2026-09-16) ───────────────────────────────────────
    // the owner: "in sample yard co metals,i want to create a sub tab under invoice
    // -documents as packing list.it should allow to upload photo/pdf ,it
    // scan and fill fields". SAMPLE YARD CO METALS — one packing list per container,
    // keyed on the container number. See helpers/packingList.js.
    PACKING_LISTS_FILE: path.join(DATA_DIR, 'packing_lists.json'),

    // ── WHICH ITEM NAMES MEAN THE SAME METAL (2026-09-16) ────────────────
    // the owner: "Warn me if al combo and aluminium combo,remember my
    // selection-then next time let ai decide based on knowldge". Her
    // decisions, kept — so one pile of aluminium stops reporting as two rows
    // with one of them impossible. See helpers/itemAliases.js.
    ITEM_ALIASES_FILE: path.join(DATA_DIR, 'item_aliases.json'),
    // What a sale COSTS: charges she pays and agent commission. Money out, so
    // unlike receipts it does mirror into PAYMENTS_FILE — load_kind
    // 'sale_cost', its own line in the spend report.
    SALES_SETTLEMENTS_FILE: path.join(DATA_DIR, 'sales_settlements.json'),
    // Sample Yard Co Metals haulage. NOT the yard's trucker bills — see the header of
    // helpers/metalsTrucking.js for why the two are separate stores and
    // separate lines in the spend report.
    METALS_TRUCKING_FILE: path.join(DATA_DIR, 'metals_trucking.json'),
    // Sample Yard Co Metals local-delivery carriers (NTG, TQL, Schneider) — own store, see helpers/carrierInvoices.js
    CARRIER_INVOICES_FILE: path.join(DATA_DIR, 'carrier_invoices.json'),
    // carrier / Jio / Sher / Pan Metal / AJ Transport / Garduno's invoices read from email — see helpers/partyInvoices.js
    PARTY_INVOICES_FILE: path.join(DATA_DIR, 'party_invoices.json'),
    // One payment across several register invoices — see helpers/partyInvoices.js
    PARTY_INVOICE_PAYMENTS_FILE: path.join(DATA_DIR, 'party_invoice_payments.json'),
    // The ONE lock over the invoice register and the carrier invoice lists — see helpers/partyInvoices.js
    PARTY_INVOICES_LOCK_FILE: path.join(DATA_DIR, 'party_invoices_lock.json'),
    // When the last "N emails still open" chase-up went out — its own file because reply_watch.json's allowlist swallows new fields. See workflow/replyWatch.js
    REPLY_WATCH_CHASE_FILE: path.join(DATA_DIR, 'reply_watch_chase.json'),
    // Customers on ETA-based payment terms (ETA-10, ETA+7 …) — skipped by the payment follow-up drafts, see helpers/paymentFollowups.js
    CUSTOMER_PAY_TERMS_FILE: path.join(DATA_DIR, 'customer_pay_terms.json'),
    // What the Follow-up Agent has already told her about each customer's unpaid invoices (helpers/paymentChaser.js).
    PAYMENT_CHASE_LOG_FILE: path.join(DATA_DIR, 'payment_chase_log.json'),
    // Nightly mail sweep -> register: what each night found, and when the morning email last went — see helpers/partyInvoiceNightly.js
    PARTY_INVOICE_NIGHTLY_FILE: path.join(DATA_DIR, 'party_invoice_nightly.json'),
    // ── SAMPLE YARD CO METALS MATERIAL RECEIVED, ITEMISED FROM A PACKING LIST ──────
    // the owner, 2026-09-11: "sometimes,we get packing list when we deliver the
    // load. that packing list contains items that needs to stored in
    // inventory,so mimic add load form but we will have only seller in form."
    //
    // NOT loads.json. That is the YARD's inventory — material bought over the
    // scale at Sample Yard Co Yard, with a weighbridge ticket, a signature and a printed
    // load ticket. This is Sample Yard Co Metals: what a supplier delivered against a
    // packing list, itemised, before it is stuffed into a container. Two
    // companies, and the standing rule is that they never share a store.
    SAMPLE_INVENTORY_FILE: path.join(DATA_DIR, 'yard_inventory.json'),
    // Yard assistant transcripts — per the owner 2026-08-29: "keep on storing the
    // conversations of yard assistant somewhere. so per day one log", then
    // "create a folder inside yard folder as log. put the logs over there."
    //
    // So: data/yard/log/. The yard/ folder is new and deliberately general —
    // anything else the yard feature needs to keep on disk belongs beside it
    // rather than as another loose entry in data/, which already has twenty.
    //
    // A DIRECTORY of one file per day rather than a single growing file. A
    // conversation log only grows, and one file that never stops growing
    // eventually has to be rewritten in full on every append, or read in full
    // to inspect one afternoon. A day per file keeps both cheap and makes
    // "what did it say on the 27th" a matter of opening one small file.
    YARD_DIR: path.join(DATA_DIR, 'yard'),
    YARD_CHAT_DIR: path.join(DATA_DIR, 'yard', 'log'),
    // Yard expenses — per the owner 2026-08-19 ("for admin access in mobile
    // app, i want expense tracker"). Its own flat store for the same reason
    // OUTBOUND_LOADS_FILE is separate from LOADS_FILE: an expense shares
    // almost nothing with a load (no items, no weights, no scale photos, no
    // PDF/Drive pipeline, no buyer/seller mapping), so bolting a `type`
    // flag onto loads.json would mean special-casing every existing
    // consumer — getInventoryReport, the PDFs, the workbooks — for no gain.
    EXPENSES_FILE: path.join(DATA_DIR, 'expenses.json'),
    // Payments received against invoices — the other half of the receivables
    // ledger (helpers/receivables.js). Deliberately its own append-only store
    // rather than new columns on the Invoice Google Sheet: that sheet is read
    // by several other tools, one invoice can be paid in instalments (a list,
    // not a column), and a payment record must survive an accidental sheet
    // edit. Joined to the sheet by invoice number.
    PAYMENTS_FILE: path.join(DATA_DIR, 'payments.json'),
    // Gmail message ids the payment watcher has already judged — same dedupe
    // pattern as EMAIL_PROCESSED_FILE, kept separate so the two watchers can
    // never mark each other's mail as handled.
    PAYMENT_EMAILS_PROCESSED_FILE: path.join(DATA_DIR, 'payment_emails_processed.json'),
    // Weight-shortage / grade claims a customer has raised against Sample
    // Metals. Its own store, NOT a row appended to the sheet's "Weight
    // Shortage 2025" tab: that tab is seven stacked tables sharing one grid,
    // so an appended row has no defined column meaning. See helpers/claims.js.
    CLAIMS_FILE: path.join(DATA_DIR, 'claims.json'),
    // The kinds of claim, as the model has named them. Deliberately NOT a list
    // in the code: the owner, 2026-09-26, "let ai decide dynamically". The model
    // names a kind and also decides whether a new name means the same as one
    // already here; this file is where they accumulate. helpers/claimKinds.js.
    CLAIM_KINDS_FILE: path.join(DATA_DIR, 'claim_kinds.json'),
    // Gmail message ids the claim watcher has already judged. Separate from
    // EMAIL_ASSESSED_FILE and PAYMENT_EMAILS_PROCESSED_FILE for the same
    // reason those two are separate — no watcher may mark another's mail as
    // handled, and replyWatch's `seen` is aged out by trimSeen, which would
    // let a chaser re-create a claim weeks later.
    CLAIM_EMAILS_PROCESSED_FILE: path.join(DATA_DIR, 'claim_emails_processed.json'),
    // Yard scale-ticket photos — standalone store, deliberately separate from
    // BOOKINGS_FILE/WORKFLOW_FILE. Added for the yard/scale-staff camera-photo
    // feature: yard staff text a photo of the digital scale ticket, Gemini reads
    // it, result lands here — never written onto a booking or container record.
    SCALE_TICKETS_FILE: path.join(DATA_DIR, 'scale_tickets.json'),
    // Custom item-type descriptions typed via the load form's "Others…"
    // free-text box — per the owner 2026-08-15 ("when something gets added in
    // others, it should get added to existing list of description"). Starts
    // empty; helpers/itemTypes.js merges this with the hardcoded
    // ITEM_DESC_OPTIONS base list on the client so a custom description
    // typed once becomes a normal selectable option afterward instead of
    // requiring "Others…" every time.
    ITEM_TYPES_FILE: path.join(DATA_DIR, 'item_types.json'),
    // Ferrous / non-ferrous learned per item name (helpers/itemMetal.js), 2026-11-17.
    ITEM_METAL_FILE: path.join(DATA_DIR, 'item-metal-types.json'),
    // Journal of Sample Yard Co Yard item renames (helpers/itemMaintenance.js) — what each
    // rename changed, so it can be undone.
    ITEM_RENAMES_FILE: path.join(DATA_DIR, 'item_renames.json'),
    // the owner, 2026-09-07: "maintain a separate catalogue for sample yard co metals.
    // keep on appending to that new catalogue as i generate proforma and keep
    // the existing workflow catalogue for yard."
    //
    // The SELLING vocabulary, distinct from ITEM_TYPES_FILE above, which is
    // the yard's. "Auto cast" goes on a load ticket at the scale; "Aluminium
    // Auto Casting Scrap" goes on a proforma read by a buyer in Busan. Filled
    // automatically from descriptions that have actually gone out on a
    // generated document — see helpers/tradeCatalog.js.
    TRADE_CATALOG_FILE: path.join(DATA_DIR, 'trade_catalog.json'),
    // Petty cash — the physical cash box, per the owner 2026-09-02: "a new tab
    // called Petty cash. Date and cash amount needs to be entered here. So it
    // is like cash reserve. If i click pay in load and select cash, the
    // invoice amount should be adjusted against this."
    //
    // A LEDGER, like payments, not a single balance field. Every top-up and
    // every cash payment is its own row and the balance is the sum. A stored
    // balance would be one crashed write away from being wrong with no way to
    // tell what it should have been — and with cash there is no bank statement
    // to reconcile against, so the ledger IS the record.
    //
    // ITS OWN FILE, for the same reason PAYMENTS_FILE is: it must not live
    // inside a record that gets rewritten wholesale by an unrelated edit.
    PETTY_CASH_FILE: path.join(DATA_DIR, 'petty_cash.json'),

    // ── what the yard owes its hauliers ───────────────────────────────────
    // the owner 2026-09-03: a Trucker tab of bills — date, company, an optional
    // load ticket, amount — payable by Zelle or Wire.
    //
    // NOT the trucker ROSTER, which is a Supabase table of hauliers and their
    // WhatsApp groups and has nothing to do with money. Two different things
    // wearing the same word; see helpers/truckerBills.js.
    //
    // Its own file, like payments and petty cash, for the same reason: it must
    // not live inside a record that some unrelated edit rewrites wholesale.
    TRUCKER_BILLS_FILE: path.join(DATA_DIR, 'trucker_bills.json'),

    // ── the bank feed ─────────────────────────────────────────────────────
    // the owner 2026-09-03: "can i link my bank account here like quickbook."
    //
    // NAMED bank-* ON PURPOSE. helpers/backup.js excludes these by FILENAME,
    // so the prefix is not cosmetic — it is what keeps a bank statement out of
    // a shared Drive folder. Renaming either of these without adding the new
    // name to SECRET_PATTERNS would start uploading them, silently, on the
    // next nightly run. tests/bank.js asserts the exclusion by walking the
    // real backup code rather than by trusting this comment.
    //
    // bank-item.json holds the Plaid ACCESS TOKEN. It is the standing ability
    // to pull this account's history, it does not expire on its own, and it
    // must never appear in an API response or a log line.
    BANK_ITEM_FILE: path.join(DATA_DIR, 'bank-item.json'),
    // The transactions themselves, keyed by Plaid's transaction_id so a
    // re-sync corrects a row rather than duplicating it.
    BANK_TX_FILE: path.join(DATA_DIR, 'bank-transactions.json'),

    // ── what the top-level profile did ────────────────────────────────────
    // Every time a Jarvis session walks past a lock that stops everyone else,
    // a row lands here. It is APPEND-ONLY and nothing in the codebase deletes
    // from it — not even the profile it records, which is the entire point: a
    // profile that can erase a paid load can erase the evidence that money
    // moved, and this is the only trace left once the record is gone.
    //
    // Under DATA_DIR on purpose, so helpers/backup.js sweeps it up with
    // everything else and a copy leaves the machine nightly. A log that only
    // exists on the disk it is meant to outlive is not a log.
    AUDIT_LOG_FILE: path.join(DATA_DIR, 'audit_log.json'),

    // Every question asked of the ledgers or the mail, with what it did —
    // see helpers/data/askLog.js. The reviewable list of what Jarvis could
    // not answer, which is the only way a gap gets fixed instead of noticed
    // once and forgotten.
    ASK_LOG_FILE: path.join(DATA_DIR, 'ask_log.json'),

    // Bugzilla — every problem she reports and what happened to it.
    // the owner, 2026-09-24: "create a bugzilla tab in website so that we can
    // keep track of all the fixes so that we can revisit it".
    BUGS_FILE: path.join(DATA_DIR, 'bugs.json'),
};

// ── Env ───────────────────────────────────────────────────────────────────────
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const GEMINI_MODEL   = process.env.GEMINI_MODEL   || 'gemini-2.5-flash-lite';
// ── TWO TIERS, NOT A SETTING PER FEATURE (2026-10-02) ─────────────────────
// the owner: "Use the best model in google for QB and Claims", then "For jarvis
// chat window,give access to latest model and same applicable for all complex
// things".
//
// The first version of this added GEMINI_MODEL_CLAIMS and GEMINI_MODEL_QB.
// That does not survive "and all complex things" — it becomes a config entry
// per feature, and the day a model is superseded she has to find all of them.
// So there are TWO TIERS and each caller says which kind of work it is doing:
//
//   GEMINI_MODEL        the workhorse. 45 call sites, most of them a yes/no
//                       gate or a one-field extraction, many on a 5-minute
//                       loop. Cheap and fast is CORRECT here; a frontier
//                       model on every inbox scan is money burnt for no
//                       better answer.
//   GEMINI_MODEL_SMART  anything where being wrong costs money, or where she
//                       READS the answer and acts on it.
//
// WHY 3.8 FLASH AND NOT THE PRO PREVIEW. Checked against Google's own list
// (ai.google.dev/gemini-api/docs/models, updated 2026-10-01) rather than from
// memory — this codebase already referenced models newer than I could assert:
//   gemini-3.8-flash        STABLE. "Our most intelligent Flash model,
//                           engineered for long-horizon software engineering,
//                           autonomous agents, and complex enterprise
//                           workflows."
//   gemini-3.1-pro-preview  Pro-tier but PREVIEW: restrictive rate limits,
//                           and preview models are "deprecated with at least
//                           2 weeks notice".
// Several of these paths run UNATTENDED — claim mail is parsed by a watcher
// nobody is sitting over. A model that disappears on two weeks' notice would
// break that silently, and silence is how the claims money went missing in
// the first place. Stable wins.
//
// ALSO: the 2.5 family is now access-limited. Google: "we are limiting access
// to the 2.5 models to users who have actively used them in the past ... for
// any new projects, use our latest models." The workhorse default below is
// legacy and should move — deliberately NOT changed in passing, because
// swapping the model under 45 callers at once is its own piece of work with
// its own testing. Filed as #159.
const GEMINI_MODEL_SMART = process.env.GEMINI_MODEL_SMART || 'gemini-3.8-flash';

// Per-path overrides, defaulting to the tier. Present so one path can be
// pinned or tried on something else without touching the others — not so
// that each needs its own value.
const GEMINI_MODEL_CLAIMS = process.env.GEMINI_MODEL_CLAIMS || GEMINI_MODEL_SMART;
const GEMINI_MODEL_QB     = process.env.GEMINI_MODEL_QB     || GEMINI_MODEL_SMART;
// ── MONEY GETS THE GOOD MODEL (the owner, 2026-10-03) ───────────────────────
// "For payments use advanced gemini."
//
// Her first live morning: "We payed $4000 for Hugi" missed the payment regex,
// went to the classifier on the LEGACY workhorse, and was filed as an invoice
// payment — she got "invoiceSheet.listAllInvoices is not a function" twice
// and no payment. A sentence about money being wrongly understood costs more
// than the model does.
//
// Derived from SMART like the others, so there is still ONE place to change
// the tier. Applied only when the message is about money — see brain.js — so
// the cheap model keeps handling the ordinary traffic.
const GEMINI_MODEL_PAY   = process.env.GEMINI_MODEL_PAY   || GEMINI_MODEL_SMART;
const GEMINI_MODEL_CHAT   = process.env.GEMINI_MODEL_CHAT   || GEMINI_MODEL_SMART;
const API_PORT       = parseInt(process.env.API_PORT || '8080');
const API_TOKEN      = process.env.API_TOKEN || '';        // simple bearer token for dashboard API
const APP_PASSWORD   = process.env.APP_PASSWORD || '';     // password gate for the web app (browser sessions)
const STAFF_PASSWORD = process.env.STAFF_PASSWORD || '';   // separate, LOWER-privileged tier — Loads tab only (see api.js login)
const SUPABASE_URL   = process.env.SUPABASE_URL || '';     // semantic memory store — Project Settings > API
const SUPABASE_KEY   = process.env.SUPABASE_KEY || '';     // service_role key (server-side only, never expose to browser)
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || '';   // separate, stronger password — gates WhatsApp QR + Facts admin panel
// ── the top-level profile ─────────────────────────────────────────────────
// the owner 2026-09-03: "create another profile as jarvis with delete option
// enabled even after payments. this is in addition to admin privileges. this
// is like top level profile."
//
// A session logging in with THIS password gets role 'admin' — not a fourth
// role — plus a `super` flag. Deliberate: 'admin' is checked in fourteen
// places across two clients and the server, and a genuinely separate role
// string would have had to be added to every one of them, where missing a
// single check means the TOP-level profile silently sees LESS than admin.
// admin + a flag means every existing check keeps working untouched and only
// the four locks she asked to lift consult the flag.
//
// UNSET BY DEFAULT, and when unset the profile does not exist: no password
// matches it and nothing changes. Set it in .env on the VM, to something
// different from ADMIN_PASSWORD — if the two are equal, the admin password
// would silently grant the ability to erase paid loads, which is precisely
// the separation this profile exists to create. api.js refuses to accept it
// in that case rather than trusting the operator to notice.
const JARVIS_PASSWORD = process.env.JARVIS_PASSWORD || '';

// ── Plaid, for the bank feed ──────────────────────────────────────────────
// the owner's own credentials, set on the VM. Not created here and never handled
// in chat — the same rule as the Picovoice key: an account in Sample Yard Co Trading's
// name is hers to open.
//
// PLAID_ENV is 'sandbox' until she has production access. Sandbox uses fake
// institutions with published test logins, so the whole flow — link, sync,
// reconcile — is exercisable end to end before a real account is ever
// connected. The switch to production is these three values changing, not a
// code change.
const PLAID_CLIENT_ID = process.env.PLAID_CLIENT_ID || '';
const PLAID_SECRET    = process.env.PLAID_SECRET    || '';
const PLAID_ENV       = process.env.PLAID_ENV       || 'sandbox';
// ── WHERE PLAID PUSHES, 2026-10-08 ───────────────────────────────────────
// the owner: "i dont want human intervention between jarvis and plaid." The
// nightly pull finds out about a dead connection up to a day late; a webhook
// says it within the hour. Empty by default and OMITTED from the link token
// when empty, because a wrong URL makes Plaid retry into nothing for 24
// hours per event rather than failing visibly.
//
// Must be a public https URL with a valid certificate — Plaid will not post
// to localhost, so this cannot be exercised against a laptop even in
// sandbox. The real value is https://jarvis.sample.example/api/plaid/webhook
// and it goes in the VM's .env, not here.
//
// The route it points at is PUBLIC and unauthenticated by necessity: Plaid
// cannot log in. helpers/plaidWebhook.js is the whole of its protection —
// an ES256 signature, a five-minute replay window and a body-hash check.
const PLAID_WEBHOOK_URL = process.env.PLAID_WEBHOOK_URL || '';
// ── HOW MUCH HISTORY A NEW BANK LINK ASKS FOR ───────────────────────────
// the owner, 2026-10-12: "all the transactions from plaid is from 2026-07-14
// to 2026-10-09.why not 2026 datas are sent?" — 2026-07-14 was exactly 90
// days earlier, which is Plaid's default when days_requested is not set.
//
// Then, asked how far back: "i need 2026 transactions from 01-01-2026" and
// "i just need 2026 data". So 2026 is the requirement, and 2025 is not.
//
// (I had defaulted this to Plaid's maximum of 730 on the reasoning that her
// ledger holds 2025 bills. That was MY inference, not her instruction, and
// she has since said otherwise — recorded here because a guess of mine
// written up as a requirement is the worst way to file a decision.)
//
// 365, not 285. The window is a ROLLING LOOKBACK from the day the bank is
// linked, not a fixed start date — 285 days reaches 1 January only if the
// link happens today, and the distance grows by a day every day. Since
// Plaid will not let the window be changed afterwards, undersizing it is
// the mistake that costs a second unlink/re-link. A year covers her ask
// with ~80 days of margin and still polls faster than two years would.
//
// SET ONCE, PER ITEM, AT LINK TIME. Changing this env does nothing to a
// bank already connected; that bank has to be unlinked and linked again
// (scripts/bank-relink.js). See the long note in helpers/plaid.js.
const PLAID_DAYS_REQUESTED = process.env.PLAID_DAYS_REQUESTED || '365';
const SESSION_PATH   = process.env.SESSION_PATH || path.join(DATA_DIR, '.wwebjs_auth');

// Google Drive (booking PDFs) — service-account JSON path
const GDRIVE_KEYFILE          = process.env.GDRIVE_KEYFILE || path.join(DATA_DIR, 'gdrive-sa.json');
const GMAIL_CREDENTIALS_FILE = process.env.GMAIL_CREDENTIALS_FILE || path.join(DATA_DIR, 'gmail-credentials.json');
// Read and write are DIFFERENT Gmail accounts (ops@sample.example reads —
// that's where carrier booking mail arrives; owner@sample.example sends —
// outbound mail should visibly come from the owner, not the shared inbox).
// Same OAuth client/credentials file works for both; each account just
// needs its own consent + token, hence two separate token files. Run
// scripts/gmail-auth.js --role=read (signed into ops) and --role=write
// (signed into owner) once each. GMAIL_TOKEN_FILE (no read/write suffix)
// is kept only as a fallback default if someone hasn't split their .env yet.
const GMAIL_TOKEN_FILE       = process.env.GMAIL_TOKEN_FILE       || path.join(DATA_DIR, 'gmail-token.json');
const GMAIL_READ_TOKEN_FILE  = process.env.GMAIL_READ_TOKEN_FILE  || path.join(DATA_DIR, 'gmail-token-read.json');
const GMAIL_WRITE_TOKEN_FILE = process.env.GMAIL_WRITE_TOKEN_FILE || path.join(DATA_DIR, 'gmail-token-write.json');
// A THIRD token, real gap found 2026-08-05: ops@ only ever sees carrier-
// initiated booking mail — any thread the owner starts herself (emailing a
// trucker/broker directly from owner@) never touches ops@'s inbox at all,
// so "reply to X" searches (hardcoded to ops@ via getGmailRead()) are
// structurally blind to it, and can end up matching the wrong thread
// entirely off a coincidental subject/word overlap. This token grants
// READ access to owner@'s OWN mailbox (separate from GMAIL_WRITE_TOKEN_FILE,
// which is send-only scope and can't list/read anything) — see
// helpers/gmail.js's getGmailSenderRead(). Run scripts/gmail-auth.js
// --role=sender-read, signed into owner, once. Optional: every caller
// treats a missing file here as "not set up yet" and falls back to the
// existing ops@sample.example search, so nothing breaks before this is deployed.
const GMAIL_SENDER_READ_TOKEN_FILE = process.env.GMAIL_SENDER_READ_TOKEN_FILE || path.join(DATA_DIR, 'gmail-token-sender-read.json');
// ── A SECOND MAILBOX TO READ (2026-09-17) ──────────────────────────────────
// the owner: "No no..it should also read ops".
//
// Every comment in helpers/gmail.js and workflow/replyWatch.js says the read
// client is ops@sample.example MEASURED on 2026-09-17: all three tokens on
// her Mac resolve to owner@sample.example. The ops mailbox the addressing
// logic reasons about has not been readable for some time, and nothing said
// so — getMyEmailAddress correctly returned whatever account was actually
// authorised, so the code was consistent and the COMMENTS were the lie.
//
// This is a SECOND read mailbox, not a replacement: she wants both. Optional,
// and absent until someone completes a browser consent signed in as ops
// (scripts/gmail-auth.js --role=read2). Every caller falls back to the single
// mailbox when it is missing, so deploying this file changes nothing on its
// own.
const GMAIL_READ2_TOKEN_FILE = process.env.GMAIL_READ2_TOKEN_FILE || path.join(DATA_DIR, 'gmail-token-read2.json');
const GDRIVE_FOLDER_ID        = process.env.GDRIVE_FOLDER_ID || '';        // Shared Drive root ID (0A...)
const GDRIVE_UPLOAD_FOLDER_ID = process.env.GDRIVE_UPLOAD_FOLDER_ID || ''; // Folder inside the Shared Drive where PDFs land
// Optional dedicated folder for yard scale-ticket photos — falls back to
// GDRIVE_UPLOAD_FOLDER_ID if unset, so the yard feature works with zero new
// Drive setup; set this later if you want ticket photos filed separately from
// booking PDFs. See helpers/drive.js's uploadScaleTicketImage().
const GDRIVE_SCALE_TICKETS_FOLDER_ID = process.env.GDRIVE_SCALE_TICKETS_FOLDER_ID || '';
// Where a claim's supporting documents land — the surveyor report, the
// weighbridge ticket, the photo of the short container. Falls back to
// GDRIVE_UPLOAD_FOLDER_ID so this works with no new Google setup, exactly as
// the scale-ticket folder above does.
const GDRIVE_CLAIMS_FOLDER_ID = process.env.GDRIVE_CLAIMS_FOLDER_ID || '';

// Address book — real need found 2026-08-05: quote-request messages to
// truckers need full pickup/delivery address blocks (yard/company name +
// street + city/state/zip), which the owner currently retypes by hand every
// time from a running Google Doc. That Doc is free-text, not a table — one
// [Name/alias1/alias2] label line followed by a multi-line address block,
// blank-line separated. Reuses the SAME Drive service account already set
// up for booking PDFs (helpers/drive.js's exportDocAsText) — no new OAuth
// scope needed, just share this specific Doc with the service account's
// email (see data/gdrive-sa.json's client_email) as Viewer, same
// prerequisite as helpers/sheets.js's price list. The Doc is the source of
// truth — syncing overwrites Jarvis's stored copy, it never merges/preserves
// a Jarvis-side edit, since nobody edits addresses from inside Jarvis.
const ADDRESS_BOOK_DOC_ID   = process.env.ADDRESS_BOOK_DOC_ID   || '1u-hKBqVvqS1GIpckUXWbT5AQtTGWjWK69rre5IlSHio';
const ADDRESS_BOOK_FILE     = path.join(DATA_DIR, 'address_book.json');

// Multi-trucker quote requests — built 2026-08-05 per the owner: "get quote
// from LA to Richmond" fans a quote ask out to one or more truckers (over
// whichever channel each one actually uses — WhatsApp group, WhatsApp DM,
// or email), tracks each trucker's reply independently, reminds on a fixed
// 30/60/90-minute schedule if no price comes back, and escalates to the
// manager after that. See helpers/quoteRequests.js for the full design.
// Own flat-array store, same pattern as address_book.json — one row per
// quote request, each holding an array of per-trucker "legs".
const QUOTE_REQUESTS_FILE = path.join(DATA_DIR, 'quote_requests.json');
// Contact quote requests — built 2026-08-16 per the owner: a separate tab from
// the trucker lane-quote feature above ("these are just truckers... I want
// another tab where there is quote request and have whatsapp/email support
// for quote"). Same request/leg shape and reminder/escalation machinery as
// QUOTE_REQUESTS_FILE (see helpers/contactQuoteRequests.js's header for why
// it's a SEPARATE store rather than a generalized version of the trucker
// one), but the recipient is resolved against helpers/emailContacts.js
// and/or helpers/addressBook.js instead of workflow/truckers.js — any saved
// person/company, not just truckers. Own flat-array store, same pattern as
// quote_requests.json.
const CONTACT_QUOTE_REQUESTS_FILE = path.join(DATA_DIR, 'contact_quote_requests.json');
// Quote-request contacts (buyers/companies) — 2026-08-16 per the owner: "i
// should have quotes contact where i have separate group/whatsapp/email
// mimicking trucker implementation." Replaces the earlier design (resolving
// recipients by merging helpers/emailContacts.js + helpers/addressBook.js)
// with a dedicated record per contact — name/group_id/whatsapp/email/
// preferred_mode, same shape as a trucker record — so
// helpers/quoteRequests.js's resolveTruckerChannel can be reused unchanged.
// See helpers/contacts.js's own header for the full reasoning.
const CONTACTS_FILE = path.join(DATA_DIR, 'contacts.json');
// General sent-email reply tracking — 2026-08-06, per the owner: "notification
// bell icon in website for reply thread". Separate from QUOTE_REQUESTS_FILE
// on purpose: quote requests already have their own full reply-tracking
// model (per-trucker legs, reminder schedule, price detection) that doesn't
// apply here — this is a much simpler "did anyone reply to this one-off
// email yet" flag for the general draftEmailForConfirm/sendDraftedEmail
// flow, which previously tracked nothing at all after sending. See
// helpers/emailThreads.js.
const EMAIL_THREADS_FILE = path.join(DATA_DIR, 'email_threads.json');
// Fixed reminder schedule (minutes since the request was sent to that
// trucker) — per the owner: "first reminder @30 minutes. next @60 min.
// another. then ask manager to send reminder." Kept as an ordered array so
// scheduler.js can look up "what's the next stage after this one" generically
// instead of hardcoding three separate branches.
const QUOTE_REMINDER_SCHEDULE_MIN = [30, 60, 90];

// Google Sheets (price list) — reuses GDRIVE_KEYFILE's service account, just a
// different API/scope (see helpers/sheets.js). Sheet must be shared with that
// SA's client_email as Viewer — same constraint as the Shared Drive above.
const PRICE_SHEET_ID          = process.env.PRICE_SHEET_ID || '';
const BOOKING_TRACKER_SHEET_ID = process.env.BOOKING_TRACKER_SHEET_ID || '';

// ── Documents (Invoice / Proforma / Verification) — added 2026-08-19 per
// the owner: "i want invoice,proforma,verification in separate tabs under
// documents". Ports the Commercial Invoice + Proforma + carrier/commission
// verification tools that previously only existed in a separate Flask app
// (apgstocks/Sample-internal on PythonAnywhere) into this, the real live
// system. INVOICE_SHEET_ID is the SAME Google Sheet that Flask app read
// from (source of truth for consignee/container/HBL/commission data) —
// hardcoded default matches invoice_gen.py's GOOGLE_SHEET_ID exactly, same
// pattern as ADDRESS_BOOK_DOC_ID's hardcoded default above. Must be shared
// with the service account's client_email as Viewer, same prerequisite as
// PRICE_SHEET_ID/ADDRESS_BOOK_DOC_ID.
const INVOICE_SHEET_ID     = process.env.INVOICE_SHEET_ID     || '1QsCeuqeRKODuouzO2PfKbxG9qJpN8yAbIurSzhI--6s';
const INVOICE_MAIN_GID     = process.env.INVOICE_MAIN_GID     || '571096144';
const INVOICE_PACKING_GID  = process.env.INVOICE_PACKING_GID  || '1340048377';
// The "Weight Shortage 2025" tab on the same workbook. Read-only, and only by
// scripts/claims-import-sheet.js — the live claim register is CLAIMS_FILE, not
// this tab. See claude/jarvis-claims-from-email.md for why the tab cannot be
// written to.
const CLAIMS_SHEET_GID     = process.env.CLAIMS_SHEET_GID     || '522311867';

// Customer pricing memory (Proforma tab) — pricing-only, NOT a full
// address/profile store, since buyer addresses already have a working
// source: ADDRESS_BOOK_DOC_ID/ADDRESS_BOOK_FILE above via
// helpers/addressBook.js. Same flat-JSON-store pattern as
// address_book.json / quote_requests.json.
const PROFORMA_PRICING_FILE = path.join(DATA_DIR, 'proforma_pricing.json');
// The FORM STATE behind each saved proforma PDF, keyed by its filename —
// what "Copy to a new proforma" reads (2026-09-18). Distinct from
// PROFORMA_PRICING_FILE beside it, which remembers PRICES PER CUSTOMER across
// documents; this remembers one specific document. See
// helpers/proformaVersions.js.
const PROFORMA_VERSIONS_FILE = path.join(DATA_DIR, 'proforma_versions.json');
// What each saved PDF actually is, so the proforma tab can stop listing old
// invoices — the owner 2026-09-30: "find a way to keep old invoice in inv tab
// only". Filled on purpose by scripts/documents-folder-audit.js --write-cache;
// see helpers/savedDocKinds.js for why it is a cache and not a live read.
const SAVED_DOC_KINDS_FILE = path.join(DATA_DIR, 'saved_doc_kinds.json');
// Claims against loads the YARD bought — the owner 2026-10-01. Deliberately not
// the export claims register (claims.json), which keys on invoice+container
// and chases overseas buyers; see helpers/yardClaims.js for why they are
// separate stores rather than one with two kinds of key.
const YARD_CLAIMS_FILE = path.join(DATA_DIR, 'yard_claims.json');
// ── THE 07:25 QUICKBOOKS CHECK, KEPT ON DISK (2026-10-02) ─────────────────
// qbAgentJob held its result in module state so the 07:30 ledger agent could
// read it. That works — one pm2 app, one process — right up until a restart,
// and a deploy restarts it. Then "what's stuck in quickbooks" answers "no
// check yet" at 10am, which reads as broken rather than as restarted.
//
// Small, overwritten each morning, and not money: losing it costs one stale
// answer, never a figure.
const QB_AGENT_LAST_FILE = path.join(DATA_DIR, 'qb_agent_last.json');
// Save-a-copy archive for generated Invoice/Proforma PDFs — mirrors the
// datewise/container-wise (invoice) and flat (proforma) folder layout
// the owner originally asked for in the Flask app, kept identical here for
// continuity. Local disk, not Drive — unlike Load PDFs (helpers/drive.js),
// these documents aren't shared with truckers/suppliers over WhatsApp, so
// there's no existing Drive-upload need driving that choice; browsed
// in-dashboard via GET /api/documents/saved instead.
const DOCUMENTS_SAVED_DIR = path.join(DATA_DIR, 'documents_saved');
// Shared secret for the Apps Script → /api/pricelist/webhook call. Required
// because Apps Script's UrlFetchApp can't carry the dashboard's session
// cookie or the API_TOKEN bearer header the same way.
const PRICELIST_WEBHOOK_TOKEN = process.env.PRICELIST_WEBHOOK_TOKEN || '';

// ── Critical-failure alerting — email + SMS, for when WhatsApp or Gemini
// itself is down (so WhatsApp can't be used to notify anyone). Both are
// optional independently; helpers/notify.js skips whichever isn't configured
// rather than erroring, so this can be set up incrementally.
const SMTP_HOST     = process.env.SMTP_HOST || '';
const SMTP_PORT     = parseInt(process.env.SMTP_PORT || '587', 10);
const SMTP_USER     = process.env.SMTP_USER || '';
const SMTP_PASS     = process.env.SMTP_PASS || '';
const ALERT_EMAIL_TO = process.env.ALERT_EMAIL_TO || '';
// ── WHO GETS THE DAILY LEDGER-AGENT NOTE ──────────────────────────────────
// helpers/ledgerAgentJob.js referenced this before it existed, and fell back
// to a cfg.ALERT_EMAIL that does not exist either (the real name is
// ALERT_EMAIL_TO). Both undefined meant the job logged "no recipient
// configured" and sent nothing — for ever, without erroring. Defined here so
// an unset env still reaches her at the address every other alert uses.
const LEDGER_AGENT_EMAILS = process.env.LEDGER_AGENT_EMAILS || ALERT_EMAIL_TO;
// Who gets the 07:25 QuickBooks agent note. Same fallback, same reason.
const QB_AGENT_EMAILS = process.env.QB_AGENT_EMAILS || ALERT_EMAIL_TO;
// Where the three nightly QuickBooks reports are collected between 00:00 and
// 07:25, so she gets one email instead of three. See helpers/qbDigest.js.
// ── UNDER DATA_DIR, LIKE EVERY OTHER STORE ───────────────────────────────
// Declared as bare filenames first, which was wrong in three ways and only
// found because a test's fresh DATA_DIR kept seeing the previous run's rows:
// the file landed in the process working directory (the repo itself on the
// VM, which is how a git tree goes dirty), it was outside the nightly
// backup, and it ignored DATA_DIR entirely so tests could not isolate it.
const QB_DIGEST_FILE = path.join(DATA_DIR, 'qb_digest.json');
// Devices reporting that they could not reach Jarvis. See helpers/clientErrors.js.
const CLIENT_ERRORS_FILE = path.join(DATA_DIR, 'client_errors.json');
// Who hears when the backup breaks. Its own setting because this is the one
// alert that must not be muted with the others — see helpers/backupWatch.js.
const BACKUP_ALERT_EMAILS = process.env.BACKUP_ALERT_EMAILS || ALERT_EMAIL_TO;
const TWILIO_SID        = process.env.TWILIO_SID || '';
const TWILIO_AUTH_TOKEN = process.env.TWILIO_AUTH_TOKEN || '';
const TWILIO_FROM       = process.env.TWILIO_FROM || ''; // your Twilio phone number
const ALERT_SMS_TO      = process.env.ALERT_SMS_TO || ''; // your real cell number, +1XXXXXXXXXX format
// Backup Gemini API key — tried if the primary fails with an auth-type error.
const GEMINI_API_KEY_BACKUP = process.env.GEMINI_API_KEY_BACKUP || '';

// Default fallback groups (used only when a contact has no group and no number)
const GROUP_TRUCKER  = process.env.GROUP_TRUCKER  || '';
const GROUP_SUPPLIER = process.env.GROUP_SUPPLIER || '';
const EMAIL_PROCESSED_FILE = path.join(DATA_DIR, 'email_processed.json');
// Emails already assessed by workflow/replyWatch.js's needs-a-reply scan.
// Separate from EMAIL_PROCESSED_FILE on purpose: that one tracks the
// booking-PDF intake, and the two scans look at completely different mail.
// Sharing one store would make each silently suppress the other's work.
const REPLY_WATCH_FILE = path.join(DATA_DIR, 'reply_watch.json');
const GMAIL_WATCH_ENABLED  = process.env.GMAIL_WATCH_ENABLED !== 'false'; // default ON — matches LLM_MANAGER_ENABLED's pattern in this same file
const GMAIL_POLL_DAYS_BACK = parseInt(process.env.GMAIL_POLL_DAYS_BACK || '3', 10);
// ── Workflow constants ────────────────────────────────────────────────────────
const WORKFLOW_STAGES = [
    'not_started',
    'supplier_assigned',
    'forwarded',
    'empty_dropped',
    'load_ready',
    'picked_up',
    'ingate_received',
    'done',
];

const STEP_LABELS = {
    not_started        : 'Not Started',
    supplier_assigned  : 'Assigned to Supplier',
    forwarded          : 'Forwarded to Trucker',
    empty_dropped      : 'Empty Dropped',
    load_ready         : 'Load Ready',
    picked_up          : 'Picked Up',
    ingate_received    : 'Ingated',
    done               : 'Complete',
};

// Stage index for dashboard progress bar (7-dot rail)
const STAGE_INDEX = {
    not_started        : 0,
    supplier_assigned  : 1,
    forwarded          : 2,
    empty_dropped      : 3,
    load_ready         : 4,
    picked_up          : 5,
    ingate_received    : 6,
    done               : 6,
};

const TERMINAL_STEPS      = ['ingate_received', 'done', 'archived'];
const MAX_REMINDERS       = 3;
const URGENT_CUTOFF_DAYS  = 3;
const PENDING_EXPIRY_MS   = 2 * 60 * 60 * 1000; // pending actions auto-expire after 2h

// ── Dynamic settings ──────────────────────────────────────────────────────────
function getSettings() {
    const defaults = {
        manager_number : process.env.MANAGER_NUMBER || '',
        manager_name   : 'Manager',
        internal_team  : [],
        team_group_id  : process.env.TEAM_GROUP_ID || '',
        bot_mode       : 'handholding',
        // Stall-detection thresholds (hours) — how long a booking can sit in a
        // stage before Jarvis proactively checks in. Adjustable here without a
        // code change. See scheduler.js's stallCheck job.
        stall_thresholds_hours: {
            awaiting_supplier    : 12,
            awaiting_forward     : 6,
            awaiting_empty_pickup: 24,
            awaiting_load_ready  : 48,
            awaiting_pickup      : 24,
            awaiting_scale_ticket: 24,
            awaiting_ingate      : 24,
        },
        // How long to wait after a check-in before escalating to the manager
        // if the supplier/trucker hasn't replied.
        stall_escalation_hours: 24,
        // End-of-day yard report recipients — kept in sync with
        // helpers/json.js's loadSettings() defaults on purpose (see that
        // file's comment): both read the same settings.json, from two
        // different call sites (scheduler.js/actions.js use this one).
        // 2026-10-26: the owner asked to remove ops from Jarvis's daily emails,
        // then narrowed it: "only in sample yard co yard report he can be there". So he
        // STAYS here and was removed from the 07:50 invoice digest instead
        // (helpers/partyInvoiceNightly.js). I had taken him out of this list
        // too, which was wider than she asked for — restored.
        yard_report_emails     : 'ops@sample.example, owner@sample.example',
        yard_whatsapp_group_id : '',
        yard_whatsapp_contacts : '',
    };
    try {
        if (fs.existsSync(FILES.SETTINGS_FILE)) {
            const saved = JSON.parse(fs.readFileSync(FILES.SETTINGS_FILE, 'utf8'));
            return {
                ...defaults, ...saved,
                stall_thresholds_hours: { ...defaults.stall_thresholds_hours, ...(saved.stall_thresholds_hours || {}) },
            };
        }
    } catch {}
    return defaults;
}

const getManagerNumber = () => (getSettings().manager_number || process.env.MANAGER_NUMBER || '').replace(/\D/g, '');
const getTeamGroupId   = () => getSettings().team_group_id || process.env.TEAM_GROUP_ID || '';

// ── Menus ─────────────────────────────────────────────────────────────────────
const MAIN_MENU = [
    'Jarvis — Sample Yard Co Metals Operations',
    '',
    '1. Bookings',
    '2. Forward booking to trucker',
    '3. Assign supplier to booking',
    '4. Check supplier for pickup',
    '5. Show truckers and suppliers',
    '6. Reports',
    '',
    'Type a number or describe what you need.',
].join('\n');

const BOOKINGS_MENU = [
    'Bookings — What would you like?',
    '',
    '1. Urgent cutoffs',
    '2. All active bookings',
    '3. Available bookings (no supplier assigned)',
    "4. This week's bookings",
    '5. Specific booking status',
    '6. Archived bookings',
    '',
    'Or type a booking number directly.',
].join('\n');

module.exports = {
    COMPANY_NAME,
    ROOT, DATA_DIR, MEMORY_DIR, LOGS_DIR, ...FILES,
    GEMINI_API_KEY, GEMINI_MODEL, GEMINI_MODEL_SMART, GEMINI_MODEL_CLAIMS, GEMINI_MODEL_PAY, GEMINI_MODEL_QB, GEMINI_MODEL_CHAT,
    API_PORT, API_TOKEN, APP_PASSWORD, ADMIN_PASSWORD, STAFF_PASSWORD, JARVIS_PASSWORD, SESSION_PATH,
    PLAID_CLIENT_ID, PLAID_SECRET, PLAID_ENV, PLAID_WEBHOOK_URL, PLAID_DAYS_REQUESTED,
    SUPABASE_URL, SUPABASE_KEY,
    GDRIVE_KEYFILE, GDRIVE_FOLDER_ID, GDRIVE_UPLOAD_FOLDER_ID, GDRIVE_SCALE_TICKETS_FOLDER_ID, GDRIVE_CLAIMS_FOLDER_ID,
    ADDRESS_BOOK_DOC_ID, ADDRESS_BOOK_FILE,
    QUOTE_REQUESTS_FILE, CONTACT_QUOTE_REQUESTS_FILE, CONTACTS_FILE, QUOTE_REMINDER_SCHEDULE_MIN, EMAIL_THREADS_FILE,
    GMAIL_CREDENTIALS_FILE, GMAIL_TOKEN_FILE, GMAIL_READ_TOKEN_FILE, GMAIL_WRITE_TOKEN_FILE, GMAIL_SENDER_READ_TOKEN_FILE, GMAIL_READ2_TOKEN_FILE, EMAIL_PROCESSED_FILE, REPLY_WATCH_FILE,
    GMAIL_WATCH_ENABLED, GMAIL_POLL_DAYS_BACK,
    PRICE_SHEET_ID, PRICELIST_WEBHOOK_TOKEN,BOOKING_TRACKER_SHEET_ID,
    INVOICE_SHEET_ID, INVOICE_MAIN_GID, INVOICE_PACKING_GID,
    CLAIMS_SHEET_GID,
    PROFORMA_PRICING_FILE, PROFORMA_VERSIONS_FILE, SAVED_DOC_KINDS_FILE, YARD_CLAIMS_FILE, QB_AGENT_LAST_FILE, DOCUMENTS_SAVED_DIR,
    SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, ALERT_EMAIL_TO, LEDGER_AGENT_EMAILS, QB_AGENT_EMAILS, QB_DIGEST_FILE, CLIENT_ERRORS_FILE, BACKUP_ALERT_EMAILS,
    TWILIO_SID, TWILIO_AUTH_TOKEN, TWILIO_FROM, ALERT_SMS_TO,
    GEMINI_API_KEY_BACKUP,
    GROUP_TRUCKER, GROUP_SUPPLIER,
    WORKFLOW_STAGES, STEP_LABELS, STAGE_INDEX, TERMINAL_STEPS,
    MAX_REMINDERS, URGENT_CUTOFF_DAYS, PENDING_EXPIRY_MS,
    getSettings, getManagerNumber, getTeamGroupId,
    MAIN_MENU, BOOKINGS_MENU,
    // ── LLM manager intent — Phase 1 ─────────────────────────────────────────
    LLM_MANAGER_ENABLED : process.env.LLM_MANAGER_ENABLED !== 'false',  // default ON; set 'false' to kill
    GEMINI_MODEL        : process.env.GEMINI_MODEL        || 'gemini-2.5-flash',
    LLM_TIMEOUT_MS      : parseInt(process.env.LLM_TIMEOUT_MS      || '2000', 10),
    LLM_CONFIDENCE_HIGH : parseFloat(process.env.LLM_CONFIDENCE_HIGH || '0.85'),
    LLM_CONFIDENCE_LOW  : parseFloat(process.env.LLM_CONFIDENCE_LOW  || '0.5'),
};