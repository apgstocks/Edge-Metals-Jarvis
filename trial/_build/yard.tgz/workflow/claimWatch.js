// ── workflow/claimWatch.js — a claim mail becomes a claim record ─────────────
//
// the owner, 2026-09-26: "it should read the mail with weight shortage detail and
// create automatically .. Notify the staff about it in whatsapp and add it in
// to do list."
//
// WHY THIS IS A SIBLING AND NOT PART OF replyWatch
// replyWatch.js is 4805 lines, exports ~70 symbols, and workflow/actions.js
// reaches into it from twenty-odd sites. The reply digest is something she
// depends on daily. A bug in claim parsing must not be able to break it, so
// this lives in its own file and replyWatch calls `consider()` inside a
// try/catch that ignores the result. replyWatch's own behaviour is unchanged:
// nothing here writes to its store, marks a message seen, or continues its loop.
//
// WHY IT PIGGYBACKS ON replyWatch'S LOOP RATHER THAN POLLING
// Five watchers already poll these mailboxes every 5–15 minutes. A sixth would
// re-fetch the same messages and double the model spend. replyWatch has already
// fetched the message, stripped the quoted tail, and resolved the mailbox by
// the time it calls in here.
//
// DRY RUN IS LOAD-BEARING. actions.js:5465 calls replyWatch.run({dryRun:true})
// when she asks "what needs my reply" in WhatsApp. Without honouring it, asking
// that question would create claims and message the team.
const cfg = require('../config');
const { loadJson, mutateJson } = require('../helpers/json');
const claims = require('../helpers/claims');
const tasks = require('../helpers/tasks');
const { gate, extract } = require('../helpers/claimParse');
const claimKind = require('../helpers/claimKind');
const claimEvidence = require('../helpers/claimEvidence');

let _sendToTeam = async () => {};
function init({ sendToTeam } = {}) {
    if (typeof sendToTeam === 'function') _sendToTeam = sendToTeam;
}

// ── PROCESSED MARKER ────────────────────────────────────────────────────────
// Its own file, keyed by Gmail message id. NOT replyWatch's `seen`: trimSeen
// ages that out, so a customer's third chaser weeks later would read as a new
// message and create a second claim. Same reasoning as
// PAYMENT_EMAILS_PROCESSED_FILE, which exists for exactly this.
const PFILE = () => cfg.CLAIM_EMAILS_PROCESSED_FILE;
const KEEP_DAYS = 400;

function processed() { return loadJson(PFILE(), {}) || {}; }
async function markProcessed(messageId, verdict) {
    const cut = Date.now() - KEEP_DAYS * 86400000;
    await mutateJson(PFILE(), {}, (m) => {
        for (const [k, v] of Object.entries(m)) {
            const at = typeof v === 'string' ? Date.parse(v) : Date.parse(v && v.at);
            if (Number.isFinite(at) && at < cut) delete m[k];
        }
        m[messageId] = { at: new Date().toISOString(), verdict };
        return m;
    }, { strict: true });
}

const money = (n) => (n === null || n === undefined ? null : '$' + Number(n).toLocaleString('en-US', { maximumFractionDigits: 2 }));

// ── THE WHATSAPP LINE ───────────────────────────────────────────────────────
// sendToTeam only — index.js:130 falls back to her own number when no team
// group is set, and never reaches a trucker or a supplier. A shortage claim is
// commercially sensitive and the supplier is the party it will be recovered
// from, so it must not land in a group they are in.
//
// The message names the SUPPLIER, because that is the actionable half. The
// claim against Sample is a cost; the recovery is the decision.
function notifyText(c, { isNew, changed }) {
    const L = [];
    L.push(isNew ? 'Weight shortage claim received' : 'Weight shortage claim updated');
    L.push('');
    if (c.claim_type) L.push(`Claiming:  ${require('../helpers/claimKinds').label(c.claim_type)}`);
    else L.push('Claiming:  not classified yet — read the mail before replying');
    L.push(`Customer:  ${c.customer || '—'}`);
    L.push(`Invoice:   ${c.invoice_no || '—'}`);
    L.push(`Container: ${c.container_no || '—'}`);
    const unit = c.weight_unit || '';
    if (c.invoice_weight != null) L.push(`Invoiced:  ${c.invoice_weight}${unit ? ' ' + unit : ' (unit not stated)'}`);
    if (c.claimed_weight != null) L.push(`They say:  ${c.claimed_weight}${unit ? ' ' + unit : ''}`);
    if (c.stated_qty != null) L.push(`Quantity: ${c.stated_qty}${c.stated_qty_unit ? ' ' + c.stated_qty_unit : ''}${c.stated_rate != null ? ' at ' + money(c.stated_rate) + (c.stated_rate_unit ? '/' + c.stated_rate_unit : '') : ''}`);
    if (c.stated_claim_amount != null) L.push(`They ask:  ${money(c.stated_claim_amount)}`);
    L.push(`Recover from: ${c.supplier || 'SUPPLIER NOT NAMED IN THE MAIL'}`);
    L.push('');
    if (changed) L.push('The customer has moved their figure since the last mail — check before agreeing anything.');
    if (!c.weight_unit) L.push('The mail did not state MT, KG or LB, so no claim amount has been worked out. Nothing is a figure until someone confirms the unit.');
    else L.push('Read from the mail, not yet checked. No claim amount is recorded until the weights are confirmed.');
    L.push('');
    L.push('Open /claims to confirm the weights and raise the recovery.');
    return L.join('\n');
}

// ── THE TO-DOS ──────────────────────────────────────────────────────────────
// target_kind is ALWAYS 'manager'. A Jarvis task is not an inert to-do —
// scheduler's taskRunner resolves the target and SENDS the message every
// minute, so 'trucker' or 'supplier' here would tell the counterparty about an
// unverified claim. `bkg_no` carries the container so cancelMatching can find
// these again when the claim moves on.
const CHASE_HOURS = Number(process.env.CLAIM_CHASE_HOURS || 48);

async function raiseVerifyTodo(c) {
    return tasks.enqueue({
        type: 'claim_verify',
        target_kind: 'manager',
        target_name: 'the owner',
        bkg_no: c.container_no || c.invoice_no || '',
        created_by: 'claims',
        claim_id: c.id,
        fire_at: Date.now() + CHASE_HOURS * 3600000,
        message: [
            `Still unverified after ${CHASE_HOURS} hours — weight shortage claim.`,
            '',
            `${c.customer || 'customer'} · ${c.invoice_no || '—'} · ${c.container_no || '—'}`,
            c.stated_claim_amount != null ? `They are asking ${money(c.stated_claim_amount)}.` : '',
            c.supplier ? `Recovery would fall to ${c.supplier}.` : 'No supplier named yet, so there is nobody to recover from.',
            '',
            'Confirm the weight and the unit on /claims — until that is done this claim is not a figure and the recovery cannot be raised.',
        ].filter(Boolean).join('\n'),
    });
}

async function raiseRecoveryTodo(c) {
    return tasks.enqueue({
        type: 'claim_recovery',
        target_kind: 'manager',
        target_name: 'the owner',
        bkg_no: c.container_no || c.invoice_no || '',
        created_by: 'claims',
        claim_id: c.id,
        fire_at: Date.now() + 24 * 3600000,
        message: [
            'Recovery not yet raised on a verified shortage claim.',
            '',
            `${c.customer || 'customer'} · ${c.invoice_no || '—'} · ${c.container_no || '—'}`,
            c.claim_amount != null ? `Claim against Sample: ${money(c.claim_amount)}.` : '',
            `Supplier: ${c.supplier || 'not named'}.`,
            '',
            'Raise it before the next payment to that supplier goes out — a recovery nobody raised is the cost Sample ends up absorbing.',
        ].filter(Boolean).join('\n'),
    });
}

// Called by helpers/claims routes when a claim moves on, so a to-do does not
// keep nagging about work that is done.
async function closeTodos(container_no, type) {
    try { await tasks.cancelMatching({ type, bkg_no: container_no }); }
    catch (e) { console.warn('[CLAIM] could not cancel', type, e.message); }
}

// ── THE HOOK ────────────────────────────────────────────────────────────────
// Returns a small verdict object for tests and logs. It never throws — the
// caller is replyWatch's per-message loop and must not be disturbed.
async function consider({ messageId, threadId, from, subject, body, mailbox, payload, fetchPart, dryRun = false, force = false, attach = null } = {}) {
    try {
        if (!messageId) return { skipped: 'no message id' };
        const g = gate({ subject, body, from });
        // `force` is the manual "read this mail" door (helpers/claims/readMail.js):
        // it steps over the gate and the processed list and NOTHING else — the
        // model still has to call it a claim, and the claim key still dedupes.
        if (!g.hit && !force) return { skipped: 'gate', why: g.why };

        if (!dryRun && !force && processed()[messageId]) return { skipped: 'already processed' };

        const diag = {};
        const got = await extract({ from, subject, body }, force ? { diag, attach } : {});
        if (!got) {
            // A mail she is being ASKED about is not written off: if it needs her
            // to pick an order, marking it processed would hide it from the next try.
            if (!dryRun && !(force && ['no_key', 'missing_one'].includes(diag.reason))) await markProcessed(messageId, 'not a claim');
            return { skipped: 'not a claim after extraction', ...(force ? { why: diag } : {}) };
        }

        const f = got.fields;
        const existing = claims.findByKey(f.invoice_no, f.container_no);
        const mail = { message_id: messageId, thread_id: threadId || '', from: from || '', subject: subject || '', date: new Date().toISOString(), mailbox: mailbox || '' };

        if (dryRun) {
            return { dryRun: true, would: existing ? 'update' : 'create', fields: f, quotes: got.quotes, claim_id: existing ? existing.id : null };
        }

        // ── TWO OR MORE CLAIMS IN ONE MAIL (2026-10-14) ─────────────────────
        // "two rows one for each claim inside one claim report against that
        // container". Each line is its own claim on the SAME container; the
        // supplier report already prints one row per claim. A line is matched
        // to an existing claim by its label, so reading the mail again fills
        // blanks and never makes a third.
        if (got.lines && got.lines.length >= 2) {
            const lk = (l) => require('../helpers/claimKinds').slugify(l);
            const ids = []; let anyNew = false; let first = null;
            for (const line of got.lines) {
                const key = lk(line.label);
                const have = claims.list().find((c) => c && c.key === claims.keyOf(f.invoice_no, f.container_no) && c.line_key === key);
                const lf = {};
                for (const k of ['invoice_weight', 'claimed_weight', 'weight_unit', 'stated_claim_amount', 'stated_qty', 'stated_qty_unit', 'stated_rate', 'stated_rate_unit']) lf[k] = line[k];
                let rec2;
                if (have) {
                    const fill = {};
                    for (const k of Object.keys(lf)) if ((have[k] === null || have[k] === undefined) && lf[k] !== null) fill[k] = lf[k];
                    rec2 = Object.keys(fill).length ? await claims.update(have.id, fill, 'claims', 'filled blanks from a later mail') : have;
                } else {
                    const kind = await claimKind.decide(claimKind.rowText([subject, `${line.label}: ${line.quote}`], ''));
                    rec2 = await claims.create({
                        ...f, ...lf, line_key: key, claim_type: kind.slug,
                        // The header's weights belong to a weight claim only if this line says them.
                        invoice_weight: lf.invoice_weight, claimed_weight: lf.claimed_weight, weight_unit: lf.weight_unit,
                        stated_claim_amount: lf.stated_claim_amount,
                        quotes: { ...got.quotes, line: line.quote, ...(kind.slug ? { claim_type: kind.quote || kind.why } : {}) },
                        mail: [mail],
                        note: [got.reason || '', `one of ${got.lines.length} claims in this mail: ${line.label}`].filter(Boolean).join(' | '),
                        flags: [],
                    }, 'claims/email');
                    await raiseVerifyTodo(rec2);
                    anyNew = true;
                    try { await _sendToTeam(notifyText(rec2, { isNew: true, changed: false })); }
                    catch (e) { console.warn('[CLAIM] team notify failed:', e.message); }
                }
                ids.push(rec2.id); if (!first) first = rec2;
            }
            if (payload && typeof fetchPart === 'function' && first) {
                try { await claimEvidence.fromMail(first.id, { payload, fetchPart, by: 'email' }); } catch (e) { console.warn('[CLAIM] attachments:', e.message); }
            }
            await markProcessed(messageId, `${anyNew ? 'created' : 'updated'} ${ids.join(',')}`);
            return { claim_id: first.id, claim_ids: ids, created: anyNew, changed: !anyNew ? false : true, confidence: got.confidence };
        }

        let rec, changed = false, isNew = false;
        if (existing) {
            const r = await claims.addMail(existing.id, mail, { claimed_weight: f.claimed_weight });
            changed = r.changed;
            // Fill only what was blank. A figure a person has confirmed is
            // never overwritten by a later mail.
            const fill = {};
            for (const k of ['customer', 'supplier', 'invoice_no', 'container_no']) {
                if (!String(existing[k] || '').trim() && f[k]) fill[k] = f[k];
            }
            for (const k of ['invoice_weight', 'claimed_weight', 'weight_unit', 'stated_claim_amount', 'stated_qty', 'stated_qty_unit', 'stated_rate', 'stated_rate_unit']) {
                if ((existing[k] === null || existing[k] === undefined) && f[k] !== null) fill[k] = f[k];
            }
            if (Object.keys(fill).length) {
                fill.quotes = { ...(existing.quotes || {}), ...got.quotes };
                rec = await claims.update(existing.id, fill, 'claims', 'filled blanks from a later mail');
            } else rec = claims.get(existing.id);
        } else {
            isNew = true;
            // What kind of claim, from the mail's own words. Null when the model
            // cannot say — the claim is still created, flagged kind_unknown, and
            // picked up later. Never defaulted to the commonest kind.
            const kind = await claimKind.decide(
                claimKind.rowText([subject, body], ''),
            );
            rec = await claims.create({
                ...f,
                claim_type: kind.slug,
                quotes: { ...got.quotes, ...(kind.slug ? { claim_type: kind.quote || kind.why } : {}) },
                mail: [mail],
                note: [got.reason || '', kind.slug ? '' : `kind not classified: ${kind.unresolved}`].filter(Boolean).join(' | '),
                flags: g.containers.length && !f.container_no ? [claims.FLAG_UNKNOWN_CONTAINER] : [],
            }, 'claims/email');
            await raiseVerifyTodo(rec);
        }

        // ── WHAT THE MAIL BROUGHT WITH IT ──────────────────────────────────
        // the owner, 2026-10-10. The surveyor's report is usually attached to the
        // very mail that raises the claim, and until now it was read for its
        // filename and dropped. This files it.
        //
        // IT HAPPENS HERE, after the claim exists, and nowhere earlier. The
        // mail loop sees every message in the mailbox; downloading attachments
        // before knowing a message is a claim would be most of a Gmail quota
        // spent on newsletters. A claim is the admission ticket.
        //
        // fromMail never throws and the claim is already written, so the worst
        // case is a claim with no document and a line in the log. dryRun never
        // reaches this — it returned above.
        let attached = null;
        if (payload && typeof fetchPart === 'function') {
            attached = await claimEvidence.fromMail(rec.id, { payload, fetchPart, by: 'email' });
            if (attached.filed) console.log(`[CLAIM] filed ${attached.filed} attachment(s) on ${rec.id}: ${attached.names.join(', ')}`);
        }

        await markProcessed(messageId, isNew ? `created ${rec.id}` : `updated ${rec.id}`);
        if (isNew || changed) {
            try { await _sendToTeam(notifyText(rec, { isNew, changed })); }
            catch (e) { console.warn('[CLAIM] team notify failed:', e.message); }
        }
        return { claim_id: rec.id, created: isNew, changed, confidence: got.confidence, attached };
    } catch (e) {
        console.error('[CLAIM] consider failed:', e.message);
        return { error: e.message };
    }
}

module.exports = { init, consider, notifyText, raiseVerifyTodo, raiseRecoveryTodo, closeTodos, processed, markProcessed, CHASE_HOURS };
