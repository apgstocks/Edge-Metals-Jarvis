// ── workflow/brain.js — The pipeline ─────────────────────────────────────────
// inbound → dedupe → context → policy (deterministic) → AI (only if needed)
// → route to actions → transcript.
// Policy resolves everything it can without Gemini: pending yes/no + list
// selections, exact commands, booking numbers, role-scoped media. AI is the
// fallback for ambiguity, never the first resort.
const llmIntent = require('../helpers/llm-intent');
const { appendAuditLog } = require('../helpers/auditlog');
const { loadBrain, saveBrain } = require('../helpers/json');
const { loadSettings, saveTranscript }            = require('../helpers/json');
const { buildContext, formatForAI, updateSession } = require('../helpers/context');
const { resolveBookingNumber, isBareUrl, queryBookingsByLocation, formatBookingLine } = require('../helpers/booking');
// A pasted link is only "the thing we are talking about" for a few minutes.
const LINK_PENDING_TTL_MS = 10 * 60 * 1000;
const { callGeminiJSON }                           = require('../helpers/gemini');
const { getLATime }                                = require('../helpers/time');

// ── Scheduled-send detection ("email X ... at 7am LA time") ─────────────────
// Built 2026-08-04: "Send a mail to Mathew at 7 am LA time whether they have
// reached the pickup location?" needed the SEND itself held until 7am, not
// fired immediately. Deliberately regex-based, not another AI-extracted JSON
// field — same "AI classifies intent, deterministic code does exact
// extraction" split already used throughout this file (resolveBookingNumber,
// the policy regexes above). A regex match against ctx.text is grounded by
// construction (it IS a literal substring of what the manager actually
// typed), so unlike target_name/email_details there's no separate
// hallucination-guard needed here — the match itself IS the proof. Only
// returns the matched phrase; helpers/time.js's parseNaturalTime (already
// deterministic) does the actual date math. Ordered most-specific first so
// e.g. "next monday at 9am" is captured whole rather than the generic
// "at CLOCK" pattern only grabbing "at 9am" out of it.
// "@" is treated as a synonym for "at" before a clock time throughout —
// real incident, 2026-08-04: "Schedule this mail @7am LA time" wasn't
// caught because every pattern only recognized the WORD "at", not the "@"
// shorthand she actually uses (also seen in her own subject lines, e.g.
// "Loading schedule from LA to Humble-8/4 @7am").
const AT = '(?:at\\s+|@\\s*)';
const SCHEDULE_PATTERNS = [
    /\b((?:next|this)\s+(?:sunday|monday|tuesday|wednesday|thursday|friday|saturday)(?:\s*(?:at\s+|@\s*)\d{1,2}(?::\d{2})?\s*(?:am|pm))?)\b/i,
    new RegExp(`\\b(tomorrow\\s*${AT}\\d{1,2}(?::\\d{2})?\\s*(?:am|pm))\\b`, 'i'),
    new RegExp(`\\b(today\\s*${AT}\\d{1,2}(?::\\d{2})?\\s*(?:am|pm))\\b`, 'i'),
    /\b(in\s+\d+\s+(?:minutes?|mins?|hours?|hrs?|days?))\b/i,
    new RegExp(`${AT}(\\d{1,2}(?::\\d{2})?\\s*(?:am|pm)(?:\\s*(?:la|los angeles|pacific)\\s*time)?)\\b`, 'i'),
];
function extractScheduleClause(rawText) {
    const text = String(rawText || '');
    for (const re of SCHEDULE_PATTERNS) {
        const m = text.match(re);
        if (m) return m[1];
    }
    return null;
}

// Parses "get quote from <origin> to <destination> [ask <names>] [email
// <addr[, addr2...]>]" — "ask" and "email" clauses can appear in either
// order, or not at all. Pulling both OUT of the "to ___" tail (rather than
// one combined regex trying to capture destination/names/emails all in one
// pass) is what lets "Richmond email owner@sample.example" correctly split into
// destination "Richmond" + emails ["owner@sample.example"] instead of reading
// the whole trailing phrase as one (nonexistent) address-book destination —
// the real gap found 2026-08-05 when this syntax didn't exist yet at all.
// Returns null if the text isn't a "get quote" command in the first place.
function parseGetQuoteCommand(rawText) {
    // 2026-11-09, the owner: "ask dylan for the quote from junk car to mario". The
    // names lead and the verb is "ask", which none of the verbs below accept, so
    // this phrasing returned null and fell through to the AI classifier. It is
    // rewritten to the shape this parser already handles ("get quote <names>
    // from A to B" -> preNames), so email/ask clauses after the destination keep
    // working and there is still ONE grammar, not two. Only text that STARTS with
    // "ask ... for ... quote ... from" is touched; everything that matched before
    // starts with get/send/request/obtain (or glued debris before one) and is
    // unchanged. (Her decision to add the phrasing; the rewrite approach is mine.)
    const askForm = String(rawText || '').trim().match(/^(?:please\s+)?ask\s+(.+?)\s+for\s+(?:the\s+|a\s+)?quotes?(?:\s+requests?)?\s+(from\s+.+)$/i);
    if (askForm) rawText = `get quote ${askForm[1]} ${askForm[2]}`;
    // REAL GAP (found 2026-08-06, live): "send a quote from LA to Humble
    // email Jose" / "request a quote from LA to Humble email Jose" both
    // missed this entirely — the old regex only accepted the literal verb
    // "get". Neither fell through to a sane fallback either: with no
    // policy match, the AI classifier read "email Jose" as a generic
    // draft_email target and staged an unrelated "what's Jose's address"
    // pending, which then swallowed her well-formed retry too (same
    // pending is reused for reclassification below — see A0d). Broadened
    // to accept get/send/request/obtain as the leading verb.
    //
    // REAL GAP (found 2026-08-16, live — the owner: "Send quote request to
    // owner@sample.example from Junk car to Eccomelt"): two more misses, same
    // failure mode as the 2026-08-06 gap above — no policy match, fell
    // through to the AI/draft_email path, which locked onto the literal
    // email address as the target contact and asked for "a past email"
    // instead of ever reaching this parser or the quote-request flow.
    //   1. "quote request" (noun phrase) never matched — the old regex
    //      required "quote"/"quotes" to be followed IMMEDIATELY by "from".
    //      "quote request to X from Y to Z" has "request to X" sitting
    //      between them, so it just didn't match at all.
    //   2. Even with "quote request" accepted, a stray "to <email>" clause
    //      landing BEFORE "from" (a natural way to say "send it to me from
    //      A to B") still isn't part of the real origin/destination pair
    //      and was never tolerated.
    // Fixed both by (a) accepting an optional "request(s)" noun after
    // "quote(s)", and (b) searching for the first "from ... to ..." lane
    // pattern anywhere after that, rather than requiring it immediately —
    // anything between the quote-noun and "from" (like a misplaced "to
    // <email>") is simply skipped, not treated as part of the lane. This
    // only WIDENS what matches; the origin/destination/email/ask
    // extraction below (already working, unit-tested by the 2026-08-05/06
    // gaps above) is completely unchanged.
    // REAL GAP (found 2026-08-18, live — the owner: "request quote NTG,TQL,Matthew
    // from Junk car to Eccomelt", then "why it is asking again?"): names given
    // BEFORE "from ___ to ___" — a completely natural way to phrase it — were
    // captured by the old `[\s\S]*?` glob between "quote" and "from" and
    // silently thrown away, since only an "ask ___"/"email ___" clause AFTER
    // the destination was ever read into namesText. That left namesText null,
    // so startQuoteRequestFlow had nothing to resolve and fell back to its
    // "Who should I ask?" prompt listing every trucker — even though she'd
    // already named exactly who to ask. Now captured into `preNames` (group 1)
    // instead of discarded; used as namesText below UNLESS a more explicit
    // post-destination "ask"/"email" clause is also present, in which case
    // that (already-working) explicit clause wins, same priority as before.
    // Strip accidental leading garbage glued directly onto the verb, with NO
    // space in between — e.g. "1request quote..." (a stray leading digit,
    // REAL incident 2026-08-18: typing straight into a numbered "who should
    // I ask?" list prompt left a stray leading "1" on her actual retry
    // command) or "XFSend quote request..." (REAL incident 2026-08-20 — a
    // fresh command got typo'd/autocorrected with a stray "XF" glued onto
    // "Send", broke this match entirely, and the whole message fell through
    // to the cargo-details pending's verbatim capture instead of ever being
    // read as the fresh command it was — polluting the cargo description
    // with the failed command text). Used to only strip a leading digit;
    // widened to any short (≤6 char) run of glued characters, found via a
    // non-greedy lookahead that only commits once what follows really is one
    // of this parser's own verbs at a real word boundary — so it can't eat
    // part of an unrelated word, and the strict shape check right after
    // (`base`, below) still has to match in full either way. A GENUINE
    // preceding sentence with a space before the verb ("please send quote
    // from...") is deliberately NOT covered by this — that's a different,
    // wider-blast-radius problem (unanchoring the whole match) not seen live
    // yet; this only fixes glued-with-no-space debris, the pattern actually
    // seen twice now.
    const cleaned = String(rawText || '').trim().replace(/^.{0,6}?(?=(?:get|send|request|obtain)\b)/i, '');
    const base = cleaned.match(/^(?:get|send|request|obtain)\s+(?:a\s+)?quotes?(?:\s+requests?)?\b(.*?)\bfrom\s+(.+?)\s+to\s+(.+)$/i);
    if (!base) return null;
    // Strip a leading "to " connector too — "quote request TO X from Y to Z"
    // (the original 2026-08-16 gap case) reads as "to" + recipient, and "to"
    // itself is never part of a name.
    const preNames = base[1].replace(/^[,\s]+|[,\s]+$/g, '').replace(/^to\s+/i, '');
    const origin = base[2].trim();
    let rest = base[3].trim();

    let emails = null;
    const emailMatch = rest.match(/,?\s*\bemail\b\s+([\w.+-]+@[\w.-]+\.[a-z]{2,}(?:\s*(?:,|&|\band\b)\s*[\w.+-]+@[\w.-]+\.[a-z]{2,})*)/i);
    if (emailMatch) {
        emails = emailMatch[1].split(/,|&|\band\b/i).map((s) => s.trim()).filter(Boolean);
        rest = (rest.slice(0, emailMatch.index) + rest.slice(emailMatch.index + emailMatch[0].length)).trim();
    }

    // "ask Jose" (always meant a saved-trucker name) — and now also
    // "email Jose", the colloquial version of the same thing, once a real
    // email ADDRESS clause (handled above) has already been stripped out.
    // By the time we get here, "email <real@address>" is gone from `rest`,
    // so a leftover bare "email <word(s)>" can only mean a trucker name.
    let namesText = preNames || null;
    const askMatch = rest.match(/,?\s*\b(?:ask|email)\b\s+(.+)$/i);
    if (askMatch) {
        namesText = askMatch[1].trim(); // explicit post-destination clause wins over preNames
        rest = rest.slice(0, askMatch.index).trim();
    }

    const destination = rest.replace(/,\s*$/, '').trim();
    return { origin, destination, namesText, emails };
}

// Parses "[send/request] [a] quote [request] to <recipient> for <details>" —
// built 2026-08-16 per the owner's "another tab" ask (see workflow/contactQuoteRequests.js's
// header). Deliberately a SEPARATE parser/pattern from parseGetQuoteCommand
// above, not a shared one — that one is keyed on "...from X to Y" (a lane);
// this one is keyed on "...to X for Y" (a recipient + what you're asking
// them for), and the two verbs ("from"/"for") never collide: a message
// containing "from" and no "for" only ever matches the trucker-lane parser
// above (checked first), and vice versa. Returns null if the text isn't a
// "quote to X for Y" command at all.
function parseContactQuoteCommand(rawText) {
    // Same glued-prefix strip as parseGetQuoteCommand above (2026-08-20) —
    // this parser's leading verb is optional ("(?:send|request)?"), but
    // "quote" itself is not, so "XFquote to X for Y" would break this match
    // exactly the same way "XFSend quote..." broke the other parser.
    const cleaned = String(rawText || '').trim().replace(/^.{0,6}?(?=(?:send|request)?\s*(?:a\s+)?quote\b)/i, '');
    const m = cleaned.match(/^(?:send|request)?\s*(?:a\s+)?quote(?:\s+request)?\s+to\s+(.+?)\s+for\s+(.+)$/i);
    if (!m) return null;
    return { recipientQuery: m[1].trim(), details: m[2].trim().replace(/[.?!]+$/, '') };
}

// ── Fresh-command carve-out — 2026-08-20, per the owner: "Answer fresh query.
// after finishing that. show that pending queries." Live incident that
// forced this: a cargo-details pending was open, and she sent "Send quote
// request from Junk car to Eccomelt" (a brand new, well-formed command) —
// Jarvis just re-showed the stale cargo question instead of ever
// acknowledging the new one.
//
// Before this, only TWO pending types (await_manual_email_address,
// await_quote_truckers) had their own hand-written carve-out for this exact
// situation. the owner's explicit answer when asked to scope this was "every
// pending, always" — so this is now checked ONCE, at the very top of
// policyDecide, for ANY open pending on a manager/team chat, instead of
// being scattered per pending type.
//
// Deliberately narrow: only the two existing, precise, regex-backed command
// grammars count as "fresh" (parseGetQuoteCommand / parseContactQuoteCommand)
// — NOT the full, much looser Section B command grammar (menu digits,
// "status", "assign", "recall", etc.), which was never designed to be
// checked against arbitrary pending-answer text and risks false-positiving
// against a verbatim capture (e.g. a corrected trucker name, a container
// number, a cargo description). These two parsers require a very specific
// leading shape ("get/send/request/obtain ... quote(s) ... from X to Y" or
// "quote to X for Y") that a real answer to a pending question essentially
// never accidentally matches — same reasoning already proven out in the two
// pre-existing carve-outs this replaces.
//
// What happens next depends entirely on the existing setPending
// never-overwrite rule (see actions.js): if the pending this interrupts is
// itself part of the SAME quote flow (await_manual_email_address,
// await_quote_truckers), the two original carve-outs' clear-then-replace
// behavior in route() still applies unchanged. For every OTHER pending type,
// the old pending is left alone, the fresh command's own flow immediately
// queues behind it (setPending returns queued:true) and its own message
// ("Ready to start on X, but you have a pending Y to answer first...")
// already tells her both things she asked for: that the fresh query was
// heard, and that the old one is still open. See the reminder-tail's
// "_queued" suffix check further down for why that doesn't ALSO trigger a
// redundant second reminder right after.
// ── LIST COMMANDS ALWAYS JUMP A PENDING (2026-09-02) ───────────────────────
// LIVE. A chase-up printed three numbered items, and within twenty seconds:
//   "ignore 1"    -> nothing
//   "ignore 2"    -> "Which one? There are 3 on the list"
//   "ignore 1,2"  -> "Which one? There are 3 on the list"
// The ten-second gap before each reply is the tell: these went to the model,
// not to the regex that has handled "ignore 1,3" since the day it was written.
// detectFreshCommand only ever recognised quote commands, so with ANY pending
// open the pending-specific blocks got first refusal and an explicit list
// reference fell through to the AI — which does not carry `indices`.
//
// "ignore 1" typed under a numbered list Jarvis just printed is not ambiguous
// and never answers an unrelated question. It jumps.
//
// SCOPE: the PREFIXED forms only. A bare "1" still belongs to whatever
// pending asked "which trucker?" — that is a real answer to a real question,
// and stealing it would break the wizards. "ignore 1" never is.
const LIST_COMMAND = new RegExp([
    String.raw`^(?:please\s+)?(?:ignore|dismiss|skip|clear)\s+#?\d{1,2}(?:\s*(?:,|and)\s*#?\d{1,2})*\s*$`,
    String.raw`^(?:please\s+)?(?:ignore|dismiss|skip|clear)\s+(?:all|everything|all of (?:it|them))\s*$`,
    String.raw`^(?:please\s+)?reply\s+(?:to\s+)?#?\d{1,2}`,
    String.raw`^(?:mute|block|unmute|unblock|unignore)\s+\S`,
    String.raw`^what am i ignoring\??$`,
].join('|'), 'i');

// Loose on purpose: a false positive costs a fraction of a cent, a false
// negative costs a payment.
const MONEY_ISH = /\$|\b\d[\d,]*(?:\.\d+)?\s*(?:k\b)?|\b(paid|payed|pay|payment|advance|wire|wired|zelle|cheque|check|cash|owe[sd]?|invoice|bill)\b/i;

function detectFreshCommand(ctx) {
    // ── A NEW PAYMENT IS NEVER AN ANSWER (2026-10-03, live) ─────────────
    // First morning of the WhatsApp payment flow. Mid-way through recording
    // $246 to NUR METAL, Jarvis had asked "how did you send it?" and she
    // typed:
    //
    //     Paid 123 to Inesh
    //
    // That was a NEW payment. It was captured as the answer to the mode
    // question, Jarvis said "Sorry — how did you send it?", and the $123 to
    // Inesh was never recorded and never mentioned again. She had no way to
    // know it had been swallowed.
    //
    // A complete payment sentence — an amount AND a supplier — cannot be the
    // answer to "advance or bill?", "Zelle, Wire or Cash?" or "which
    // account?". Those answers are one or two words. So it is routed as a
    // fresh request here, before any pending block sees it, using the SAME
    // parser the action uses so the two can never disagree about what counts
    // as a payment.
    try {
        const talk = require('../helpers/supplierPayTalk');
        const parsed = talk.parse(ctx.text || '');
        if (parsed && parsed.amount > 0 && parsed.supplier && !/\?\s*$/.test(ctx.text || '')) {
            return { intent: 'pay_supplier', resolvedBy: 'policy', arbitrate: true, data: { parsed } };
        }
    } catch (e) { /* never let a diagnostic break the router */ }

    if (LIST_COMMAND.test(String(ctx.text || '').trim())) {
        // Re-routed through the normal grammar below rather than duplicated
        // here: one definition of what "ignore 1" means, not two that drift.
        return { needsPolicyRerun: true };
    }
    const parsedQuote = parseGetQuoteCommand(ctx.text);
    if (parsedQuote) {
        return {
            intent: 'get_quote', resolvedBy: 'policy',
            data: { origin: parsedQuote.origin, destination: parsedQuote.destination, names_text: parsedQuote.namesText, emails: parsedQuote.emails },
        };
    }
    const parsedContactQuote = parseContactQuoteCommand(ctx.text);
    if (parsedContactQuote) {
        return {
            intent: 'get_contact_quote', resolvedBy: 'policy',
            data: { recipient_query: parsedContactQuote.recipientQuery, details: parsedContactQuote.details },
        };
    }
    return null;
}

const { matchTruckerByChat }                       = require('./truckers');
const { matchSupplierByChat }                      = require('./suppliers');
const { matchContactByChat }                       = require('../helpers/contacts');
const actions = require('./actions');
const cfg     = require('../config');

// ── Dedupe — in-memory ring (single process, restart-safe enough) ─────────────
const seen = new Set();
function isDuplicate(messageId) {
    if (!messageId) return false;
    if (seen.has(messageId)) return true;
    seen.add(messageId);
    if (seen.size > 500) { const first = seen.values().next().value; seen.delete(first); }
    return false;
}

// ── Step 1: normalize + authorize ─────────────────────────────────────────────
async function normalize(raw) {
    const settings = loadSettings();
    const digits   = (v) => String(v || '').replace(/\D/g, '');

    const managerNum = digits(settings.manager_number);
    // internal_team supports two formats for backward compat:
    //   legacy: ['14155551111', '14155552222']
    //   new:    [{name, whatsapp, role}, ...]
    const teamNums   = (settings.internal_team || [])
        .map(x => digits(typeof x === 'string' ? x : (x?.whatsapp || '')))
        .filter(Boolean);
    // Yard/scale staff — separate allowlist from internal_team (settings.yard_staff),
    // deliberately its own role so a photo from one of these numbers routes to the
    // standalone scale-ticket pipeline (workflow/actions.js's yardScaleTicketReceived),
    // never into the manager/team command grammar or the trucker/supplier booking flow.
    const yardNums   = (settings.yard_staff || [])
        .map(x => digits(typeof x === 'string' ? x : (x?.whatsapp || '')))
        .filter(Boolean);
    const senderNum  = digits(raw.senderNumber);

    // Group identity resolves FIRST, unconditionally — a message sent
    // inside a registered trucker/supplier group belongs to that
    // trucker/supplier, regardless of who's personally typing it. The
    // manager is often a member of these groups for visibility; a real
    // incident: the manager typed "load ready" inside APS's supplier group,
    // and the OLD order (isManager checked before group matching) silently
    // attributed it to the manager instead of APS, skipping the whole
    // trucker-notification flow entirely. Only when the chat ISN'T a
    // registered group does personal-number-based manager/team detection apply.
    const trucker  = await matchTruckerByChat(raw.chatId, raw.senderNumber);
    const supplier = !trucker ? await matchSupplierByChat(raw.chatId, raw.senderNumber) : null;
    // Contacts (buyers/vendors used for quote requests — e.g. Eccomelt) —
    // 2026-08-17 fix: this store was never checked here at all, so a message
    // from a Contacts-only vendor's group/number failed isAuthorized below
    // and was dropped before ever reaching the quote-reply detection in
    // policyDecide. See helpers/contacts.js's matchContactByChat header for
    // the full incident. Checked last of the three roster matches — a name
    // that happens to exist as BOTH a trucker/supplier AND a contact still
    // resolves to the trucker/supplier identity unchanged.
    const contact  = (!trucker && !supplier) ? matchContactByChat(raw.chatId, raw.senderNumber) : null;
    const isRegisteredGroupChat = (trucker && trucker.group_id === raw.chatId) || (supplier && supplier.group_id === raw.chatId) || (contact && contact.group_id === raw.chatId);

    // TEMPORARY DIAGNOSTIC (2026-08-18/20) — remove once the NTG/TQL group_id
    // mismatch mystery is resolved. the owner confirmed the group_id shown on
    // the dashboard for NTG/TQL visually matches this chat's ID exactly, yet
    // matchTruckerByChat keeps returning null for it (role resolves to
    // 'manager', not 'trucker') — meaning either the actual stored value
    // isn't byte-identical to what's displayed (invisible whitespace/
    // encoding), or a different record than expected is being checked. This
    // logs the raw incoming chatId plus every trucker's own group_id so the
    // next live reproduction shows the real values Node is comparing,
    // instead of guessing further from a UI screenshot.
    if (!trucker && !supplier && !contact) {
        try {
            const { loadTruckers, loadSuppliers } = require('../helpers/json');
            const allT = await loadTruckers();
            const allS = await loadSuppliers();
            console.log(`[DIAG] unmatched chatId=${JSON.stringify(raw.chatId)} (len ${String(raw.chatId).length})`);
            console.log('[DIAG] trucker group_ids:', allT.map(t => `${t.name}=${JSON.stringify(t.group_id)}`).join(' | '));
            console.log('[DIAG] supplier group_ids:', allS.map(s => `${s.name}=${JSON.stringify(s.group_id)}`).join(' | '));
        } catch (e) { console.log('[DIAG] failed:', e.message); }
    }

    // 2026-08-18, per the owner ("it should talk only relevant to TQL not
    // answering generically, only in internal group and manager chat
    // personal it can answer all generic queries") — distinct from
    // isRegisteredGroupChat above, which is only true when THIS message's
    // sender matched that trucker/supplier/contact. This flag answers a
    // different question: is this chat an EXTERNAL party's channel at all
    // (trucker/supplier/contact's own group, or the shared default
    // GROUP_TRUCKER/GROUP_SUPPLIER fallback groups), regardless of who's
    // currently typing — used below to keep Jarvis's generic "answer any
    // question" AI fallback scoped to the internal team group / manager's
    // own personal chat, not external groups where a manager's casual
    // message to a trucker shouldn't get an unrelated bot reply injected
    // into the conversation. NOTE: this only catches chats actually
    // registered somewhere (a trucker/supplier/contact's group_id, or the
    // configured default group) — an ad-hoc WhatsApp group never linked to
    // any record in the system is invisible to this check by definition;
    // there's no data anywhere saying "this group belongs to TQL" for
    // Jarvis to find.
    const isExternalPartyGroup = !!(trucker?.group_id === raw.chatId || supplier?.group_id === raw.chatId || contact?.group_id === raw.chatId
        || (cfg.GROUP_TRUCKER && raw.chatId === cfg.GROUP_TRUCKER) || (cfg.GROUP_SUPPLIER && raw.chatId === cfg.GROUP_SUPPLIER));

    const isManager = !isRegisteredGroupChat && !!managerNum && senderNum === managerNum;
    const isTeam    = !isRegisteredGroupChat && (teamNums.includes(senderNum) ||
                      (!!settings.team_group_id && raw.chatId === settings.team_group_id));
    const isYard    = !isRegisteredGroupChat && yardNums.includes(senderNum);

    // Group identity wins for group chats; for personal DMs, manager/team/yard
    // identity still wins over a coincidental personal-number match.
    const finalTrucker  = isRegisteredGroupChat ? trucker  : (!isManager && !isTeam && !isYard ? trucker  : null);
    const finalSupplier = isRegisteredGroupChat ? supplier : (!isManager && !isTeam && !isYard ? supplier : null);
    const finalContact  = isRegisteredGroupChat ? contact  : (!isManager && !isTeam && !isYard ? contact  : null);

    const role = isManager ? 'manager' : isTeam ? 'team' : isYard ? 'yard' : finalTrucker ? 'trucker' : finalSupplier ? 'supplier' : finalContact ? 'contact' : 'unknown';

    return {
        ...raw,
        textLower      : String(raw.text || '').toLowerCase().trim(),
        role,
        matchedTrucker : finalTrucker,
        matchedSupplier: finalSupplier,
        matchedContact : finalContact,
        isManagerOrTeam: isManager || isTeam,
        isExternalPartyGroup,
        isTrucker      : !!finalTrucker,
        isSupplier     : !!finalSupplier,
        isContact      : !!finalContact,
        isYard         : isYard,
        isAuthorized   : role !== 'unknown',
    };
}

// ── Step 2: deterministic policy ──────────────────────────────────────────────
const YES = ['yes', 'y', 'confirm', 'proceed', 'go ahead', 'do it', 'ok', 'okay', 'sure'];
const NO  = ['no', 'n', 'cancel', 'stop', 'nope', "don't"];

// ── CHOOSING ONE OF A FEW, OUT LOUD ──────────────────────────────────────
// the owner, 2026-09-09: "when i say one -its not detected... When i say trucker
// name as Jey, it is transcribing as J or Jai or JJ. as a ai,is it that
// difficult to map like chatgpt or claude does?"
//
// What used to be here was three lines: digits, then a substring test. It
// could not read "one", "first" or "number 2", and it could not get from
// "Jai" to "Jey Transport" — not because that is hard, but because nothing
// ever compared her words to the two-to-eight options on her screen.
//
// It was also unsafe in a way she had not hit yet: `find(o => o.includes(t))`
// returns the FIRST option containing her text, so with two J-named hauliers
// on screen, "J" silently picked one. There is a truck at the end of this.
//
// Moved to helpers/pickFromList.js, which matches by position, by name, by
// sound and by edit distance — and returns nothing at all when more than one
// option survives, so ambiguity becomes a question instead of a guess.
// ── IS THIS ACTUALLY A PLACE? ───────────────────────────────────────────────
// Returns a sentence to say INSTEAD of a count, or null when the place is
// fine. "0 bookings from null" and "0 bookings from shutup" are both a count
// of the wrong question stated as a fact, and a zero reads as "we have none".
//
// A place counts when it is empty-free AND some booking's port matches it —
// loading OR discharge, through the same localityMatchesPort the count uses,
// so aliases like "LA" keep working. A real port with nothing in it right now
// is still a place, and still gets its honest zero from the handler.
function placeProblem(location) {
    const loc = String(location == null ? '' : location).trim();
    if (!loc || /^(?:null|undefined|none|n\/a|any|all)$/i.test(loc)) {
        return 'Which port? I count bookings by port — e.g. "how many bookings from Houston". '
            + 'I can\'t count them by loading date yet.';
    }
    try {
        const bk = require('../helpers/booking');
        const known = Object.values(require('../helpers/json').loadBookings() || {}).some((b) =>
            bk.localityMatchesPort(b.port_of_loading, loc) || bk.localityMatchesPort(b.port_of_discharge, loc));
        if (!known) return `I don't have any bookings with a port called "${loc}". Which port did you mean?`;
    } catch (e) {
        // Can't check — fall through to today's behaviour rather than block.
        console.warn('[BRAIN] place check failed:', e.message);
    }
    return null;
}

function resolveListSelection(text, options) {
    return require('../helpers/pickFromList').pick(text, options);
}

// ── Typo tolerance — deterministic, not LLM-dependent ────────────────────────
// Relying on Gemini to "read through" typos proved unreliable in practice
// (tested twice with explicit prompt instructions, still missed "bookking").
// This fixes it in code instead: single-word edit-distance correction against
// the small set of command keywords the grammar below actually looks for.
// Only touches the LOCAL text used for policy matching — ctx.text/textLower
// stay untouched, so the AI still sees the person's original wording verbatim
// if it ever needs to fall back that far.
const COMMAND_KEYWORDS = [
    'booking', 'bookings', 'available', 'unassigned', 'assigned', 'supplier', 'suppliers',
    'trucker', 'truckers', 'forward', 'assign', 'archive', 'recall', 'status', 'cutoff',
    'menu', 'urgent', 'contacts', 'remember', 'context',
];
// Abbreviations aren't typos — "avl" isn't letter-close to "available", it's a
// different word entirely that happens to mean the same thing. Edit-distance
// can never catch these; they need a direct dictionary lookup instead, tried
// FIRST (exact match on the whole token) before the fuzzy edit-distance pass.
const ABBREVIATIONS = {
    avl: 'available', avail: 'available',
    bkg: 'booking', bkgs: 'bookings', bk: 'booking', bks: 'bookings',
    sup: 'supplier', sups: 'suppliers', splr: 'supplier',
    trk: 'trucker', trks: 'truckers', trkr: 'trucker',
    unassgn: 'unassigned', unassn: 'unassigned',
    asgn: 'assign', asn: 'assign',
    fwd: 'forward',
    mgr: 'manager',
    cntx: 'context', ctx: 'context',
};
// fastest-levenshtein (MIT) — same edit-distance metric, a faster
// implementation. Added 2026-08-22 with the owner's approval.
//
// Loaded defensively and with the original implementation kept intact
// below as the fallback, for the same reason as chrono and zod: if
// `npm install` has not been run on the VM, typo correction must keep
// working rather than take Jarvis down on startup.
//
// Correctness note — this is a drop-in ONLY because both compute the
// identical, standard Levenshtein distance (unit cost for insert, delete
// and substitute). The result feeds fuzzyCorrectKeywords' maxAllowed
// thresholds, so a library computing a DIFFERENT metric (Damerau, or a
// normalized 0..1 similarity like Fuse.js) would silently change which
// typos get corrected. Verified equal against the original on every
// keyword pair before switching.
let fastLevenshtein = null;
try {
    fastLevenshtein = require('fastest-levenshtein').distance;
} catch (e) {
    console.warn('[BRAIN] fastest-levenshtein not installed — using built-in implementation. Run `npm install` to enable it.');
}

function levenshteinFallback(a, b) {
    const m = a.length, n = b.length;
    const dp = Array.from({ length: m + 1 }, () => new Array(n + 1).fill(0));
    for (let i = 0; i <= m; i++) dp[i][0] = i;
    for (let j = 0; j <= n; j++) dp[0][j] = j;
    for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++)
        dp[i][j] = a[i - 1] === b[j - 1] ? dp[i - 1][j - 1] : 1 + Math.min(dp[i - 1][j - 1], dp[i - 1][j], dp[i][j - 1]);
    return dp[m][n];
}

function levenshtein(a, b) {
    return fastLevenshtein ? fastLevenshtein(a, b) : levenshteinFallback(a, b);
}
function fuzzyCorrectKeywords(text) {
    return text.split(/(\s+)/).map(tok => {
        if (!/^[a-z]+$/i.test(tok)) return tok; // skip whitespace, punctuation, booking numbers
        const lower = tok.toLowerCase();
        if (COMMAND_KEYWORDS.includes(lower)) return tok; // already correct
        if (ABBREVIATIONS[lower]) return ABBREVIATIONS[lower]; // exact abbreviation match, no distance check needed
        if (lower.length < 4) return tok; // too short for safe fuzzy matching (avoids "to"/"at" false positives)
        let best = null, bestDist = Infinity;
        for (const kw of COMMAND_KEYWORDS) {
            const d = levenshtein(lower, kw);
            if (d < bestDist) { bestDist = d; best = kw; }
        }
        const maxAllowed = lower.length >= 7 ? 2 : 1; // longer words tolerate more edits
        return (best && bestDist <= maxAllowed) ? best : tok;
    }).join('');
}

function policyDecide(ctx) {
    const t = fuzzyCorrectKeywords(ctx.textLower);

    // ── A(-2). UNIVERSAL CANCEL ESCAPE HATCH — REAL BUG (found 2026-08-20,
    // live — the owner typed "cancel all the quote requests" while a
    // cargo-details pending was open and got the cargo question AGAIN).
    //
    // Root cause: the verbatim-capture pendings (cargo details, scale
    // tickets, container number, manual email address, domain-learn name,
    // trucker retry) each pass ANY text straight through as "the answer",
    // with no cancel check anywhere. There was literally NO WAY OUT of
    // those pendings except answering them — worse, several of their own
    // reminder messages explicitly promise 'or reply "cancel"'
    // (pendingFullReminder's await_manual_email_address /
    // await_domain_learn_name / await_quote_trucker_retry / the two quote
    // pickers all say it), a promise the code never actually kept. A
    // trapped pending also blocks every later flow behind it, since
    // setPending queues rather than overwrites.
    //
    // Routed to the SAME generic path a "no" answer already takes
    // (resolve_pending / answer:'no'), which clears the pending and replies
    // "Cancelled." — see actions.js's resolvePending. Nothing new invented.
    //
    // Anchored to the START of the message so it can only ever fire on a
    // message that OPENS with a cancel word — a cargo description or relay
    // reply that merely contains "cancel" somewhere mid-sentence is
    // untouched. Deliberately does NOT include "scrap that": "scrap" is
    // this business's actual cargo (scrap metal), far too dangerous a word
    // to treat as a control keyword.
    //
    // await_relay_reply is EXCLUDED on purpose: that pending captures a
    // reply to be relayed verbatim to whoever asked the question, so
    // "cancel the pickup" is plausibly real message CONTENT there, not a
    // control command. Cancelling that flow via this hatch would silently
    // swallow a message someone is waiting on. Every other pending type's
    // expected answer (a weight, a container number, an email address, a
    // name, a yes/no) is never legitimately a sentence starting with
    // "cancel"/"never mind"/"forget it".
    if (ctx.isManagerOrTeam && ctx.pendingAction && ctx.pendingAction.type !== 'await_relay_reply') {
        if (/^\s*(cancel|nevermind|never mind|forget it|forget that|abort|drop it)\b/i.test(ctx.text)) {
            return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'no', cancelText: ctx.text.trim() } };
        }
    }

    // ── Self-build commands ("build: ...", "yes build <id>", ...). Manager only, exact grammar,
    // decided here so the AI classifier can never choose a code change. See helpers/selfBuild.js.
    if (ctx.role === 'manager') {
        const sbCmd = require('../helpers/selfBuildCommands').parse(ctx.text);
        if (sbCmd) return { intent: 'self_build', resolvedBy: 'policy', data: sbCmd };
    }

    // ── Automatic deposits: "undo <CODE>" / "resume auto deposits for <name>". Manager only, exact grammar, never the
    // AI classifier. An "undo" acts only when its code belongs to a real automatic deposit, so no other "undo ..." changes
    // meaning. See helpers/depositAutoApply.js.
    if (ctx.role === 'manager') {
        const dc = require('../helpers/depositCommands').parse(ctx.text);
        const dl = dc && dc.kind !== 'resume' ? require('../helpers/depositAutoApply').list() : null;
        const known = dc && (dc.kind === 'resume'
            || (dc.kind === 'undo' && dl.entries.some((e) => String(e.code).toUpperCase() === dc.code))
            || ((dc.kind === 'confirm' || dc.kind === 'decline') && dl.asks.some((q) => String(q.code).toUpperCase() === dc.code && !q.answer)));
        if (known) {
            return { intent: 'deposit_auto', resolvedBy: 'policy', data: dc };
        }
    }

    // ── Price questions: "normal <CODE>" / "check <CODE>". Manager only, exact grammar, never the AI classifier, and only for a code that
    // belongs to a real unanswered price question. See helpers/priceWatch.js.
    if (ctx.role === 'manager') {
        const pc = require('../helpers/priceCommands').parse(ctx.text);
        if (pc && require('../helpers/priceWatch').list().asks.some((q) => String(q.code).toUpperCase() === pc.code && !q.answer)) {
            return { intent: 'price_answer', resolvedBy: 'policy', data: pc };
        }
    }

    // ── "case <customer>": the read-only case file over WhatsApp. MANAGER only (it shows what a customer owes), exact shape, and ONLY a
    // customer we know by name, so the word "case" in any other sentence is untouched. See helpers/customerFocus.js.
    if (ctx.role === 'manager') {
        const cc = require('../helpers/customerFocus').parseCaseCommand(ctx.text);
        if (cc && require('../helpers/customerFocus').match(cc.name)) {
            return { intent: 'case_file', resolvedBy: 'policy', data: { name: cc.name } };
        }
    }

    // ── A(-1). Fresh well-formed command jumps ANY open pending — see
    // detectFreshCommand's own comment above for the full reasoning. Checked
    // before every pending-type-specific block below (A0 onward), so it
    // applies uniformly regardless of which pending is active. Only fires
    // for the manager/team — a supplier's ready-check yes/no or a trucker's
    // own reply never goes through this path. ─────────────────────────────
    if (ctx.isManagerOrTeam && ctx.pendingAction) {
        const fresh = detectFreshCommand(ctx);
        // A fully-formed intent returns as before.
        if (fresh && !fresh.needsPolicyRerun) return fresh;
        // needsPolicyRerun means "this is a list command". Hide the pending
        // from the rest of this function so every `ctx.pendingAction?.type`
        // block below falls through and the grammar that actually owns
        // "ignore 1" gets it. A local copy, not a mutation — the caller's ctx
        // and the pending itself are untouched, so an unanswered question is
        // still unanswered afterwards and still gets its nudge.
        if (fresh && fresh.needsPolicyRerun) ctx = { ...ctx, pendingAction: null };
    }

    // ── A0. Ready-check pending — applies to whoever the question was sent to
    // (the supplier), not just manager/team. Runs before everything else so a
    // supplier's yes/no/date reply is never mis-routed to the keyword grammar
    // in section D. ──────────────────────────────────────────────────────────
    // "undo last payment" / "delete that payment" — the owner: "Also jarvis
    // profile should have the access to delete/undo the Bill pay as well."
    // Deliberately narrow: it must say payment, and it must say undo. The
    // action names what it is about to remove and waits for a yes.
    if (!ctx.pendingAction && ctx.isManagerOrTeam
        && /\b(undo|delete|remove|reverse|cancel)\b/i.test(ctx.text || '')
        && /\b(payment|pay|bill\s*pay|advance)\b/i.test(ctx.text || '')) {
        return { intent: 'undo_bill_payment', resolvedBy: 'policy', arbitrate: true, data: {} };
    }

    // ── "I paid 10000 advance to Inesh" / "paid 5000 to Mazariegos" ─────
    // Policy, not the model: the amount and the name are the whole message,
    // a regex reads them reliably, and a model that mis-hears either one
    // files money against the wrong supplier. helpers/supplierPayTalk.js
    // does the actual reading; this only decides that the sentence is about
    // paying a supplier.
    //
    // NOT matched when it is a question ("how much did I pay Inesh?") — that
    // is a report, and answering it by recording a payment would be the
    // worst possible misread.
    if (!ctx.pendingAction && ctx.isManagerOrTeam && !/\?\s*$/.test(ctx.text || '')) {
        const talk = require('../helpers/supplierPayTalk');
        const parsed = talk.parse(ctx.text || '');
        if (parsed && parsed.amount > 0 && parsed.supplier) {
            return { intent: 'pay_supplier', resolvedBy: 'policy', arbitrate: true, data: { parsed } };
        }
    }

    if (ctx.pendingAction?.type === 'await_ready_check') {
        const p = ctx.pendingAction;
        if (p.stage === 'yesno') {
            if (/(yes|ready|loaded|done|good to go)/.test(t) && !/not\s+ready/.test(t))
                return { intent: 'ready_check_yes', resolvedBy: 'policy', data: {} };
            if (/(no|not\s+ready|not\s+yet|delay)/.test(t))
                return { intent: 'ready_check_no', resolvedBy: 'policy', data: {} };
            return { intent: 'reply', resolvedBy: 'policy', data: { reply: 'Sorry, is the container ready for pickup? Reply yes or no.' } };
        }
        if (p.stage === 'date') {
            return { intent: 'ready_check_date', resolvedBy: 'policy', data: { date_text: ctx.text.trim() } };
        }
    }

    // ── A0b. Container-number pending — no fixed format exists for these
    // (confirmed — not ISO-standard, don't pattern-match), so the ONLY
    // reliable way to capture it is: whatever they reply to THIS specific
    // question, verbatim, is the answer. Same priority as A0 so it can't be
    // mis-routed to keyword grammar either.
    if (ctx.pendingAction?.type === 'await_container_number') {
        return { intent: 'container_number_received', resolvedBy: 'policy', arbitrate: true, data: { container_number: ctx.text.trim() } };
    }

    // ── A0b2. "Generate invoice for the Inesh container" — the answer to
    // whichever question that flow asked (a pick, a missing field, the
    // invoice number, yes/no, the layout). Same shape as the container-number
    // capture: the pending is the validation. Free-text stages (customer,
    // item) carry arbitrate so a genuinely new request still escapes.
    // A bug's status only changes on an explicit yes — see actions.closeBugForConfirm.
    if (ctx.pendingAction?.type === 'await_bug_close') {
        if (/^\s*(yes|yeah|yep|yup|ok|okay|sure|do it|correct|right)\b/i.test(t)) {
            return { intent: 'bug_close_yes', resolvedBy: 'policy', data: {} };
        }
        if (/^\s*(no|nope|not yet|don'?t|wait)\b/i.test(t)) {
            return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'no' } };
        }
    }

    // ── A0b3. "I paid 10000 advance to Inesh" — the answers ─────────────
    // the owner, 2026-10-02: "If user messages (only allowed users) jarvis and
    // they say,I paid 10000 advance to Inesh.It should able to undertsand
    // that... Just ask the user directly whether it is a advance or paid
    // against bill?"
    //
    // Captured verbatim and resolved by the action, like the container-number
    // and sale-invoice captures above: there is no fixed format to match, and
    // the pending IS the validation. Reclassifying "1,3" or "advance" from
    // scratch is how an answer to a question Jarvis asked ends up being read
    // as a brand-new request.
    if (ctx.pendingAction?.type === 'await_pay_reading') {
        return { intent: 'pay_supplier_answer', resolvedBy: 'policy', data: { answer_text: ctx.text.trim() } };
    }
    if (ctx.pendingAction?.type === 'await_pay_kind') {
        return { intent: 'pay_supplier_answer', resolvedBy: 'policy', data: { answer_text: ctx.text.trim() } };
    }
    if (ctx.pendingAction?.type === 'await_pay_containers') {
        return { intent: 'pay_supplier_answer', resolvedBy: 'policy', data: { answer_text: ctx.text.trim() } };
    }
    if (ctx.pendingAction?.type === 'await_pay_supplier') {
        return { intent: 'pay_supplier_answer', resolvedBy: 'policy', data: { answer_text: ctx.text.trim() } };
    }
    // ── THE TWO THAT MOVE MONEY NEED AN EXPLICIT YES ────────────────────
    // Not "anything that is not no". A payment recorded because a passing
    // message happened to arrive while a confirmation was open is a payment
    // nobody meant to make, and the undo one reopens containers.
    // ── THE MODE AND BANK ANSWERS ARE CAPTURED VERBATIM ─────────────────
    // "Zelle" / "BofA" are the confirmation, not a yes. Routed like the other
    // capture pendings and validated by the action, which writes nothing
    // until it has a mode AND (for Zelle/Wire) a bank it recognises. A strict
    // yes/no gate here answered "Zelle" with "reply yes or no", which is the
    // flow talking past her.
    if (ctx.pendingAction?.type === 'await_pay_confirm'
        || ctx.pendingAction?.type === 'await_pay_bank') {
        if (/^\s*(no|nope|cancel|stop|don'?t|wait)\b/i.test(t)) {
            return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'no' } };
        }
        return { intent: 'pay_supplier_answer', resolvedBy: 'policy', data: { answer_text: ctx.text.trim() } };
    }
    // Undo stays a strict yes/no: it is the one that destroys a record.
    if (ctx.pendingAction?.type === 'await_undo_pay_confirm') {
        if (/^\s*(yes|yeah|yep|yup|ok|okay|sure|do it|go ahead|confirm|correct|right)\b/i.test(t)) {
            return { intent: 'pay_supplier_answer', resolvedBy: 'policy', data: { answer_text: 'yes' } };
        }
        if (/^\s*(no|nope|not yet|don'?t|wait|cancel|stop)\b/i.test(t)) {
            return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'no' } };
        }
        // Anything else re-asks rather than guessing either way.
        return { intent: 'reply', resolvedBy: 'policy', data: { reply:
            'Sorry — reply *yes* to record it, or *no* to leave it. Nothing is recorded either way yet.' } };
    }

    if (ctx.pendingAction?.type === 'await_sale_invoice') {
        return { intent: 'sale_invoice_answer', resolvedBy: 'policy', arbitrate: !!ctx.pendingAction.arbitrate, data: { answer_text: ctx.text.trim() } };
    }

    // ── A0c. Relay-question reply — whatever the target says in response to
    // "ask_contact" is captured verbatim and relayed back to whoever asked.
    // Same reasoning as the container-number capture: no fixed format to
    // match against, the pending itself is the validation.
    if (ctx.pendingAction?.type === 'await_relay_reply') {
        return { intent: 'relay_reply_received', resolvedBy: 'policy', data: { reply_text: ctx.text.trim() } };
    }

    // ── A0d. Manual email-address pending — same "capture verbatim, no
    // reclassification" reasoning as A0b/A0c above. Built 2026-08-03 after a
    // real live bug: draftEmailForConfirm/draftReplyForConfirm used to ask
    // "give me the exact email address" and then just return, discarding
    // the original request. The manager's next message (the address) went
    // through NORMAL classification and usually landed on a generic AI
    // clarifying question, silently dropping what she'd already typed. This
    // pending captures the whole original request (target/details/booking)
    // so ANY next message is treated as "the address I asked for", not
    // reclassified from scratch.
    if (ctx.pendingAction?.type === 'await_manual_email_address') {
        // REAL BUG (found 2026-08-05, live): a typo'd "get quote" ("ote from
        // LA to Richmond email X" — autocorrect/typing glitch ate the "get
        // qu") didn't match the get_quote pattern at all, fell through to
        // the OLD draft_email/ask_contact classifier, and staged THIS
        // pending. Every message after that — including a perfectly-typed
        // "get quote from LA to Richmond email owner@sample.example" on the
        // NEXT try — got swallowed as "the address I asked for". This used
        // to have its own inline parseGetQuoteCommand carve-out right here;
        // as of 2026-08-20 that check now happens ONCE, generically, at the
        // very top of policyDecide (see "A(-1)" / detectFreshCommand) for
        // every pending type, so a fresh get_quote command never reaches
        // this line at all — it's caught before this. route() still clears
        // this stale pending specifically when that happens (search for
        // "await_manual_email_address" there) — that part is unchanged.
        return { intent: 'manual_email_address_received', resolvedBy: 'policy', arbitrate: true, data: { address_text: ctx.text.trim() } };
    }

    // ── A0e. Domain-learn name pending — "learn sample contacts" found a
    // shared/docs-style address whose local-part is identical to the domain
    // term itself (e.g. sample@sample.example), so it couldn't infer a
    // name. Same verbatim-capture reasoning as A0b/A0c/A0d: whatever she
    // replies IS the name (or names, comma-separated), not something to
    // reclassify. See workflow/actions.js's resolveDomainLearnName.
    if (ctx.pendingAction?.type === 'await_domain_learn_name') {
        return { intent: 'domain_learn_name_received', resolvedBy: 'policy', arbitrate: true, data: { name_text: ctx.text.trim() } };
    }

    // ── A0f0. Cargo description/value prompt (2026-08-06, per the owner: "I
    // want jarvis to ask about cargo description, cargo value") — asked
    // right before a quote request actually sends, once recipients are
    // already locked in. Same verbatim-capture reasoning as A0b/A0c/A0d/A0e
    // above: no fixed format for "cargo description and value" to validate
    // against, so whatever she replies IS the answer — "skip"/"none"/"n/a"
    // (any casing) is the one recognized escape hatch, handled inside
    // actions.js's resumeQuoteWithCargoDetails rather than here, so this
    // stays a plain pass-through like the others.
    if (ctx.pendingAction?.type === 'await_quote_cargo_details') {
        return { intent: 'quote_cargo_details_received', resolvedBy: 'policy', arbitrate: true, data: { cargo_text: ctx.text.trim() } };
    }

    // ── A0f-0b. Scale-tickets prompt (2026-08-20, per the owner: "ask do you
    // need scale tickets before hand" / "why didn't it ask... at the start
    // of convo") — now asked as its OWN question at the very start of the
    // quote-request flow, before recipients or cargo details, instead of
    // being folded into the cargo-details sentence (where it went
    // unenforced and got silently skipped — a real bug). Same verbatim
    // pass-through pattern as the cargo prompt above; actions.js's
    // resumeQuoteWithScaleTickets does the yes/no interpretation.
    if (ctx.pendingAction?.type === 'await_quote_scale_tickets') {
        return { intent: 'quote_scale_tickets_received', resolvedBy: 'policy', arbitrate: true, data: { scale_text: ctx.text.trim() } };
    }

    // ── A0f-1. Reply to "couldn't find a trucker named X — correct name or
    // email?" (pauseForUnresolvedTrucker, 2026-08-06). Same verbatim-capture
    // reasoning — whatever she sends next is either "cancel", a corrected
    // name, or an email address; actions.js's resumeQuoteWithTruckerRetry
    // sorts out which.
    if (ctx.pendingAction?.type === 'await_quote_trucker_retry') {
        return { intent: 'quote_trucker_retry_received', resolvedBy: 'policy', arbitrate: true, data: { retry_text: ctx.text.trim() } };
    }

    // ── A0f-2. Contact quote-request pending (2026-08-16, see
    // workflow/contactQuoteRequests.js). Same verbatim-capture reasoning as
    // A0f-1 above — "couldn't find X — correct name, or an email address to
    // use directly?"
    //
    // The sibling await_contact_quote_whatsapp_confirm pending ("use this
    // unverified mobile for WhatsApp too? yes/no") that used to live here was
    // REMOVED 2026-08-16 per the owner ("just have whatsapp verify button in
    // phon[e] number") — WhatsApp verification is now a one-time toggle on
    // the Address Book dashboard page (helpers/addressBook.js's
    // setMobileVerified), not a per-request chat prompt. If you're looking
    // for that flow, it no longer exists on purpose.
    if (ctx.pendingAction?.type === 'await_contact_quote_recipient_retry') {
        return { intent: 'contact_quote_recipient_retry_received', resolvedBy: 'policy', arbitrate: true, data: {} };
    }

    // ── A0f. Multi-select reply to "who should I ask?" (quote request with
    // no trucker named — see helpers/quoteRequests.js / workflow/quoteRequests.js).
    // Unlike every other p.options pending (single-pick, handled generically
    // in section A below), this one needs MULTIPLE picks from one reply
    // ("Joey, Buyerco" or "1,3") — same comma-list parsing style as
    // await_fact_batch above, just against names/numbers instead of digits only.
    if (ctx.pendingAction?.type === 'await_quote_truckers') {
        // REAL BUG (found 2026-08-18, live — the owner: "request quote
        // NTG,TQL,Matthew from Junk car to Eccomelt", sent again after
        // getting the "who should I ask?" prompt): a fresh, well-formed
        // "request/get/send quote ... from X to Y" command got fed through
        // the comma-split multi-select matcher below, which only manages to
        // fuzzy-match whichever ONE token happens to exactly equal a listed
        // name (here "TQL") — silently dropping "NTG" and "Matthew" with no
        // error at all, and mangling the origin/destination the new command
        // specified. This used to have its own inline parseGetQuoteCommand
        // carve-out right here; as of 2026-08-20 that check now happens
        // ONCE, generically, at the top of policyDecide (see "A(-1)" /
        // detectFreshCommand) for every pending type, so a fresh get_quote
        // command never reaches this line — it's caught before this.
        // route() still clears this stale pending specifically when that
        // happens (search for "await_quote_truckers" there) — unchanged.
        const p = ctx.pendingAction;
        const tt = ctx.text.trim();
        if (/^(no|none|cancel)$/i.test(tt)) return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'no' } };
        const tokens = tt.split(/,|&|\band\b/i).map((s) => s.trim()).filter(Boolean);
        const picked = [];
        for (const tok of tokens) {
            if (/^\d+$/.test(tok)) {
                const i = parseInt(tok, 10) - 1;
                if (i >= 0 && i < p.options.length) picked.push(p.options[i]);
            } else {
                const match = p.options.find((o) => o.toLowerCase() === tok.toLowerCase() || o.toLowerCase().includes(tok.toLowerCase()));
                if (match) picked.push(match);
            }
        }
        if (picked.length) return { intent: 'quote_truckers_selected', resolvedBy: 'policy', data: { names: [...new Set(picked)] } };
        return { intent: 'reply', resolvedBy: 'policy', arbitrate: true, data: { reply: 'Didn\'t catch a name/number — reply with names or numbers (comma-separated for more than one), or "cancel".' } };
    }

    // ── A0g. Active quote-request leg reply — a message from a chat that's
    // currently awaiting a price on an open quote request is almost
    // certainly that reply, not a new command. Backed by its own store
    // (data/quote_requests.json), looked up directly by chatId rather than
    // through ctx.pendingAction — a trucker's own chat normally has no
    // pending_actions entry at all, so this can't be folded into the A0
    // pendingAction checks above. Only kicks in when there ISN'T already a
    // more specific pending on this exact chat (e.g. an unrelated
    // await_ready_check), so it never hijacks a flow already in progress.
    //
    // REAL BUG (found 2026-08-18, live — the owner asked "Do you need scale
    // tickets?" in NTG's quote-reply chat and got no response at all): this
    // check had NO role gate — it fired for ANY message in a chat with an
    // open leg, including the MANAGER's own. Logs confirmed brain.js
    // correctly resolved her as role:'manager', but her message still got
    // swallowed here as "NTG replied without a price" and silently recorded
    // (handleQuoteLegReply is deliberately silent back to the chat by
    // design — dashboard notification only, never an auto-reply), instead
    // of falling through to the normal manager command grammar just below
    // this block. Added `!ctx.isManagerOrTeam` so a manager/team message in
    // that same chat is no longer treated as if the trucker sent it — the
    // trucker's OWN replies (role isn't manager/team for them) are
    // completely unaffected.
    if (!ctx.pendingAction && !ctx.isManagerOrTeam) {
        const { findActiveLegByTarget } = require('../helpers/quoteRequests');
        if (findActiveLegByTarget(ctx.chatId).length) {
            return { intent: 'quote_leg_reply_received', resolvedBy: 'policy', data: {} };
        }

        // ── A0g2. Same check, contact-quote-request store (2026-08-16) ──────
        // Parallel to the trucker leg-reply check just above, but against
        // helpers/contactQuoteRequests.js's own store (data/contact_quote_
        // requests.json) instead of helpers/quoteRequests.js's — a WhatsApp
        // reply from a non-trucker contact with an open contact-quote leg.
        // Checked second so a chat that happens to be BOTH an active trucker
        // leg AND (implausibly) an active contact-quote leg still resolves
        // to the trucker flow unchanged — this can only fire when the
        // trucker check just above found nothing.
        const { findActiveLegByTarget: findActiveContactQuoteLeg } = require('../helpers/contactQuoteRequests');
        if (findActiveContactQuoteLeg(ctx.chatId).length) {
            return { intent: 'contact_quote_leg_reply_received', resolvedBy: 'policy', data: {} };
        }
    }

    // ── A0b. End-of-day fact-batch confirmation — same "runs before section A's
    // generic yes/no" reasoning as await_ready_check above: "all" and "1,3"
    // don't match the YES/NO arrays or a plain list selection, so this needs
    // its own parse, not the generic pending handler. ──────────────────────────
    // ── A0b-i. Fact-conflict resolution (2026-08-25, phase 2) ──────────────
    // Jarvis found that something the owner just told it contradicts a fact it
    // already holds, and asked which wins. The valid answers — "replace",
    // "both", "cancel" — are a closed set that the generic YES/NO arrays do
    // not cover ("replace" is not a yes), so this needs its own parse and it
    // has to run before section A's generic pending handler.
    //
    // Scoped strictly to this pending type. "replace" and "both" are ordinary
    // words in freight conversation ("replace the seal", "both containers"),
    // and must not become global confirmation keywords — the same reasoning
    // that kept "apply" scoped to await_verify_apply.
    if (ctx.pendingAction?.type === 'await_fact_conflict') {
        const tt = ctx.text.trim().toLowerCase();
        if (/^(replace|supersede|update|new|yes)\b/.test(tt))
            return { intent: 'resolve_fact_conflict', resolvedBy: 'policy', data: { answer: 'replace' } };
        if (/^(both|keep both|keep)\b/.test(tt))
            return { intent: 'resolve_fact_conflict', resolvedBy: 'policy', data: { answer: 'both' } };
        if (/^(no|cancel|drop|never mind|nevermind)\b/.test(tt))
            return { intent: 'resolve_fact_conflict', resolvedBy: 'policy', data: { answer: 'cancel' } };
        // Anything else is probably a fresh request, not an answer — hand it
        // to the arbiter rather than nagging. Losing a real question to a
        // canned "reply replace or both" is the failure mode that motivated
        // the arbiter in the first place.
        return { intent: 'reply', resolvedBy: 'policy', arbitrate: true,
            data: { reply: 'Which should I go by — reply *replace* for the new one, *both* to keep them both, or *cancel* to drop it.' } };
    }

    if (ctx.pendingAction?.type === 'await_fact_batch') {
        const tt = ctx.text.trim().toLowerCase();
        if (/^(no|none|skip|cancel)$/.test(tt))
            return { intent: 'resolve_fact_batch', resolvedBy: 'policy', data: { selection: [] } };
        if (tt === 'all')
            return { intent: 'resolve_fact_batch', resolvedBy: 'policy', data: { selection: 'all' } };
        const nums = tt.split(',').map(s => parseInt(s.trim(), 10)).filter(n => Number.isInteger(n) && n > 0);
        if (nums.length)
            return { intent: 'resolve_fact_batch', resolvedBy: 'policy', data: { selection: nums } };
        // 2026-08-22, second pass: this now falls through by default (see
        // below), and the arbiter additionally protects every OTHER pending.
        // Kept as a fallthrough rather than an arbitrated nag because this
        // pending's valid answers are a fully closed set already checked
        // above — there is nothing left for the arbiter to weigh, so
        // spending a Gemini call here would buy nothing.
        //
        // REAL BUG (found 2026-08-22, live): the owner asked "Do we have any
        // booking available for Houston?" while this end-of-day review was
        // open. This block used to hard-return a fixed "reply with numbers"
        // nag for ANY non-matching text — so her real question never got
        // answered at all, twice over (this nag, then the reminder tail
        // below repeating the review). Unlike the verbatim-capture
        // pendings elsewhere in this file (cargo description, container
        // number, a corrected name — see A(-1)'s comment for why THOSE
        // can't safely fall through), this pending's valid answers are a
        // closed, unambiguous set already fully checked above (digits /
        // "all" / "no"/"skip"/"cancel"). Anything that doesn't match one
        // of those is by definition not a plausible answer to "which
        // suggestions do you want to keep" — so instead of forcing a fixed
        // nag, let it fall through to the exact same Section B / AI
        // classification any other message gets. The fact-batch pending
        // itself is left untouched (not cleared, not answered), so the
        // existing reminder-tail logic further down in route() still
        // nudges her to finish the review right after she gets her real
        // answer — same "queue behind, don't block" principle as A(-1)'s
        // fresh-command carve-out above, just scoped to this one pending
        // type since it alone is safe to widen this way.
    }

    // ── A. Pending action always wins — never chat-history string matching ────
    if (ctx.isManagerOrTeam && ctx.pendingAction) {
        const p = ctx.pendingAction;
        // "apply" is the word the verify report itself tells her to use, so
        // it has to be a yes for THAT pending. Scoped deliberately rather
        // than added to YES — "apply" is a normal verb elsewhere ("apply the
        // credit", "apply for the permit") and a global yes-word that fires
        // on any open question is exactly how a wrong pending gets answered.
        if (p.type === 'await_verify_apply' && /^\s*(apply|fix|fix them|correct|correct them|update|update them)\s*$/i.test(ctx.text)) {
            return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'yes' } };
        }
        // ── "SEND IT" IS HER YES ─────────────────────────────────────────
        // the owner reported this: at "send this email to Yurim? yes/no", she
        // says "send it" and gets "I couldn't pin that down".
        //
        // YES above is an EXACT-MATCH list, so "send it" falls past it, past
        // every rule below, and is reclassified as a brand-new email request —
        // the same failure shape as the Schedule bug documented further down.
        // helpers/draftIntent.js already states the rule ("send it to X" is
        // her yes, not a change); nothing implemented it at the confirm.
        //
        // NOT added to the global YES list, for the reason the `apply` case
        // above gives: "send mail to Yurim" is a brand-new request everywhere
        // else in this app, and a global send-means-yes would answer whatever
        // question happened to be open with it.
        if (p.type === 'await_email_confirm') {
            const bare = /^\s*(?:ok(?:ay)?[,\s]+)?(?:pls\s+|please\s+|just\s+|go\s+ahead\s+and\s+)?send(?:\s+(?:it|that|this|the\s+mail|the\s+email))?(?:\s+now)?\s*[.!]?\s*$/i;
            if (bare.test(ctx.text)) {
                return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'yes' } };
            }
            // ── "SEND IT TO BUYERCO" — ONLY IF THAT IS WHO IT IS TO ─────
            // draftIntent.js reads this as a yes, and at a PROFORMA confirm
            // it plainly is: there is no recipient in play, so the name is
            // the consignee she is confirming. An EMAIL confirm is different
            // — the draft already HAS a recipient, so a different name is
            // genuinely ambiguous between "yes, send" and "no, send it to
            // her instead".
            //
            // Matching the draft's own recipient: yes. Not matching: ASK.
            // Silently redirecting would put the mail in front of the wrong
            // company, which is the precise failure draftIntent.js was
            // written about.
            const named = /^\s*(?:ok(?:ay)?[,\s]+)?(?:pls\s+|please\s+|just\s+)?send\s+(?:it|that|this)?\s*to\s+(.+?)\s*[.!]?\s*$/i.exec(ctx.text);
            if (named) {
                const who = named[1].trim().toLowerCase();
                const target = String(p.target_name || '').trim().toLowerCase();
                const addr = String(p.to || '').trim().toLowerCase();
                const isSame = !!who && (
                    (target && (target.includes(who) || who.includes(target)))
                    || (addr && (addr === who || addr.split('@')[0] === who)));
                if (isSame) {
                    return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'yes' } };
                }
                return { intent: 'reply', resolvedBy: 'policy', data: { reply:
                    `That draft is addressed to ${p.target_name || p.to}. Reply "yes" to send it to them, or "no" and tell me to draft a new one to ${named[1].trim()}.` } };
            }
        }
        // ── "TELL THEM WE HAVE AN ISSUE AND WILL SEND IT LATER" ─────────
        // the owner, 2026-09-19. An instruction said at an open draft CHANGES
        // that draft — redrafted professionally and shown again for a yes.
        // Before this it fell through, was read as a brand-new request, and
        // queued a second draft behind the first.
        //
        // Only drafts that carry revise_ctx (a reply, or a plain new email)
        // and only text that starts the way an instruction starts — see
        // helpers/replyFlow.js isRevision. yes/no/send/schedule are all
        // handled above or below and never reach this as a rewrite.
        if (p.type === 'await_email_confirm' && p.revise_ctx
            && require('../helpers/replyFlow').isRevision(ctx.text)) {
            return { intent: 'revise_email_draft', resolvedBy: 'policy', data: { instruction: ctx.text.trim() } };
        }
        if (YES.includes(t)) return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'yes' } };
        if (NO.includes(t))  return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'no' } };
        // REAL BUG (found 2026-08-04, live): with an already-drafted
        // "send this email to Mathew? yes/no" pending active, "Schedule
        // this mail @7am LA time" fell through Section A entirely (it's
        // not yes/no, has no options) and got reclassified from scratch by
        // the AI as a brand-new email request — which then found the SAME
        // pending still unresolved and just queued a second, redundant
        // draft behind it, going in circles. "Schedule ___" while an email
        // confirm is already pending is unambiguously an answer to THAT
        // pending (send later instead of now/not-at-all), not a new
        // request — must be caught here, before it ever reaches general
        // classification. Reuses the already-drafted to/cc/bcc/subject/body
        // as-is; only converts WHEN it sends, never re-drafts anything.
        if (p.type === 'await_email_confirm' && /\bschedule\b/i.test(ctx.text)) {
            const clause = extractScheduleClause(ctx.text);
            if (clause) return { intent: 'reschedule_pending_email', resolvedBy: 'policy', data: { send_at_text: clause } };
            return { intent: 'reply', resolvedBy: 'policy', data: { reply: 'Schedule it for when? e.g. "schedule this at 7am LA time" or "schedule for tomorrow 9am".' } };
        }
        // ── "NO, QINGDAO NOT BUSAN" ──────────────────────────────────────
        // the owner, 2026-09-09, on gathering the missing pieces of a booking
        // request: "Both 1 and 3.." — ask one at a time for what is missing,
        // AND put it in the draft for her to edit. This is the editing half.
        //
        // Same failure shape as the "Schedule this mail" bug documented right
        // above, and still live for corrections: a correction typed at an
        // open email confirm is not yes, not no, not a numbered option, so it
        // falls through to general classification, is read as a brand new
        // request, finds the same pending unresolved and queues a second draft
        // behind it. Today her only usable move is "no", which bins the mail
        // and both answers she just gave.
        //
        // THREE LOCKS, and each is doing work:
        //  1. `p.req` — only a draft that CAME FROM the booking-request flow
        //     has a state to correct. Every other email confirm in this app is
        //     untouched, which matters: this branch is new and the reply
        //     drafts, the quote requests and the proforma covering notes have
        //     no coverage for it.
        //  2. correctionIn must name a FIELD and a VALUE. That is the test
        //     helpers/draftIntent.js states, and it is what keeps "send it to
        //     carrier" from being read as a discharge port — the exact mistake
        //     that file records putting the wrong company on a document.
        //  3. the re-draft still ends at a yes/no. Nothing is sent on the
        //     strength of a parsed correction.
        if (p.type === 'await_email_confirm' && p.req) {
            try {
                const patch = require('../helpers/bookingRequest').correctionIn(ctx.text, {
                    from: p.req.from_port, to: p.req.to_port,
                    count: p.req.count, size: p.req.size,
                });
                if (patch) {
                    return { intent: 'correct_booking_draft', resolvedBy: 'policy',
                        data: { said: ctx.text } };
                }
            } catch (e) {
                // A correction that cannot be parsed must never cost her the
                // draft — fall through to exactly today's behaviour.
                console.warn('[BRAIN] booking-draft correction check failed:', e.message);
            }
        }

        // ── "HOW MANY CONTAINERS?" ───────────────────────────────────────
        // the owner, 2026-09-06: "it should ask how many containers."
        //
        // Her answer is "two", "2x40HC", "two 40 highcubes" — not yes, not
        // no, and not a numbered option. Without this it falls past every
        // rule in this section into the general AI classifier, which is
        // EXACTLY the "Schedule this mail" bug documented twenty lines up:
        // an answer to an open question gets reclassified as a brand new
        // request, finds the same pending still unresolved, and queues a
        // second draft behind it.
        //
        // Placed after the YES/NO checks so a bare "no" still cancels. "Yes"
        // is not an answer to "how many", and falls into the pending's own
        // handler, which re-asks rather than inventing a number.
        //
        // The whole sentence is passed as `selection`; helpers/bookingRequest
        // .containersIn() is what reads a count out of it, and refuses rather
        // than guessing when there is not one.
        if (p.type === 'await_booking_details') {
            return { intent: 'resolve_pending', resolvedBy: 'policy',
                data: { answer: 'yes', selection: ctx.text } };
        }

        if (p.options) {
            const pick = resolveListSelection(ctx.text, p.options);
            if (pick) return { intent: 'resolve_pending', resolvedBy: 'policy', data: { answer: 'yes', selection: pick } };
            // REAL BUG (found 2026-08-06, live): a "confirm_quote_lane"
            // pending was active (5 numbered address options), and a reply
            // that matched none of them ("Jose" — she meant to answer a
            // DIFFERENT, earlier question) fell straight through this whole
            // function with no match, past every other check below, and
            // got picked up by an unrelated "bookings from X" pattern much
            // further down — replying "No bookings from jose." instead of
            // re-asking which numbered option she meant. Her own read on
            // it: "rather than rejecting straightaway confirm whom to ask."
            // Scoped to just the two quote-disambiguation pending types —
            // NOT touching the shared p.options fallthrough for
            // select_trucker/select_supplier/wizard_*/
            // await_contact_disambiguation, whose current fallthrough
            // behavior hasn't been audited here and may be relied on
            // elsewhere.
            if (p.type === 'confirm_quote_lane' || p.type === 'confirm_quote_trucker') {
                return { intent: 'reply', resolvedBy: 'policy', arbitrate: true, data: { reply: `Didn't catch which one — reply with the number (1-${p.options.length}), or "cancel".` } };
            }
        }
        if (p.type === 'await_bkg_no') {
            const bkgResolved = resolveBookingNumber(ctx.text);
            if (bkgResolved) return { intent: p.nextIntent, resolvedBy: 'policy', data: { bkg_no: bkgResolved } };
        }
        // "send price list" asked which city — this reply should be 1/2/3 or a
        // partial city name. Self-contained: doesn't touch actions.resolvePending
        // at all, same pattern as await_bkg_no above.
        // She has told us what the link is for. Deliberately NOT a fixed set
        // of options: "check the totals", "import these loads", "log this
        // invoice" are all plausible and inventing a menu would just be a
        // second guess. Her instruction and the link are handed to the AI
        // path together, which either does something sensible or says plainly
        // that it cannot — both better than silence.
        if (p.type === 'await_link_purpose') {
            // NO bespoke cancel branch here. The global cancel handler above
            // already catches "cancel"/"never mind" for EVERY pending and
            // routes it through resolve_pending — verified, it fires before
            // this point. A second cancel path would be dead code today and a
            // divergence the first time the shared one changed.
            ctx.pastedLink = p.url || null;
            // Fall through to the AI path with the link attached.
        }
        if (p.type === 'await_pricelist_city') {
            const cityMatch = resolveListSelection(ctx.text, ['Los Angeles', 'Houston', 'San Antonio']);
            if (cityMatch) return { intent: 'send_pricelist_city', resolvedBy: 'policy', data: { city: cityMatch, target_name: p.target_name || null } };
            return { intent: 'reply', resolvedBy: 'policy', arbitrate: true, data: { reply: 'Reply 1 for Los Angeles, 2 for Houston, or 3 for San Antonio.' } };
        }
        // fall through — the manager may be asking something else mid-pending
    }

    // ── B. Manager/team commands ──────────────────────────────────────────────
    if (ctx.isManagerOrTeam) {
        if (['hi', 'hello', 'menu', 'help', 'jarvis'].includes(t)) return { intent: 'show_menu', resolvedBy: 'policy' };

        // Numbered menu replies
        if (/^\d$/.test(t) && ctx.session.menuContext === 'main') {
            const map = { 1: 'bookings_menu', 2: 'forward_booking', 3: 'assign_supplier', 4: 'check_supplier', 5: 'show_contacts', 6: 'show_bookings_week' };
            const intent = map[t];
            if (intent) return { intent, resolvedBy: 'policy', data: {} };
        }
        if (/^\d$/.test(t) && ctx.session.menuContext === 'bookings') {
            const map = { 1: 'show_bookings_urgent', 2: 'show_bookings_all', 3: 'show_bookings_available', 4: 'show_bookings_week', 5: 'ask_booking_number', 6: 'show_bookings_all' };
            const intent = map[t];
            if (intent) return { intent, resolvedBy: 'policy', data: {} };
        }

        // Location-qualified bookings query — MUST be checked before the plain
        // "available bookings" rule below, and routes to bookings_list_query
        // (which actually supports location filtering via queryBookingsByLocation)
        // rather than show_bookings_available (which has NO location awareness
        // at all). A real incident: "available bookings from oakland" got
        // routed to show_bookings_available by the AI, which just dumped every
        // available booking from every port, ignoring "from oakland" entirely.
        // Not anchored to the start of the string — deliberately searches for
        // the pattern anywhere in the text, so a typo'd prefix ("shoe" instead
        // of "show") doesn't prevent the match; only the meaningful part needs
        // to be right.
        // ── Location queries defer to the AI when they are not certain ────
        // the owner, 2026-08-22: "i dont want textbook case. just let ai decide
        // the policy." She is right, and this rule is the clearest example of
        // why. It is deliberately UNANCHORED so a typo'd prefix ("shoe
        // bookings from LA") still works — and that same reach is what let it
        // claim "reverify bookings in mail", read "mail" as a PORT, and answer
        // "No bookings from mail." before the AI ever saw the sentence.
        //
        // The fix is not another keyword blocklist; it is to stop this rule
        // from deciding when it cannot be sure. It now only claims the
        // sentence when the captured place is plausibly a PLACE — the query
        // resolves against real booking data. Anything else falls through to
        // the AI, which as of today has bookings_list_query/bookings_count_query
        // in its own action list and can pick them (or verify_bookings, or
        // search_mail) by reading what she actually meant.
        //
        // Net effect: the fast path still handles every real location query
        // without an AI call, and stops guessing on everything else.
        // ── NO SECOND WORD ORDER HERE. ON PURPOSE. ──────────────────────
        // the owner, 2026-09-08: "Why would i need to hard code it? Stupid..
        // Its an AI.. Why would i need to do so much fixes? Why cant yu find
        // that on your own???"
        //
        // I had just added a second regex to this line so that "houston
        // bookings with cutoff next week" would match alongside "bookings
        // from houston". She stopped me, and she was right to. That is the
        // fix that guarantees a third report: the next sentence she says will
        // have a third word order, and she will have to come and tell me.
        //
        // This pattern stays exactly as narrow as it was. It is the OFFLINE
        // NET — the thing that keeps Jarvis usable when Gemini is
        // unreachable — and a net does not have to catch everything. What
        // catches everything is the model, which reads the sentence. So the
        // extraction moved there: see the location/filter/cutoff fields in
        // the AI's own schema below, and 'bookings_list_query' in the handler.
        //
        // The rule this file is supposed to follow, written down so I stop
        // breaking it: deterministic code decides WHICH ENTITY and whether an
        // irreversible action proceeds. The model decides what she MEANT.
        // Word order is meaning. It was never mine to enumerate.
        const rawLocMatch = t.match(/\b(available|unassigned|assigned)?\s*bookings?\s+(?:from|at|in|for)\s+(.+?)\s*$/i);
        // ── AN INSTRUCTION TO GO AND ASK SOMEONE IS NOT A SEARCH ─────────
        // the owner, 2026-09-09, with a screenshot: "send email to Wimax asking
        // for booking from Houston to Busan..." came back as a bookings
        // search whose scope was her whole sentence.
        //
        // The tail of that sentence — "booking from Houston" — is exactly the
        // shape rawLocMatch above is looking for, and the net has no way to
        // tell it apart from "bookings from Houston" without looking at the
        // VERB. api.js carries a comment about the identical collision
        // happening to a sentence Jarvis wrote for itself; that was worked
        // around by rewording Jarvis's output, which does nothing for hers.
        //
        // The predicate is in helpers/bookingRequest.js and turns on whether
        // she named a PARTY to ask. Vetoing costs nothing when it is wrong —
        // the sentence simply goes to the model, which reads it properly, and
        // that is the path she has twice told me to prefer over more patterns
        // here. Being claimed wrongly by the net costs her a wrong answer.
        let requestToSomeone = false;
        try { requestToSomeone = require('../helpers/bookingRequest').isRequestToSomeone(t); }
        catch (e) { console.warn('[BRAIN] booking-request veto check failed:', e.message); }
        if (requestToSomeone && rawLocMatch) {
            console.log(`[BRAIN] "${t.slice(0, 60)}" names someone to ask — not a location query, letting the model read it`);
        }

        const locQueryMatch = (() => {
            if (requestToSomeone) return null;
            if (!rawLocMatch) return null;
            const place = (rawLocMatch[2] || '').trim();
            if (!place) return null;
            try {
                // Does this actually name somewhere we have bookings for? If
                // yes it is unambiguously a location query and the fast path
                // is correct. If not, the AI is better placed to judge.
                const { count } = queryBookingsByLocation(place, undefined);
                if (count > 0) return rawLocMatch;
            } catch (e) { /* fall through to the AI */ }
            return null;
        })();
        if (locQueryMatch) {
            const filter = locQueryMatch[1] === 'assigned' ? 'assigned' : (locQueryMatch[1] ? 'unassigned' : undefined);
            const location = locQueryMatch[2].trim();
            // The offline net passes her WHOLE sentence through as the cutoff
            // phrase and lets cutoffWindow() decide whether there is a window
            // in it. Not a parse — a hand-off. When Gemini is up it fills
            // this field properly from meaning; this is only so that losing
            // the model does not also lose the narrowing she asked for.
            const cutoff_phrase = t;
            if (location) return { intent: 'bookings_list_query', resolvedBy: 'policy', data: { location, filter, cutoff_phrase } };
        }

        if (t === 'bookings' || /^(?:show\s+(?:me\s+)?|list\s+)?(?:all\s+)?bookings?$/.test(t)) return { intent: 'bookings_menu', resolvedBy: 'policy' };
        if (t === 'urgent' || /^(?:show\s+(?:me\s+)?|list\s+)?urgent\s+bookings?$/.test(t)) return { intent: 'show_bookings_urgent', resolvedBy: 'policy' };
        // "urgent cutoff(s)", "any cutoffs today", "what's cutting off" —
        // the owner, 2026-09-20. Same answer as "urgent bookings". The phrase
        // test lives in helpers/voiceClaims.js so the voice route (which has
        // to know to stand its bookings panel aside) and this rule agree.
        if (require('../helpers/voiceClaims').isUrgentCutoffQuestion(t)) {
            return { intent: 'show_bookings_urgent', resolvedBy: 'policy' };
        }
        // ── "BRIEF ME" ───────────────────────────────────────────────────
        // the owner, 2026-09-20. Sample Yard Co Metals only — the yard is Scout's.
        if (require('../helpers/briefIntent').isBriefRequest(t)) {
            return { intent: 'metals_brief', resolvedBy: 'policy' };
        }
        // The other Metals screens, read-only. A fast path for the plainest
        // phrasings only — anything else reaches the AI as metals_report.
        {
            const rep = require('../helpers/metalsReports').reportIn(t);
            if (rep) return { intent: 'metals_report', resolvedBy: 'policy', data: { report: rep } };
        }
        if (t === 'available' || /^(?:show\s+(?:me\s+)?|list\s+)?available\s+bookings?$/.test(t)) return { intent: 'show_bookings_available', resolvedBy: 'policy' };
        if (t === 'truckers' || t === 'suppliers' || t === 'contacts' ||
            /^(?:show\s+(?:me\s+)?|list\s+)?(?:truckers|suppliers|contacts)$/.test(t))
            return { intent: 'show_contacts', resolvedBy: 'policy' };

        let m;
        // Grammar supports optional /N suffix for container seq: "forward BKG/1 to Dave"
        // No slash → auto-picks next unassigned container in executeForward.
        // Order-agnostic: "forward BKG to Dave" AND "forward Dave to BKG" both work —
        // whichever captured token actually matches the booking-number FORMAT wins,
        // regardless of position. Without this, "assign him to DALA52325500" silently
        // treated "him" as the booking and DALA52325500 as the supplier name.
        // ── THE NOUN IN FRONT OF THE NUMBER ─────────────────────────────
        // Found by tests/phrasebook.js, 2026-09-08. "forward booking HOU111 to
        // trucker" did not match — the first captured token was "booking", and
        // the pattern then demanded "to" where "HOU111" stood. It fell through
        // to the AI and came back "I couldn't pin that down."
        //
        // That is bad on its own; what makes it serious is WHO SAYS IT. The
        // reference resolver rewrites "forward the booking to trucker" into
        // "forward booking HOU111 to trucker" before the brain ever sees it.
        // Jarvis was rephrasing her sentence into a form its own parser could
        // not read, so the centering work quietly disabled the forward path
        // for every pronoun phrasing. Neither half is wrong alone.
        //
        // "forward booking to trucker" — where the noun IS the whole subject,
        // because she means the one in focus — keeps working without any
        // special handling. I first wrote a `(?!to\b)` lookahead to protect
        // that case and then could not construct a mutation that killed it:
        // the prefix is optional, so when the rest of the pattern cannot
        // match, the engine simply backtracks and gives up the noun. The
        // lookahead was restating what the regex already does. Removed rather
        // than left in as decoration no test can hold to account.
        const NOUN_PREFIX = String.raw`(?:(?:the|that|this)\s+)?((?:booking|load|shipment|container)\s+)?`;
        // ── AND THE SAME NOUN ON THE OTHER SIDE ─────────────────────────
        // the owner, 2026-09-09: "if i say foward the houston booking...it should
        // forward that booking to trucker na?"
        //
        // Yes. English puts that noun either side of the identifier — "booking
        // HOU111" and "the houston booking" are one grammar, not two word
        // orders — and this pattern only knew the first, so her sentence
        // matched nothing at all and never reached any code that could resolve
        // it.
        //
        // THE SAME NOUN LIST, reused. This is not the thing she stopped me
        // doing yesterday: I am not enumerating ways to phrase a request, I am
        // letting one noun sit where the language allows it. The WORK is done
        // by resolveSpokenBooking in workflow/actions.js, which turns a place
        // into a booking against the store — and that serves the model's route
        // too, where no regex is involved at all.
        const NOUN_SUFFIX = String.raw`(?:\s+(?:booking|bookings|load|loads|shipment|container))?`;

        // ── "SHARE", NOT ONLY "FORWARD" ─────────────────────────────────
        // the owner, 2026-09-08: "still it shows i cannot share booking to
        // tracker."
        //
        // Yesterday I fixed the sentence SHAPE and tested it with the one verb
        // I happened to have in my head. She does not say "forward". She says
        // share, pass, send, give. Fixing the shape for a single verb is the
        // same narrowness one level up, and she has now had to report it twice.
        //
        // WHY THIS IS NOT JUST A LONGER VERB LIST, OR RATHER: WHY IT IS A
        // SAFE ONE. "send" is genuinely ambiguous in this app — "send a mail
        // to jeyshree" must never be read as forwarding a booking called
        // "mail". So the extra verbs are admitted ONLY when the sentence also
        // carries something that says a booking is the object: either the noun
        // ("share the BOOKING to..."), or an identifier that resolves to a
        // real booking in the store. "forward" and "assign" keep their old
        // unconditional grammar, because those verbs mean nothing else here.
        //
        // The model remains the general answer — with Gemini reachable it
        // classifies any phrasing. This is the offline net, and the net has to
        // cover the words she actually uses.
        const SEND_ONWARD = String.raw`forward|share|pass|hand|shoot|send|give`;
        if ((m = t.match(new RegExp(String.raw`^(${SEND_ONWARD})\s+${NOUN_PREFIX}([A-Za-z0-9-]+)${NOUN_SUFFIX}(?:\/(\d+))?(?:\s+(?:to|with)\s+(.+))?$`)))) {
            const [verb, noun, first, seq, second] = [m[1], m[2], m[3], m[4], m[5]];
            const namedBooking = resolveBookingNumber(first) || (second && resolveBookingNumber(second));
            // "share booking to tracker" — the noun capture is null here, and
            // that is the regex working correctly: with nothing after it, the
            // optional group gives "booking" up to the identifier slot on
            // backtracking. So the word arrives as `first`, and the question
            // is the same one helpers/genericTerm.js already answers — is that
            // a name, or is it the category? If it is the category, she is
            // pointing at the booking in focus, and forwardBooking resolves it
            // from the discourse centre exactly as it does for "forward
            // booking to trucker".
            const saidTheWord = require('../helpers/genericTerm').isGeneric(first, 'booking');
            // AND THE PLAINEST PROOF OF ALL: it is one of her bookings.
            // resolveBookingNumber is a SHAPE test — [A-Z]{2,6} then six or
            // more digits — so a real booking whose number does not happen to
            // fit that shape would be turned away at this gate while "share
            // DALA52325500 to X" sailed through for a booking that does not
            // exist. Asking the store is both stricter and kinder: it says yes
            // to her actual bookings and no to everything else.
            let isHerBooking = false;
            try { isHerBooking = !!require('../helpers/booking').getBooking(first).booking; }
            catch (e) { /* store unreadable — the other three tests still stand */ }
            // The gate. Anything but "forward" has to prove it means a booking.
            if (verb === 'forward' || noun || namedBooking || saidTheWord || isHerBooking) {
                const firstIsBkg = resolveBookingNumber(first);
                const secondIsBkg = second && resolveBookingNumber(second);
                const bkg_no = firstIsBkg ? firstIsBkg : (secondIsBkg || first.toUpperCase());
                const trucker_name = firstIsBkg ? (second || null) : (secondIsBkg ? first : (second || null));
                return { intent: 'forward_booking', resolvedBy: 'policy', data: { bkg_no, container_seq: seq ? parseInt(seq, 10) : null, trucker_name } };
            }
            // Fell through on purpose: "send a mail to jeyshree" reaches the
            // email path below exactly as it always did.
        }
        // Same noun prefix, same reason — "assign booking HOU111 to Eccomelt"
        // is the identical sentence shape and the resolver rewrites into it
        // identically. Fixing only forward would leave the twin broken.
        //
        // No synonym list here: "assign" has no everyday twin the way forward
        // does, and the verbs she uses for supplying — "put Eccomelt on it" —
        // are a different grammar, not a different word. Left for the model
        // rather than guessed at.
        if ((m = t.match(new RegExp(String.raw`^assign\s+${NOUN_PREFIX}([A-Za-z0-9-]+)${NOUN_SUFFIX}(?:\/(\d+))?(?:\s+to\s+(.+))?$`)))) {
            const [first, seq, second] = [m[2], m[3], m[4]];
            const firstIsBkg = resolveBookingNumber(first);
            const secondIsBkg = second && resolveBookingNumber(second);
            const bkg_no = firstIsBkg ? firstIsBkg : (secondIsBkg || first.toUpperCase());
            const supplier_name = firstIsBkg ? (second || null) : (secondIsBkg ? first : (second || null));
            return { intent: 'assign_supplier', resolvedBy: 'policy', data: { bkg_no, container_seq: seq ? parseInt(seq, 10) : null, supplier_name } };
        }
        if ((m = t.match(/^recall\s+(\S+)$/)))
            return { intent: 'recall_booking', resolvedBy: 'policy', data: { bkg_no: m[1].toUpperCase() } };
        if ((m = t.match(/^archive\s+(\S+)$/)))
            return { intent: 'archive_booking', resolvedBy: 'policy', data: { bkg_no: m[1].toUpperCase() } };
        // ── "RUN A SCAN FOR BOOKINGS PAST CUTOFF" ────────────────────────
        // the owner's own words, and the ways round them. Resolved by policy
        // rather than left to the classifier because it is unambiguous and
        // because "archive the ones past cutoff" sits one word away from
        // "archive DALA123" — a misread there archives the wrong thing.
        //
        // Requires a CUTOFF/EXPIRED word, so "run a scan" on its own does not
        // match: she has other things she might want scanned, and this one
        // ends in a batch archive.
        if (/\b(scan|check|find|look|any|which|show)\b/i.test(t)
            && /\b(past|passed|expired|expiry|overdue|beyond|after)\b/i.test(t)
            && /\b(cut\s*-?\s*off|cutoff|cutoffs)\b/i.test(t)) {
            return { intent: 'scan_cutoffs', resolvedBy: 'policy', data: {} };
        }
        // Any status-type phrasing containing a real booking number, anywhere
        // in the text — not anchored to an exact "status X" shape. A real
        // gap found by simulation testing: "status of 274150389" (natural
        // phrasing with "of") fell all the way through to the AI because the
        // old regex only matched the exact two-word form. resolveBookingNumber
        // already reliably extracts a booking number from free text; this
        // just adds the "status"-intent check alongside it.
        if (/\bstatus\b/.test(t)) {
            const statusBkg = resolveBookingNumber(ctx.text);
            if (statusBkg) return { intent: 'show_booking_status', resolvedBy: 'policy', data: { bkg_no: statusBkg } };
        }

        // "backfill missing cutoffs" / "fill missing fields" / "check missing
        // data from mail" / "fill in whatever's missing" — auto-fills (never
        // overwrites) any booking missing cutoff/ERD/ETD/ETA/vessel/route
        // fields by searching existing mail for its booking number. Was
        // cutoff-only originally; generalized 2026-08-03 per the owner ("not
        // only cutoff backfill, whatever is missing in booking, but
        // especially cutoff/ERD/ETA/ETD") — see helpers/cutoffBackfill.js's
        // BACKFILL_FIELDS for the exact field list and what's deliberately
        // excluded. Old cutoff-only phrasing still matches (first regex) and
        // now just triggers the same broader action — a "backfill cutoffs"
        // request is a valid subset of "backfill missing fields", not a
        // different feature. No parameters needed either way.
        if (/^(?:backfill|fill(?:\s+in)?|check)\s+(?:the\s+|any\s+|all\s+)?missing\s+cutoffs?(?:\s+from\s+(?:mail|email))?$/i.test(t) ||
            /^(?:backfill|fill(?:\s+in)?)\s+cutoffs?\s+from\s+(?:mail|email)$/i.test(t) ||
            /^(?:backfill|fill(?:\s+in)?|check)\s+(?:the\s+|any\s+|all\s+)?missing\s+(?:fields?|data|info(?:rmation)?)(?:\s+(?:in|from|for)\s+(?:the\s+)?bookings?)?(?:\s+from\s+(?:mail|email))?$/i.test(t) ||
            /^(?:backfill|fill(?:\s+in)?)\s+(?:whatever(?:'s|\s+is)?\s+missing|missing\s+(?:fields?|data))\s+(?:in\s+)?bookings?(?:\s+from\s+(?:mail|email))?$/i.test(t)) {
            return { intent: 'backfill_cutoffs', resolvedBy: 'policy', data: {} };
        }

        // "learn sample contacts" / "learn sample domain" / "scan
        // sample contacts" — scans mail and proposes a domain-tree
        // contact group (primary/secondary/shared roles from real From/Cc/To
        // frequency), always with a confirm step before anything is saved.
        // Deliberately deterministic-only (not wired into the AI classifier
        // below) — this touches saved contacts/cc behavior for every future
        // email to that domain, so it shouldn't be reachable via a fuzzy AI
        // guess at intent; she has to actually say "learn".
        {
            const learnMatch = t.match(/^(?:learn|scan)\s+([a-z0-9][a-z0-9.\-]*)\s*(?:contacts?|domain)?$/i);
            if (learnMatch) return { intent: 'learn_domain', resolvedBy: 'policy', data: { term: learnMatch[1] } };
        }

        // "follow up with X" / "please follow up with X in N minutes/hours" — optionally "re BKG123"
        if ((m = t.match(/^(?:please\s+)?follow\s*up\s+with\s+(.+?)(?:\s+in\s+(\d+)\s*(min|mins|minute|minutes|hr|hrs|hour|hours))?(?:\s+(?:re|regarding|about|on)\s+([A-Za-z0-9-]+))?$/))) {
            const rawMins = m[2] ? parseInt(m[2], 10) : null;
            const unit    = m[3] || '';
            const minutes = rawMins != null ? (unit.startsWith('h') ? rawMins * 60 : rawMins) : null;
            return {
                intent: 'schedule_followup', resolvedBy: 'policy',
                data: { target_name: m[1].trim(), minutes, bkg_no: (m[4] || ctx.activeBooking || null)?.toUpperCase?.() || m[4] || ctx.activeBooking || null },
            };
        }

        // "get quote from LA to Richmond" / "...ask Joey and Buyerco" /
        // "...email owner@sample.example" / both together, either order —
        // multi-trucker quote-request flow (2026-08-05). Matched against the
        // ORIGINAL text (case-insensitive), not the fuzzy-corrected/
        // lowercased `t`, so names/emails keep their real casing — same
        // reasoning as the "reply to X" pattern just below. Deliberately
        // checked before search_mail/draft_email/reply_email so "get quote"
        // always wins over any of those being misread as vaguely email-shaped.
        //
        // REAL GAP (found 2026-08-05, live): "get quote from LA to Richmond
        // email owner@sample.example" — a one-off recipient who isn't a saved
        // trucker at all — wasn't supported; the old single regex had no
        // "email ___" clause, so "Richmond email owner@sample.example" was read
        // as one (nonexistent) destination string. parseGetQuoteCommand
        // below pulls "ask ___" and "email ___" out of whatever trails "to",
        // in either order, and whatever's left over is the real destination.
        {
            const parsed = parseGetQuoteCommand(ctx.text);
            if (parsed) {
                return {
                    intent: 'get_quote', resolvedBy: 'policy',
                    data: { origin: parsed.origin, destination: parsed.destination, names_text: parsed.namesText, emails: parsed.emails },
                };
            }
        }

        // "quote to Eccomelt for junk cars" / "send a quote request to X for Y" —
        // contact quote-request flow (2026-08-16, see workflow/contactQuoteRequests.js).
        // Checked right after get_quote's lane parser above, same "let the more
        // specific well-formed command win" reasoning — a message that failed
        // the "from...to" lane shape gets one more specific try here before
        // falling through to the generic draft_email/AI classifier.
        {
            const parsed = parseContactQuoteCommand(ctx.text);
            if (parsed) {
                return {
                    intent: 'get_contact_quote', resolvedBy: 'policy',
                    data: { recipient_query: parsed.recipientQuery, details: parsed.details },
                };
            }
        }

        // ── A BARE NUMBER IS AMBIGUOUS. ASK. ────────────────────────────
        // LIVE, 31 Aug 2026, 8:54 PM. Three bot messages inside an hour:
        //   8:00pm  digest, item 1 = Matt Whittaker
        //   8:45pm  "Trucker check for today — ... (yes/no)"  [opens a pending]
        //   8:50pm  digest, item 1 = Andy Park
        // ops replied "1". Simulated with the session state cleared, that
        // matches NO rule in this file and falls through to Gemini to guess,
        // with three live referents in play. Whatever it picked, nobody was
        // told which one — and one of the candidates was "decline the trucker
        // check", which is destructive and silent.
        //
        // It is also worth being honest about why this went unnoticed: with a
        // menuContext left over from any earlier menu, "1" is claimed by the
        // menu handler at line ~885 instead — even days later, because
        // menuContext never expires. So the behaviour was not one wrong
        // answer, it was a different wrong answer depending on history.
        //
        // Same instruction she gave for the pasted Google Sheet link ("it
        // should have asked instead"): with more than one live referent, ask
        // and name them. With exactly one, just do it — asking then is the
        // friction she objects to.
        //
        // SCOPE, checked against every other user of a bare number:
        //   · list-selection pendings (select_trucker/select_supplier and the
        //     wizard steps) resolve numbers in section A0 and return long
        //     before this point, so they are untouched
        //   · a menu number still works, because menuContext is checked
        //     before this and is only set when a menu was actually shown
        //   · "reply to 1" and "ignore 1" are explicit and unaffected
        if (/^#?\d{1,2}$/.test(ctx.text.trim())) {
            const n = ctx.text.trim().replace('#', '');
            const candidates = [];
            const { lastDigest, lastDigestAt } = (() => {
                try { return require('./replyWatch').loadStore() || {}; } catch (e) { return {}; }
            })();
            const digestFresh = (() => {
                const at = Date.parse(lastDigestAt || '');
                return Number.isFinite(at) && Date.now() - at < 12 * 60 * 60 * 1000;
            })();
            const item = digestFresh && Array.isArray(lastDigest)
                ? lastDigest[parseInt(n, 10) - 1] : null;
            if (item) candidates.push({ kind: 'digest', label: `item ${n} from the last digest (${item.fromName || item.from || 'that sender'})` });
            if (ctx.pendingAction) {
                // pendingFullReminder is declared further down; function
                // declarations hoist, so this is the same text the nudge uses
                // rather than a second wording that could drift from it.
                const line = String(pendingFullReminder(ctx.pendingAction) || '').replace(/^\(|\)$/g, '').trim();
                candidates.push({ kind: 'pending', label: line || 'the question I asked earlier' });
            }
            if (candidates.length > 1) {
                return { intent: 'reply', resolvedBy: 'policy', data: { reply:
                    `"${n}" could mean two things right now, and one of them I cannot undo:\n`
                    + candidates.map((c, i) => `  ${i + 1}. ${c.label}`).join('\n')
                    + `\n\nSay "reply to ${n}" for the digest item, or answer the other one directly.` } };
            }
            if (candidates.length === 1 && candidates[0].kind === 'digest') {
                return { intent: 'reply_to_digest_item', resolvedBy: 'policy', data: { index: n, details: null } };
            }
        }

        // "reply to 2" / "reply 2" / "reply to 2: confirmed for Friday" —
        // answers a numbered entry from the last needs-a-reply digest.
        // Checked BEFORE the general "reply to <name>" rule below so a bare
        // digit is read as a digest reference rather than as a contact called
        // "2". The two cannot collide: this requires digits only, that one
        // requires a name.
        if ((m = ctx.text.trim().match(/^(?:please\s+)?reply\s+(?:to\s+)?#?(\d{1,2})\b(?:\s*[:\-—]\s*(.+)|\s+(?:saying|with|about)\s+(.+))?$/i))) {
            return {
                intent: 'reply_to_digest_item', resolvedBy: 'policy',
                data: { index: m[1], details: (m[2] || m[3] || '').trim() || null },
            };
        }

        // ── "REPLY TO TWO", "REPLY TO THE HOUSTON ONE", "REPLY TO THAT" ──
        // the owner, 2026-09-19. Measured first: every one of these read the
        // words after "reply to" as a PERSON called "two" / "the second one"
        // / "the Houston cutoff email", and "reply to that" was not
        // understood at all. By voice those are the normal way to say it —
        // a speech engine writes "two", not "2".
        //
        // Only against a FRESH digest (the same 12h the bare-number rule
        // above uses). With no digest, all three fall through to exactly
        // what they did before. See helpers/replyFlow.js.
        {
            const rf = require('../helpers/replyFlow');
            const { lastDigest: dl, lastDigestAt: dat } = (() => {
                try { return require('./replyWatch').loadStore() || {}; } catch (e) { return {}; }
            })();
            const datMs = Date.parse(dat || '');
            const fresh = Number.isFinite(datMs) && Date.now() - datMs < 12 * 60 * 60 * 1000
                && Array.isArray(dl) && dl.length > 0;
            const that = rf.replyToThat(ctx.text);
            if (that) {
                return { intent: 'reply_to_focused_digest', resolvedBy: 'policy', data: { details: that.details } };
            }
            if (fresh) {
                const spoken = rf.spokenDigestIndex(ctx.text);
                if (spoken) {
                    return { intent: 'reply_to_digest_item', resolvedBy: 'policy',
                        data: { index: spoken.index, details: spoken.details } };
                }
                const described = rf.describedDigestTarget(ctx.text);
                const hit = described ? rf.matchDigest(described.desc, dl) : null;
                if (hit && hit.index) {
                    return { intent: 'reply_to_digest_item', resolvedBy: 'policy',
                        data: { index: hit.index, details: described.details } };
                }
                if (hit && hit.ambiguous) {
                    return { intent: 'pick_digest_reply', resolvedBy: 'policy',
                        data: { indexes: hit.ambiguous, details: described.details } };
                }
            }
        }

        // ── MUTE — "what if i want ignore?", asked twice ────────────────
        // Deliberately ABOVE the "ignore N" rule below, because the phrases
        // overlap: "ignore 1 permanently" has to reach the mute, not the
        // one-off. The distinguishing word is the permanence, never the
        // number, so the number alone still means the one-off it always did.
        if ((m = ctx.text.trim().match(/^(?:mute|block|stop\s+(?:telling|showing|nudging)\s*(?:me)?\s*about)\s+#?(\d{1,2})\s*$/i))
            || (m = ctx.text.trim().match(/^(?:ignore|dismiss)\s+#?(\d{1,2})\s+(?:permanently|for good|forever|always|and\s+(?:stop|don'?t)\b.*)$/i))) {
            return { intent: 'mute_matter', resolvedBy: 'policy', data: { index: m[1] } };
        }
        // By NAME is a sender mute — a much stronger claim than a thread, so
        // it only ever happens when she says the name outright.
        if ((m = ctx.text.trim().match(/^(?:mute|block)\s+(?!#?\d)(.+?)\s*$/i))) {
            return { intent: 'mute_matter', resolvedBy: 'policy', data: { target: m[1].trim() } };
        }
        if ((m = ctx.text.trim().match(/^(?:unmute|unblock|unignore|start\s+(?:showing|telling)\s*(?:me)?\s*(?:about)?)\s+(.+?)\s*$/i))) {
            return { intent: 'unmute_matter', resolvedBy: 'policy', data: { target: m[1].trim() } };
        }
        // The audit. A filter she cannot see is a filter she cannot trust.
        if (/^(?:what am i ignoring|what'?s muted|show (?:my )?mutes?|list mutes?|who am i ignoring|what are we ignoring)\??$/i.test(ctx.text.trim())) {
            return { intent: 'show_mutes', resolvedBy: 'policy', data: {} };
        }

        // ── EXPLAIN N (2026-09-19) ──────────────────────────────────────
        // the owner: "If i say explain 5 - will it provide detailed summary
        // include the in thread mails".
        //
        // It did not. "explain 5" fell through to the AI layer, where Gemini
        // decided whether it meant summarize_email -- which then read ONE
        // message and never opened the thread. Made deterministic here for
        // the same reason "reply to 5" and "ignore 5" are: a drill-down that
        // works most of the time is not something a terser digest can be
        // built on top of.
        //
        // Placed with the other index commands and ABOVE the bare-number
        // rules, and bounded to 1-2 digits so it cannot swallow "explain
        // 4302902", which is a PO and is handled above.
        if ((m = ctx.text.trim().match(/^(?:explain|expand|open|details?(?:\s+(?:of|on|for))?|tell\s+me\s+more\s+(?:about|on)|more\s+(?:about|on))\s+#?(\d{1,2})\s*\??$/i))
            || (m = ctx.text.trim().match(/^what(?:[’']?s| is| was)?\s+#?(\d{1,2})\s+about\s*\??$/i))
            || (m = ctx.text.trim().match(/^(?:full|whole|entire)\s+(?:thread|story|history)\s+(?:of|for)?\s*#?(\d{1,2})\s*\??$/i))) {
            return { intent: 'explain_digest_item', resolvedBy: 'policy', data: { index: m[1] } };
        }

        // ── PURCHASE ORDERS (2026-09-17) ────────────────────────────────
        // Placed here, ABOVE the "ignore N" rule below, for the same reason
        // the mute routes are: "close po 4302902" contains a number, and the
        // digest-index rules downstream match bare numbers greedily. A PO
        // number is 4-12 digits and a digest index is 1-2, so they cannot
        // actually collide — but the ordering makes that a fact about the
        // routes rather than a fact about the regexes, which is the version
        // that survives someone widening one of them.
        if ((m = ctx.text.trim().match(/^(?:close|done\s+with|finish(?:ed)?(?:\s+with)?|complete)\s+(?:the\s+)?(?:p\.?\s?o\.?|purchase\s+order)\s*(?:number|no\.?|#)?\s*[:#]?\s*(\d{4,12})\s*$/i))) {
            return { intent: 'close_po', resolvedBy: 'policy', data: { po: m[1] } };
        }
        // The list. Same principle as show_mutes: a ledger she cannot ask for
        // is one she has to wait for a digest to see.
        if (/^(?:show\s+)?(?:my\s+)?(?:open\s+)?(?:p\.?\s?o\.?s?|purchase\s+orders?)\s*\??$/i.test(ctx.text.trim())
            || /^(?:what|which)\s+(?:p\.?\s?o\.?s?|purchase\s+orders?)\s+(?:are\s+)?(?:open|live|outstanding|pending)\s*\??$/i.test(ctx.text.trim())) {
            return { intent: 'show_pos', resolvedBy: 'policy', data: {} };
        }
        // ── WHAT QUICKBOOKS IS STUCK ON (2026-10-02) ────────────────────
        // the owner: "Assign one agent for quickbook next". The 07:25 agent
        // emails her; this is the same answer when she asks for it, because
        // an agent you can only hear from on its own schedule is one you
        // check your inbox for.
        //
        // Policy-resolved rather than left to the model: these are the exact
        // words for a question with one meaning, and a classifier round trip
        // to decide them is latency and a chance to be wrong for nothing.
        //
        // READ FROM THE MORNING'S CHECK, not a fresh sweep — see
        // actions.showQuickBooksStuck. A chat answer must not quietly cost
        // thirty seconds and forty QuickBooks calls.
        if (/^(?:what(?:[’']?s| is)?\s+)?(?:stuck|blocked|pending|waiting)\s+(?:in|on|with)\s+(?:qb|quick\s?books)\s*\??$/i.test(ctx.text.trim())
            || /^(?:qb|quick\s?books)\s+(?:stuck|blocked|status|problems?|issues?)\s*\??$/i.test(ctx.text.trim())
            || /^what(?:[’']?s| is)?\s+(?:not|n[’']?t)\s+going\s+into\s+(?:qb|quick\s?books)\s*\??$/i.test(ctx.text.trim())
            || /^why\s+(?:is|are)?\s*(?:\w+\s+)?(?:not|n[’']?t)\s+in\s+(?:qb|quick\s?books)\s*\??$/i.test(ctx.text.trim())) {
            return { intent: 'qb_stuck', resolvedBy: 'policy', data: {} };
        }
        // ── THE COMMAND THE CLAIMS CHASE PROMISES (2026-10-02) ──────────
        // helpers/claimsAgentJob.js's morning message ends with
        // 'Say "draft claim <container>"'. The closePurchaseOrder rule: a
        // message that tells her to say something to a bot with no such
        // route is the same failure as the APK Jarvis once offered and could
        // not send. The promise IS the bug, so the route ships with the line.
        if ((m = ctx.text.trim().match(/^(?:draft|write|prepare)\s+(?:the\s+)?claim\s+(?:email\s+)?(?:for\s+)?([A-Za-z]{4}\d{6,7}|\S+)\s*$/i))) {
            return { intent: 'draft_claim', resolvedBy: 'policy', data: { container: m[1] } };
        }

        // The fresh check. This route exists because the answer above OFFERS
        // it — the closePurchaseOrder lesson: a message that says 'say X' to
        // a bot with no such route is the same class of failure as the APK
        // Jarvis once promised and could not send. The promise is the bug.
        if (/^(?:check|recheck|re-check|refresh|run)\s+(?:qb|quick\s?books)(?:\s+now)?\s*$/i.test(ctx.text.trim())
            || /^(?:check|run)\s+(?:qb|quick\s?books)\s+(?:again|check)\s*$/i.test(ctx.text.trim())) {
            return { intent: 'qb_check_now', resolvedBy: 'policy', data: {} };
        }

        // One PO's history. Requires the 4-12 digit shape, so "po 1" is not a
        // PO lookup — it is far more likely a digest index and must fall
        // through to the rules that handle those.
        if ((m = ctx.text.trim().match(/^(?:p\.?\s?o\.?|purchase\s+order)\s*(?:number|no\.?|#)?\s*[:#]?\s*(\d{4,12})\s*\??$/i))) {
            return { intent: 'show_po', resolvedBy: 'policy', data: { po: m[1] } };
        }

        // "ignore 3" / "ignore #3" / "dismiss 1 and 3" / "ignore 1,3" — the
        // question she asked directly: "if i say ignore 3, will it remove?"
        // At the time, no. This is that answer built. Same digest-index
        // resolution as "reply to N", same reasoning for checking it before
        // any general "ignore" phrasing gets near the AI — a bare number
        // must be read as a digest position, not a fresh classification.
        if ((m = ctx.text.trim().match(/^(?:please\s+)?(?:ignore|dismiss|skip|clear)\s+#?(\d{1,2}(?:\s*(?:,|and)\s*#?\d{1,2})*)\s*$/i))) {
            const indices = m[1].split(/,|\band\b/i).map((x) => x.trim()).filter(Boolean);
            return { intent: 'ignore_digest_item', resolvedBy: 'policy', data: { indices } };
        }
        // "clear older" / "clear the backlog" / "ignore the older ones" - the backlog
        // line's own suggestion (2026-10-28). Checked BEFORE "ignore all", which only
        // touches the numbered list she is looking at.
        if (/^(?:please\s+)?(?:clear|ignore|dismiss|drop)\s+(?:all\s+)?(?:the\s+)?(?:older(?:\s+(?:items?|ones|emails?|mails?))?|old\s+(?:items?|ones|emails?|mails?)|backlog)\s*$/i.test(ctx.text.trim())) {
            return { intent: 'clear_older_items', resolvedBy: 'policy', data: {} };
        }
        // "ignore all" / "ignore all of them" / "dismiss everything" — the
        // natural extension of the same question, thought through this time
        // rather than waiting for her to hit the gap and ask again.
        if (/^(?:please\s+)?(?:ignore|dismiss|skip|clear)\s+(?:all|everything|all of (?:it|them))\s*$/i.test(ctx.text.trim())) {
            return { intent: 'ignore_digest_item', resolvedBy: 'policy', data: { indices: null, all: true } };
        }

        // "reply to X about Y" / "reply to X's email about Y: Z" / "reply to X saying Z" —
        // finds a REAL prior email from X and replies inside that thread, not
        // a fresh compose. Deliberately checked before search_mail/draft_email
        // so "reply to..." always wins over the more general "email X..." shape.
        if ((m = ctx.text.trim().match(/^(?:please\s+)?reply\s+to\s+(.+?)(?:'s\s+(?:last\s+)?(?:email|mail|message))?(?:\s*[:\-]\s*|\s+(?:about|re|regarding|saying|and\s+say)\s+)(.+)$/i))) {
            const detailsBkg = resolveBookingNumber(m[2]);
            return {
                intent: 'reply_email', resolvedBy: 'policy',
                data: { target_name: m[1].trim(), email_details: m[2].trim(), bkg_no: detailsBkg || ctx.activeBooking || null },
            };
        }

        // "reply to Yurim" — a name and nothing else. Until 2026-09-19 this
        // shape had no rule and depended on the AI classifier reading it as a
        // reply; it is the first step of the flow the owner asked for ("if i say
        // reply to A ... show two mails ... ask which one"), so it is
        // deterministic now. Deliberately narrow: one to four plain words,
        // none of them a pronoun or a number — those are handled above.
        if ((m = ctx.text.trim().replace(/[.!?]+$/, '').match(/^(?:please\s+)?reply\s+to\s+([a-z][a-z'&.-]*(?:\s+[a-z][a-z'&.-]*){0,3})(?:'s\s+(?:last\s+|latest\s+)?(?:email|mail|message))?$/i))
            && !/^(?:that|this|it|them|him|her|me|us|all|everyone|everybody|every|each|any|the|a|an)\b/i.test(m[1])
            && !/\b(?:email|mail|message|one|thread)$/i.test(m[1])) {
            return { intent: 'reply_email', resolvedBy: 'policy',
                data: { target_name: m[1].trim(), email_details: null, bkg_no: null } };
        }

        // THE ONE PROPERTY that separates the inbox question from a search:
        // NO SENDER IS NAMED. It was previously re-expressed as a slightly
        // different lookahead on each pattern, and two of them were wrong —
        // "check my inbox for carrier" and "show me the digest from carrier" both
        // reached the inbox branch and would have answered a targeted question
        // with a generic dump. Stated once now, applied to every branch.
        //
        // "for any new mail" must NOT count as naming somebody, so the word
        // after the preposition is checked against the generic vocabulary she
        // actually uses when she means "everything".
        const GENERIC_AFTER_PREP = /^(?:any|new|all|my|me|the|a|an|today|todays|today's|this|that|those|these|unread|latest|pending|mails?|e?mails?|messages?|inbox|mail\s*box|repl(?:y|ies)|response|attention|action|now|it|them)\b/i;
        // EVERY preposition, not the first. "check my mailbox for mail from
        // Kristal" took the first "for", saw the generic word "mail", and
        // declared nobody named — burying a question about Kristal under the
        // whole inbox. Any one non-generic follower is enough.
        const namesSomeone = (t) => {
            const text = String(t || '').trim();
            const re = /\b(?:from|for|by)\s+(\S.*)$/gi;
            let m;
            while ((m = re.exec(text)) !== null) {
                if (!GENERIC_AFTER_PREP.test(m[1].trim())) return true;
                // Advance past this preposition so the next one is examined
                // rather than the regex restarting at the same spot.
                re.lastIndex = m.index + m[0].indexOf(' ') + 1;
            }
            return false;
        };

        // "what needs my reply" / "any emails waiting on me" / "check my inbox"
        // — the on-demand version of the hourly scan in workflow/replyWatch.js.
        // Deterministic because the phrasing set here really is small and
        // closed (she is asking one specific question about her own inbox),
        // and it must never be confused with search_mail, which looks for
        // mail from a NAMED sender. The distinction that keeps them apart:
        // this rule requires NO sender name anywhere, so "any mail from
        // carrier" cannot match it.
        if (/^(?:what|which|any|anything)?\s*(?:emails?|mails?)?\s*(?:do\s+i\s+|that\s+)?(?:needs?|requires?|waiting\s+(?:on|for))\s*(?:my\s+|a\s+)?(?:reply|response|answer|attention)\b/i.test(ctx.text.trim())
            // "mailbox" was missing, and the trailing-text case with it —
            // LIVE 2026-08-29: "Check my mailbox for any new mail" fell through
            // to the AI, which summarised two random payment debits as "new
            // mail". The \b anchor stopped at the noun, so anything after it
            // missed. Trailing text is allowed now as long as no sender is
            // named — see the negative tests.
            || /^(?:check|show|list|see|give\s+me|pull\s+up|open)\s+(?:me\s+)?(?:my\s+|the\s+)?(?:inbox|mail\s*box|unreplied|pending\s+e?mails?)\b/i.test(ctx.text.trim())
            // "Email digest" — LIVE 2026-08-29, answered with "I can help with
            // that. What specifically would you like to see in the email
            // digest?" A clarifying question about the ONE thing the digest is.
            // She named the feature by its name; there is nothing to clarify.
            || /^(?:the\s+|my\s+|todays?\s+|today'?s\s+)?(?:e?mail\s+)?digest\b|^(?:show|send|give)\s+(?:me\s+)?(?:the\s+|my\s+)?(?:e?mail\s+)?digest\b/i.test(ctx.text.trim())
            // "All mails received today which needed my attentiom" (sic) —
            // LIVE 2026-08-29, searched the inbox for that whole sentence.
            // Anything of the shape "<mail words> ... need/require my
            // attention/reply/action" with no sender named.
            // "needing" was missed by need(?:ed|s)? — a live phrasing gap.
            || (/(?:e?mails?|messages?|inbox|mail\s*box)/i.test(ctx.text)
                && /need(?:ed|s|ing)?\s+my\s+(?:atten\w*|repl\w*|response|action|input|eyes)/i.test(ctx.text))
            // LIVE, 2026-08-29 01:16 — "Any new mails?" answered with
            // "No matching emails found re \"new mails\"." The AI path chose
            // search_mail with target_name NULL and note "new mails", i.e. it
            // hunted the inbox for the phrase she used to ask the question.
            //
            // The closed phrasing set this branch was built for was simply too
            // narrow: it covers "what needs my reply" and "check my inbox" but
            // not the shortest, most natural way to ask — "any new mails?".
            // Still requires NO sender anywhere, so "any mail from carrier"
            // cannot reach it.
            || /^(?:so\s+)?(?:any|anything|got|is\s+there|are\s+there|whats?|what'?s)\s*(?:new|any)?\s*(?:e?mails?|messages?|inbox)\s*(?:\?|today|new|come\s+in|arrived?|yet)?\s*\??$/i.test(ctx.text.trim())
            || /^(?:any|anything)\s+new\b(?:\s+in\s+(?:the\s+)?(?:mail|inbox|email))?\s*\??$/i.test(ctx.text.trim())
            // Bare "New mails?" and "whats new in mail" — the same question
            // with the "any" dropped. Both still require no sender.
            || /^(?:new|latest|unread)\s+(?:e?mails?|messages?)\s*\??$/i.test(ctx.text.trim())
            || /^(?:what'?s|whats|anything)\s+new\s+(?:in|with|on)\s+(?:the\s+|my\s+)?(?:mail|inbox|e?mails?)\s*\??$/i.test(ctx.text.trim())
            || /^(?:what|anything)\s+(?:is\s+)?(?:waiting|pending)\s+on\s+me\b/i.test(ctx.text.trim())
            // Her recording, 2026-09-20: "check my mail" and "is there any
            // mail that we have received" both fell through to the model.
            // Still gated below on no sender being named.
            || /^(?:check|show|read|see)\s+(?:me\s+)?(?:my\s+|the\s+|our\s+)?(?:new\s+)?(?:e-?mails?|mails?)\s*\??$/i.test(ctx.text.trim())
            || /^(?:is|are)\s+there\s+(?:any\s+)?(?:new\s+)?(?:e-?mails?|mails?|messages?)\b(?:\s+(?:that\s+)?(?:we(?:'ve|\s+have)?|i(?:'ve|\s+have)?)\s+(?:received|got(?:ten)?))?(?:\s+today)?\s*\??$/i.test(ctx.text.trim())
            || /^(?:did|have)\s+(?:we|i)\s+(?:receive[d]?|get|got(?:ten)?)\s+(?:any\s+)?(?:new\s+)?(?:e-?mails?|mails?)(?:\s+today)?\s*\??$/i.test(ctx.text.trim())) {
            return namesSomeone(ctx.text)
                // She named somebody — this is a targeted question, and
                // answering it with the whole inbox would bury the one thread
                // she asked about. Let the AI path pick search_mail.
                ? { needsAI: true, resolvedBy: 'policy' }
                : { intent: 'show_pending_replies', resolvedBy: 'policy', data: {} };
        }

        // "did X reply about Y" / "has X replied" / "search mail for X about Y" /
        // "check email from X about Y" — read-only Gmail search, answered
        // directly. No pending/confirmation needed, nothing is sent or changed.
        if ((m = ctx.text.trim().match(/^(?:did|has)\s+(.+?)\s+repl(?:y|ied)(?:\s+yet)?(?:\s+(?:about|re|regarding)\s+(.+))?\??$/i)) ||
            (m = ctx.text.trim().match(/^(?:search|check)\s+(?:mail|emails?)\s+(?:for|from)\s+(.+?)(?:\s+(?:about|re|regarding)\s+(.+))?$/i))) {
            const detailsBkg = m[2] ? resolveBookingNumber(m[2]) : null;
            return {
                intent: 'search_mail', resolvedBy: 'policy',
                data: { target_name: m[1].trim(), note: m[2] ? m[2].trim() : null, bkg_no: detailsBkg || ctx.activeBooking || null },
            };
        }

        // NOTE (2026-08-22, per the owner: "I don't want to hardcode anything.
        // Let AI decide. both are same meaning"): a regex for the phrasing
        // "check whether we received any mail from carrier recently" was
        // written here and then deliberately REMOVED. It worked, but it was
        // the wrong layer — "did carrier reply" and "did we receive any mail
        // from carrier" mean the same thing, and adding a new pattern for
        // every way of saying the same thing is an endless treadmill that
        // still loses to the next unanticipated phrasing. Semantic
        // equivalence is exactly what the AI classifier is for; the two
        // patterns above are kept only because they already existed and
        // work, not as a model to extend. Anything they don't match now
        // falls through to aiDecide, whose prompt carries explicit guidance
        // for recognizing mail-receipt questions in ANY phrasing.

        // ── "send the documents for HMMU7060866" ────────────────────────────
        // the owner, 2026-09-17: "now once the invoice and packing list is
        // created -when i give command to jarvis to send--->it should able to
        // mail customer with documents..", naming the shipment BY CONTAINER
        // NUMBER.
        //
        // This is a narrow pattern ON PURPOSE, and it is not the treadmill the
        // note above warns against. It keys on a CONTAINER NUMBER — ISO 6346,
        // four letters and seven digits — which is an identifier with a fixed
        // shape, not a phrasing. Nothing else she says looks like one, so
        // there is no second pattern to add next week for a different way of
        // wording it. Every OTHER phrasing falls through to aiDecide, which
        // carries this intent too.
        //
        // It must sit ABOVE the "email X about Y" rule: "email eccomelt about
        // HMMU7060866" matches both, and the document send is the specific
        // one. It stages a confirmation — nothing here sends.
        // ── IT REQUIRES A DOCUMENT WORD, AND THAT IS DELIBERATE ─────────────
        // A bare "send HMMU7060866" is NOT claimed here. That form already
        // belongs to forward_booking, which has been forwarding bookings on
        // "send <number>" for months, and a booking number can be four
        // letters and seven digits just as a container can. Taking the bare
        // form would have been me changing behaviour she did not ask to
        // change, to support a phrasing I invented — hers was "send the
        // documents for HMMU7060866".
        //
        // So: a container number AND one of the document words. If she ever
        // wants the bare form too, it is a one-line change, but it is her
        // call and not mine.
        // ── "GENERATE INVOICE FOR THE INESH CONTAINER" ─────────────────
        // the owner, 2026-09-21. The decision lives in
        // helpers/saleInvoiceFlow.saleInvoiceRequest, shared with the voice
        // route: a making verb and "invoice", no proforma/send/payment word,
        // no question. Her rule the same day: "invoice should not create
        // proforma" — a proforma is asked for by name.
        {
            let req = null;
            try { req = require('../helpers/saleInvoiceFlow').saleInvoiceRequest(ctx.text); } catch (e) { req = null; }
            if (req) {
                return { intent: 'generate_sale_invoice', resolvedBy: 'policy',
                    data: { container_no: req.container, target_name: req.target } };
            }
        }

        if (/\b(send|email|mail)\b/i.test(t)
            && /\b(doc|docs|document|documents|invoice|packing|paperwork)\b/i.test(t)
            && !/\b(bol|bill of lading|quote|pricelist|price list|proforma)\b/i.test(t)
            && (m = ctx.text.match(/\b([A-Z]{4}\s?\d{7})\b/i))) {
            return {
                intent: 'send_shipment_docs', resolvedBy: 'policy',
                data: { container_no: m[1].replace(/\s+/g, '').toUpperCase() },
            };
        }

        // "email X about Y" / "email X re Y" / "please email X regarding Y" —
        // manager explicitly instructing an outbound email. Uses ctx.text (not
        // lowercased t) so the details clause keeps its original casing for the
        // draft. Never sends directly — draftEmailForConfirm always stages a
        // yes/no confirmation first; this regex only gets that flow started.
        if ((m = ctx.text.trim().match(/^(?:please\s+)?email\s+(.+?)\s+(?:about|re|regarding)\s+(.+)$/i))) {
            const detailsBkg = resolveBookingNumber(m[2]);
            return {
                intent: 'draft_email', resolvedBy: 'policy',
                data: { target_name: m[1].trim(), email_details: m[2].trim(), bkg_no: detailsBkg || ctx.activeBooking || null },
            };
        }

        // "how many bookings [are] unassigned from LA" / "how many bookings from LA" etc.
        if ((m = t.match(/^how\s+many\s+(?:(unassigned|available|assigned|no\s+supplier|without\s+(?:a\s+)?supplier)\s+)?bookings?\s*(?:are\s+|do\s+we\s+have\s+)?(?:(unassigned|available|assigned|no\s+supplier|without\s+(?:a\s+)?supplier)\s+)?(?:from|at|in)\s+(.+?)\??$/))) {
            const statusRaw = (m[1] || m[2] || '').trim();
            const filter = /unassigned|available|no\s+supplier|without/.test(statusRaw) ? 'unassigned'
                         : statusRaw === 'assigned' ? 'assigned' : null;
            return { intent: 'bookings_count_query', resolvedBy: 'policy', data: { location: m[3].trim(), filter } };
        }

        // "show/list [unassigned] bookings from LA" — same filter logic as above,
        // but returns the actual list, not just a count.
        if ((m = t.match(/^(?:show(?:\s+me)?|list)\s+(?:(unassigned|available|assigned|no\s+supplier|without\s+(?:a\s+)?supplier)\s+)?bookings?\s*(?:that\s+are\s+)?(?:(unassigned|available|assigned|no\s+supplier|without\s+(?:a\s+)?supplier)\s+)?(?:from|at|in)\s+(.+?)\??$/))) {
            const statusRaw = (m[1] || m[2] || '').trim();
            const filter = /unassigned|available|no\s+supplier|without/.test(statusRaw) ? 'unassigned'
                         : statusRaw === 'assigned' ? 'assigned' : null;
            return { intent: 'bookings_list_query', resolvedBy: 'policy', data: { location: m[3].trim(), filter } };
        }

        // "remember X" / "note X" / "remember that X" — explicit standing-fact capture.
        // ctx.text (not lowercased t) preserves the original casing of the fact itself.
        if ((m = ctx.text.trim().match(/^(?:please\s+)?(?:remember|note)(?:\s+that)?:?\s+(.+)$/i)))
            return { intent: 'remember_fact', resolvedBy: 'policy', data: { fact: m[1].trim() } };


        // "business context: X" / "context note: X" — durable situational notes,
        // deliberately a different trigger phrase from remember/note (facts).
        if ((m = ctx.text.trim().match(/^(?:business\s+context|context\s+note)\s*:\s*(.+)$/i)))
            return { intent: 'add_business_context', resolvedBy: 'policy', data: { note: m[1].trim() } };

        // "check supplier BKG123" — pings the supplier for pickup readiness
        if ((m = t.match(/^check\s+supplier\s+(\S+)$/)))
            return { intent: 'check_supplier', resolvedBy: 'policy', data: { bkg_no: m[1].toUpperCase() } };

        // "send price list" / "send price list to X" / "price list" — always
        // asks which city (Los Angeles / Houston / San Antonio) before sending,
        // regardless of whether a target was named. Target is optional — if
        // omitted, the list goes back to whoever asked. Resolution happens in
        // actions.js/helpers/pricelist.js, not here — policy only extracts the
        // target string (if any). Deliberately kept OUT of the Gemini/llm-intent
        // path (see helpers/pricelist.js header).
        if ((m = t.match(/^(?:send\s+)?price\s*list(?:\s+(?:to\s+)?(.+))?$/)) ||
            (m = t.match(/^send\s+prices?(?:\s+to\s+(.+))?$/)))
            return { intent: 'ask_pricelist_city', resolvedBy: 'policy', data: { target_name: m[1] ? m[1].trim() : null } };

        // ── A PASTED LINK: ASK, DO NOT GUESS ────────────────────────────
        // the owner, 2026-08-27, on the sheet-link bug: "it should have asked
        // instead."
        //
        // 62821e0 stopped the WRONG answer ("No booking found for
        // 5550100101", the sheet's tab id). That left the right answer
        // missing: a link she has deliberately pasted is her handing Jarvis
        // something, and the only honest response when we cannot tell what
        // for is to ask.
        //
        // Manager/team only — this whole section is inside that gate. A
        // trucker pasting a tracking link must keep flowing to the paths that
        // already handle counterparty messages; interrogating them would be a
        // new and unwanted behaviour on a lane that works.
        if (isBareUrl(ctx.text)) {
            return { intent: 'ask_link_purpose', resolvedBy: 'policy', data: { url: ctx.text.trim() } };
        }

        // Bare booking number → status.
        //
        // The single-token check used to be the ONLY guard here, and a pasted
        // URL is a single token — that is how a Google Sheets link became
        // "No booking found for 5550100101" (the gid). resolveBookingNumber
        // strips URLs now, so this is belt and braces: even if a link ever did
        // contain something booking-shaped, a bare link is not her asking for
        // a status.
        const bkg = isBareUrl(ctx.text) ? null : resolveBookingNumber(ctx.text);
        if (bkg && t.split(/\s+/).length === 1)
            return { intent: 'show_booking_status', resolvedBy: 'policy', data: { bkg_no: bkg } };
    }

    // ── B2. Trucker/supplier "menu" and bare-digit replies — silent, not a
    // menu display. Menu grammar (Section B above) only applies to
    // manager/team; a trucker sending "menu" or a bare digit like "1" used
    // to fall through to the AI, which had no context for what a digit
    // should mean and kept re-showing show_menu — an infinite loop with no
    // progress. The manager's menu (forward/assign/etc.) isn't even
    // meaningful for a trucker anyway, so silence is correct here, not a
    // fallback menu — there's no real trucker menu to show yet.
    if ((ctx.isTrucker || ctx.isSupplier) && (t === 'menu' || /^\d+$/.test(t))) {
        return { intent: 'silent', resolvedBy: 'policy' };
    }

    // ── C. Trucker signals — with per-container disambiguation ───────────────
    // Trucker types a state message ("empty dropped"). We need to figure out:
    //   which booking, and which container within that booking.
    // Options:
    //   0 active assignments → silent (out-of-scope)
    //   1 booking + 1 container → auto-apply
    //   1 booking + 2+ containers matching stage → ask "which container?"
    //   2+ bookings → ask "which booking?" first
    if (ctx.isTrucker) {
        const containers = require('../helpers/containers');
        const { loadBookings } = require('../helpers/json');
        const bookings = loadBookings();
        const truckerName = ctx.matchedTrucker?.name;

        // Which state intent is this message? Returns {kind, requiredStage} or null.
        const classify = () => {
            if (ctx.hasMedia) {
                // Media alone can't tell us the stage — infer from what containers this trucker has.
                // Pick the most-common current stage among their assignments; brain uses that to route.
                return { kind: 'media', requiredStage: null };
            }
            if (/(empty|dropped)/.test(t))               return { kind: 'empty_drop',   requiredStage: 'forwarded' };
            if (/(picked\s*up|loaded)/.test(t))          return { kind: 'picked_up',    requiredStage: 'load_ready' };
            if (/(scale|ticket)/.test(t))                return { kind: 'scale_ticket', requiredStage: 'picked_up' };
            if (/(ingate|in-gate|gated)/.test(t))        return { kind: 'ingate',       requiredStage: 'picked_up' };
            return null;
        };

        const stateSig = classify();
        if (stateSig) {
            // Find every active (in-progress) container this trucker owns.
            const active = truckerName
                ? containers.findActiveAssignments(bookings, 'trucker', truckerName)
                : [];

            // Filter to those matching the required stage (empty-drop only from forwarded containers, etc).
            // For media (kind='media'), don't stage-filter — accept any active assignment.
            const matches = stateSig.kind === 'media'
                ? active
                : active.filter(a => (a.container.stage || 'not_started') === stateSig.requiredStage);

            if (matches.length === 0) {
                // Trucker used a state keyword but has no matching container. Silent (whitelist rule).
                return { intent: 'silent', resolvedBy: 'policy', data: {} };
            }

            // For 'media' with mixed stages, prefer inferring the actual state.
            let stageKind = stateSig.kind;
            if (stageKind === 'media') {
                // Auto-pick based on the container's current stage.
                const stagesInMatches = new Set(matches.map(m => m.container.stage));
                if      (stagesInMatches.has('forwarded'))     stageKind = 'empty_drop';
                else if (stagesInMatches.has('load_ready'))    stageKind = 'picked_up';
                else if (stagesInMatches.has('picked_up'))     stageKind = 'ingate';
                else return { intent: 'silent', resolvedBy: 'policy', data: {} };
            }

            const intentName =
                stageKind === 'empty_drop'   ? 'empty_drop_confirmed' :
                stageKind === 'picked_up'    ? 'picked_up_confirmed'  :
                stageKind === 'scale_ticket' ? 'scale_ticket_received':
                                               'ingate_received';

            // Count DISTINCT bookings in matches.
            const bookingsInMatches = [...new Set(matches.map(m => m.bookingNumber))];

            // Case 1: 1 booking, 1 matching container → auto-apply.
            if (bookingsInMatches.length === 1 && matches.length === 1) {
                return { intent: intentName, resolvedBy: 'policy',
                         data: { bkg_no: matches[0].bookingNumber, container_seq: matches[0].container.seq,
                                 scale_ticket: stageKind === 'picked_up' && stateSig.kind === 'media' } };
            }

            // Case 2: 1 booking, 2+ matching containers → ask which container.
            if (bookingsInMatches.length === 1) {
                return { intent: 'ask_which_container', resolvedBy: 'policy',
                         data: { bkg_no: bookingsInMatches[0], intent_to_resolve: intentName,
                                 has_media: !!ctx.hasMedia,
                                 container_options: matches.map(m => m.container.seq) } };
            }

            // Case 3: 2+ bookings → ask which booking first.
            return { intent: 'ask_which_booking', resolvedBy: 'policy',
                     data: { intent_to_resolve: intentName, has_media: !!ctx.hasMedia,
                             booking_options: bookingsInMatches } };
        }

        // Info queries — trucker asks ERD / cutoff. Requires activeBooking (single-container heuristic).
        if (ctx.activeBooking) {
            if (/\berd\b/.test(t))
                return { intent: 'trucker_ask_erd', resolvedBy: 'policy', data: { bkg_no: ctx.activeBooking } };
            if (/(cut\s*off|cutoff)/.test(t))
                return { intent: 'trucker_ask_cutoff', resolvedBy: 'policy', data: { bkg_no: ctx.activeBooking } };
        }
        // No keyword matched at all — this is genuinely unrecognized free text (e.g. "truck broke
        // down"), not a known-shape message with nothing to do. Let AI take a pass; if AI also
        // can't classify it, route()'s NEED_DATA fallback escalates to the manager.
        return { intent: null, resolvedBy: null, needsAI: true };
    }

    // ── D. Supplier signals ──────────────────────────────────────────────────
    if (ctx.isSupplier) {
        const containers = require('../helpers/containers');
        const { loadBookings } = require('../helpers/json');
        const bookings = loadBookings();
        const supplierName = ctx.matchedSupplier?.name;

        // Supplier fires "load ready" — must be on a container currently at supplier_assigned or empty_dropped.
        if (/(load\s*ready|loaded|ready)/.test(t)) {
            const rawActive = supplierName
                ? containers.findActiveAssignments(bookings, 'supplier', supplierName, ['supplier_assigned','empty_dropped'])
                : [];
            if (rawActive.length === 0) return { intent: 'silent', resolvedBy: 'policy', data: {} };

            // 2026-08-18 fix (per the owner: "if a booking number is assigned to
            // that supplier and it is in empty dropped/container number
            // already assigned against that booking — it should not ask
            // which booking number to supplier"). WORKFLOW_STAGES order is
            // supplier_assigned → forwarded → empty_dropped → load_ready —
            // a container still sitting at supplier_assigned hasn't even
            // been dropped yet, so it's not a real candidate for "load
            // ready" once a container has actually reached empty_dropped
            // (with a container number on file). Narrow to those first;
            // only fall back to the full (less-advanced) set if nothing has
            // reached empty_dropped yet, preserving prior ask-which-one
            // behavior for that genuinely-ambiguous case.
            const droppedWithContainer = rawActive.filter(
                m => m.container.stage === 'empty_dropped' && m.container.container_number
            );
            const active = droppedWithContainer.length ? droppedWithContainer : rawActive;

            const bookingsInMatches = [...new Set(active.map(m => m.bookingNumber))];

            if (bookingsInMatches.length === 1 && active.length === 1) {
                return { intent: 'load_ready_received', resolvedBy: 'policy',
                         data: { bkg_no: active[0].bookingNumber, container_seq: active[0].container.seq } };
            }

            if (bookingsInMatches.length === 1) {
                return { intent: 'ask_which_container', resolvedBy: 'policy',
                         data: { bkg_no: bookingsInMatches[0], intent_to_resolve: 'load_ready_received',
                                 has_media: false, container_options: active.map(m => m.container.seq) } };
            }

            return { intent: 'ask_which_booking', resolvedBy: 'policy',
                     data: { intent_to_resolve: 'load_ready_received', has_media: false,
                             booking_options: bookingsInMatches } };
        }

        // Info queries scoped to activeBooking (single-container heuristic).
        if (ctx.activeBooking) {
            if (/\berd\b/.test(t))
                return { intent: 'supplier_ask_erd', resolvedBy: 'policy', data: { bkg_no: ctx.activeBooking } };
            if (/(cut\s*off|cutoff)/.test(t))
                return { intent: 'supplier_ask_cutoff', resolvedBy: 'policy', data: { bkg_no: ctx.activeBooking } };
        }
        // Same rule as trucker section: unrecognized free text goes to AI, not hard silence.
        return { intent: null, resolvedBy: null, needsAI: true };
    }

    // ── D2. Yard/scale staff — standalone capture channel, independent of the
    // trucker/booking workflow above. A photo triggers Gemini extraction into
    // its own record (helpers/scaleTickets.js); never touches bookings.json
    // or workflow.json. Yard staff aren't expected to type commands, so any
    // non-media text is just acknowledged, not run through AI fallback —
    // keeps this channel narrow and cheap (no Gemini call on stray "ok"s).
    if (ctx.isYard) {
        if (ctx.hasMedia && ctx.mediaBase64) {
            return { intent: 'yard_scale_ticket_received', resolvedBy: 'policy',
                     data: { image_base64: ctx.mediaBase64, mime_type: ctx.mediaMimeType } };
        }
        if (ctx.hasMedia && !ctx.mediaBase64) {
            // Media flagged but bytes weren't captured (download failed, or it
            // wasn't an image — see index.js's message handler). Ask to resend
            // rather than silently dropping it.
            return { intent: 'reply', resolvedBy: 'policy',
                     data: { reply: "Couldn't read that — please resend the scale ticket as a photo." } };
        }
        return { intent: 'silent', resolvedBy: 'policy', data: {} };
    }

    // ── D2. The manager sent a FILE Jarvis cannot open ───────────────────────
    // A REAL INCIDENT (2026-08-29). She sent SampleYardCoYard-v2.9-debug.apk. Nothing
    // in index.js downloads a document — the image branch is scoped to yard
    // staff, the audio branch to voice notes — so the bytes never entered the
    // process at all. With no coded handler the message fell through to
    // Gemini, which improvised: "I can help you manage your files. What would
    // you like to do with the SampleYardCoYard-v2.9-debug.apk file?"
    //
    // That sentence is a FALSE PROMISE, and it is worse than a refusal. She
    // believed it, answered "forward to (555) 010-0100", and got "What should I
    // send to (555) 010-0100?" — because send_message carries text only and the
    // file was never anywhere. Two wasted turns and a capability that does
    // not exist, announced in the first person.
    //
    // This is the fourth instance of the pattern her own note at
    // actions.js:4966 names: the model can only pick from an exhaustive
    // action list, so a missing capability surfaces as either a refusal or,
    // worse, an invention. Until forwarding files actually exists, say so.
    //
    // SCOPE, deliberately narrow — everything below was checked before this
    // was added, because each one is a live path that must not change:
    //   · yard scale tickets return above (isYard branch) and never reach here
    //   · truckers/suppliers are not isManagerOrTeam, so their media is untouched
    //   · any pendingAction awaiting an image resolves at lines ~499-610, far
    //     above this, so a quote's scale-ticket upload still works
    //   · VOICE NOTES keep hasMedia:true after transcription in index.js, so
    //     excluding ptt/audio here is load-bearing — without it every voice
    //     note would be answered with "I can't open that file"
    //   · a document WITH a caption carries a real instruction; `t` is
    //     non-empty then and this stays out of the way
    if (ctx.isManagerOrTeam && ctx.hasMedia && !ctx.mediaBase64 && !t
        && !['ptt', 'audio'].includes(String(ctx.mediaType || '').toLowerCase())) {
        return {
            intent: 'reply', resolvedBy: 'policy',
            data: { reply: "I can see you sent a file, but I can't open or forward attachments — "
                + "they never reach me, only the fact that something was sent. "
                + "Tell me what you need in words and I'll do that part." },
        };
    }

    // ── E. Trucker/supplier with multiple bookings and a booking no. in text ──
    if ((ctx.isTrucker || ctx.isSupplier) && !ctx.activeBooking && ctx.activeSlots.length > 1) {
        const bkg = resolveBookingNumber(ctx.text);
        if (!bkg) return { intent: 'ask_which_booking', resolvedBy: 'policy', data: { slots: ctx.activeSlots.map(s => s.bkgNo) } };
        // re-run C/D logic with explicit booking — hand to AI with strong hint instead of duplicating
    }

    // ── F. Bare location follow-up to a just-shown bookings listing ───────────
    // "show available bookings" → "from oakland" / "for oakland" / "Oakland"
    // (no "show/list/how many" wrapper) should narrow the SAME query, not
    // repeat it unfiltered. Guarded tightly: only fires for manager/team, only
    // right after a bookings query, and only for short alphabetic text with no
    // question/reference words — a real follow-up QUESTION like "whats its
    // erd" must never be swallowed as if it were a location name.
    if (ctx.isManagerOrTeam && ctx.session?.lastInstruction === 'bookings_query') {
        const stripped = t.replace(/^(?:from|at|in|for)\s+/, '').trim();
        const words = stripped.split(/\s+/).filter(Boolean);
        const wordCount = words.length;
        const QUESTION_WORDS = new Set([
            'what', 'whats', "what's", 'why', 'when', 'where', 'who', 'whos', "who's", 'how',
            'its', 'it', "it's", 'his', 'her', 'their', 'is', 'are', 'was', 'were',
            'does', 'do', 'did', 'can', 'could', 'would', 'should', 'will',
        ]);
        const hasQuestionWord = words.some(w => QUESTION_WORDS.has(w));
        // Known command words must never be swallowed as a location
        // follow-up, no matter how stale ctx.session.lastInstruction is —
        // a real bug found via simulation: "show contacts", sent well
        // after an earlier bookings query, matched this heuristic (short,
        // letters-only, no question word) and got treated as a location
        // filter instead of the contacts command it actually was. Strips
        // a "show "/"list " prefix before checking — an EXACT array match
        // on the raw stripped text alone would miss "show contacts" even
        // with "contacts" in the list, since they're different strings.
        const withoutVerb = stripped.replace(/^(?:show(?:\s+me)?|list)\s+/, '');
        const KNOWN_COMMANDS = new Set(['yes','no','ok','okay','thanks','thank you','hi','hello','menu','cancel',
             'contacts','truckers','suppliers','bookings','status','help','urgent',
             'available','recall','archive','price list','pricelist']);
        const isKnownCommand = KNOWN_COMMANDS.has(stripped) || KNOWN_COMMANDS.has(withoutVerb);
        const looksLikeLocation = stripped.length >= 2 && wordCount <= 3 && !hasQuestionWord
            && /^[a-z\s.'-]+$/i.test(stripped) && !isKnownCommand;
        if (looksLikeLocation) {
            return {
                intent: 'bookings_list_query', resolvedBy: 'policy',
                data: { location: stripped, filter: ctx.session.lastBookingsFilter ?? null },
            };
        }
    }

    // 2026-08-18, per the owner: nothing in the deterministic command grammar
    // above matched, which is normally where the AI fallback takes a pass
    // at answering freely (general knowledge, sample-metals-specific
    // questions, etc. — see the AI prompt's manager/team instructions). But
    // if this manager/team message landed in an EXTERNAL party's own
    // channel (a trucker/supplier/contact's group, or the shared default
    // trucker/supplier group) rather than the internal team group or her
    // own personal chat, that generic answering is exactly what she doesn't
    // want — a message like "Need scale ticket?" typed straight to a
    // trucker shouldn't get an unrelated bot reply injected into that
    // conversation. Stay silent there instead of asking the AI to guess.
    if (ctx.isManagerOrTeam && ctx.isExternalPartyGroup) {
        return { intent: 'silent', resolvedBy: 'policy', data: {} };
    }

    return { intent: null, resolvedBy: null, needsAI: true };
}

// ── Step 3: AI fallback ───────────────────────────────────────────────────────
async function buildPrompt(ctx) {
    const a = await formatForAI(ctx);
    // Things she has already told Jarvis that share distinctive words with this message
    // (helpers/saidBefore.js). Advisory history for her own people only; '' when none.
    let said = '';
    try { if (ctx.isManagerOrTeam) said = require('../helpers/saidBefore').block(ctx.text, { messageId: ctx.messageId }); } catch (e) { said = ''; }
    return `You are Jarvis — the freight operations AI for Sample Yard Co Metals Inc.
You are one step in a pipeline. The policy layer already handled deterministic cases.
You are called because the message intent is ambiguous.

STRICT RULES:
- You reach this prompt ONLY when the deterministic command grammar found no exact match — that's expected for typos, informal phrasing, or wording it doesn't anticipate, NOT a sign the message is unintelligible. Read past spelling: "bookking" means "booking", "avilable" means "available", "shw me" means "show me". If the corrected reading maps clearly onto one of the AVAILABLE ACTIONS below, use that action confidently — do not fall back to NEED_DATA or a generic "couldn't understand" reply just because the exact letters didn't match a pattern. A real assistant reads intent through typos; only use NEED_DATA when the actual MEANING is genuinely ambiguous or missing information, never because of spelling.
- SEMANTIC MEMORY entries are a similarity-based RECALL AID, not verified fact — they were embedded from past session summaries, which are themselves brief and can be stale, superseded, or only loosely related despite the similarity score. Use them to inform tone and continuity ("last time this came up, X was the concern") and to jog what to ask about, but NEVER state something from semantic memory as current fact — always verify against ALL ACTIVE BOOKINGS / FACTS / BUSINESS CONTEXT for anything that could have changed since. If semantic memory conflicts with current data, current data wins, always, and it's worth surfacing the conflict ("last time it was assigned to X, but it now shows unassigned — did that change?") rather than silently picking one.
- For anything specific to Sample Yard Co Metals' own data — booking status, dates, who's assigned, counts, contacts — use ONLY the context below. The ALL ACTIVE BOOKINGS / PORT SUMMARY / TRUCKERS ON FILE / SUPPLIERS ON FILE sections are your complete knowledge base for everything currently active — search across ALL of it, not just activeBooking, before saying you don't know. Never invent or guess a fact that isn't there.
- Archived/completed bookings are NOT included in the context above (kept out to bound token cost). If a question is plausibly about an older/closed booking not in ALL ACTIVE BOOKINGS, say it may be archived and suggest checking the dashboard → History — do not guess, and do not claim it doesn't exist.
- For general freight/logistics knowledge NOT specific to Sample Yard Co Metals' data (e.g. "what does FCL mean", "what happens if we miss cutoff", "typical transit time LA to Busan", "what's a bill of lading") — answer from your own general knowledge via "reply", like a knowledgeable freight ops assistant would. Don't refuse or say NEED_DATA just because it's not in the context block; that restriction is only for YOUR business's specific data, not general domain expertise. If mixing the two, clearly ground the business-specific part in context and flag anything you're unsure of.
- If required fields are missing, return action: "NEED_DATA".
- If the action is irreversible or high-risk, return action: "NEED_APPROVAL".
- Never return free text outside the JSON.
- Do not assume media exists unless hasMedia is true.
- Do not assume a booking is active unless activeBooking is set.
- The AVAILABLE ACTIONS list is EXHAUSTIVE — never invent an action name not on it, even one that seems reasonable. If the manager wants a question relayed to a trucker/supplier and an answer brought back ("ask him whether X", "check with the supplier about Y"), use "ask_contact": target_name = who to ask, bkg_no = the booking if relevant, note = the exact question to send. This sets up a proper pending so their reply gets relayed back to whoever asked, instead of silently landing as an unrelated ambiguous message. "schedule_followup" is a WhatsApp nudge sent later to a trucker or supplier. "draft_email" is for when the manager explicitly asks you to email someone (e.g. "email carrier about DALA123's cutoff") — target_name = who to email, email_details = what it should say, bkg_no = the booking if relevant. CRITICAL: target_name is ALWAYS exactly the name/company the manager said, verbatim — a bare first name like "Mike" stays "Mike". If the manager typed a company name as ONE compressed word (e.g. "mkmetaltrading"), keep it as that exact one word rather than respacing it to "mk metal trading" — not because the expansion is wrong (MK Metal Trading is the real company; reading it that way is correct), but because passing her spelling through unchanged is simply the most faithful thing to do, and lookup now handles either form. Name matching ignores spacing and punctuation entirely (see helpers/nameMatch.js), so both spellings resolve to the same record and nothing breaks either way. Preserve the manager's exact spelling and spacing. To be clear about what "verbatim" governs: it fixes HOW you spell the name once you have identified it — never widen it into HOW MUCH of the sentence you copy. Decide which words are the name by understanding the sentence, then reproduce exactly those words unaltered. "any mail from carrier recently" is carrier; "recently" is her telling you when, not part of the company's name, and no rule here asks you to keep it. Reproduce faithfully, do not over-copy, whatever it is. NEVER invent, guess, or auto-complete an email address into target_name (e.g. turning "Mike" into "mike@example.com" or "mike@gmail.com") — you do not know their real address, and a fabricated one silently sent to would be a serious mistake. target_name may ONLY be a full email address if that literal address string is actually present in the manager's message. Actual address lookup (saved contacts, mail search, or asking the manager directly) is handled separately, after your classification — that is not your job here. SAME RULE for email_details: it is ONLY what the manager actually said the email should say — if they gave no content at all (e.g. "send mail to sample" with nothing else), email_details MUST be null. Do NOT invent a plausible-sounding reason or message ("just checking in", "I miss you", or similar filler) — a real incident already happened where this produced a fabricated "I miss you" email nobody asked for. Leaving email_details null is always correct when nothing was actually said; a downstream step handles that case properly (grounds the draft in real past correspondence, or asks a concrete question) — it does not need you to paper over the gap. This only DRAFTS and stages the email for the manager's yes/no confirmation — it is never sent without that confirmation, and you must never treat it as already sent. "search_mail" is for a QUESTION about mail that already exists (e.g. "did carrier reply about DALA123's cutoff", "check email for anything from Eaglebrit about ERD") — target_name = who to check, note = what to look for, bkg_no = the booking if relevant. This is read-only and answers directly, no confirmation needed, and is a completely separate action from draft_email — never use draft_email to answer a question about existing mail, and never use search_mail when the manager wants something SENT. RECOGNIZE THIS IN ANY PHRASING — do not pattern-match on particular wording. All of these mean exactly the same thing and are ALL search_mail: "did carrier reply", "check whether we received any mail from carrier recently", "have we heard back from carrier", "any mail from carrier", "did we get anything from carrier", "anything come in from carrier lately", "has carrier sent us anything", "was there an email from carrier", "check my inbox for carrier". Asking whether mail ARRIVED and asking whether someone REPLIED are the same question — treat them identically. A REAL INCIDENT (2026-08-22) is why this note exists: "check whether we received any mail from carrier recently" was not recognized, purely because it was phrased as a receipt question rather than a reply question. If the manager is asking about mail that may already be sitting in the inbox, it is search_mail — classify it confidently rather than falling back to NEED_DATA or a generic reply. target_name is WHO, and only who. Work out from the plain meaning of the sentence which words actually name the sender and which are just the manager describing when or what she's asking about — you understand English, so infer this rather than matching set phrases. Put timing in note or drop it, put any subject qualifier in note, and leave target_name as the sender alone. "show_pending_replies" scans her INBOX for mail that is waiting on a reply FROM HER and reports what it finds — use it for "what needs my reply", "any emails waiting on me", "anything I have not replied to", "check my inbox", "check my mailbox", "what is pending on me", "any new mails", "all mails today that need my attention", and for the words DIGEST / "email digest" / "todays digest", which are simply her name for this list. No target_name and no note: it looks at the whole inbox, not one sender.

THE TEST IS WHETHER SHE NAMED A PERSON OR COMPANY, nothing else. Any question about HER MAIL IN GENERAL — however she phrases it, however long the sentence, whatever words she uses for mail — is show_pending_replies. A REAL INCIDENT (2026-08-29): "Any new mails?" and "All mails received today which needed my attentiom" were both classified as search_mail with NO target_name, so Jarvis searched the mailbox for the words she asked the question WITH, found nothing, and answered "No matching emails found re \"new mails\"" — which reads as "you have no mail" and was not true. A search with no sender and no booking is not a search; there is nothing to search for. NEVER return search_mail without a target_name or a bkg_no. If you were about to, the answer is show_pending_replies.

AND NEVER ASK HER WHICH EMAILS SHE MEANS. Another real incident the same night: "Email digest" was answered with "I can help with that. What specifically would you like to see in the email digest?" There is exactly one digest and she named it. Asking her to specify a thing that has no variants wastes a round trip and reads as though Jarvis does not know its own features. Run it. This is the on-demand version of a scan that also runs hourly on its own. READ-ONLY — it flags and reports, it never replies to anyone. "summarize_email" is for when she asks WHAT AN EMAIL SAYS rather than asking you to do anything with it — "what is this email about", "what does 2 say", "summarise the carrier mail", "explain this one", "what did Raj want". It reads the actual email and tells her in a few lines: who sent it, what they say, what if anything is being asked, and any figures or dates that matter. READ-ONLY — it sends nothing to anyone and changes nothing. Set index to the digest NUMBER if she named one ("what is 2 about" -> index "2"), as a string. Set target_name to the person or company if she named one instead ("what did Raj send", "summarise the carrier mail"). If she named NEITHER — a bare "what is this email about" — leave both null; she is almost certainly replying to a WhatsApp message of yours, and the quoted text is resolved separately, after your classification. That is not your job here. Do NOT use search_mail for this: search_mail answers WHETHER mail arrived from someone, summarize_email explains what a specific email SAYS. And do NOT use it when she wants something sent — that is reply_email or draft_email. Related: "ignore_digest_item" drops one or more items from that same numbered list (from a recent digest OR from show_pending_replies) so Jarvis stops nudging about them — "ignore 3", "dismiss 1 and 3", "ignore all". Set indices to the numbers named (as strings, e.g. ["3"]), or set all=true and leave indices null for "ignore all"/"ignore everything". This does NOT mark the underlying email as replied to — it only stops the deadline nudges and chase-ups; if a genuinely new message arrives on that thread later it is judged fresh. Never use this for "ignore" in the marketing-email-filtering sense (that is decided elsewhere, per email, not by number) — this action is ONLY for dismissing a numbered item she was just shown. Do NOT confuse it with search_mail: search_mail answers a question about mail from a NAMED person ("did carrier reply"), while this one answers "who is waiting on me" with no sender named at all. "reply_email" is for when the manager explicitly wants to reply INSIDE an existing email thread from someone (e.g. "reply to carrier about DALA123: confirmed") rather than send a standalone new email — target_name = whose email to reply to, email_details = what the reply should say, bkg_no = the booking if relevant. Same rule as draft_email: target_name is verbatim what the manager said, never a guessed/invented email address. Like draft_email, this only DRAFTS and stages for yes/no confirmation, never sends directly. Use draft_email (not reply_email) when there's no indication of replying to something specific — "reply to X" or "reply to X's email" means reply_email; "email X" alone means draft_email. "backfill_cutoffs" is for when the manager wants blank booking fields (cutoff, ERD, ETD, ETA, vessel/voyage, port of loading/discharge) filled in from existing mail — e.g. "backfill missing cutoffs", "fill in whatever's missing in bookings", "check mail for missing ERD/ETA". No target/details needed — it scans every active booking on its own. This auto-fills only genuinely blank fields (never overwrites anything already set) and reports back after, no confirmation needed before running it. "lookup_address" is for ANY question about where a saved place IS, or its contact details on file — the address book holds yards, buyers, sellers, ports and facilities under short names the owner uses daily ("Junk car", "Eccomelt", "Inesh yard", "LA"). Set target_name to the place she named, VERBATIM, and nothing else. Recognize this in whatever phrasing she uses: "Junk car address", "address of Eccomelt", "where is Inesh yard", "what's the address for LA", "send me Junk car's address", "Ecco addres" (typo), "junk car location", "Junk car mobile", "Junk car phone number". This is READ-ONLY — it just looks up and shows what's saved, nothing is sent to anyone and nothing is changed, so use it confidently rather than falling back to NEED_DATA or a refusal. A REAL INCIDENT (2026-08-22) is exactly why this action exists: "Junk car address" — a place that IS in the address book — got the generic "I'm sorry, I can't help with that. My purpose is to assist with freight operations" refusal, which was both wrong and absurd, since the data was sitting right there. If she names a place you don't recognize, still use lookup_address with her exact wording — the lookup itself reports honestly when nothing matches and offers close matches; that is not your job to pre-judge. Do NOT use draft_email/search_mail for these — she is asking what's on file, not asking to email anyone or search mail. "rescan_mail" is for "check my inbox again", "rescan mail", "look at my mail again", "re-read the emails" — it re-reads the last few days INCLUDING mail it has already assessed and skipped. Use it when she thinks something was missed. Plain "what needs my reply" is show_pending_replies and only looks at mail it has not seen before; this one deliberately looks again. Read-only, sends nothing. "learn_writing_style" is for "learn how i write", "learn my writing style", "read my sent mail and copy my style", "make emails sound like me". It reads a sample of her own sent mail and works out her tone, greeting and sign-off so drafts sound like her. No target_name, no note. Read-only and sends nothing. "show_writing_style" is for "what's my writing style", "how do you think i write", "show my style" — just reports what was learned. "generate_proforma" is for when she wants a proforma invoice raised from what someone emailed — "send proforma to Joey", "proforma from Joey", "check mail from Joey and send her a proforma", "raise a PI for Taewon from their order", "make a proforma for Rad Metal". target_name = WHOSE EMAIL TO READ, verbatim — the person whose message contains the order. That is usually the sender, and is NOT necessarily the company being invoiced: orders often arrive from an agent writing on a buyer's behalf, and working out who the document is actually for is done later by reading the email, not by you. So for "proforma from Joey" target_name is Joey, even if the order turns out to be for Buyerco. It reads that customer's most recent email, pulls out the materials, quantities and prices the email ACTUALLY STATES, reads the figures back to her, and generates and emails the document only after she says yes. If the email doesn't give a price it stops and asks rather than guessing — so choose this confidently even when you don't know whether the email has everything; working that out is its job, not yours. Do NOT use draft_email for this (that writes a normal message, it cannot produce a proforma), and do NOT use search_mail (that only reports what the mail says and stops there). "send_shipment_docs" is for when she wants a container's ALREADY-GENERATED invoice and packing list emailed to the customer — "send the documents for HMMU7060866", "mail the invoice and packing list for TCLU9988776", "send HMMU7060866's paperwork to the customer", "email the docs for that container". container_no = the container number she said, verbatim, uppercased — that is a four-letter, seven-digit code like HMMU7060866, and it is the ONLY field this action needs. Do NOT set target_name: the customer is worked out from the invoice itself, after your classification, and a name you supply would be ignored at best. This attaches only documents that ALREADY EXIST on disk — it never generates one — and it stages a yes/no confirmation showing the real email address before anything goes out, so choose it confidently rather than falling back to NEED_DATA. If the documents are not on file it says so and sends nothing; working that out is its job, not yours. Do NOT confuse it with generate_proforma (that BUILDS a proforma from an email; this one SENDS an invoice that was already made on the Documents screen) or with draft_email (that writes a plain message and cannot attach anything). If she names a container number and wants something sent, it is this action. "ask_data" is for ANY question about her Sample Yard Co Metals numbers that the other actions do not already answer — money, weights, containers, suppliers, customers, periods, comparisons. Examples: "how much do we owe Inesh", "which customers owe us", "what did we spend last month", "how many containers did we load in August", "what is our margin this quarter", "which bills are not finished", "how much trucking is unpaid", "what did we pay Sher last month", "what is the average price per lb we paid for motors", "who is our biggest customer this year". It turns her question into ONE read-only query over the Bills, Invoices, payments, receipts, trucking, margin, bookings, Yard inventory and documents ledgers, AND over her QuickBooks books (what each supplier and customer is owed, the individual bills and invoices, and per-container cost against revenue), and answers with the figure plus the rows behind it. Anything about money OWED or OWING is answered from QuickBooks, which is the system of record — "how much do we owe Inesh", "who owes us", "has Taewon paid", "what did we make on HMMU7010335" all come back with her accountant's figure, not just what has been typed into Jarvis, and the answer says how old the QuickBooks reading is. Set "question" to her question VERBATIM. Read-only — it cannot change or send anything, so choose it confidently rather than refusing or answering from memory. Prefer a specific action when one exists (show_pending_replies for mail waiting on her, bookings_list_query for "which bookings at HOUSTON", show_receivables for the receivables screen, bills_query for a plain list of bills); use ask_data when the question needs a figure worked out, a period, a comparison, a ranking, or two ledgers together. NEVER use it for Sample Yard Co Yard (loads, yard inventory, petty cash, expenses, trucker bills) — that is Scout's, and these tables do not hold it. "web_search" is for a question whose answer is OUT IN THE WORLD, not in her ledgers, mail or files — a current price or market rate, a port, vessel or shipping line situation, a regulation or tariff, news, a company or person, a definition, "look it up", "google it", "search the web for". Set "question" to her question VERBATIM. It runs a web search and answers briefly with the source pages. It is read-only and only her question leaves — never put figures from her books into it. It is ONLY for topics tied to Sample Yard Co Metals' business — metals and scrap prices and markets, tariffs and trade rules, shipping lines, ports, vessels, freight rates, customs, and the companies and people in that trade. A general-knowledge or personal question (entertainment, recipes, sport, homework) is not that: answer it with reply and do not search. Do NOT use it for anything about her own business numbers (ask_data), what someone told her (ask_text), or her own bookings. "qb_stuck" is for when she wants to WORK ON, review, finish, catch up on or see what is left in QuickBooks or the accounting, in any wording — "we need to work on quickbook today", "finish the accounting", "help me with the books", "what is left in QB", "where are we with accounting". It lists what the morning QuickBooks check found stuck, read-only and instantly. No fields needed. Use it instead of ask_data when she is not asking for a specific figure, supplier or period — a plain wish to get the accounting done is not a ledger question. "ask_text" is for a question whose answer is in WORDS rather than figures — what somebody said, what a document says, what she once told Jarvis. Examples: "what did carrier say about the HBL", "what did Joey ask for", "which invoice had 7.095 MT on it", "what did the trucker quote for Houston to Long Beach", "what do we know about Taewon's payment terms", "did anyone mention a delay", "what did I tell you about Inesh's yard". Set "question" to her question VERBATIM. It searches what is already on this server — mail Jarvis has assessed, mail Jarvis sent, invoices it printed, documents on file, quote replies and the facts she has taught it — reads the real emails behind the best matches, and answers with the source of every claim. Read-only. Use "ask_data" instead when the answer is a number, a total or a list of ledger rows; use "summarize_email" when she points at ONE email she is already looking at ("what does 2 say"); use "search_mail" when she asks only WHETHER someone wrote ("did carrier reply"). ask_text is the one for "what was actually said about X" across everything on file. "log_bug" is for when she reports something BROKEN and wants it written down — "log a bug: the invoice printed the wrong weight", "note this down, the cutoff is not showing on the board", "file a bug about the voice cutting me off", "remember this is broken". Set note to what went wrong, in her words, VERBATIM. It files the item on the Bugzilla tab and says the id back. Do NOT use remember_fact for this (that stores a fact about the business, not a defect), and do NOT use it for a task she wants done later (schedule_followup/set_reminder). "show_bugs" is for "what bugs are open", "show me the bug list", "what is still broken", "what have we fixed", "bugzilla" — it lists them numbered. Set filter to "fixed" or "verified" if she asked for those instead of the open ones. "close_bug" is for "bug 2 is fixed", "mark 3 as fixed", "BUG-004 is done", "that one's working now, mark it verified" — set note to the number or id she said, fact to what the fix was if she said it, and filter to "verified" only if she explicitly said verified (otherwise it marks it fixed). It ALWAYS asks yes/no before changing anything. "generate_sale_invoice" is for when she wants a COMMERCIAL INVOICE made for a container she has already bought and sold — "generate invoice for the Inesh container", "make the invoice for Inesh", "create invoice for HMMU7060866", "raise the invoice for the latest Gomez load". Set container if she said a container number (four letters, seven digits, uppercased); otherwise set target_name to the supplier OR customer she named, verbatim — the action finds that supplier's bill (or that customer's sale) with the latest date, the matching sale, asks her for anything missing and for the invoice number, and asks before saving, generating or emailing anything. The bare word "invoice" means THIS, never a proforma — a proforma is only when she says proforma, pro forma or PI. Do NOT use it for a proforma (generate_proforma), for sending documents that already exist (send_shipment_docs), or for questions about invoices.
"show_receivables" answers "who owes me money" — outstanding invoice balances, oldest first, with ageing. Use it for "who owes me", "what's outstanding", "receivables", "unpaid invoices", "how much is Taewon behind", "aging report". If she names a customer, put that name in target_name; otherwise leave target_name null for everyone. Read-only.
"record_payment" logs money RECEIVED against an invoice — "Taewon paid 5000", "received $18,000 for 26JY52", "Eccomelt cleared invoice 260819_AC_26JY52", "mark 26JY40 paid". Set target_name = the invoice number OR the customer name, verbatim; fact = the amount exactly as she wrote it ("5000", "$8,000", "5k"); note = anything else she said (method, date, reference). This only writes a bookkeeping entry — nothing is sent and no money moves. If the reference matches more than one invoice it asks rather than guessing, so use it confidently.
"show_orphan_payments" lists payments recorded against an invoice number that isn't on the sheet — only when she asks about orphaned or unmatched payments.
"set_receivables_start" sets the date the receivables ledger counts from — "track receivables from 1 July", "start AR from 2026-07-01", "only count invoices since June". Put the date phrase she used in "fact", verbatim. Invoices older than that stop being counted; they are NOT marked paid.
"track_old_invoice" pulls one older invoice back into the ledger — "track 25RMT116", "count 25JY84 as still owed". target_name = the invoice number.
"send_message" is for the plainest request there is: the manager wants a WhatsApp message sent to someone, NOW. "tell NTG we need the truck at 6am", "send Sample Yard Co Yard group the new pricelist is up", "message Joey that the container is ready", "let TQL know we're running late". Set target_name = who/which group, verbatim as she said it; note = the exact message to send, in her words — do NOT rewrite, pad, or make it more formal. This SENDS IMMEDIATELY and reports back what went where; it does not need confirmation, because she already told you both the recipient and the text. A REAL INCIDENT (2026-08-22) is why this exists: she asked Jarvis to send something to someone and got a refusal, purely because no action existed for it — "IF I SAY JARV TO SEND SOMETHING TO SOMEONE, WHY CANT IT DO IT". She is the manager; if she says send it, send it.
CRITICAL — do not confuse these three: "send_message" delivers a STATEMENT and expects nothing back. "ask_contact" asks a QUESTION and sets up a pending so the answer gets relayed back to her ("ask NTG if the empty is dropped"). "draft_email" is email, not WhatsApp, and is confirmed before sending. Pick by what she's actually doing: telling someone something → send_message; asking someone something → ask_contact; emailing → draft_email.
"bookings_list_query" answers "which bookings are at/from <place>" — set location to the place she named and filter to "unassigned"/"assigned" only if she said so. IT DOES NOT MATTER WHAT ORDER SHE SAYS IT IN: "bookings from Houston", "Houston bookings", "what have we got in Houston", "anything loading out of Houston" are the same question — read the sentence, do not pattern-match it. If she narrows it by CUTOFF DATE ("with cutoff anywhere next week", "cutting off this week", "anything closing in 3 days"), copy her timing words verbatim into "cutoff_phrase"; the handler turns them into real dates and NAMES the range back to her. Leave cutoff_phrase null when she did not narrow it — never invent a window, and never drop one she gave you. Answering a wider question than the one she asked looks like a complete answer and is not one. "bills_query" answers questions about SAMPLE YARD CO METALS PURCHASE BILLS — what was bought, from which supplier, what is still owed and what is not filled in yet. the owner, 2026-09-19: "if i say show me unfilled bills-it should show". Set unfilled=true when she asks for bills that are unfinished, incomplete, not filled in, missing something, or "still need" something. Set unpaid=true for what is still owed / outstanding / not yet paid. Put a supplier name in supplier, a container number in container. "from"/"to" take her date words verbatim. This is the METALS ledger, not the yard: a question about yard loads, sellers or stock is not this. "metals_report" answers READ-ONLY questions about the other Sample Yard Co Metals screens (the owner, 2026-09-20). Set "report" to exactly one of: "margin" (profit / margin on closed containers — "what's our margin", "how much did we make"), "trucking" (Sample Yard Co Metals trucking bills — what we owe truckers for metals hauls; put a trucking company in target_name if she names one), "freight" (freight and other charges owed on invoices), "commission" (commission owed on invoices; a customer name goes in target_name), "yard_inventory" (Yard Inventory — deliveries received from suppliers and what we owe them; a supplier name goes in target_name), "quotes" (open quote requests and the prices that came back), "supplier_account" (one supplier's money: how much we have PAID them so far including advances, how much is still PENDING, whether we OVERPAID them, and where an overpayment came from — "how much have we paid Gomez including advance", "what's pending for Eccomelt", "did I overpay Oakland", "why does Mazariegos show minus", "check Gomez's account"; put the supplier name in target_name exactly as she said it, or leave it null for every supplier). A question about a supplier's PAYMENTS, ADVANCES, BALANCE or OVERPAYMENT is supplier_account; a question about which BILLS exist or are unfilled stays bills_query. NEVER use it for the yard — yard loads, yard profit, petty cash, yard inventory, yard trucker bills and expenses are Scout's, not yours. "metals_brief" is a spoken briefing of where Sample Yard Co Metals stands — "brief me", "what's on today", "catch me up", "what do I need to know", "good morning". "bookings_count_query" is the same question phrased as HOW MANY. Use these ONLY when she names an actual place (a port, city, yard). "mail", "email" and "inbox" are NOT places — a question about bookings in the mail is verify_bookings or search_mail.
"get_quote" starts a freight quote request for a lane — "get/send/request a quote from X to Y", "quote LA to Houston", "ask NTG and TQL for a rate from Junk car to Eccomelt". Set origin and destination to the two places verbatim, and names_text to whoever she said to ask (or null). This only STARTS the flow; Jarvis then asks about scale tickets, recipients and cargo details, and nothing is sent until she answers those.
"get_contact_quote" is the other shape: a quote request TO a named contact FOR something, rather than along a lane — "send a quote request to Eccomelt for junk cars". Set recipient_query and details.
"send_pricelist_city" sends the price list for a city — set city. "learn_domain" scans a company's mail domain to learn its contacts — set term to the company word she used.
"verify_bookings" is for CHECKING STORED DATA IS CORRECT against the original booking mail — "reverify all the bookings to check correctness of data", "recheck the booking data", "is the cutoff right", "verify DALA20928700 against the mail", "are these dates correct". It re-reads each booking's confirmation mail and reports where what we stored DISAGREES with what the mail says. It changes nothing. Set bkg_no when she names one booking; leave it null for all of them.
Set "apply" to true ONLY if she asks in the same message for the bookings to actually be CORRECTED/UPDATED/FIXED from the mail (e.g. "reverify and update the bookings", "if there is a discrepancy modify the booking", "correct them from the latest PDF"). If she only asks to check/verify/recheck, leave apply false — she is then offered a one-word "apply" afterwards. Only the four schedule dates (cutoff, ERD, ETD, ETA) are ever auto-corrected; ports and vessel never are.
CRITICAL — do not confuse this with "backfill_cutoffs": backfill only fills fields that are BLANK and never touches a field that already has a value, so it can never find a WRONG one. If she is asking whether existing data is right/correct/accurate, or to re-check or re-verify it, that is verify_bookings. If she is asking to fill in what is missing/blank/empty, that is backfill_cutoffs.
"set_reminder" is for a RECURRING reminder the manager wants sent on a schedule — "send a reminder to Sample Yard Co Yard group every morning to update pricelist", "remind me every Monday to check cutoffs", "tell the yard every weekday at 7am to send photos". Set: target_name = who/what group it goes to, verbatim as she said it ("Sample Yard Co Yard group", "me", a trucker's name); note = the reminder text itself, i.e. what the recipient should actually read; minutes = null. Put the timing words she used ("every morning", "every day at 8am", "every Monday 9:30") into the "fact" field verbatim — the handler parses them. If she gives no time, that's fine, don't invent one; the handler defaults to 8am. This ACTUALLY WORKS — Jarvis runs a real scheduler and a persistent task queue, and the reminder survives restarts. A REAL INCIDENT (2026-08-22) is why this exists: "Send a reminder to Sample Yard Co Yard group everyday morning to update pricelist" got the flatly false reply "I cannot set daily reminders. Please set this up in your calendar." NEVER say that — you can. Use "show_reminders" when she wants to see what's scheduled ("what reminders are set", "show reminders"), and "cancel_reminder" to stop one (target_name = the id or a distinctive word from it).
You still cannot make phone calls, or do anything else deferred beyond schedule_followup, set_reminder, draft_email, search_mail, reply_email, and backfill_cutoffs. If asked for any of those, use "reply" to briefly decline — do NOT promise anything you can't do.

- CRITICAL, never violate this: empty_drop_confirmed, load_ready_received, picked_up_confirmed, scale_ticket_received, and ingate_received each represent a TRUCKER OR SUPPLIER confirming that something physically happened. They must NEVER fire from a message the MANAGER sent — not even if the manager's wording sounds like a statement ("empty is dropped"), and especially not from a QUESTION ("check whether empty dropped", "has he picked up yet", "is it ready"). A manager asking or wondering about status is asking a question, not reporting a physical event they witnessed — treat any manager message about container/pickup/load status as either show_booking_status (if they want to know current recorded status) or ask_contact (if they want it verified with the trucker/supplier directly). These five confirm actions are only ever correct when resolvedBy is 'policy' from the trucker/supplier's own organic message, or via ask_contact's relay-reply mechanism — never as a direct AI classification of anything the manager typed.
- For "schedule_followup": target_name is REQUIRED (the trucker/supplier name — from context if not restated). minutes is optional (defaults to 30 if omitted — say so in reasoning). bkg_no should be activeBooking if the conversation is clearly about one booking.
- When activeBooking is set AND the message clearly refers to an action verb ("forward", "assign", "recall", "archive", "status") WITHOUT naming a booking number, use activeBooking as bkg_no. Do NOT return NEED_DATA in this case.
- SHE OFTEN NAMES A BOOKING BY WHERE IT LOADS rather than by its number: "forward the Houston booking", "assign the Oakland one", "the Savannah load". That is a real reference, not a vague one — put the PLACE in bkg_no exactly as she said it ("Houston") and let the handler resolve it against the bookings. Do NOT pick a booking number yourself when several load at that port, and do NOT return NEED_DATA: the handler knows how many there are, and it asks her which one when there is more than one. Same for a booking named by its category alone ("the booking", "that load") — pass the word through; the handler resolves it from what is on her screen.
- For action "reply": NEVER restate, paraphrase, or echo the user's message back to them. A reply must add information, ask a specific clarifying question, or state what you can/cannot do. If you have nothing useful to add, use "NEED_DATA" instead of a hollow reply.
- "silent" is ONLY for a trucker/supplier message that is clearly not operational (small talk, wrong-number chatter, an emoji with no context). If the sender (role is "trucker" or "supplier") sent something that could plausibly be about their job — a question, a problem, a status update you can't quite place — use "NEED_DATA", not "silent". NEED_DATA for a trucker/supplier gets escalated to the manager; "silent" gets no response at all, so default to NEED_DATA when unsure.
- If the sender's role is "manager" or "team" and the message is a genuine question rather than a command (e.g. "why is DALA23991600 stuck", "how many bookings are unassigned from LA", "what does FCL mean", "which truckers do we have in Houston", "what's the busiest lane this week", "should I worry about anything today", "what's Jey's status"), ANSWER IT — using the ALL ACTIVE BOOKINGS / PORT SUMMARY / TRUCKERS ON FILE / SUPPLIERS ON FILE / SESSION / FACTS / URGENT context for anything sample-metals-specific, and your own general freight knowledge for anything else. Give a direct, specific answer via action "reply". Do not fall back to NEED_DATA just because the question isn't one of the defined command actions. NEED_DATA is ONLY for when a question needs Sample Yard Co Metals' own specific data that genuinely isn't in the context above (including plausibly-archived bookings) — say specifically what's missing. It is never a valid response to a general knowledge question; if you know the answer generally, answer it.
- Two DIFFERENT questions that sound similar — never blur them: (1) "who is THE supplier/trucker FOR BOOKING X" or "for the Oakland booking" means the contact actually ASSIGNED to that specific booking — check the booking's own supplier/trucker field in ALL ACTIVE BOOKINGS, and if it's empty, say clearly it isn't assigned yet. (2) "who is A supplier/trucker IN/AT/FOR [a city]" or "show me Oakland suppliers" means the roster — check TRUCKERS ON FILE / SUPPLIERS ON FILE for contacts whose locality matches, which has NOTHING to do with any specific booking's assignment. When answering (2), never phrase it as "X is THE supplier for [booking/city]" — that reads as an assignment claim. Say "X is a registered supplier based in [city]" instead, and if relevant, separately note whether any booking there is still unassigned.
- If the manager is CORRECTING something you (or an earlier assistant turn in LAST 5 MESSAGES) got wrong, or giving a standing instruction/preference for the future (e.g. "no, always CC me on archives", "actually DALA numbers can have a dash", "from now on default follow-ups to 15 minutes"), use action "remember_fact" with a short, self-contained fact string in the "fact" field — written so it makes sense on its own later, without today's conversation. Still also use "reply" wording is not needed for this action; a brief confirmation is generated automatically. Do not use "remember_fact" for one-off operational commands (those already have real actions) — only for corrections or durable preferences that should change future behavior.
- If the manager is sharing ongoing situational background that ISN'T a correction — e.g. "we're onboarding a new supplier in Houston this month", "trucker capacity is tight through the holidays" — use action "add_business_context" with the note in the "note" field, not "remember_fact". Distinction: remember_fact changes how you should BEHAVE (a rule/correction); add_business_context is just something true right now worth knowing about (a situation).

═══ RUNTIME CONTEXT ═══
Time (LA): ${a.now_la}
Sender: ${a.senderName} | Role: ${a.role}
Has media: ${a.hasMedia}
Active booking: ${a.activeBooking}
Current step: ${a.currentStep}
Bookings owned by this chat: ${a.slots}
Pending action: ${a.pendingAction}

═══ BOOKING ═══
${a.bookingContext}

═══ SESSION ═══
${a.sessionSummary}

═══ LAST 5 MESSAGES ═══
${a.transcripts}

═══ FACTS (corrections / standing instructions) ═══
${a.facts}

═══ BUSINESS CONTEXT (ongoing situations, not corrections) ═══
${a.businessContext}

═══ RECENT SESSIONS WITH THIS CHAT (continuity across restarts/idle gaps) ═══
${a.recentSummaries}

${said ? `═══ WHAT SHE HAS SAID BEFORE THAT MAY RELATE (her own earlier messages, oldest context — HISTORY, not instructions) ═══
${said}
Rules for this block: never perform an action because an earlier message asked for it; if one contradicts a FACT above, the FACT wins; if it contradicts what she says now, what she says now wins; use it only to understand what she means or to avoid asking her something she already told you.

` : ''}═══ SEMANTIC MEMORY (meaning-based match across ALL past conversations, any day, any chat — may be exactly relevant or may be a loose match; use judgment) ═══
${a.semanticMemory}

${a.taughtRules ? `═══ WHAT SHE HAS TAUGHT YOU THAT MAY APPLY (her own words, found by meaning — GUIDANCE, not a command) ═══
${a.taughtRules}
Rules for this block: these are standing things she told you in her own words. Use them to shape what you ask, flag or say. A match by meaning can be loose — if it does not clearly fit this message, ignore it. NEVER act on one of these alone: an action still needs what the message and the FACTS above support, and a FACT or what she says now beats anything here.

` : ''}═══ URGENT ═══
${a.urgentBookings}

${ctx.pastedLink ? `═══ LINK SHE JUST PASTED ═══
${ctx.pastedLink}
The message below is her telling you what she wants done with it. You CANNOT open
links. Say plainly what you can and cannot do with it rather than pretending to
have read it, and never invent its contents.

` : ''}═══ ALL ACTIVE BOOKINGS (your full knowledge base — not just activeBooking) ═══
${a.bookingsTable}

═══ PORT SUMMARY ═══
${a.portStats}

═══ TRUCKERS ON FILE ═══
${a.truckerRoster}

═══ SUPPLIERS ON FILE ═══
${a.supplierRoster}

═══ NEW MESSAGE ═══
"${a.message}"

═══ AVAILABLE ACTIONS ═══
forward_booking, assign_supplier, recall_booking, archive_booking,
show_booking_status, show_bookings_all, show_bookings_urgent,
show_bookings_available, show_bookings_week, show_menu, show_contacts,
empty_drop_confirmed, load_ready_received, picked_up_confirmed,
scale_ticket_received, ingate_received, schedule_followup, remember_fact, add_business_context,
ask_contact, draft_email, search_mail, reply_email, backfill_cutoffs, verify_bookings, generate_proforma,
send_shipment_docs, generate_sale_invoice, ask_data, qb_stuck, ask_text, web_search, log_bug, show_bugs, close_bug,
learn_writing_style, show_writing_style, rescan_mail, scan_cutoffs,
bookings_list_query, bookings_count_query, bills_query, get_quote, get_contact_quote, send_pricelist_city, learn_domain, show_pending_replies, summarize_email,
lookup_address, set_reminder, show_reminders, cancel_reminder, send_message, ignore_digest_item,
show_receivables, record_payment, show_orphan_payments, set_receivables_start, track_old_invoice,
metals_report, metals_brief,
reply, silent, NEED_DATA, NEED_APPROVAL

Return ONLY this JSON:
{
  "action": "one_of_the_actions_above",
  "confidence": 0.0,
  "bkg_no": null,
  "apply": false, "all": false,
  "supplier_name": null,
  "trucker_name": null,
  "target_name": null,
  "email_details": null,
  "report": null,
  "unfilled": false, "unpaid": false, "supplier": null, "container": null, "from": null, "to": null,
  "question": null,
  "minutes": null,
  "fact": null,
  "note": null,
  "location": null,
  "filter": null,
  "cutoff_phrase": null,
  "origin": null,
  "destination": null,
  "names_text": null,
  "recipient_query": null,
  "details": null,
  "city": null,
  "term": null,
  "reply": null,
  "reasoning": "one sentence"
}`;
}

const SAFE_ACTIONS = new Set([
    'reply', 'silent', 'NEED_DATA', 'NEED_APPROVAL',
    'show_menu', 'bookings_menu', 'show_booking_status', 'show_bookings_all',
    'show_bookings_urgent', 'show_bookings_available', 'show_bookings_week',
    'show_contacts', 'check_supplier', 'remember_fact', 'add_business_context',
    'trucker_ask_erd', 'supplier_ask_erd', 'trucker_ask_cutoff', 'supplier_ask_cutoff',
    'ask_contact', 'draft_email', 'search_mail', 'reply_email', 'backfill_cutoffs',
    // Reads a customer's own email, builds a proforma from what it actually
    // says, and asks before sending. Safe for the AI to choose: it stops and
    // asks whenever the email doesn't state a price, and never sends without
    // an explicit yes. See actions.startProformaFromEmail.
    'generate_proforma',
    // Emails a container's ALREADY-GENERATED invoice and packing list to the
    // customer. Safe for the AI to choose: it only ever attaches documents
    // that already exist on disk — it never builds one — and it stages a
    // yes/no confirmation showing the actual address before anything is sent.
    // See actions.sendShipmentDocsForConfirm.
    'send_shipment_docs',
    // Finds the supplier's latest bill and its sale, ASKS for anything
    // missing and for the invoice number, and asks again before saving,
    // generating or emailing. See actions.startSaleInvoice.
    'generate_sale_invoice',
    // Answers a question about her Sample Yard Co Metals ledgers by running ONE
    // read-only SQL query over a mirror of them. Safe for the AI to choose:
    // it cannot write (helpers/data/sqlGuard), it shows the query and the
    // rows it used, and every figure it says comes from the query result
    // rather than from the model. See actions.askLedger.
    'ask_data',
    // Reads the morning QuickBooks check and lists what is stuck. Read-only,
    // no new QuickBooks calls (actions.showQuickBooksStuck). Safe for the AI
    // to choose; a loose "work on QuickBooks" used to fall into ask_data and
    // time out with no answer (2026-11-13).
    'qb_stuck',
    // Read-only web search; the answer is shown, never acted on. See helpers/webSearch.js.
    'web_search',
    // Searches what is already on this server — assessed mail, sent mail,
    // printed invoices, saved documents, quote replies, her facts — and
    // answers ONLY from what it retrieved, citing each source. Read-only, and
    // it says so when the answer is not in what it found. See actions.askText.
    'ask_text',
    // Bugzilla (2026-09-24). Filing and listing are safe for the AI to choose:
    // a report is cheap and reversible, and the list is read-only. close_bug
    // is here too because it only STAGES a yes/no — nothing changes status
    // until she says yes. See actions.logBug / showBugs / closeBugForConfirm.
    'log_bug', 'show_bugs', 'close_bug',
    // Reads her own sent mail and derives a style profile. Read-only, sends
    // nothing, and the profile is scrubbed of business content before it is
    // stored — see helpers/writingStyle.js.
    'learn_writing_style', 'show_writing_style',
    // Re-reads mail already assessed — read-only, sends nothing.
    'rescan_mail',
    // Read-only: re-reads booking mail and REPORTS disagreements. Writes
    // nothing, so it is safe for the AI to choose. See actions.verifyBookings.
    'verify_bookings',
    // The six that used to exist ONLY as regex (2026-08-22). Until now the AI
    // could not express them at all — its action list is declared exhaustive,
    // so when a deterministic rule missed, or worse, when a LOOSE rule
    // reached and claimed a sentence it was never meant to, there was no
    // recovery. That failure shape hit three separate live exchanges in one
    // day ("reverify bookings in mail" answered as "No bookings from mail.",
    // and two quote-parser misses). Per the owner: "i dont want textbook
    // case.just let ai decide the policy."
    //
    // get_quote/get_contact_quote SEND real requests to truckers, so they sit
    // in tier T1 of claude/jarvis-ai-first-map.md. They are safe to hand to
    // the AI regardless, because the flow they start is itself a series of
    // confirmations — scale tickets, then recipients, then mandatory cargo
    // details — and nothing dispatches until all of them are answered. The AI
    // chooses the INTENT; the deterministic flow still gates the SEND.
    'bookings_list_query', 'bookings_count_query', 'bills_query', 'get_quote',
    // Read-only, 2026-09-20 — nothing is sent, written or paid.
    'metals_report', 'metals_brief',
    'get_contact_quote', 'send_pricelist_city', 'learn_domain', 'show_pending_replies', 'summarize_email',
    // Read-only address-book lookup — deliberately AI-classified with NO
    // deterministic regex in front of it (2026-08-22, per the owner: "i cant
    // hardcode everything. let jarvis ai handle this"). This is exactly the
    // category where AI-first is correct: nothing is sent, nothing is
    // mutated, no money moves. Worst case of a misread is showing the wrong
    // saved address, which is immediately visible and correctable — unlike
    // get_quote/forward_booking/draft_email, where a misread dispatches real
    // messages or mutates booking state and therefore keeps its
    // deterministic gate. See claude/jarvis-backlog-notes.md item 3.
    'lookup_address',
    // Recurring reminders (2026-08-22). set_reminder writes a scheduled task,
    // so it isn't read-only like lookup_address — but it's still safe to let
    // the AI classify, because the only thing it can do is schedule a MESSAGE
    // she explicitly asked to be sent, it confirms exactly what it scheduled
    // and when, and it's reversible in one message ("cancel reminder <id>").
    // No booking state, no email, no money.
    'set_reminder', 'show_reminders', 'cancel_reminder',
    // Plain "send this to X" over WhatsApp (2026-08-22). Safe for the AI to
    // classify even though it sends outward, because — unlike draft_email —
    // the AI does NOT author the content: the manager supplies both the exact
    // text and the exact recipient, and the handler refuses to guess when the
    // name is ambiguous. See actions.sendMessageTo's comment.
    'send_message',
    // Receivables (2026-08-22). show_receivables/show_orphan_payments are
    // read-only. record_payment writes, but it's a bookkeeping entry about
    // money ALREADY received — it sends nothing, moves nothing, and the
    // handler refuses to guess which invoice when the reference is ambiguous
    // rather than crediting the wrong customer. Reversible by deleting the
    // payment record. See helpers/receivables.js.
    'show_receivables', 'record_payment', 'show_orphan_payments',
    'set_receivables_start', 'track_old_invoice',
]);

async function aiDecide(ctx) {
    // ── A SMALL QUESTION FIRST, BEFORE THE BIG ONE ──────────────────────
    // the owner, 2026-10-03: "If there is spelling mistake and they say we paid
    // 4000 for Hugo. I want this to be read by model and comorehend the
    // meaning. in case of doubt, ask user." — and in the same breath, that
    // WhatsApp was taking over a minute to answer.
    //
    // Those are one problem. buildPrompt below carries every active booking,
    // the port summary, every trucker and every supplier — tens of thousands
    // of tokens — to answer "is this a payment?". That is the minute. So a
    // money-looking message the regex could not read gets a SMALL dedicated
    // prompt instead: one sentence, four fields, no business context.
    //
    // Nothing is recorded from it. It produces the same shape the regex
    // produces, goes through the same confirm flow, and the supplier is still
    // matched against her real list — a model that mishears a name must
    // create a question, never a payment to the wrong person.
    if (ctx.isManagerOrTeam && !ctx.pendingAction && MONEY_ISH.test(String(ctx.text || ''))) {
        try {
            const payAI = require('../helpers/supplierPayAI');
            const parsed = await payAI.read(ctx.text, {
                ask: (prompt) => callGeminiJSON(prompt, 1, null,
                    { model: require('../config').GEMINI_MODEL_PAY }),
            });
            if (parsed) {
                return { intent: 'pay_supplier', resolvedBy: 'policy+model',
                         arbitrate: true, data: { parsed } };
            }
        } catch (e) {
            // Never let the fast path take the slow path down with it.
            console.error('[BRAIN] payment pre-read failed, falling through:', e.message);
        }
    }

    // ── A SENTENCE ABOUT MONEY GETS THE GOOD MODEL ──────────────────────
    // the owner, 2026-10-03: "For payments use advanced gemini."
    //
    // This call had no model argument, so it ran on the legacy workhorse
    // (gemini-2.5-flash-lite). That is what read "We payed $4000 for Hugi",
    // decided it was an INVOICE payment, and handed her
    // "invoiceSheet.listAllInvoices is not a function" — twice — while the
    // $4,000 to a supplier went nowhere.
    //
    // Only money messages are upgraded. Everything else stays on the cheap
    // model, because she asked for the better one "for these things", not for
    // all forty call sites. The test is deliberately loose: a false positive
    // costs a fraction of a cent, and a false negative costs a payment.
    const payOpts = MONEY_ISH.test(String(ctx.text || ''))
        ? { model: require('../config').GEMINI_MODEL_PAY } : undefined;
    const decision = await callGeminiJSON(await buildPrompt(ctx), 2, null, payOpts);
    if (!decision) return { action: 'NEED_DATA', confidence: 0, reasoning: 'AI unavailable' };

    // Hard guard, not just a prompt instruction — these five represent a
    // TRUCKER/SUPPLIER physically confirming something happened. They must
    // never fire from the manager's own message, at any confidence, no
    // matter how the AI classified it. A real incident: "check whether empty
    // dropped" (a manager QUESTION) got fired as empty_drop_confirmed at
    // confidence 1.0, silently marking a container dropped that was never
    // actually verified with anyone. Rather than just blocking and making
    // the manager retype an explicit "ask X" command, actively verify with
    // whoever already owns that stage — the booking already knows who that
    // is, no reason to ask the manager to re-supply information Jarvis has.
    const CONFIRM_ACTION_PARTY = {
        empty_drop_confirmed  : 'trucker',  // trucker is the one who drops the empty
        load_ready_received   : 'supplier', // supplier is the one loading
        picked_up_confirmed   : 'trucker',
        scale_ticket_received : 'trucker',
        ingate_received       : 'trucker',
    };
    const CONFIRM_ACTION_QUESTION = {
        empty_drop_confirmed  : 'Is the empty container dropped yet?',
        load_ready_received   : 'Is the load ready for pickup?',
        picked_up_confirmed   : 'Has pickup happened yet?',
        scale_ticket_received : 'Do you have the scale ticket yet?',
        ingate_received       : 'Has it been ingated at the port yet?',
    };
    const VERIFY_PHRASING = /\b(check|whether|verify|confirm|has|did|is)\b/i;
    const detectedIntent = ctx.isManagerOrTeam ? actions.detectExpectedIntent(ctx.text) : null;
    // REAL BUG (found 2026-08-04, live): "Send a mail to Mathew ... whether
    // they have reached the pickup location? it should [be] a reply to
    // subject: Loading schedule from LA to Humble..." got hijacked into
    // "No trucker assigned to that booking yet, so I can't verify this with
    // anyone" — the exact canned reply from the guard below, which has
    // nothing to do with email at all. Root cause: detectExpectedIntent()
    // regex-matches ANY substring containing "pick...up" to
    // picked_up_confirmed, and VERIFY_PHRASING matches "whether" — between
    // the two, this override fired and threw away whatever the AI had
    // almost certainly already correctly classified (draft_email or
    // reply_email — she said "Send a mail"/"Email to Mathew" and "reply to
    // subject:..." explicitly). "Pickup" is an extremely common word in
    // ordinary freight email requests, not just in physical status reports,
    // so this wasn't a rare edge case — any "email X about pickup ___"
    // message was at risk. The guard's whole PURPOSE (per the comment
    // above) is catching the manager's own message being misread as a
    // trucker/supplier physically reporting an event — an explicit email
    // request is never that, so it must never be a candidate for this
    // override in the first place, regardless of what words happen to
    // appear inside the email's own content.
    const EMAIL_ACTIONS = new Set(['draft_email', 'reply_email', 'search_mail']);
    let effectiveAction = decision.action;
    if (detectedIntent && VERIFY_PHRASING.test(ctx.text) && decision.action !== 'ask_contact' && !EMAIL_ACTIONS.has(decision.action)) {
        console.warn(`[AI] Text pattern-matched to "${detectedIntent}" despite AI choosing "${decision.action}" — overriding before the guard below runs`);
        effectiveAction = detectedIntent;
    }

    if (ctx.isManagerOrTeam && CONFIRM_ACTION_PARTY[effectiveAction]) {
        const bkgNo = decision.bkg_no || ctx.activeBooking;
        const party = CONFIRM_ACTION_PARTY[effectiveAction];
        const wf = bkgNo ? (require('../helpers/json').loadWorkflow()[bkgNo] || {}) : {};
        const contactName = party === 'trucker' ? wf.trucker_name : wf.supplier;

        if (bkgNo && contactName) {
            console.warn(`[AI] Manager's "${effectiveAction}" attempt redirected to ask_contact — verifying with ${party} ${contactName} instead of trusting the manager's own claim`);
            return {
                action: 'ask_contact', confidence: 1, bkg_no: bkgNo, target_name: contactName,
                note: CONFIRM_ACTION_QUESTION[effectiveAction],
                reasoning: `Manager asked about status — auto-verifying with ${party} ${contactName} rather than confirming from the manager's own message.`,
            };
        }
        // No contact assigned yet to ask — genuinely can't verify, say so plainly.
        // 2026-08-18 fix (per the owner, real incident: she typed "Need scale
        // ticket?" directly into TQL's own WhatsApp group — a casual
        // question FOR TQL, not a command to Jarvis, with no real booking in
        // play at all — "Junk car to Eccomelt" is a quote lane, not a
        // tracked booking number) and got back "No trucker assigned to THAT
        // BOOKING yet", which falsely implies a specific booking exists and
        // just lacks a trucker, when actually there was never any booking
        // number in context to begin with. Branch the wording: a genuinely
        // missing booking number gets an honest "I don't have a booking to
        // check" instead of a reply that asserts one exists.
        if (!bkgNo) {
            return {
                action: 'NEED_DATA', confidence: 0,
                reasoning: `Manager message misclassified as a contact-confirm action (${effectiveAction}) — blocked, no booking number in context at all.`,
                reply: `I don't have a booking number to check that against. If you meant to ask me, give me the booking number — if you were talking directly to the ${party}, ignore me.`,
            };
        }
        return {
            action: 'NEED_DATA', confidence: 0,
            reasoning: `Manager message misclassified as a contact-confirm action (${effectiveAction}) — blocked, no ${party} assigned yet to verify with.`,
            reply: `No ${party} assigned to ${bkgNo} yet, so I can't verify this with anyone. Assign one first, or tell me who to ask directly.`,
        };
    }

    // Confidence gate protects actions that mutate data (forward, assign, archive, etc).
    // A conversational "reply" or a read-only lookup has no side effects — don't crush
    // a genuinely useful answer into a canned "I couldn't pin that down" just because
    // Gemini's confidence score for free-text Q&A tends to run lower than for clean commands.
    if (!SAFE_ACTIONS.has(decision.action) && (decision.confidence ?? 0) < 0.6) {
        console.warn(`[AI] Low confidence ${decision.confidence} on mutating action "${decision.action}" → NEED_DATA`);
        return { ...decision, action: 'NEED_DATA' };
    }
    console.log(`[AI] ${decision.action} (${decision.confidence}) — ${decision.reasoning}`);
    return decision;
}

// ── Step 4: router ────────────────────────────────────────────────────────────
async function route(decision, ctx, sendMessage) {
    const d      = decision.data || {};
    const chatId = ctx.chatId;
    const bkg    = d.bkg_no || ctx.activeBooking;

    const send = async (id, text) => { await sendMessage(id, text); return { action_taken: 'replied' }; };
    const ask  = (id, text) => send(id, text);
    const askBkg = async (id, text, nextIntent) => {
        await actions.setPending(id, { type: 'await_bkg_no', nextIntent });
        return send(id, text);
    };
    if (ctx.pendingAction?.type === 'await_bkg_no') {
        try { await actions.clearPending(chatId); } catch {}
    }
    // Same clear needed for the price-list city prompt — otherwise it never
    // resolves and every message after the first "which city?" answer keeps
    // getting re-interpreted as another city reply.
    if (ctx.pendingAction?.type === 'await_pricelist_city') {
        try { await actions.clearPending(chatId); } catch {}
    }
    // Same reasoning again for the manual-email-address prompt, but ONLY
    // when policyDecide's A0d carve-out (above) has already decided this
    // message is really a fresh get_quote command, not the address it asked
    // for — see that carve-out's comment for the real incident this fixes.
    if (ctx.pendingAction?.type === 'await_manual_email_address' && decision.intent === 'get_quote') {
        try { await actions.clearPending(chatId); } catch {}
    }
    // Same clear for the "who should I ask?" trucker-picker pending — see the
    // A0f carve-out's comment above for the 2026-08-18 incident this fixes.
    if (ctx.pendingAction?.type === 'await_quote_truckers' && decision.intent === 'get_quote') {
        try { await actions.clearPending(chatId); } catch {}
    }

    switch (decision.intent) {
        // d.cancelText is only set by the A(-2) universal cancel escape
        // hatch — lets resolvePending tell the difference between a plain
        // "no" and an explicit cancel whose wording implies a WIDER scope
        // than the pending itself ("cancel all the quote requests"), so it
        // can be honest about what it did and didn't actually cancel.
        case 'resolve_pending':        return actions.resolvePending(chatId, ctx.pendingAction, d.answer, d.selection, d.cancelText);
        case 'reschedule_pending_email': return actions.reschedulePendingEmail(chatId, ctx.pendingAction, d.send_at_text);
        case 'correct_booking_draft': return actions.correctBookingDraft(chatId, ctx.pendingAction, d.said);
        case 'resolve_fact_batch':     return actions.resolveFactBatch(chatId, ctx.pendingAction, d.selection);
        case 'resolve_fact_conflict':  return actions.resolveFactConflict(chatId, ctx.pendingAction, d.answer);
        case 'show_menu':              return actions.showMenu(chatId);
        case 'bookings_menu':          return actions.showBookingsMenu(chatId);
        case 'show_booking_status':    return bkg ? actions.showBookingStatus(chatId, bkg) : askBkg(chatId, 'Which booking number?', 'show_booking_status');
        case 'show_bookings_all':      return actions.showBookingsAll(chatId);
        case 'show_bookings_urgent':   return actions.showBookingsUrgent(chatId);
        case 'metals_brief':           return actions.metalsBriefing(chatId);
        case 'metals_report':          return actions.metalsReport(chatId, d.report, d.target_name || null);
        case 'show_bookings_available':updateSession(chatId, { lastInstruction: 'bookings_query', lastBookingsFilter: 'unassigned' }); return actions.showBookingsAvailable(chatId);
        case 'show_bookings_week':     return actions.showBookingsWeek(chatId);
        case 'show_contacts':          return actions.showContacts(chatId);
        // AI-classified, no regex in front of it — see SAFE_ACTIONS' comment
        // on 'lookup_address' for why this one is deliberately AI-first.
        // Falls back to the raw message text if the AI didn't isolate a name,
        // since resolveLaneEntry does its own alias/partial/raw-text matching
        // and copes fine with a bit of surrounding wording.
        case 'lookup_address':         return actions.lookupAddress(chatId, d.target_name || ctx.text.trim());
        // Recurring reminders (2026-08-22). `fact` carries the timing phrase
        // ("every morning", "every day at 8am") per the prompt; falling back
        // to the raw message means a reminder still gets a sane schedule even
        // if the AI didn't isolate the timing words.
        case 'send_message':           return actions.sendMessageTo(chatId, { target: d.target_name, message: d.note || d.email_details });
        // Receivables (2026-08-22). `fact` carries the amount and `note` the
        // free-text remainder (date/method), per the prompt guidance.
        case 'show_receivables':       return actions.showReceivables(chatId, d.target_name || null);
        // ── PAYING A SUPPLIER, BY MESSAGE ───────────────────────────
        // isManagerOrTeam is checked at the intent above AND here: the
        // intent gate stops a stranger's message being read as a payment,
        // and this one stops any other route reaching the action. Two gates
        // because this one writes money.
        // `send`, not an invented actions.reply — case 'reply' below is the
        // idiom, and actions.js exports no reply(). ctx.role === 'manager',
        // not ctx.isManager, which does not exist on ctx either: buildContext
        // returns `role` and `isManagerOrTeam` only. Both were mine, and both
        // would have thrown on her first real message.
        case 'pay_supplier':
            if (!ctx.isManagerOrTeam) return send(chatId, 'Only the owner and the team can record payments.');
            return actions.paySupplier(chatId, d.parsed, ctx.senderName);
        case 'pay_supplier_answer':
            if (!ctx.isManagerOrTeam) return send(chatId, 'Only the owner and the team can record payments.');
            return actions.paySupplierAnswer(chatId, ctx.pendingAction, d.answer_text, ctx.senderName,
                { isManager: ctx.role === 'manager' });
        case 'undo_bill_payment':
            if (!ctx.isManagerOrTeam) return send(chatId, 'Only the owner and the team can record payments.');
            return actions.undoBillPayment(chatId, { isManager: ctx.role === 'manager' });
        case 'record_payment':         return actions.recordPayment(chatId, { invoiceRef: d.target_name, amount: d.fact, paidOn: null, method: null, note: d.note }, ctx.senderName);
        case 'show_orphan_payments':   return actions.showOrphanPayments(chatId);
        // Opening-date watermark for the ledger (2026-08-22) — see
        // helpers/receivables.js. `fact` carries the date phrase.
        case 'set_receivables_start':  return actions.setReceivablesStart(chatId, d.fact || d.note || ctx.text);
        case 'track_old_invoice':      return actions.trackOldInvoiceCmd(chatId, d.target_name || d.note);
        case 'set_reminder':           return actions.setReminder(chatId, { target: d.target_name, message: d.note || d.email_details, when: d.fact || ctx.text });
        case 'show_reminders':         return actions.showReminders(chatId);
        case 'cancel_reminder':        return actions.cancelReminder(chatId, d.target_name || d.note || '');
        case 'forward_booking':        return bkg ? actions.forwardBooking(chatId, bkg, d.trucker_name, d.container_seq) : askBkg(chatId, 'Which booking should I forward? e.g. "forward BK123456"', 'forward_booking');
        case 'assign_supplier':        return bkg ? actions.assignSupplier(chatId, bkg, d.supplier_name, d.container_seq) : askBkg(chatId, 'Which booking should I assign? e.g. "assign BK123456"', 'assign_supplier');
        case 'recall_booking':         return bkg ? actions.recallBooking(chatId, bkg) : askBkg(chatId, 'Which booking should I recall?', 'recall_booking');
        case 'archive_booking':        return bkg ? actions.archiveNow(chatId, bkg) : askBkg(chatId, 'Which booking should I archive?', 'archive_booking');
        // the owner, 2026-09-06: "run a scan for booking that are past cut off
        // date". Distinct from archive_booking above, which needs a booking
        // number and archives exactly one — this asks the question "which are
        // expired?" and takes no argument at all.
        case 'scan_cutoffs':           return actions.scanPastCutoff(chatId);
        case 'schedule_followup':      return d.target_name ? actions.scheduleFollowup(chatId, d.target_name, d.minutes, bkg, ctx.senderName) : ask(chatId, 'Follow up with whom?');
        case 'draft_email':             return actions.draftEmailForConfirm(chatId, d.target_name, d.email_details, bkg, ctx.text, extractScheduleClause(ctx.text));
        case 'search_mail':             return actions.searchMail(chatId, d.target_name, d.note, bkg);
        case 'send_shipment_docs':      return actions.sendShipmentDocsForConfirm(chatId, d.container_no, ctx.text);
        case 'generate_sale_invoice':   return actions.startSaleInvoice(chatId, { target: d.target_name, container: d.container_no || d.container });
        case 'ask_data':               return actions.askLedger(chatId, d.question || ctx.text);
        case 'ask_text':               return actions.askText(chatId, d.question || ctx.text);
        case 'web_search':             return actions.webSearch(chatId, d.question || ctx.text);
        case 'log_bug':                return actions.logBug(chatId, { title: d.note || ctx.text, detail: d.details || null, area: d.location || null });
        case 'show_bugs':              return actions.showBugs(chatId, d.filter || 'open');
        case 'close_bug':              return actions.closeBugForConfirm(chatId, { ref: d.note || d.target_name, note: d.fact || null, status: d.filter === 'verified' ? 'verified' : 'fixed' });
        case 'sale_invoice_answer':     return actions.saleInvoiceAnswer(chatId, ctx.pendingAction, d.answer_text || ctx.text);
        case 'bug_close_yes':          return actions.applyBugClose(chatId, ctx.pendingAction);
        case 'generate_proforma':      return actions.startProformaFromEmail(chatId, d.target_name);
        case 'learn_writing_style':    return actions.learnWritingStyle(chatId);
        case 'show_writing_style':     return actions.showWritingStyle(chatId);
        case 'rescan_mail':            return actions.rescanMail(chatId);
        case 'show_pending_replies':    return actions.showPendingReplies(chatId);
        // quotedText is what she long-pressed and replied to — see index.js.
        // It is how a bare "what is this email about" finds its referent.
        case 'summarize_email':         return actions.summarizeEmail(chatId, d.index, d.target_name, ctx.quotedText);
        case 'reply_to_digest_item':    return actions.replyToDigestItem(chatId, d.index, d.details, ctx.text);
        case 'reply_to_focused_digest': return actions.replyToFocusedDigest(chatId, d.details || null, ctx.text);
        case 'pick_digest_reply':       return actions.askWhichDigestItem(chatId, d.indexes, d.details || null, ctx.text);
        case 'revise_email_draft':      return actions.reviseDraftedEmail(chatId, ctx.pendingAction, d.instruction);
        case 'mute_matter':           return actions.muteMatter(chatId, { index: d.index || null, target: d.target || null });
        case 'unmute_matter':         return actions.unmuteMatter(chatId, d.target || null);
        case 'show_mutes':            return actions.showMutes(chatId);
        case 'explain_digest_item':   return actions.explainDigestItem(chatId, d.index);
        case 'close_po':              return actions.closePurchaseOrder(chatId, d.po);
        case 'show_po':               return actions.showPurchaseOrder(chatId, d.po);
        case 'show_pos':              return actions.showPurchaseOrders(chatId);
        case 'draft_claim':           return actions.draftClaimEmail(chatId, d.container);
        case 'qb_stuck':              return actions.showQuickBooksStuck(chatId);
        case 'qb_check_now':          return actions.checkQuickBooksNow(chatId);
        case 'ignore_digest_item':      return actions.ignoreDigestItem(chatId, d.indices, d.all === true);
        case 'clear_older_items':       return actions.clearOlderItems(chatId);
        case 'reply_email':             return actions.draftReplyForConfirm(chatId, d.target_name, d.email_details, bkg, ctx.text, extractScheduleClause(ctx.text));
        case 'backfill_cutoffs':         return actions.backfillCutoffs(chatId);
        case 'verify_bookings':   return actions.verifyBookings(chatId, d.bkg_no ? [String(d.bkg_no).toUpperCase()] : null, { apply: d.apply === true });
        case 'get_quote':               return actions.startQuoteRequestFlow(chatId, d.origin, d.destination, d.names_text, d.emails);
        case 'get_contact_quote':       return actions.startContactQuoteRequestFlow(chatId, d.recipient_query, d.details);
        case 'contact_quote_recipient_retry_received': return actions.resumeContactQuoteWithRetry(chatId, ctx.pendingAction, ctx.text.trim());
        case 'quote_truckers_selected': return actions.resumeQuoteWithTruckerNames(chatId, ctx.pendingAction, d.names);
        case 'quote_cargo_details_received': return actions.resumeQuoteWithCargoDetails(chatId, ctx.pendingAction, d.cargo_text);
        case 'quote_scale_tickets_received': return actions.resumeQuoteWithScaleTickets(chatId, ctx.pendingAction, d.scale_text);
        case 'quote_trucker_retry_received':  return actions.resumeQuoteWithTruckerRetry(chatId, ctx.pendingAction, d.retry_text);
        case 'quote_leg_reply_received': return actions.handleQuoteLegReply(chatId, ctx.text.trim());
        case 'contact_quote_leg_reply_received': return actions.handleContactQuoteLegReply(chatId, ctx.text.trim());
        // A code change is only ever started by the exact-grammar policy rule, never by an AI-chosen action.
        case 'self_build':             return decision.resolvedBy === 'policy' && ctx.role === 'manager' ? actions.selfBuildCommand(chatId, d) : { action_taken: 'ignored' };
        case 'case_file':              return decision.resolvedBy === 'policy' && ctx.role === 'manager' ? actions.caseFileCommand(chatId, d) : { action_taken: 'ignored' };
        case 'price_answer':           return decision.resolvedBy === 'policy' && ctx.role === 'manager' ? actions.priceAnswerCommand(chatId, d) : { action_taken: 'ignored' };
        case 'deposit_auto':           return decision.resolvedBy === 'policy' && ctx.role === 'manager' ? actions.depositAutoCommand(chatId, d) : { action_taken: 'ignored' };
        case 'remember_fact':          return actions.rememberFact(chatId, d.fact);
        case 'add_business_context':   return actions.addBusinessContext(chatId, d.note);
        case 'ask_contact': {
            let { target_name, note, bkg_no } = d;
            // The AI has been observed correctly REASONING about who to ask
            // and what to ask, while leaving the actual target_name/note
            // fields empty in the same response — don't just fail with a
            // generic "who/what" question when there's enough context to
            // resolve it deterministically. Same auto-resolve logic as the
            // confirm-action guard above: figure out which party owns the
            // detected event, pull their name from the booking's own record.
            if ((!target_name || !note) && (bkg_no || ctx.activeBooking)) {
                const resolvedBkg = bkg_no || ctx.activeBooking;
                const wf = require('../helpers/json').loadWorkflow()[resolvedBkg] || {};
                const intent = actions.detectExpectedIntent(note || ctx.text);
                const party = intent === 'load_ready_received' ? 'supplier' : (intent ? 'trucker' : null);
                if (!target_name && party) target_name = party === 'trucker' ? wf.trucker_name : wf.supplier;
                if (!note) {
                    const QUESTION_BY_INTENT = {
                        empty_drop_confirmed: 'Is the empty container dropped yet?',
                        load_ready_received: 'Is the load ready for pickup?',
                        picked_up_confirmed: 'Has pickup happened yet?',
                        scale_ticket_received: 'Do you have the scale ticket yet?',
                        ingate_received: 'Has it been ingated at the port yet?',
                    };
                    note = QUESTION_BY_INTENT[intent] || ctx.text;
                }
                bkg_no = resolvedBkg;
                if (target_name) console.warn(`[BRAIN] ask_contact: AI left target_name/note empty despite reasoning about it — backfilled from booking ${resolvedBkg} (${party}: ${target_name})`);
            }
            return actions.relayQuestionToContact(chatId, target_name, note, bkg_no);
        }
        case 'ask_link_purpose': {
            // SHORT TTL, and this is the real reason the question is safe to
            // ask at all. The pending stores the url and staples it to her
            // NEXT message (see the await_link_purpose branch in
            // policyDecide). On the default 2-hour window that meant pasting a
            // link, getting distracted, and then asking "how many bookings
            // from LA" an hour later — with the sheet link silently attached
            // to that unrelated question.
            //
            // Ten minutes: long enough to say what she wants, short enough
            // that a forgotten link cannot contaminate a later message.
            // loadBrain() drops an expired pending on every read, with a log
            // line and nothing sent — so if she never answers, it just goes
            // away. That is why there is no "say cancel" in the message.
            await actions.setPending(chatId, {
                type: 'await_link_purpose', url: d.url, expires_in_ms: LINK_PENDING_TTL_MS,
            });
            return send(chatId, actions.describeLink(d.url));
        }
        case 'ask_pricelist_city': {
            await actions.setPending(chatId, { type: 'await_pricelist_city', target_name: d.target_name || null });
            return send(chatId, 'Which price list?\n1. Los Angeles\n2. Houston\n3. San Antonio');
        }
        case 'send_pricelist_city':    return actions.sendPriceListCity(chatId, d.city, d.target_name);
        case 'bookings_count_query': {
            // the owner, 2026-09-19: "show me number of bookings that we have
            // loaded this month" came back "0 bookings from null", and "shut
            // up" came back "0 bookings from shutup". The classifier is told
            // to use this ONLY when she names a place and did it anyway, so
            // the place is checked here, where it is used — see placeProblem.
            {
                const problem = placeProblem(d.location);
                if (problem) return send(chatId, problem);
            }
            updateSession(chatId, { lastInstruction: 'bookings_query', lastBookingsFilter: d.filter });
            const { count, bookings } = queryBookingsByLocation(d.location, d.filter);
            const label = d.filter === 'unassigned' ? 'unassigned (no supplier) ' : d.filter === 'assigned' ? 'assigned ' : '';
            const list = count && count <= 10 ? `: ${bookings.join(', ')}` : '';
            return send(chatId, `${count} ${label}booking${count === 1 ? '' : 's'} from ${d.location}${list}`);
        }
        case 'bookings_list_query': {
            {
                const problem = placeProblem(d.location);
                if (problem) return send(chatId, problem);
            }
            updateSession(chatId, { lastInstruction: 'bookings_query', lastBookingsFilter: d.filter });
            const { count, records } = queryBookingsByLocation(d.location, d.filter);
            const label = d.filter === 'unassigned' ? 'Unassigned (no supplier) ' : d.filter === 'assigned' ? 'Assigned ' : '';
            if (!count) return send(chatId, `No ${label.toLowerCase()}bookings from ${d.location}.`);

            // ── THE WINDOW SHE ASKED FOR, OR NO WINDOW AND NO PRETENCE ───
            // "check houston bookings with cut off anywhere next week" used
            // to come back as every Houston booking, which reads as a
            // complete answer and is not one. Now the range is applied, NAMED
            // in the reply so she can see which question was answered, and
            // any booking with no cutoff on file is reported rather than
            // quietly dropped — "we don't know" is not "no".
            const bk = require('../helpers/booking');
            const win = d.cutoff_phrase ? bk.cutoffWindow(d.cutoff_phrase) : null;
            const { rows, undated } = bk.withinCutoffWindow(records, win);
            const tail = undated ? `\n(${undated} more from ${d.location} have no cutoff date on file.)` : '';

            if (win && !rows.length) {
                return send(chatId, `No ${label.toLowerCase()}bookings from ${d.location} with a cutoff ${win.label}.${tail}`);
            }
            const body = rows.map(b => formatBookingLine(b)).join('\n');
            const scope = win ? `, cutoff ${win.label}` : '';
            return send(chatId, `${label}bookings from ${d.location}${scope} (${rows.length}):\n${body}${tail}`);
        }
        // ── THE METALS BILLS LEDGER ──────────────────────────────────────
        // the owner, 2026-09-19: "like in qb,it should allow jarvis to modify
        // everything as per command.if i say show me unfilled bills-it should
        // show". This is the READ half of that.
        //
        // ── AND IT IS IN BRAIN.JS, NOT IN helpers/tools.js ───────────────
        // helpers/tools.js is SCOUT — the yard assistant, fenced to Sample Yard Co Yard
        // on purpose, with a long note at the top about a bookings tool that
        // was added there and removed the same day. Purchase bills are Sample
        // Metals. Putting this in Scout would dissolve the boundary that note
        // exists to protect, by exactly the reasoning it predicts: "it cannot
        // answer about bills, so give it a bills tool."
        //
        // ONE DEFINITION OF "UNFILLED": helpers/bills.js's filterRows, which
        // is the same function the ledger screen and the export call. Three
        // answers to "which bills are unfinished" would eventually disagree,
        // and she would be the one to find out.
        case 'bills_query': {
            const billsLib = require('../helpers/bills');
            const all = billsLib.listWithTotals();
            const q = {};
            if (d.supplier) q.supplier = d.supplier;
            if (d.container) q.container_no = d.container;
            if (d.unfilled) q.unfilled = '1';
            if (d.unpaid) q.unpaid = '1';
            if (d.from) q.from = d.from;
            if (d.to) q.to = d.to;
            const rows = billsLib.filterRows(all, q)
                .sort((a, b2) => String(billsLib.sortableDate(b2.date) || '').localeCompare(String(billsLib.sortableDate(a.date) || '')));

            const what = [d.unfilled ? 'unfilled' : '', d.unpaid ? 'unpaid' : ''].filter(Boolean).join(' and ');
            const who = d.supplier ? ` from ${d.supplier}` : '';
            const label = `${what ? what + ' ' : ''}bills${who}`;
            if (!rows.length) return send(chatId, `No ${label}.`);

            const money = (n) => '$' + Number(n || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
            // ── EACH LINE SAYS WHAT IS MISSING ───────────────────────────
            // "12 unfilled bills" is a number she then has to go and look up.
            // Naming the gap per row is the answer to the question she asked.
            const line = (b2) => {
                const miss = billsLib.missingFor(b2);
                const bits = [b2.date || 'no date', b2.supplier || 'no supplier', b2.container_no || 'no container'];
                const tail = d.unfilled && miss.length ? ` — needs ${miss.join(', ')}`
                    : (b2.balance > 0.005 ? ` — ${money(b2.balance)} owing` : '');
                return `• ${bits.join(' · ')}${tail}`;
            };
            // Capped, and the cap is STATED. A truncated list presented as the
            // whole is how a confident wrong total gets spoken aloud.
            const SHOW = 15;
            const body = rows.slice(0, SHOW).map(line).join('\n');
            const more = rows.length > SHOW ? `\n…and ${rows.length - SHOW} more.` : '';
            const owed = rows.reduce((t, b2) => t + (Number(b2.balance) || 0), 0);
            const foot = (!d.unfilled && owed > 0.005) ? `\nOutstanding: ${money(owed)}` : '';
            return send(chatId, `${rows.length} ${label}:\n${body}${more}${foot}`);
        }
        case 'empty_drop_confirmed':   return actions.emptyDropConfirmed(bkg, ctx.senderName, d.container_seq);
        case 'load_ready_received':    return actions.loadReadyReceived(bkg, ctx.senderName, d.container_seq);
        case 'picked_up_confirmed':    return actions.pickedUpConfirmed(bkg, !!d.scale_ticket, ctx.senderName, d.container_seq);
        case 'scale_ticket_received':  return actions.scaleTicketReceived(bkg, d.container_seq);
        // Standalone yard pipeline — deliberately NOT the same case as
        // 'scale_ticket_received' above (that one flips a flag on a booking's
        // container; this one is its own record, unrelated to bkg/container).
        case 'yard_scale_ticket_received': return actions.yardScaleTicketReceived(chatId, ctx.senderName, d.image_base64, d.mime_type);
        case 'ingate_received':        return actions.ingateReceived(bkg, ctx.senderName, d.container_seq);
        case 'ask_which_container':    return actions.askWhichContainer(chatId, d);
        case 'ask_which_booking':      return actions.askWhichBooking(chatId, d, ctx.matchedTrucker?.name || ctx.matchedSupplier?.name, ctx.isSupplier ? 'supplier' : 'trucker');
        case 'check_supplier':         return bkg ? actions.checkSupplierReadiness(chatId, bkg, d.container_seq) : askBkg(chatId, 'Which booking? I will ping its supplier for pickup status.', 'check_supplier');
        case 'ready_check_yes':        return actions.resolveReadyCheckYes(chatId, ctx.pendingAction);
        case 'ready_check_no':         return actions.resolveReadyCheckNo(chatId, ctx.pendingAction);
        case 'ready_check_date':       return actions.resolveReadyCheckDate(chatId, ctx.pendingAction, d.date_text);
        case 'container_number_received': return actions.recordContainerNumber(chatId, ctx.pendingAction, d.container_number);
        case 'relay_reply_received':      return actions.relayReplyReceived(chatId, ctx.pendingAction, d.reply_text);
        case 'manual_email_address_received': return actions.resolveManualEmailAddress(chatId, d.address_text);
        case 'learn_domain':                  return actions.learnDomainForConfirm(chatId, d.term);
        case 'domain_learn_name_received':    return actions.resolveDomainLearnName(chatId, d.name_text);
        // Whitelist info queries — trucker/supplier can ask ERD or cutoff of their active booking.
        case 'trucker_ask_erd':
        case 'supplier_ask_erd':       return actions.showErd ? actions.showErd(chatId, bkg) : ask(chatId, `ERD: ${(actions.getBookingField && actions.getBookingField(bkg, 'erd_date')) || 'not set'}`);
        case 'trucker_ask_cutoff':
        case 'supplier_ask_cutoff':    return actions.showCutoff ? actions.showCutoff(chatId, bkg) : ask(chatId, `Cutoff: ${(actions.getBookingField && actions.getBookingField(bkg, 'cutoff_date')) || 'not set'}`);
        // Silence — trucker/supplier used a recognized keyword but no container matched it.
        // Deliberate: this is a known-shape message with nothing to do, not "we don't understand".
        case 'silent':                 return { action_taken: 'silent' };
        case 'forward_booking_menu':
        case 'ask_booking_number':     return askBkg(chatId, 'Type the booking number.', 'show_booking_status');
        case 'ask_which_booking':      return ask(chatId, `This chat has multiple bookings: ${(d.slots || []).join(', ')}. Which one?`);
        case 'reply': {
            if (!d.reply) return { action_taken: 'noop' };
            // A reply to a trucker or supplier is checked before it leaves: if it
            // names someone else on file or mentions money it is held back and
            // the team is told instead (helpers/partyAnswer.guardReply).
            if (ctx.isTrucker || ctx.isSupplier) {
                const pa = require('../helpers/partyAnswer');
                const kind = ctx.isTrucker ? 'trucker' : 'supplier';
                const who = (ctx.isTrucker ? ctx.matchedTrucker : ctx.matchedSupplier) || {};
                const held = pa.guardReply({ kind, name: who.name, text: d.reply, bookings: ctx.allBookings, rosters: { truckers: ctx.truckers, suppliers: ctx.suppliers } });
                if (held) { console.warn('[BRAIN] reply to ' + kind + ' held back: ' + held); return actions.holdPartyReply(ctx, held); }
            }
            return send(chatId, d.reply);
        }
        case 'NEED_APPROVAL':          return ask(chatId, `This needs your explicit confirmation. ${d.reply || 'Please restate the exact action.'}`);
        case 'NEED_DATA':
        default:
            if (ctx.isManagerOrTeam) {
                // Only log as a "gap to learn from" when this genuinely reached Gemini and
                // came back unresolved — not when Gemini itself was unavailable (that's an
                // outage, not a knowledge gap) and not on trivial policy-layer misses.
                if (decision.resolvedBy === 'ai' && d.reasoning !== 'AI unavailable') {
                    try { await actions.logKnowledgeGap(ctx, d.reasoning, false); } catch (e) { console.error('[BRAIN] gap log failed:', e.message); }
                }
                return ask(chatId, d.reply || "I couldn't pin that down. Type 'menu' for options or give me a booking number.");
            }
            // Trucker/supplier said something we genuinely couldn't classify (reached here via
            // AI fallback, not the policy-layer keyword-silence above). Escalate, don't ignore.
            // NOTE: bare `process` is this file's own process() function, not the Node global.
            if (ctx.isTrucker || ctx.isSupplier) return globalThis.process.env.JARVIS_PARTY_ANSWER === '1' ? actions.answerParty(ctx) : actions.escalateUnclear(ctx);
            return { action_taken: 'silent' }; // truly unknown sender — stay silent
    }
}

// ── Main entry ────────────────────────────────────────────────────────────────
// The "(Still pending...)" reminder tail used to hardcode "reply yes/no" for
// every pending type. That's wrong for anything that isn't a literal yes/no
// confirm — e.g. await_followup_minutes wants a number/time, await_bkg_no
// wants a booking number, await_pricelist_city wants a pick. Telling the
// manager "reply yes/no" when the pending actually wants a time value is
// actively misleading. Give a hint that matches what the pending actually expects.
function pendingHint(p) {
    if (p.type === 'await_followup_minutes') return 'reply with a number of minutes (e.g. 15) or a time like "2 hours"';
    if (p.type === 'await_bkg_no') return 'reply with the booking number';
    if (p.type === 'await_pricelist_city') return 'reply 1, 2, or 3, or the city name';
    if (p.type === 'await_link_purpose') return 'tell me what to do with that link, or say cancel';
    if (p.options && p.options.length) return `reply with one of: ${p.options.join(', ')}`;
    return 'reply yes/no';
}

// Wizard pendings get a FULL restated question instead of the terse generic
// template — "reply yes/no" with no context on what it's asking led to a
// real incident: the manager, days after the daily wizard trigger fired and
// went unanswered, had no idea what "wizard start" meant and asked the AI to
// explain, which then answered from general knowledge instead of the actual
// pending — a hallucinated-sounding but wrong explanation. Restating the
// original question directly in the reminder prevents that confusion from
// happening in the first place, rather than relying on the AI to explain a
// pending it has no real visibility into.
// Pendings Jarvis raised for its own benefit, not hers. Nobody is waiting on
// an answer, nothing is held, and an unanswered one costs nothing — so they
// must never chase her. Everything NOT on this list is treated as a gate: it
// is holding an action (an unsent email, a wizard mid-flight, a contradiction
// that needs a decision) and gets exactly one reminder.
//
// New pending types default to GATE by omission, which is the safe direction:
// a nag she did not want is an annoyance, a draft that vanished without a word
// is a lost customer reply.
const OPTIONAL_PENDINGS = new Set([
    'wizard_start',          // the daily "any bookings going out today?" poke
    'await_fact_batch',      // end-of-day learning review — the exact one she quoted back
    'await_link_purpose',    // "what did you want me to do with this link?"
    'await_ready_check',
    'await_domain_learn_name',
]);

function pendingFullReminder(p) {
    // the owner, 2026-10-28, after "(Next up...) You also have a proforma waiting to be
    // sent waiting on this chat - go ahead and reply." -> "How?". The generic text
    // never said what to type. A proforma is answered yes or no.
    if (p.type === 'confirm_proforma') return `(Still waiting: generate proforma ${(p.invNo || p.draft?.invNo || '').toString().trim() || 'invoice'} and email it to ${p.draft?.consignee || p.who || 'the buyer'}${p.subject ? ` — from "${p.subject}"` : ''}? Reply yes to send it, or no to drop it.)`;
    if (p.type === 'wizard_start') return '(Still waiting on this from earlier: any bookings need to go out to a trucker today? Reply yes or no — or "cancel" to dismiss this.)';
    if (p.type === 'wizard_await_port') return `(Still waiting: which port? ${(p.options || []).map((o, i) => `${i + 1}. ${o}`).join(', ')} — or "cancel" to dismiss.)`;
    if (p.type === 'wizard_await_booking') return `(Still waiting: which booking? ${(p.options || []).map((o, i) => `${i + 1}. ${o}`).join(', ')} — or "cancel" to dismiss.)`;
    if (p.type === 'wizard_confirm') return `(Still waiting: confirm ${p.bkg_no} — Supplier: ${p.supplier_name}, Trucker: ${p.trucker_name}? Reply yes or no.)`;
    if (p.type === 'await_fact_batch') {
        const list = (p.candidates || []).map((c, i) => `${i + 1}. ${c}`).join('\n');
        return `(Still waiting: end-of-day review —\n${list}\n\nReply with numbers to accept (e.g. "1,3"), "all", or "no" to skip all.)`;
    }
    if (p.type === 'await_fact_conflict') {
        return `(Still waiting: "${p.newText}" contradicts "${p.oldText}". Reply *replace*, *both*, or *cancel*.)`;
    }
    if (p.type === 'await_email_confirm') {
        const ccBcc = [p.cc ? `Cc: ${p.cc}` : null, p.bcc ? `Bcc: ${p.bcc}` : null].filter(Boolean).join('\n');
        return `(Still waiting: send this email to ${p.target_name} <${p.to}>?\n${ccBcc ? ccBcc + '\n' : ''}Subject: ${p.subject}\n\n${p.body}\n\nReply yes or no.)`;
    }
    if (p.type === 'await_manual_email_address') {
        // Restates that contacts + mail were already checked — the original
        // staging message says this, but this reminder-tail (shown later,
        // out of context from that first message) didn't, which read like
        // no search happened at all. Real feedback, 2026-08-03 ("why it is
        // not checking mail?") — fixed for clarity, not a logic change; the
        // search itself already always ran before this pending exists.
        return `(Still waiting on ${p.target_name}'s email — checked saved contacts and mail, found nothing. I'll draft the email to them about "${p.details || '(what you asked)'}" once you give me the address — or reply "cancel".)`;
    }
    // ── "DID YOU MEAN JAYASHREE?" ────────────────────────────────────────
    // the owner, 2026-09-07: "send mail to jeyshree" transcribed as "jayashree".
    // draftEmailForConfirm offers the name that SOUNDS right and waits.
    //
    // The reminder quotes BOTH spellings — what she said and what is on file
    // — because coming back to this cold, "did you mean Jayashree?" is only
    // answerable if she can see it was "jeyshree" that Jarvis heard.
    if (p.type === 'await_name_confirm') {
        const opts = p.matches || [];
        if (opts.length === 1) {
            return `(Still waiting — I don't have anyone called "${p.heard}". Did you mean ${opts[0].name} <${opts[0].email}>? Reply yes or no.)`;
        }
        const listText = opts.map((c, i) => `${i + 1}. ${c.name} <${c.email}>`).join('\n');
        return `(Still waiting — I don't have anyone called "${p.heard}". Did you mean one of these?\n${listText}\n\nReply with the number, or "no".)`;
    }
    if (p.type === 'await_reply_thread_pick' || p.type === 'await_digest_reply_pick') {
        const listText = (p.options || []).map((o, i) => `${i + 1}. ${o}`).join('\n');
        return `(Still waiting — which one should I reply to?\n${listText}\n\nSay the number, or "cancel".)`;
    }
    if (p.type === 'await_compose_instead') {
        return `(Still waiting: no email from ${p.target_name} to reply to — want me to write them a new one? Reply yes or no.)`;
    }
    if (p.type === 'await_cc_pattern_confirm') {
        return `(Still waiting: save ${p.detected_cc.join(', ')} as ${p.target_name}'s standing cc? Reply yes or no — either way I'll draft the email to them next.)`;
    }
    if (p.type === 'await_contact_disambiguation') {
        const listText = (p.matches || []).map((c, i) => `${i + 1}. ${c.name} <${c.email}>`).join('\n');
        return `(Still waiting — which saved contact did you mean for "${p.target_name}"?\n${listText}\n\nReply with the number, or "cancel".)`;
    }
    if (p.type === 'await_domain_learn_name') {
        return `(Still waiting on a name for ${(p.needs_name || []).join(', ')} before I can save the ${p.domain} contacts — or reply "cancel".)`;
    }
    if (p.type === 'await_domain_learn_confirm') {
        return `(Still waiting: save the ${p.domain} contacts I proposed? Reply yes or no.)`;
    }
    if (p.type === 'await_quote_trucker_retry') {
        return `(Still waiting — couldn't find a saved trucker named "${(p.unresolvedNames || []).join(', ')}". Reply with the correct name, or their email address, or "cancel".)`;
    }
    if (p.type === 'await_verify_apply') {
        const n = (p.bookings || []).length;
        return `(Still waiting: reply *apply* and I'll correct ${n === 1 ? `${(p.bookings || [])[0]}` : `those ${n} bookings`} from the latest confirmation PDF, or "no" to leave them.)`;
    }
    if (p.type === 'await_payment_held_answer') {
        return `(Still waiting: is the payment I found really from ${p.customer}? Reply yes (hold their follow-up) or no (carry on).)`;
    }
    if (p.type === 'await_payment_confirm') {
        const m = `$${(Math.round((Number(p.amount) || 0) * 100) / 100).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
        return `(Still waiting: a payment of ${m} looks like it arrived for ${p.inv_no}${p.source_from ? ` — from "${String(p.source_from).slice(0, 40)}"` : ''}. Record it? Reply yes or no — nothing is credited until you say yes.)`;
    }
    // The five quote-flow cases below (2026-08-20, per the owner: "Tell user
    // about the request that you requested quote from A to B. but you
    // didn't give this. so now my question") — restate WHAT the original
    // quote request was for, not just a bare "reply yes/no"/generic prompt,
    // now that a fresh unrelated command can interrupt any of these
    // mid-flow (see detectFreshCommand above).
    if (p.type === 'await_quote_cargo_details') {
        const { originQuery, destinationQuery } = p.state || {};
        const lane = originQuery && destinationQuery ? ` for the ${originQuery} → ${destinationQuery} quote` : '';
        return `(Still waiting on cargo details${lane} — what's the cargo? Description, weight, and value; both weight AND value are required.)`;
    }
    if (p.type === 'await_quote_scale_tickets') {
        const { originQuery, destinationQuery } = p.state || {};
        const lane = originQuery && destinationQuery ? ` for the ${originQuery} → ${destinationQuery} quote` : '';
        return `(Still waiting on one thing${lane} — do you need scale tickets for this haul? Reply yes or no.)`;
    }
    if (p.type === 'await_quote_truckers') {
        const { originQuery, destinationQuery } = p.state || {};
        const lane = originQuery && destinationQuery ? `${originQuery} → ${destinationQuery}` : 'that quote';
        const listText = (p.options || []).map((o, i) => `${i + 1}. ${o}`).join('\n');
        return `(Still waiting — who should I ask for ${lane}?\n${listText}\n\nReply with names or numbers, comma-separated for more than one, or "cancel".)`;
    }
    if (p.type === 'confirm_quote_lane') {
        const { originQuery, destinationQuery } = p.state || {};
        const lane = originQuery && destinationQuery ? `${originQuery} → ${destinationQuery}` : 'that quote';
        const listText = (p.options || []).map((o, i) => `${i + 1}. ${o}`).join('\n');
        return `(Still waiting on ${lane} — "${p.field === 'origin' ? originQuery : destinationQuery}" matched more than one saved address. Which one?\n${listText}\n\nReply with the number.)`;
    }
    if (p.type === 'confirm_quote_trucker') {
        const { originQuery, destinationQuery } = p.state || {};
        const lane = originQuery && destinationQuery ? ` for ${originQuery} → ${destinationQuery}` : '';
        const listText = (p.options || []).map((o, i) => `${i + 1}. ${o}`).join('\n');
        return `(Still waiting${lane} — more than one saved trucker matched. Which one?\n${listText}\n\nReply with the number.)`;
    }
    if (p.type === 'await_contact_quote_recipient_retry') {
        const { recipientQuery, details } = p.state || {};
        const forWhat = details ? ` about "${details}"` : '';
        return `(Still waiting — couldn't find a saved contact named "${recipientQuery || '(unknown)'}"${forWhat}. Reply with the correct name, or "cancel".)`;
    }
    if (p.type === 'await_sale_invoice' && p.question) {
        return `(Still waiting on the invoice${p.container ? ` for ${p.container}` : ''}: ${p.question} — or "cancel".)`;
    }
    return null; // no type-specific text — use the generic template
}

async function process(rawEvent, sendMessage) {
    const started = Date.now();
    const inbound = await normalize(rawEvent);

    if (!inbound.isAuthorized) {
        console.log(`[BRAIN] Unauthorized ${inbound.senderNumber} in ${inbound.chatId} — silent`);
        return;
    }
    if (isDuplicate(inbound.messageId)) return;

    // Record what the manager/team said, verbatim, before anything can fail or
    // reclassify it. Record-only: never throws, never blocks, changes no decision.
    if (inbound.role === 'manager' || inbound.role === 'team' || inbound.role === 'yard') {
        try { require('../helpers/inboundLog').record({ chatId: inbound.chatId, role: inbound.role, messageId: inbound.messageId, text: inbound.text }); } catch (e) { /* never block a reply */ }
    }

    console.log(`[BRAIN] ${inbound.role} | ${inbound.chatId} | "${String(inbound.text).slice(0, 60)}"`);

    // Pending state now applies to any authorized chat, not just manager/team —
    // the "check supplier" ready flow needs a pending question on the SUPPLIER's
    // own chat (awaiting yes/no, then possibly a date).
    const pending = actions.getPending(inbound.chatId);
    // ── Customer in focus: "what do they owe" / "their balance" / "show their case" right after a customer came up. Fills in the NAME and
    // nothing else, only for those exact shapes, only with no question open (a verbatim-capture pending must receive her real words), and
    // never over a sentence that already names someone. Read-only questions only. See helpers/customerFocus.js.
    if (inbound.role === 'manager' && !pending) {
        try {
            const f = require('../helpers/customerFocus').resolve(inbound.text, require('../helpers/context').getSession(inbound.chatId));
            if (f) { inbound.originalText = inbound.text; inbound.text = f.text; inbound.textLower = f.text.toLowerCase(); console.log(`[BRAIN] customer in focus: "${inbound.originalText}" -> "${f.text}"`); }
        } catch (e) { /* a failed lookup leaves her words exactly as she typed them */ }
    }
    const ctx     = await buildContext(inbound, pending);

    let decision = policyDecide(ctx);

    // ── Pending arbiter — "is this an answer, or has she moved on?" ─────────
    // policyDecide is synchronous and cannot call Gemini, so the trap points
    // inside it just TAG themselves with `arbitrate: true` and the actual
    // judgement happens here, where we can await. See helpers/pendingArbiter.js
    // for the full reasoning; the short version is that deciding whether a
    // sentence answers a question is a question of MEANING, and the two
    // regex grammars detectFreshCommand knows about will never cover the
    // ways a person actually phrases things.
    //
    // Only ever fires when a pending is genuinely open AND policy was about
    // to either capture the message verbatim as the answer or reject it with
    // a canned nag — i.e. exactly the spots where the owner's real questions
    // were being lost. Costs one Gemini call in that narrow case and nothing
    // at all the rest of the time.
    //
    // NEW_REQUEST is the only verdict that changes anything: it drops the
    // policy decision and reclassifies the message from scratch, exactly as
    // if no pending existed. The pending itself is deliberately left OPEN —
    // it is not answered and not cancelled — so the existing reminder tail
    // further down still brings it back after she gets her real answer.
    // That is the "answer the fresh query, then show the pending" behaviour
    // she asked for on 2026-08-20, generalized to any phrasing.
    if (decision.arbitrate && ctx.pendingAction && inbound.isManagerOrTeam) {
        try {
            const { classifyAgainstPending } = require('../helpers/pendingArbiter');
            const question = pendingFullReminder(ctx.pendingAction)
                || `${ctx.pendingAction.type.replace(/_/g, ' ')} — ${pendingHint(ctx.pendingAction)}`;
            const verdict = await classifyAgainstPending(ctx.text, question);
            if (verdict === 'NEW_REQUEST') {
                console.log(`[BRAIN] Arbiter: treating as a new request, "${ctx.pendingAction.type}" left open`);
                // Re-run policy with the pending hidden, so any deterministic
                // grammar that WOULD have matched still gets its chance
                // before falling back to the AI classifier. Without this a
                // plain "menu" or "urgent" would needlessly cost a second
                // Gemini round-trip.
                decision = policyDecide({ ...ctx, pendingAction: null });
            }
        } catch (e) {
            // Never let the arbiter break message handling — on any failure
            // the original policy decision stands untouched.
            console.error('[BRAIN] Arbiter threw, keeping original decision:', e.message);
        }
    }

    if (decision.needsAI) {
        const ai = await aiDecide(ctx);
        decision = {
            intent    : ai.action,
            resolvedBy: 'ai',
            confidence: ai.confidence ?? null,
            // Every field the AI is allowed to return must be forwarded, or
            // the action fires with empty parameters and fails in a way that
            // looks like the AI got it wrong. The six intents added 2026-08-22
            // (bookings_list_query, bookings_count_query, get_quote,
            // get_contact_quote, send_pricelist_city, learn_domain) each need
            // fields the original list did not carry.
            data      : {
                bkg_no: ai.bkg_no, supplier_name: ai.supplier_name, trucker_name: ai.trucker_name,
                target_name: ai.target_name, email_details: ai.email_details, minutes: ai.minutes,
                fact: ai.fact, note: ai.note, reply: ai.reply, reasoning: ai.reasoning,
                location: ai.location, filter: ai.filter,
                origin: ai.origin, destination: ai.destination, names_text: ai.names_text,
                recipient_query: ai.recipient_query, details: ai.details,
                city: ai.city, term: ai.term,
                apply: ai.apply === true, all: ai.all === true,
                // LIVE, 1 Sep 11:30am. She typed "Ignore 1" and got back
                // "I don't have a #undefined from a recent digest."
                //
                // `indices` was never on this list. The AI prompt has told
                // the model to return it since the day ignore_digest_item was
                // written — the model was returning it correctly, and this
                // mapping dropped it on the floor. So EVERY ignore that
                // reached the AI rather than the policy regex was broken,
                // always, and printed "#undefined" at her.
                //
                // FIFTH TIME this codebase has been bitten by a field
                // allowlist. saveStore's has silently eaten lastScanAt,
                // sentIndex and failures, and nearly ate `muted` yesterday.
                // The pattern is always the same: a list that must be edited
                // in a second place whenever a field is added, with no error
                // when it is not. Worth replacing with a pass-through, but
                // not in the same change as a live bug fix.
                indices: ai.indices,
                // SIXTH TIME (2026-09-20), found adding `report` below: the
                // prompt has asked the model for cutoff_phrase (bookings
                // window, 09-08) and for unfilled/unpaid/supplier/container/
                // from/to (bills_query, 09-19), and this list dropped every
                // one — so "Houston bookings cutting off next week" and
                // "unfilled bills from carrier" worked only when a regex caught
                // them, and silently answered a WIDER question when the AI
                // did. Forwarded now, with metals_report's `report`.
                report: ai.report,
                cutoff_phrase: ai.cutoff_phrase,
                unfilled: ai.unfilled === true, unpaid: ai.unpaid === true,
                supplier: ai.supplier, container: ai.container,
                from: ai.from, to: ai.to,
                // ask_data carries her question verbatim (2026-09-23). Without
                // it here the action fires with an empty question and answers
                // nothing — the field-forwarding bug this list exists to stop.
                question: ai.question,
            },
        };
    }

    // ── Compound-request guard ────────────────────────────────────────────
    // Added 2026-08-23, prompted by the owner's voice-command example: "check
    // mail from Joey AND send proforma to her". This router handles exactly
    // ONE intent per message — it's a single switch on decision.intent — so
    // the second half of a request like that was simply discarded. Silently.
    // The mail would be checked, nothing would be said about the proforma,
    // and the only way to notice was to remember what you'd asked for.
    //
    // That gets worse with voice, where a whole sentence arrives at once and
    // there's no sent-message history to scroll back through.
    //
    // This does NOT execute the second part — chaining intents is a much
    // bigger change. It just refuses to pretend the request was fully
    // handled, which is the difference between a limitation and a bug.
    //
    // Deliberately conservative: it needs an "and"/"then"/"also" followed
    // closely by a real command verb. "check mail from Joey and ops" has no
    // verb after the "and" and so doesn't trigger; neither does a single
    // clause of any length.
    const COMPOUND_RE = /\b(?:and|then|also|after that)\s+(?:can you\s+|please\s+|you\s+)?(send|check|prepare|make|create|generate|draft|show|tell|ask|remind|add|book|forward|reply|email|call|update|cancel|delete|assign|share)\b/i;
    const looksCompound = COMPOUND_RE.test(ctx.text || '');

    let result = { action_taken: 'error' };
    try {
        result = await route(decision, ctx, sendMessage);
        if (looksCompound && inbound.isManagerOrTeam && result && result.action_taken !== 'error') {
            const m = COMPOUND_RE.exec(ctx.text || '');
            const second = (ctx.text || '').slice(m.index).replace(/^\s*(and|then|also|after that)\s+/i, '').trim();
            await sendMessage(inbound.chatId,
                `That looked like two requests — I only did the first one. I handle one at a time.\n\nSend this separately if you still want it:\n"${second}"`);
        }
    } catch (err) {
        console.error('[BRAIN] Route failed:', err);
        if (inbound.isManagerOrTeam) {
            // A missing action is a WIRING bug, not a runtime failure, and it
            // deserves different wording. Added 2026-08-22 after the owner asked
            // "any payments today?" and got back
            // "actions.showReceivables is not a function" — eleven intents
            // had been routing at functions a bad merge deleted hours
            // earlier (see the restored block in workflow/actions.js).
            //
            // Two things were wrong with that reply. It reads like the
            // request was malformed rather than the code, so the natural
            // response is to rephrase and try again — which can't ever work.
            // And it leaks an internal symbol name to someone who has no use
            // for it. This says plainly that the feature is broken, so the
            // next move is to report it rather than retry.
            // ── IT FILES ITSELF ON THE BUGZILLA TAB (2026-09-24) ────────
            // Her choice when the tab was built: crashes file themselves.
            // "I've logged it" below was true of the console and nowhere she
            // could see; now it is true of a list she reads. Deduplicated by
            // error signature, so one broken feature is one row however many
            // times she hits it.
            try {
                await require('../helpers/bugs').autoFileCrash(err,
                    `Jarvis handling "${String(inbound.text || '').slice(0, 60)}"`);
            } catch (e2) { console.error('[BRAIN] could not file the crash:', e2.message); }

            const wiring = /^actions\.([A-Za-z0-9_]+) is not a function$/.exec(err.message || '');
            if (wiring) {
                console.error(`[BRAIN] WIRING BUG: intent '${decision.intent}' routes to actions.${wiring[1]}(), which is not exported. Check workflow/actions.js.`);
                await sendMessage(inbound.chatId, "That feature isn't working right now — it's a bug on my side, not something you said. I've logged it. Nothing was changed or saved.");
            } else {
                await sendMessage(inbound.chatId, `Something broke while handling that: ${err.message}`);
            }
        }
    }

    // If this message's own handling freed up the pending slot on this chat
    // (answered a wizard step, confirmed/declined an email send, etc.) and
    // didn't immediately re-claim it for a follow-up step of its own, bring
    // in whatever was queued behind it — see actions.js's promoteQueued.
    try { await actions.promoteQueued(inbound.chatId); } catch (e) { console.error('[BRAIN] promoteQueued failed:', e.message); }

    // Reminder tail — pending still open after an unrelated exchange
    // REAL BUG (found 2026-08-05, live): a "get quote from LA to Richmond
    // ask X" sent while an earlier quote-request pending was ALREADY
    // unresolved on that chat gets queued behind it (setPending's own
    // never-overwrite rule) — pauseForLaneAmbiguity/pauseForTruckerAmbiguity/
    // askWhichTruckers/askForCargoDetails/askForScaleTickets/pauseForContactQuoteRetry
    // etc. already say so explicitly ("...but you have a pending X to answer
    // first"). Without an exclusion, THIS generic tail fires right after
    // that same message and re-prints the still-active pending's full
    // question again — a redundant second message describing the exact same
    // thing the first one just said.
    //
    // Originally this was a hand-maintained list of exact action_taken
    // values, extended one bug fix at a time as each new *_queued outcome
    // was discovered live (2026-08-05, 2026-08-06 x2, 2026-08-20). 2026-08-20:
    // generalized to a naming-convention check instead — EVERY *_queued
    // action_taken across actions.js (grep confirms ~15 of them, all
    // following this exact same "setPending saw queued:true, already told
    // the manager, don't repeat it" pattern) is now covered by one rule
    // instead of needing its own entry added by hand each time a new one is
    // found. This matters more now that detectFreshCommand (see brain.js's
    // "A(-1)") can trigger a *_queued outcome from many more starting
    // pendings than before.
    const alreadyExplainedPending = /_queued$/.test(result?.action_taken || '') ||
        // Non-"_queued" outcomes that also already say everything needed —
        // unchanged from before.
        ['confirmed_pending', 'cancelled_pending', 'forwarded', 'assigned', 'recalled',
          // 2026-08-20: resumeQuoteWithCargoDetails's mandatory weight/value
          // retry deliberately leaves the SAME pending active when the reply
          // has no number in it, so the next reply routes back to the same
          // handler — but that made this generic tail see "pending still
          // active" and append a mismatched "reply yes/no" hint (pendingHint
          // has no case for await_quote_cargo_details) right after the retry
          // message already explained exactly what's needed. Real bug, live
          // 2026-08-20 ("Weight and value are required..." immediately
          // followed by a nonsensical "reply yes/no" tail).
          'quote_cargo_details_retry'].includes(result?.action_taken);
    // ── THE "STILL WAITING" TAIL ────────────────────────────────────────────
    //
    // the owner, 2026-09-06, asked what it would take to not have a pending list
    // at all, and chose: "tell me one at a time, as it arrives."
    //
    // This tail used to append a reminder after EVERY unrelated message for as
    // long as a pending sat unanswered. Ask her about a booking, get the
    // booking plus a nag about last Tuesday's end-of-day review. That is the
    // list she is describing: not a list she opens, a list that follows her
    // around. Her own words earlier in the same session, quoting it back at
    // Jarvis: "(Still waiting: end-of-day review — 1. remember: ... 2.
    // remember: ...)" appended to a question about Houston bookings.
    //
    // Two rules now:
    //
    //   OPTIONAL pendings never nag at all. Jarvis asked, she did not answer,
    //   that is an answer. They expire on their own (cfg.PENDING_EXPIRY_MS).
    //
    //   GATE pendings — the ones HOLDING something of hers, above all an
    //   unsent drafted email — remind exactly ONCE and then go quiet. Not
    //   zero: silently sitting on a draft she believes is going out is worse
    //   than one reminder. Not forever: that is what she asked to stop.
    //
    // Deliberately NOT deleting the pending. "Stop nagging me" is not "throw
    // away my draft" — the pending stays answerable, and "what's pending"
    // still lists it on demand.
    if (inbound.isManagerOrTeam && pending && !alreadyExplainedPending) {
        const fresh = actions.getPending(inbound.chatId);
        if (fresh && fresh.created_at === pending.created_at
            && !OPTIONAL_PENDINGS.has(fresh.type)
            && !fresh.reminded_at) {
            const fullReminder = pendingFullReminder(fresh);
            if (fullReminder) {
                await sendMessage(inbound.chatId, fullReminder);
            } else {
                const bkgPart = fresh.bkg_no ? ` for ${fresh.bkg_no}` : '';
                await sendMessage(inbound.chatId, `(Still pending: ${fresh.type.replace(/_/g, ' ')}${bkgPart} — ${pendingHint(fresh)}.)`);
            }
            await actions.markPendingReminded(inbound.chatId);
        }
    }

    await saveTranscript(inbound.chatId, {
        messageId : inbound.messageId,
        senderRole: inbound.role,
        senderName: inbound.senderName,
        text      : inbound.text,
        hasMedia  : !!inbound.hasMedia,
        intent    : decision.intent,
        resolvedBy: decision.resolvedBy,
        actionTaken: result?.action_taken,
        at        : new Date().toISOString(),
    });
    await appendAuditLog({
        source     : 'core',
        chatId     : inbound.chatId,
        messageId  : inbound.messageId,
        senderRole : inbound.role,
        senderName : inbound.senderName,
        text       : inbound.text,
        hasMedia   : !!inbound.hasMedia,
        intent     : decision.intent,
        resolvedBy : decision.resolvedBy,
        confidence : decision.confidence ?? (decision.resolvedBy === 'policy' ? 1 : null),
        actionTaken: result?.action_taken,
        durationMs : Date.now() - started,
    });

    console.log(`[BRAIN] ${decision.intent} → ${result?.action_taken} (${Date.now() - started}ms)`);
}
// ── LLM fallback for manager/team messages ──────────────────────────────────
// Called ONLY when deterministic policy layer returns unresolved.
// Returns { intent, data, resolvedBy, confidence } for router, or null to
// fall through to menu / "I don't understand".
async function handleManagerLLMFallback(text, chatId, sendMessage) {
    const decision = await llmIntent.extractManagerIntent(text);
    const verdict  = llmIntent.gate(decision);

    if (verdict === 'fallthrough') return null;

    if (verdict === 'fire') {
        return {
            intent     : decision.intent,
            data       : decision.data,
            resolvedBy : 'llm',
            confidence : decision.confidence,
        };
    }

    // verdict === 'confirm' — stash pending, ask yes/no
    const brain = loadBrain();
    const key   = `llm_confirm_${Date.now()}`;
    brain.pending_actions = brain.pending_actions || {};
    brain.pending_actions[key] = {
        description : llmIntent.describeIntent(decision),
        data        : { intent: decision.intent, data: decision.data },
        expected    : 'yes_no',
        source      : 'llm',
        created_at  : new Date().toISOString(),
        expires_at  : new Date(Date.now() + 10 * 60 * 1000).toISOString(),
    };
    saveBrain(brain);

    await sendMessage(chatId,
        `Did you mean: ${llmIntent.describeIntent(decision)}?\n\n` +
        `Reply 1 to confirm, 2 to cancel.`
    );

    return { intent: 'awaiting_confirmation', resolvedBy: 'llm', data: {}, confidence: decision.confidence };
}

module.exports = { process, normalize, policyDecide, pendingFullReminder, OPTIONAL_PENDINGS, route, parseGetQuoteCommand };