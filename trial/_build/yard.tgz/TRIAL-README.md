# Sample Yard Co — trial

Start:   npm install && node trial-seed.js && node trial-server.js   (then open http://<server>:3951)
Logins:  manager (everything)  8L9a7aMcEljn15
         staff (loads only)    g3lk2pYh95Ls46
         team                  j0d3wWzCatXh49
Switch off: stop the process. Reset the demo: delete the data/ folder, run node trial-seed.js again.
Not included: WhatsApp, Gmail, QuickBooks, Google Drive.
