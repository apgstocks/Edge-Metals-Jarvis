// ── scheduler.js — node-cron jobs (replaces Cloud Scheduler + Pub/Sub) ───────
// All schedules run in America/Los_Angeles because every freight deadline
// (ERD/cutoff) is a US port date. Dedup via brain.proactive_sent so a restart
// mid-day never double-sends.

// ── EVERY JOB NOW LEAVES A PULSE (2026-10-08) ──────────────────────────────
// the owner: "if something is broke - i should know." 31 jobs were scheduled
// here and exactly ONE recorded that it ran (settings.gmail_watcher_last_run,
// which read null), so a job that died was invisible -- its only symptom an
// absence. helpers/heartbeat.js wraps cron.schedule and keeps its signature,
// so all 31 call sites below are UNTOUCHED: hand-editing them would have been
// 31 chances to drop a .catch or a timezone, and a scheduler that throws at
// startup takes every job down, which is worse than the gap being closed.
const cron = require('./helpers/heartbeat').instrument(require('node-cron'));
const { usd } = require('./helpers/money');
const { loadBookings, loadWorkflow, mutateBrain, loadBrain,
        mutateJson, loadHistory } = require('./helpers/json');
const { daysUntil, getLADate }    = require('./helpers/time');
const { describePending }         = require('./helpers/pendingLabel');
const { getUrgentBookings }       = require('./helpers/booking');
const { stepLabel }               = require('./helpers/booking');
const { pushAlert }               = require('./alerts');
const cfg = require('./config');
const emailWatcher = require('./workflow/emailWatcher');
const paymentWatcher = require('./workflow/paymentWatcher');
const { pickVariant } = require('./helpers/phrasing');
const actions = require('./workflow/actions');

let _sendToManager = async () => {}, _sendToTeam = async () => {}, _sendMessage = async () => {};
function init({ sendToManager, sendToTeam, sendMessage }) {
    _sendToManager = sendToManager;
    _sendToTeam    = sendToTeam;
    if (sendMessage) _sendMessage = sendMessage;
    emailWatcher.init({ sendToManager });
    // setPending is passed so a single clean payment match can stage a real
    // yes/no confirm rather than only being described in a message.
    paymentWatcher.init({ sendToManager, setPending: (action) => {
        const settings = cfg.getSettings ? cfg.getSettings() : {};
        const managerChatId = (settings.manager_number || cfg.MANAGER_NUMBER || '') + '@c.us';
        return actions.setPending(managerChatId, action);
    } });
}

const TZ = { timezone: 'America/Los_Angeles' };
const todayKey = () => getLADate().toDateString();

async function markSent(key) { await mutateBrain(b => { b.proactive_sent[key] = new Date().toISOString(); }); }
const alreadySent = (key) => !!loadBrain().proactive_sent[key];

// ── 9AM — daily trucker-assignment wizard trigger ───────────────────────────
// Kicks off the guided flow: "need to send any bookings to a trucker today?"
// The rest of the conversation (port → booking → supplier → trucker →
// confirm) is handled by workflow/actions.js's wizardAdvance, driven by the
// normal pending-resolution path — this function only sends the opener.
async function dailyTruckerCheck() {
    const key = `trucker_wizard_${todayKey()}`;
    if (alreadySent(key)) return;

    const settings = cfg.getSettings ? cfg.getSettings() : {};
    const managerChat = (settings.manager_number || cfg.MANAGER_NUMBER || '') + '@c.us';
    const teamChat = settings.team_group_id || managerChat;
    if (!teamChat || teamChat === '@c.us') return; // nothing configured to send to

    // Mark BEFORE sending, not after — if the process restarts between the
    // send and the mark (a real risk on a day with many restarts), the guard
    // never persists and the next cron tick or restart fires the whole
    // sequence again: duplicate message, AND a fresh setPending overwriting
    // whatever pending was already there. Marking first means a crash after
    // this point just costs one skipped morning prompt, not a duplicate.
    await markSent(key);
    const staged = await actions.setPending(teamChat, { type: 'wizard_start' });
    if (staged.queued) {
        // Something on this chat is already unresolved (e.g. last night's
        // learning digest never got answered) — don't show a live yes/no
        // prompt for a wizard that isn't actually the active pending yet.
        await _sendToTeam(`(Trucker check queued — you have a pending ${describePending(staged.blockedBy)} to answer first. I'll ask once that's resolved.)`);
        return;
    }
    // TIME-OF-DAY WORDING (2026-08-22): these schedules are anchored to
    // America/Los_Angeles because every freight deadline is a US port date —
    // that is correct and stays. But the owner reads them in IST, where 8:15 AM
    // LA lands at 8:45 PM. A message opening with "Morning" at a quarter to
    // nine in the evening reads as a bug even though the timing is right. The
    // schedule is not the problem, the greeting is — so the greeting goes and
    // the message says what it is about instead of what time it thinks it is.
    await _sendToTeam('Trucker check for today — any bookings need to go out to a trucker? (yes/no)');
}

// ── 8AM — morning digest ──────────────────────────────────────────────────────
// ── DEVICES THAT COULD NOT REACH JARVIS ──────────────────────────────────
// the owner, 2026-10-02, after an outage nobody reported: "I cant afford
// mistakes like this when i sell this to many customers."
//
// Returns null on a quiet night. A daily "no devices failed" is a line she
// stops reading, and the morning it matters she stops reading that too.
function deviceTroubleLine() {
    try {
        const ce = require('./helpers/clientErrors');
        return ce.digestText(ce.summary({ hours: 24 }));
    } catch (e) {
        console.error('[DIGEST] could not read device reports:', e.message);
        return null;
    }
}

async function morningDigest() {
    const key = `daily_digest_${todayKey()}`;
    if (alreadySent(key)) return;

    const bookings = loadBookings();
    const workflow = loadWorkflow();
    const active   = Object.values(bookings);
    if (!active.length) {
        // ── A QUIET BOOKING DAY IS NOT A QUIET DAY ───────────────────────
        // This used to return outright, which would have buried the device
        // reports on exactly the kind of slow day when someone has time to
        // notice they cannot sign in. The bookings digest still does not go
        // out — there is nothing in it — but anything that could not reach
        // Jarvis is still said.
        const only = deviceTroubleLine();
        if (only) {
            await _sendToManager(only);
            await markSent(key);
            console.log('[SCHED] Morning digest: no bookings, device trouble reported');
        }
        return;
    }

    const { laggingContainers, allContainersTerminal } = require('./helpers/containers');

    const urgent = getUrgentBookings();
    const stuck  = Object.entries(workflow).filter(([bkgNo, wf]) => {
        if (!bookings[bkgNo] || allContainersTerminal(bookings[bkgNo])) return false;
        if (cfg.TERMINAL_STEPS.includes(wf.step) && !Array.isArray(bookings[bkgNo]?.containers)) return false;
        const last = new Date(wf.updated_at || wf.created_at || 0).getTime();
        return Date.now() - last > 2 * 86400000; // no movement in 48h
    });

    // Per-booking urgent line: if multi-container, list lagging containers explicitly.
    const urgentLine = (b) => {
        const wf   = workflow[b.booking_number] || {};
        const lag  = laggingContainers(b);
        const dLeft = daysUntil(b.cutoff_date);
        if (Array.isArray(b.containers) && b.containers.length > 1 && lag.length > 0 && lag.length < b.containers.length) {
            const lagList = lag.map(c => `${b.booking_number}/${c.seq} (${stepLabel(c.stage)})`).join(', ');
            return `- ${b.booking_number} cutoff ${b.cutoff_date} (${dLeft}d) — lagging: ${lagList}`;
        }
        return `- ${b.booking_number} cutoff ${b.cutoff_date} (${dLeft}d) — ${stepLabel(wf.step)}`;
    };

    const lines = [
        // See the time-of-day note in dailyTruckerCheck above.
        `Daily digest — ${active.length} active booking(s)`,
        '',
        urgent.length ? 'URGENT CUTOFFS:' : 'No urgent cutoffs.',
        ...urgent.map(urgentLine),
    ];
    if (stuck.length) {
        lines.push('', 'STUCK (48h+ no movement):');
        lines.push(...stuck.map(([bkgNo, wf]) => `- ${bkgNo} at ${stepLabel(wf.step)}`));
    }

    // Bookings still without ERD/cutoff: one line, silent when none.
    const dl = require('./helpers/bookingDates').digestLine();
    if (dl) lines.push('', dl);

    // ── AND WHO COULD NOT GET IN ─────────────────────────────────────────
    // Last, because it is rare — but FIRST among the things she can act on
    // when it appears, because a staff member who cannot sign in has usually
    // not told anyone. Silent on a normal morning.
    const devices = deviceTroubleLine();
    if (devices) lines.push('', devices);

    await _sendToManager(lines.join('\n'));
    await markSent(key);
    console.log('[SCHED] Morning digest sent');
}

// ── Hourly 9–17 — urgent cutoff watch ─────────────────────────────────────────
// Alerts fire per lagging container on multi-container bookings, or per-booking
// on single-container bookings. Booking is considered done when ALL containers
// reach a terminal stage (per user rule: cutoff is booking-level).
async function urgentWatch() {
    const workflow = loadWorkflow();
    const { laggingContainers, allContainersTerminal } = require('./helpers/containers');

    for (const b of getUrgentBookings()) {
        const wf = workflow[b.booking_number] || {};
        if (allContainersTerminal(b)) continue;
        // Legacy flat: fall back to top-level step
        if (!Array.isArray(b.containers) && cfg.TERMINAL_STEPS.includes(wf.step)) continue;

        const d   = daysUntil(b.cutoff_date);
        const key = `urgent_${b.booking_number}_${todayKey()}`;
        if (alreadySent(key)) continue;

        const lag = laggingContainers(b);
        let message;
        if (lag.length > 0 && Array.isArray(b.containers) && b.containers.length > 1) {
            const lagList = lag.map(c => `${b.booking_number}/${c.seq} at ${stepLabel(c.stage)}`).join(', ');
            message = `${b.booking_number}: cutoff in ${d}d — lagging: ${lagList}`;
        } else {
            message = `${b.booking_number}: cutoff in ${d}d, still at "${stepLabel(wf.step)}"`;
        }

        // notify:false when d<=1 — the explicit _sendToTeam escalation just
        // below is the message that actually goes out for that case; without
        // this, pushAlert's own severity:'high' handling ALSO pings the
        // manager with a near-duplicate "ALERT: ... cutoff in 1d" message in
        // the same breath, which is the double-cutoff-message bug reported
        // 2026-08-18. Still logged to alert history/dashboard regardless.
        await pushAlert({
            type    : 'cutoff_risk',
            bkgNo   : b.booking_number,
            message,
            severity: d <= 1 ? 'high' : 'warning',
            notify  : d > 1,
        });
        if (d <= 1) await _sendToTeam(`${b.booking_number}: cutoff TOMORROW — ${lag.length && Array.isArray(b.containers) && b.containers.length > 1 ? `${lag.length} of ${b.containers.length} containers still lagging` : `still at "${stepLabel(wf.step)}"`}. Escalate now.`);
        await markSent(key);
    }
}

// ── Daily 09:30 — try to fill missing ERD / cutoff from mail ────────────────
// the owner, 2026-11-09: monitor until filled, but "i dont want jarvis to bomb my
// whatsapp clumsily". So this sends NOTHING. What is still blank rides the one
// morning digest (a single compact line) and the 06:30 sweep email.
async function datesWatch() {
    try { await require('./helpers/cutoffBackfill').run(); } catch (e) { console.error('[SCHED] dates-watch backfill:', e.message); }
}

// ── Hourly — stall detection + proactive outreach ──────────────────────────
// Piggybacks on the same cron slot as urgentWatch (9-17 LA time). Different
// concern though: urgentWatch is cutoff-deadline-driven; this is STAGE-STALL
// driven — a booking that's been sitting in the same step too long, regardless
// of how far away the cutoff is. Two of the seven steps (not_started,
// supplier_assigned) are MANAGER-side stalls — nobody else can act, so the
// "check-in" is a direct reminder to the manager, not outreach to a contact.
// The rest ping the trucker/supplier who actually owns the next action, using
// a plain nudge message — NOT a new pending/state-machine, so whatever they
// reply naturally flows through the EXISTING trucker/supplier keyword
// handling in workflow/brain.js. Two-tier: check-in first, escalate to
// manager only if that goes unanswered past stall_escalation_hours.
const STALL_PARTY = {
    not_started       : 'manager',
    supplier_assigned : 'manager',
    forwarded         : 'trucker',
    empty_dropped     : 'supplier',
    load_ready        : 'trucker',
    picked_up         : 'trucker',
};
const STALL_NUDGE = {
    forwarded         : [
        (bkg) => `Checking in on ${bkg} — any update on the empty pickup?`,
        (bkg) => `Hey — where are we on the empty pickup for ${bkg}?`,
        (bkg) => `${bkg}: has the empty been picked up yet?`,
    ],
    empty_dropped     : [
        (bkg) => `Checking in on ${bkg} — is the load ready yet?`,
        (bkg) => `${bkg} — how's loading coming along?`,
        (bkg) => `Any word on load-ready for ${bkg}?`,
    ],
    load_ready        : [
        (bkg) => `Checking in on ${bkg} — has pickup happened yet?`,
        (bkg) => `${bkg} — did the trucker pick up yet?`,
        (bkg) => `Any update on pickup for ${bkg}?`,
    ],
    picked_up         : [
        (bkg) => `Checking in on ${bkg} — scale ticket ready?`,
        (bkg) => `${bkg} — got the scale ticket yet?`,
        (bkg) => `Any word on the scale ticket for ${bkg}?`,
    ],
};
const STALL_MANAGER_REMINDER = {
    not_started       : [
        (bkg, hrs) => `${bkg} has had no supplier assigned for ${hrs}h — needs attention.`,
        (bkg, hrs) => `Heads up — ${bkg} is still unassigned after ${hrs}h.`,
        (bkg, hrs) => `${bkg}: no supplier yet, ${hrs}h and counting.`,
    ],
    supplier_assigned : [
        (bkg, hrs) => `${bkg} has a supplier but hasn't been forwarded to a trucker in ${hrs}h.`,
        (bkg, hrs) => `${bkg} is assigned but sitting unforwarded — ${hrs}h now.`,
        (bkg, hrs) => `Heads up — ${bkg} still needs to go to a trucker, ${hrs}h since assignment.`,
    ],
};

async function stallWatch() {
    const settings   = cfg.getSettings ? cfg.getSettings() : {};
    const thresholds = settings.stall_thresholds_hours || {};
    const escalateAfterHrs = settings.stall_escalation_hours ?? 24;
    const bookings = loadBookings();
    const workflow = loadWorkflow();
    const { allContainersTerminal } = require('./helpers/containers');

    for (const b of Object.values(bookings)) {
        if (allContainersTerminal(b)) continue;
        const wf = workflow[b.booking_number] || {};
        const step = wf.step || 'not_started';
        if (cfg.TERMINAL_STEPS.includes(step)) continue;

        // Dual-role contact (supplier = trucker, same entity) — doesn't get
        // the normal stage-by-stage nudges (empty pickup / load ready / scale
        // ticket), since they only report back once at the end with the
        // scale ticket. Instead: periodic cutoff/ERD reminder, and once the
        // ERD window has actually started, ask for the container number
        // specifically — that's the one thing actually needed from them
        // mid-process.
        if (wf.dual_role) {
            const truckers = require('./workflow/truckers');
            const chatId = await truckers.getTruckerGroupIdForBooking(b.booking_number);
            const erdStarted = b.erd_date && new Date() >= new Date(b.erd_date);
            const hasContainerNumber = !!(wf.container_number || b.container_number);

            if (step === 'forwarded' && erdStarted && !hasContainerNumber) {
                const key = `dualrole_container_${b.booking_number}`;
                if (!alreadySent(key) && chatId) {
                    await actions.setPending(chatId, { type: 'await_container_number', bkg_no: b.booking_number });
                    await _sendMessage(chatId, `${b.booking_number}: ERD has started — what's the container number?`);
                    await markSent(key);
                }
            } else {
                const key = `dualrole_reminder_${b.booking_number}_${todayKey()}`;
                if (!alreadySent(key) && chatId) {
                    const d = b.cutoff_date ? daysUntil(b.cutoff_date) : null;
                    const msg = `${b.booking_number}: reminder — ERD ${b.erd_date || '—'}, cutoff ${b.cutoff_date || '—'}${d != null ? ` (${d}d)` : ''}.`;
                    await _sendMessage(chatId, msg);
                    await markSent(key);
                }
            }
            continue;
        }

        const threshold = thresholds[step];
        if (!threshold) continue; // no threshold configured for this step — skip silently
        const enteredAt = wf.stage_entered_at || wf.created_at;
        if (!enteredAt) continue;
        const hoursInStage = (Date.now() - new Date(enteredAt).getTime()) / (1000 * 60 * 60);
        if (hoursInStage < threshold) continue;

        const stageKey = `${b.booking_number}_${step}_${enteredAt}`;
        const checkinKey   = `stall_checkin_${stageKey}`;
        const escalateKey  = `stall_escalate_${stageKey}`;
        const party = STALL_PARTY[step];
        const hrsRounded = Math.round(hoursInStage);

        if (!alreadySent(checkinKey)) {
            // First touch — check in.
            if (party === 'manager') {
                const msg = STALL_MANAGER_REMINDER[step]
                    ? pickVariant(STALL_MANAGER_REMINDER[step], b.booking_number, hrsRounded)
                    : `${b.booking_number} stalled at "${stepLabel(step)}" for ${hrsRounded}h.`;
                await pushAlert({ type: 'stall', bkgNo: b.booking_number, message: msg, severity: 'warning' });
                await _sendToTeam(msg);
            } else {
                const truckers  = require('./workflow/truckers');
                const suppliers = require('./workflow/suppliers');
                const chatId = party === 'trucker'
                    ? await truckers.getTruckerGroupIdForBooking(b.booking_number)
                    : await suppliers.getSupplierGroupIdForBooking(b.booking_number);
                const nudge = STALL_NUDGE[step]
                    ? pickVariant(STALL_NUDGE[step], b.booking_number)
                    : `Checking in on ${b.booking_number} — any update?`;
                if (chatId) await _sendMessage(chatId, nudge);
                await pushAlert({ type: 'stall', bkgNo: b.booking_number, message: `${b.booking_number} stalled at "${stepLabel(step)}" for ${hrsRounded}h — pinged ${party}.`, severity: 'info' });
            }
            await markSent(checkinKey);
        } else if (hoursInStage >= threshold + escalateAfterHrs && !alreadySent(escalateKey)) {
            // Checked in already, still no movement after the escalation window — tell the manager.
            const msg = party === 'manager'
                ? `${b.booking_number} STILL stalled at "${stepLabel(step)}" — ${hrsRounded}h now, needs direct attention.`
                : `${b.booking_number}: no response from ${party} after check-in — stalled at "${stepLabel(step)}" for ${hrsRounded}h. Might need a call.`;
            // notify:false — same duplicate-message issue as urgentWatch's
            // cutoff alert above: pushAlert(severity:'high') would otherwise
            // ALSO ping the manager with this exact same `msg` text via its
            // own notify, right alongside the explicit _sendToTeam(msg) call
            // below. Logged to alert history either way.
            await pushAlert({ type: 'stall_escalated', bkgNo: b.booking_number, message: msg, severity: 'high', notify: false });
            await _sendToTeam(msg);
            await markSent(escalateKey);
        }
    }
}

// ── 7AM — YESTERDAY, AS THE LOGS SAW IT ──────────────────────────────────────
// the owner, 2026-09-20: "I want to have an agent which reads all the logs and
// suggest improvements next day", and, asked where it should land: email.
//
// Seven, so it is already sitting there before the 8am digest rather than
// arriving in the middle of her morning.
//
// ── WHY THIS EXISTS AT ALL ───────────────────────────────────────────────────
// On 2026-09-19 every email with an attachment threw — three separate send
// paths — while 134 test files were green. The error was in pm2-error.log the
// first time anyone pressed Send. Nobody reads that file; she found it by
// using the app and reading the message back to me.
//
// ── IT SENDS ON A CLEAN DAY TOO, AND THAT IS DELIBERATE ──────────────────────
// A report that only arrives when something is wrong is one whose absence
// means either "fine" or "the job is broken", and those are not the same
// thing. The SUBJECT carries the verdict — "clean", "3 new problems", "2
// POSSIBLE LOST WRITES" — so a clean day costs her one glance at a subject
// line and never needs opening.
// Reads helpers/heartbeat.js and messages her ONLY when something is wrong.
// Deliberately quiet on a healthy system -- see the cron comment above.
async function healthWatch() {
    const hb = require('./helpers/heartbeat');
    const s = hb.status();
    if (!s.total) {
        // Nothing has reported at all. On the very first run after deploy
        // that is normal, so it is logged rather than sent.
        console.log('[HEALTH] no jobs have reported in yet');
        return { sent: false, reason: 'nothing-reported' };
    }
    if (s.healthy) {
        console.log(`[HEALTH] all ${s.total} scheduled jobs on time`);
        return { sent: false, reason: 'healthy' };
    }
    const body = 'Jarvis health check\n\n' + hb.report();
    // Same problems as the last report -> say nothing, until a day has passed.
    // It used to repeat the identical list three times a day.
    const sig = [...s.failing, ...s.late, ...s.silent].map((j) => j.name).sort().join(',');
    const ps = loadBrain().proactive_sent || {};
    const prev = { sig: ps.health_sig, at: ps.health_sig_at };
    if (prev.sig === sig && Date.now() - Date.parse(prev.at || 0) < 24 * 3600 * 1000) {
        return { sent: false, reason: 'unchanged' };
    }
    try {
        await _sendToManager(body);
        await mutateBrain((b) => { b.proactive_sent.health_sig = sig; b.proactive_sent.health_sig_at = new Date().toISOString(); });
        console.warn(`[HEALTH] reported ${s.failing.length} failing, ${s.late.length} late, ${s.silent.length} never-run`);
        return { sent: true, failing: s.failing.length, late: s.late.length, silent: s.silent.length };
    } catch (err) {
        console.error('[HEALTH] could not deliver the health report:', err.message);
        return { sent: false, reason: 'send-failed' };
    }
}

async function nightlyLogDigest() {
    const path = require('path');
    const fs = require('fs');
    const logDigest = require('./helpers/logDigest');
    const cfg = require('./config');
    const { getLADate } = require('./helpers/time');

    // Yesterday in LA, like every other date decision here. On UTC this job
    // would report half of two days and head it with one date.
    const d0 = getLADate();
    d0.setDate(d0.getDate() - 1);
    const DAY = `${d0.getFullYear()}-${String(d0.getMonth() + 1).padStart(2, '0')}-${String(d0.getDate()).padStart(2, '0')}`;
    const prevDate = new Date(`${DAY}T12:00:00Z`);
    prevDate.setUTCDate(prevDate.getUTCDate() - 1);
    const dayBefore = prevDate.toISOString().slice(0, 10);

    const LOGS = cfg.LOGS_DIR || path.join(cfg.DATA_DIR, 'logs');
    const lines = logDigest.readLines([path.join(LOGS, 'pm2-out.log'), path.join(LOGS, 'pm2-error.log')]);
    if (!lines.length) {
        console.log('[SCHED] log-digest: no pm2 logs to read — skipping');
        return;
    }

    const prev = logDigest.digest(lines, { onDay: dayBefore });
    const d = logDigest.digest(lines, { onDay: DAY, previousSignatures: prev.items.map((i) => i.sig) });
    const timings = logDigest.timings(lines, { onDay: DAY });
    let audit = { intents: [], unparsed: 0 };
    try { audit = logDigest.decisions(fs.readFileSync(path.join(LOGS, `${DAY}.jsonl`), 'utf8')); } catch (e) {}

    // The FULL list by email. The 15-row cap exists so a terminal stays
    // readable; an email has a scrollbar, and the row she needs is as likely
    // to be the sixteenth as the first.
    let body = logDigest.render({ day: DAY, dayBefore, d, timings, audit, full: true });
    const subject = logDigest.subjectFor(DAY, d);

    // ── WHAT THE PHONES COULD NOT DO (2026-10-05) ────────────────────────
    // the owner: "it's working for me. but people in us are facing issue."
    //
    // POST /api/client-errors has recorded exactly that since 2026-10-02 and
    // NOTHING has ever read it — no route, no screen, no job called list(),
    // summary() or digestText(). The reports were piling up in a file nobody
    // opened, which is the same fault as a screen nobody can reach: it looks
    // monitored and is not.
    //
    // It goes HERE rather than on a screen because the person who needs it is
    // asleep in a different timezone from the person who hit the problem, and
    // a diagnostic she has to remember to open is one she will open after the
    // next four hours are lost, not before.
    //
    // 24 hours to match this digest's own window. Best-effort: a digest that
    // fails to send because of its newest block helps nobody.
    try {
        const ce = require('./helpers/clientErrors');
        const text = ce.digestText(ce.summary({ hours: 24 }));
        if (text) body += `\n\n${'='.repeat(62)}\n${text}\n`;
    } catch (e) { console.warn('[SCHED] log-digest: client errors unreadable:', e.message); }

    // ── WHERE IT GOES ────────────────────────────────────────────────────
    // ALERT_EMAIL_TO when it is configured, her own sending address
    // otherwise — RESOLVED, never assumed. helpers/gmail.js carries a long
    // note about the fortnight its comments claimed one mailbox while all
    // three tokens pointed at another.
    const gmail = require('./helpers/gmail');
    let to = cfg.ALERT_EMAIL_TO || '';
    if (!to) {
        try { to = await gmail.getMyEmailAddress(gmail.getGmailWrite()); } catch (e) {}
    }
    if (!to) {
        console.warn('[SCHED] log-digest: no destination (set ALERT_EMAIL_TO) — not sent');
        return;
    }

    // ── MONOSPACE, OR THE COLUMNS ARE NOISE ──────────────────────────────
    // Every mail Jarvis sends now carries an HTML half derived from the
    // plain text (2026-09-19), and that default renders in Arial with
    // pre-wrap — right for a letter to a buyer, wrong for a report whose
    // meaning is in its alignment. This is the caller that supplies its own.
    const bodyHtml = '<div style="font-family:ui-monospace,SFMono-Regular,Menlo,Consolas,monospace;'
                   + 'font-size:12px;line-height:1.45;white-space:pre;color:#202124;">'
                   + gmail.escapeHtmlText(body) + '</div>';

    try {
        await gmail.sendEmail({ to, subject, body, bodyHtml });
        console.log(`[SCHED] log-digest: ${subject} → ${to}`);
    } catch (e) {
        // A failed report must not take the scheduler down with it, and must
        // not be silent either — that would make this job an instance of the
        // exact problem it exists to find.
        console.error('[SCHED] log-digest: could not send:', e.message);
    }
}

// ── 11PM — auto-archive (cutoff passed yesterday, no ingate, not kept) ────────
// Multi-container rule: archive only if ALL containers are in a terminal stage.
// If /1 is ingated but /2 is still forwarded, the booking stays active so ops
// can decide (recall /2, escalate, etc).
async function autoArchive() {
    // ── THE RULE MOVED, THE BEHAVIOUR DID NOT ────────────────────────────
    // the owner, 2026-09-06 asked to be able to run this on demand. The scan is
    // now helpers/cutoffScan.js so the nightly job and the on-demand version
    // share ONE definition of "past cutoff" — two copies would mean the
    // preview showing her one set of bookings and this job archiving another,
    // with no way to tell which was right.
    //
    // This function keeps everything else it had: the archive writes, the
    // team and manager messages, the alert. Only the loop that decided WHICH
    // is gone.
    const archived = [];

    for (const { bkgNo, booking: b, wf } of require('./helpers/cutoffScan').pastCutoff()) {
        // Cutoff passed = strict archive regardless of container completion —
        // if any further movement happens, it happens under a NEW booking
        // (the owner's correction, 2026-08-01): a container still shown as
        // not_started/empty_dropped on an expired booking isn't "still in
        // progress," it's just stale data. The record isn't lost — it moves
        // to history.json with its actual final container states intact, so
        // an incomplete booking is still visible there, just off the active
        // dashboard. Previously this required allContainersTerminal() to be
        // true first; that gate is removed.

        await mutateJson(cfg.HISTORY_FILE, {}, (h) => {
            h[bkgNo] = { ...b, archived_at: new Date().toISOString(), archive_reason: 'cutoff_passed_auto', final_step: wf.step || 'not_started' };
            return h;
        });
        await mutateJson(cfg.BOOKINGS_FILE, {}, (x) => { delete x[bkgNo]; return x; });
        await mutateJson(cfg.WORKFLOW_FILE, {}, (x) => { delete x[bkgNo]; return x; });
        archived.push(bkgNo);
    }

    if (!archived.length) return;
    const msg = [`Auto-archived ${archived.length} booking(s):`, ...archived, '', 'Cutoff passed with no ingate. See dashboard → history.'].join('\n');
    await _sendToTeam(msg);
    await _sendToManager(msg);
    await pushAlert({ type: 'auto_archived', bkgNo: null, message: `Auto-archived: ${archived.join(', ')}`, severity: 'info' });
}

// ── 10:45PM — nightly field backfill ────────────────────────────────────────
// Scans every active booking missing ANY of cutoff/ERD/ETD/ETA/vessel/route
// (see BACKFILL_FIELDS in helpers/cutoffBackfill.js) and tries to fill it
// from existing mail. Runs before autoArchive (11PM) on purpose: a booking
// that's ACTUALLY past cutoff but just never had the field populated
// shouldn't dodge archiving forever purely because cutoff_date was empty —
// this gives it one more chance to get filled in first, same night, before
// the archive check runs.
async function nightlyCutoffBackfill() {
    let results;
    let FIELD_LABELS;
    try {
        const mod = require('./helpers/cutoffBackfill');
        FIELD_LABELS = mod.FIELD_LABELS;
        results = await mod.run();
    } catch (err) {
        console.error('[SCHED] cutoff-backfill:', err.message);
        return;
    }
    if (!results.length) return;
    const lines = results.map((r) => {
        const parts = Object.entries(r.filled).map(([k, v]) => `${FIELD_LABELS[k] || k}: ${v}`);
        return `${r.bkgNo} — ${parts.join(', ')}`;
    });
    await _sendToManager(`Nightly backfill — filled missing fields from existing mail:\n${lines.join('\n')}`);
}

// ── 6AM — price list fallback reconciliation ──────────────────────────────
// Safety net for the real-time Apps Script webhook (helpers/pricelist.js +
// POST /api/pricelist/webhook): if the webhook never fires — VM down, trigger
// misconfigured on the Sheet side, token mismatch, transient network failure —
// this catches any missed price change within 24h instead of drifting
// silently forever. One Sheets read/day, negligible cost either way.
async function pricelistFallback() {
    try {
        const pricelist = require('./helpers/pricelist');
        const result = await pricelist.checkForChangesAndNotify();
        if (result.changed) console.log('[SCHED] Price list fallback caught a missed change:', result.changes);
    } catch (err) {
        console.error('[SCHED] pricelist fallback failed:', err.message);
    }
}

// ── Task runner — fires persistent tasks whose fire_at has passed ─────────
// Called every minute. For each due task:
//   1. Evaluate its condition (if any). If condition says 'skip', archive as done_condition_met.
//   2. Resolve target chatId by looking up trucker/supplier by name (name is the durable key,
//      whatsapp/group_id can drift). Falls back to task.target_chat if lookup fails.
//   3. Send the message. On success, archive as done_fired.
//      On failure, increment tries; if tries >= max_tries, archive as failed.
async function taskRunner() {
    const tasks = require('./helpers/tasks');
    const { loadTruckers, loadSuppliers } = require('./helpers/json');
    const settings = cfg.getSettings ? cfg.getSettings() : {};
    const managerChat = (settings.manager_number || cfg.MANAGER_NUMBER || '') + '@c.us';

    const due = tasks.dueTasks();
    if (!due.length) return;

    for (const task of due) {
        try {
            // 1. Condition check — has the reason for this task already resolved?
            const gate = tasks.evaluateCondition(task);
            if (gate === 'skip') {
                await tasks.archive(task.id, { status: 'done', result_note: 'condition_met_before_fire' });
                continue;
            }

            // ── Quote-request reminder / escalation (2026-08-05) ────────────
            // Both delegate entirely to workflow/quoteRequests.js, which
            // resolves its OWN destination per leg (handleQuoteReminderTask
            // picks sendEmailReminder vs send(leg.target) off leg.channel;
            // handleQuoteEscalationTask resolves managerChatId() itself), so
            // neither needs the outer chatId resolved below at all.
            //
            // REAL BUG (found 2026-08-06, live — the owner: "if a reminder of
            // quote goes idle, saying that chat id is missing"): this block
            // used to sit BELOW the chatId resolution + `if (!chatId)` gate.
            // workflow/quoteRequests.js deliberately sets target_chat:null
            // for EMAIL legs (see scheduleFirstReminder — "leg.channel !==
            // 'email' ? leg.target : null"), expecting this delegation to
            // handle delivery. But for an email-only trucker (no group_id,
            // no whatsapp) the name lookup below couldn't fill chatId either,
            // so the task hit that gate, burned all 3 tries, and archived as
            // 'no_chatid_resolved' — the reminder chain silently dying
            // without one reminder ever being sent, exactly as reported.
            //
            // SECOND BUG, introduced by me EARLIER TODAY in the
            // preferred_mode work below and caught here: that new branch
            // fires on any targetRecord with preferred_mode==='email', which
            // includes quote_reminder tasks — it would have intercepted them
            // and sent task.message as a plain generic email, bypassing
            // handleQuoteReminderTask entirely. That skips recordReminderSent,
            // the dashboard alert, AND the scheduling of the next reminder
            // stage/escalation — so the 30/60/90 chain would fire stage 1 and
            // then stop dead. Hoisting this block above both is what makes
            // that impossible rather than merely unlikely.
            if (task.type === 'quote_reminder' || task.type === 'quote_escalation') {
                await tasks.updateTask(task.id, { status: 'firing' });
                const quoteRequests = require('./workflow/quoteRequests');
                try {
                    const result = task.type === 'quote_reminder'
                        ? await quoteRequests.handleQuoteReminderTask(task, { send: _sendMessage })
                        : await quoteRequests.handleQuoteEscalationTask(task, { send: _sendMessage });
                    await tasks.archive(task.id, { status: 'done', result_note: result.fired ? 'fired' : (result.reason || 'send_failed') });
                } catch (err) {
                    console.error(`[TASK] quote task ${task.id} failed:`, err.message);
                    await tasks.archive(task.id, { status: 'failed', result_note: 'runner_exception: ' + err.message });
                }
                continue;
            }

            // ── Contact-quote-request reminder / escalation (2026-08-16) ────
            // Same delegation pattern as the trucker quote_reminder/
            // quote_escalation block just above (own module resolves its own
            // destination per leg — email vs whatsapp — and needs nothing
            // from the chatId-resolution code below), but routed to
            // workflow/contactQuoteRequests.js instead, and gated on its own
            // task types so this can't collide with or change behavior of
            // the trucker block above it.
            if (task.type === 'contact_quote_reminder' || task.type === 'contact_quote_escalation') {
                await tasks.updateTask(task.id, { status: 'firing' });
                const contactQuoteRequests = require('./workflow/contactQuoteRequests');
                try {
                    const result = task.type === 'contact_quote_reminder'
                        ? await contactQuoteRequests.handleReminderTask(task, { send: _sendMessage })
                        : await contactQuoteRequests.handleEscalationTask(task, { send: _sendMessage });
                    await tasks.archive(task.id, { status: 'done', result_note: result.fired ? 'fired' : (result.reason || 'send_failed') });
                } catch (err) {
                    console.error(`[TASK] contact-quote task ${task.id} failed:`, err.message);
                    await tasks.archive(task.id, { status: 'failed', result_note: 'runner_exception: ' + err.message });
                }
                continue;
            }

            // 2. Resolve target chatId. Look up by name; fall back to explicit chat if not found.
            let chatId = task.target_chat || null;
            let targetRecord = null;
            if (task.target_kind === 'trucker' && task.target_name) {
                const truckers = await loadTruckers();
                targetRecord = truckers.find(x => x.name === task.target_name);
                if (targetRecord?.group_id)      chatId = targetRecord.group_id;
                else if (targetRecord?.whatsapp) chatId = targetRecord.whatsapp + '@c.us';
            } else if (task.target_kind === 'supplier' && task.target_name) {
                const suppliers = await loadSuppliers();
                targetRecord = suppliers.find(x => x.name === task.target_name);
                if (targetRecord?.group_id)      chatId = targetRecord.group_id;
                else if (targetRecord?.whatsapp) chatId = targetRecord.whatsapp + '@c.us';
            } else if (task.target_kind === 'manager') {
                chatId = managerChat;
            }

            // REAL BUG (found 2026-08-06, live — the owner: "fix supplier/trucker
            // mode of communication is email"), same class as the fix in
            // workflow/actions.js's notifyContactRespectingChannel: this
            // generic nudge/reminder firing loop had no email option at all —
            // an email-preferred trucker/supplier either got a WhatsApp
            // message anyway (if they happened to have a number on file too)
            // or, worse, got marked "no_chatid_resolved" and silently failed
            // after 3 tries if they didn't. Checked BEFORE the no-chatId
            // failure below so an email-only contact doesn't get wrongly
            // failed for lacking a WhatsApp chatId it was never going to use.
            if (targetRecord && targetRecord.preferred_mode === 'email' && targetRecord.email) {
                await tasks.updateTask(task.id, { status: 'firing' });
                let msg = task.message;
                if (task.bkg_no && !msg.includes(task.bkg_no)) {
                    const label = task.container_seq != null ? `${task.bkg_no}/${task.container_seq}` : task.bkg_no;
                    msg = `${label}: ${msg}`;
                }
                const subject = task.bkg_no ? `${task.bkg_no} — update` : 'Update';
                try {
                    const { sendEmail } = require('./helpers/gmail');
                    const sent = await sendEmail({ to: targetRecord.email, subject, body: msg });
                    require('./helpers/emailThreads').trackSentEmail({
                        threadId: sent?.threadId, to: targetRecord.email, targetName: targetRecord.name, subject, bkgNo: task.bkg_no || null,
                    }).catch((e) => console.error('[SCHED] emailThreads.trackSentEmail failed (non-fatal):', e.message));
                    await tasks.archive(task.id, { status: 'done', result_note: 'fired_email' });
                    console.log(`[TASK] Fired ${task.id} → ${targetRecord.email} (email): "${task.message.slice(0, 60)}"`);
                } catch (err) {
                    const nextTries = (task.tries || 0) + 1;
                    if (nextTries >= (task.max_tries || 3)) {
                        await tasks.archive(task.id, { status: 'failed', result_note: 'email_send_failed: ' + err.message });
                    } else {
                        await tasks.updateTask(task.id, {
                            status: 'pending', tries: nextTries,
                            fire_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
                        });
                    }
                }
                continue;
            }

            if (!chatId) {
                await tasks.updateTask(task.id, { tries: (task.tries || 0) + 1 });
                if ((task.tries || 0) + 1 >= (task.max_tries || 3)) {
                    await tasks.archive(task.id, { status: 'failed', result_note: 'no_chatid_resolved' });
                }
                continue;
            }

            // ── Scheduled email — "email X at 7am" (2026-08-04) ────────────
            // Fires a real Gmail send instead of a WhatsApp message. Reuses
            // this SAME due/condition/retry/archive machinery rather than a
            // parallel scheduler, per the same "single execution gateway"
            // reasoning actions.js states at its own top — one place that
            // fires things, not two. chatId here is always the manager's own
            // WhatsApp (target_kind: 'manager', set by
            // actions.js's scheduleDraftedEmail), used only to notify her the
            // email went out — never the email's own To/Cc/Bcc, which live
            // in task.email_payload and were fully resolved and confirmed by
            // her at drafting time, long before this ever fires.
            if (task.type === 'scheduled_email') {
                await tasks.updateTask(task.id, { status: 'firing' });
                try {
                    const { sendEmail } = require('./helpers/gmail');

                    // STALENESS GUARD — the owner, 2026-08-22: "if there is
                    // to-and-fro messages in email, if one of the to and fro
                    // already addressed what i have scheduled — how does this
                    // work?" It used to fire regardless. Now, if this is a
                    // reply into a thread and that thread moved after she
                    // approved the draft, it is HELD and she is asked rather
                    // than sent blind. See helpers/scheduledEmailGuard.js.
                    //
                    // Fails open by design: a fresh compose, an unreachable
                    // Gmail, or a Gemini outage all return proceed:true, so a
                    // broken guard can never silently stop her mail.
                    const guard = require('./helpers/scheduledEmailGuard');
                    const check = await guard.checkBeforeSend(task.email_payload, task.approved_at || task.created_at);
                    if (!check.proceed) {
                        // Stage the same await_email_confirm pending the
                        // normal draft flow uses, so answering "yes" here
                        // goes through exactly one send path — no parallel
                        // machinery, and the scheduled email keeps its
                        // already-resolved to/cc/bcc/subject/body untouched.
                        const held = { ...task.email_payload, bkg_no: task.bkg_no || null, scheduled_for: null };
                        const staged = await actions.setPending(chatId, { type: 'await_email_confirm', ...held });
                        await tasks.archive(task.id, { status: 'done', result_note: 'held_thread_moved' });
                        const note = guard.buildHoldMessage(task.email_payload, check);
                        // Critical: this asks whether an email she already
                        // approved should still go out. If it is dropped she
                        // never learns the send was held, and the email
                        // simply never happens.
                        const heldMsg = staged.queued
                            ? `${note}\n\n(You have a pending ${describePending(staged.blockedBy)} to answer first — I'll ask about this right after.)`
                            : note;
                        // Delivered ONLY through the outbox — a second direct
                        // _sendMessage here would double-send whenever
                        // WhatsApp is up, which is exactly what the first
                        // version of this patch did.
                        try {
                            const outbox = require('./helpers/managerOutbox');
                            outbox.init({ sendToManager: (t) => _sendMessage(chatId, t) });
                            await outbox.deliver(heldMsg, { critical: true, subject: 'Scheduled email held' });
                        } catch (e) {
                            console.error('[TASK] outbox deliver failed, sending directly:', e.message);
                            await _sendMessage(chatId, heldMsg);
                        }
                        console.log(`[TASK] Scheduled email ${task.id} HELD — thread moved (${check.newMessages.length} new, superseded=${check.superseded})`);
                        continue;
                    }

                    const sent = await sendEmail(task.email_payload);
                    // Same reply-tracking as the immediate-send path in
                    // actions.js's sendDraftedEmail — a scheduled email is
                    // still a general sent email that can get a reply worth
                    // surfacing in the bell (2026-08-06).
                    require('./helpers/emailThreads').trackSentEmail({
                        threadId: sent?.threadId, to: task.email_payload.to, targetName: task.email_payload.target_name,
                        subject: task.email_payload.subject, bkgNo: task.bkg_no,
                    }).catch((e) => console.error('[SCHED] emailThreads.trackSentEmail failed (non-fatal):', e.message));
                    await tasks.archive(task.id, { status: 'done', result_note: 'fired' });
                    await _sendMessage(chatId, `Scheduled email sent to ${task.email_payload.target_name || ''} <${task.email_payload.to}>: ${task.email_payload.subject}`);
                    console.log(`[TASK] Scheduled email fired ${task.id} → ${task.email_payload.to}`);
                } catch (err) {
                    const nextTries = (task.tries || 0) + 1;
                    if (nextTries >= (task.max_tries || 3)) {
                        await tasks.archive(task.id, { status: 'failed', result_note: 'send_failed: ' + err.message });
                        await _sendMessage(chatId, `Scheduled email to ${task.email_payload.to} FAILED after ${nextTries} tries: ${err.message}. Not retried further — you'll need to resend manually.`);
                    } else {
                        await tasks.updateTask(task.id, {
                            status: 'pending', tries: nextTries,
                            fire_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
                        });
                    }
                }
                continue;
            }

            // 3. Send. Auto-prefix booking/container label so the recipient has context.
            //    Skips prefix if the message already mentions the booking number.
            await tasks.updateTask(task.id, { status: 'firing' });
            let msg = task.message;
            if (task.bkg_no && !msg.includes(task.bkg_no)) {
                const label = task.container_seq != null ? `${task.bkg_no}/${task.container_seq}` : task.bkg_no;
                msg = `${label}: ${msg}`;
            }
            const ok = await _sendMessage(chatId, msg);
            if (ok) {
                await tasks.archive(task.id, { status: 'done', result_note: 'fired' });
                console.log(`[TASK] Fired ${task.id} → ${chatId}: "${task.message.slice(0, 60)}"`);
            } else {
                const nextTries = (task.tries || 0) + 1;
                if (nextTries >= (task.max_tries || 3)) {
                    await tasks.archive(task.id, { status: 'failed', result_note: 'send_failed_max_tries' });
                } else {
                    // Reschedule 5 minutes out for a retry
                    await tasks.updateTask(task.id, {
                        status: 'pending', tries: nextTries,
                        fire_at: new Date(Date.now() + 5 * 60 * 1000).toISOString(),
                    });
                }
            }
        } catch (err) {
            console.error(`[TASK] runner error on ${task.id}:`, err.message);
            const nextTries = (task.tries || 0) + 1;
            if (nextTries >= (task.max_tries || 3)) {
                await tasks.archive(task.id, { status: 'failed', result_note: 'runner_exception: ' + err.message });
            } else {
                await tasks.updateTask(task.id, { status: 'pending', tries: nextTries });
            }
        }
    }
}

// ── Quote-request email-leg reply poll (2026-08-05) ─────────────────────────
// No inbound-email watcher exists anywhere for trucker-style correspondence
// (emailWatcher.js's poll is scoped to ops@'s carrier-booking intake, a
// different mailbox/purpose) — reminders/escalation timers don't need this
// (they're pure timers), but detecting "did the email-channel trucker
// actually reply with a price" does. Runs every 5 minutes — frequent enough
// that a price via email doesn't sit unnoticed for long, infrequent enough
// not to hammer the Gmail API for what's normally a handful of open legs.
async function quoteEmailReplyWatch() {
    try {
        const quoteRequests = require('./workflow/quoteRequests');
        const result = await quoteRequests.pollEmailReplies();
        if (result.replied) console.log(`[SCHED] quote email poll: ${result.replied}/${result.checked} legs had a new reply`);
    } catch (err) {
        console.error('[SCHED] quote-email-poll:', err.message);
    }
}

// ── Contact-quote-request email-leg reply poll (2026-08-16) ────────────────
// Same reasoning/cadence as quoteEmailReplyWatch just above, for the new
// contact-quote-request feature's email legs instead of trucker legs — see
// workflow/contactQuoteRequests.js's pollEmailReplies for the actual polling
// logic (reuses the same gmail-token-sender-read.json client as the trucker
// poll, so if that token isn't set up, BOTH polls no-op with a warning until
// it is — not a new dependency).
async function contactQuoteEmailReplyWatch() {
    try {
        const contactQuoteRequests = require('./workflow/contactQuoteRequests');
        const result = await contactQuoteRequests.pollEmailReplies();
        if (result.replied) console.log(`[SCHED] contact-quote email poll: ${result.replied}/${result.checked} legs had a new reply`);
    } catch (err) {
        console.error('[SCHED] contact-quote-email-poll:', err.message);
    }
}

// ── General sent-email reply poll (2026-08-06) ──────────────────────────────
// Same cadence/reasoning as quoteEmailReplyWatch just above, for the general
// draftEmailForConfirm/sendDraftedEmail flow instead of quote-request legs —
// see workflow/emailReplyWatch.js's own header. Kept as its own function/cron
// entry (not folded into quoteEmailReplyWatch) so a failure or slowdown in
// one poll can't affect the other.
// Scans the inbox for mail that is waiting on HER — see
// workflow/replyWatch.js. Distinct from the three *EmailReplyWatch functions
// above: those follow up on threads Jarvis itself started, this one watches
// inbound mail nobody asked for. Read-only; it only ever flags.
async function replyWatch() {
    try {
        const { run } = require('./workflow/replyWatch');
        // sendMessage is passed so deadline reminders can go to the internal
        // team group rather than only to the manager — see replyWatch's
        // deadline block.
        const result = await run({ sendToManager: _sendToManager, sendMessage: _sendMessage });
        if (result.flagged) console.log(`[SCHED] reply-watch: ${result.flagged}/${result.checked} email(s) need a reply`);
    } catch (err) {
        console.error('[SCHED] reply-watch:', err.message);
    }
}

async function generalEmailReplyWatch() {
    try {
        const { pollGeneralEmailReplies } = require('./workflow/emailReplyWatch');
        const result = await pollGeneralEmailReplies();
        if (result.replied) console.log(`[SCHED] general email poll: ${result.replied}/${result.checked} thread(s) had a new reply`);
    } catch (err) {
        console.error('[SCHED] general-email-poll:', err.message);
    }
}

// 'YYYY-MM-DD' in America/New_York — used ONLY by eodYardReport below, kept
// separate from todayKey()/getLADate() above since every other job in this
// file deliberately runs on LA time and this one deliberately doesn't (see
// eodYardReport's comment). Intl.formatToParts (not toLocaleDateString's
// plain string output) so the field order is unambiguous regardless of
// runtime locale.
function getEasternDateKey() {
    const parts = new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit' }).formatToParts(new Date());
    const get = (t) => parts.find(p => p.type === t).value;
    return `${get('year')}-${get('month')}-${get('day')}`;
}

// Builds the full text summary — used as BOTH the email body and the
// WhatsApp message, same text, two channels — for a given day's yard
// report. Pulled out as its own pure function, separate from eodYardReport's
// Drive/email/WhatsApp side effects below, specifically so the TEXT can be
// tested on its own against plain in-memory load arrays without a live
// Drive/Gmail/WhatsApp connection.
//
// The two "Inventory by item type" sections were added 2026-08-15 per
// the owner ("I want inventory report to be sent... item type summary of all
// the loads so far... per day, how many loads"). Her direct answer on scope
// was "Two categories. per day load data and then in another, overall load
// inventory" — so this is deliberately TWO separate sections (today's
// breakdown, then an all-time cumulative one across every load ever
// recorded), both folded into this one existing report rather than a
// second send, per her preference on structure. Reuses helpers/pdf.js's
// groupItemsByDescription — the exact same grouping the PDF's own "Summary
// by Item Type" table already uses — so "how items roll up by type" has one
// definition, not two that could drift apart.
function buildYardReportText(dateKey, todays, allLoads) {
    const unit = todays.find(l => l.weight_unit)?.weight_unit || 'lb';
    const totals = todays.reduce((acc, l) => ({
        gross : acc.gross  + (l.gross_weight || 0),
        tare  : acc.tare   + (l.tare_weight  || 0),
        net   : acc.net    + (l.net_weight   || 0),
        amount: acc.amount + (l.amount       || 0),
    }), { gross: 0, tare: 0, net: 0, amount: 0 });

    // Uses l.seller — the outside counterparty's name. (Briefly used
    // l.buyer earlier today after finding this WAS reading the wrong field —
    // that diagnosis was correct at the time, but the owner then corrected the
    // field mapping itself: seller/seller_address are now the free-text
    // counterparty fields and buyer is the fixed company constant — see
    // helpers/loads.js's validateLoadForSave comment. l.seller is right
    // again under the new mapping.)
    const lines = todays.map(l =>
        `• ${l.id} — ${l.seller || 'Unnamed seller'} — Net ${l.net_weight ?? '—'} ${unit}${l.amount != null ? ` — ${usd(l.amount)}` : ''}`
    );

    // Reformatted 2026-08-16 per the owner ("this looks ugly and unorganised" /
    // "show this in pdf"): the two "Inventory by item type" sections that
    // used to live here (today's breakdown + an ever-growing all-time list)
    // are gone. UPDATED 2026-08-19: that content moved again — the daily
    // inventory PDF this used to point at is no longer produced at all, and
    // the item-type breakdown now lives in the live "Inventory-Overall"
    // Google Sheet, whose link the email carries. This text is WhatsApp's job: a quick
    // same-night read, not the full record — see the "WhatsApp gets the
    // text summary only" comment further down for the email-vs-WhatsApp
    // split this follows. `*text*` renders bold on WhatsApp; email clients
    // just show the literal asterisks, which is an acceptable tradeoff for
    // one shared body string across both channels (per the owner's original
    // "same text, two channels" design — see this function's header
    // comment) rather than maintaining two separately-formatted bodies.
    // A ZERO-LOAD DAY IS TWO LINES. the owner, 2026-08-24: "if zero loads, dont
    // sent any url. Just send as *Loads today (0)* / No loads recorded today."
    // Nothing happened; a wall of spreadsheet links underneath that is noise,
    // and noise on a report that arrives every single night is how the report
    // stops being read at all.
    if (!todays.length) {
        return [
            `*${cfg.COMPANY_NAME} — Yard Report — ${dateKey}*`,
            '',
            `*Loads today (0)*`,
            'No loads recorded today.',
        ].join('\n');
    }

    // The line that used to sit here — "Full inventory breakdown (by item
    // type, today + all-time) is in the attached PDF" — was removed
    // 2026-08-24 because it had been untrue since 2026-08-19, when this
    // report stopped attaching anything and switched to links only (see the
    // "LINKS ONLY, no attachments" comment in eodYardReport). Every report
    // since has told her to look at an attachment that wasn't there. It
    // reads as a bug in the send, and would have been chased as one.
    // ── OPEN CLAIMS, ON THE YARD'S OWN CHANNEL ───────────────────────────
    // the owner, 2026-10-01: "remind user abut the claim every day" — and then,
    // when the reminder had been put in the Sample Yard Co Metals integrity sweep,
    // "SAMPLE_9 — Sam never involve yard with this."
    //
    // She was right twice over. A claim against a load the YARD bought is
    // Sample Yard Co Yard's business, and this report is Sample Yard Co Yard's channel: its own
    // toggle, its own recipients, its own WhatsApp group under Settings >
    // Yard. The metals sweep reads bills, sales and margin and should carry
    // nothing from here.
    //
    // Appended rather than given its own send, so a claim open for a week
    // does not become seven emails of its own — it sits under the day's
    // loads, where whoever reads this is already looking.
    //
    // Best-effort: a claims file that cannot be read must not cost her the
    // whole yard report, which is the part someone is waiting for.
    let claimLines = [];
    try {
        const open = require('./helpers/yardClaims').openForReminder();
        if (open.length) {
            claimLines = ['', `*Open claims (${open.length})*`,
                ...open.map((c) => `${c.load_id}${c.seller ? ` — ${c.seller}` : ''}: `
                    + `${usd(c.amount)} · ${c.reason}`
                    + (c.age_days == null ? '' : ` · ${c.age_days}d`))];
        }
    } catch (e) {
        console.error('[SCHED] eod-yard-report: could not read open claims:', e.message);
    }

    return [
        `*${cfg.COMPANY_NAME} — Yard Report — ${dateKey}*`,
        '',
        `*Loads today (${todays.length})*`,
        ...lines,
        '', '*Totals*',
        `Gross ${totals.gross} ${unit} · Tare ${totals.tare} ${unit} · Net ${totals.net} ${unit} · ${usd(totals.amount)}`,
        ...claimLines,
    ].join('\n');
}

// ── 8PM Eastern — end-of-day yard report ────────────────────────────────────
// the owner asked for a daily wrap-up of that day's scrap-yard "Loads" activity
// (dashboard/index.html's Loads tab, backed by helpers/loads.js): the priced
// ticket + weights PDF for every load dated today, emailed to whoever's
// configured under dashboard Settings > Yard, plus a text summary posted to
// the yard WhatsApp group/contacts configured there too. Registered with its
// OWN timezone option in start() below (America/New_York), not the shared
// LA `TZ` constant every other job in this file uses.
async function eodYardReport() {
    const dateKey = getEasternDateKey();
    const key = `eod_yard_report_${dateKey}`;
    if (alreadySent(key)) return;

    const { loadSettings } = require('./helpers/json');
    const settings = loadSettings();

    // Master on/off switch — Settings > Yard, dashboard-editable. Added
    // 2026-08-15 per the owner ("there should be an option to enable the daily
    // report sending in dashboard admin access"). Checked BEFORE the
    // recipients check below and does NOT markSent — same reasoning as the
    // "no recipients configured" case: flipping this on later should send
    // on the very next 8PM run, not stay skipped because today already
    // "ran" while it was off.
    if (!settings.yard_report_enabled) {
        console.log(`[SCHED] eod-yard-report: disabled in Settings > Yard for ${dateKey} — skipping`);
        return;
    }

    const emails = (settings.yard_report_emails || '').split(',').map(s => s.trim()).filter(Boolean);
    const waTargets = [];
    if (settings.yard_whatsapp_group_id) waTargets.push(settings.yard_whatsapp_group_id.trim());
    (settings.yard_whatsapp_contacts || '').split(',').map(s => s.trim()).filter(Boolean)
        .forEach(num => waTargets.push(num.replace(/\D/g, '') + '@c.us'));

    if (!emails.length && !waTargets.length) {
        // Nothing configured yet under Settings > Yard — log once per day
        // rather than mark-and-skip silently forever, and deliberately do
        // NOT markSent here: once the owner fills in the settings, the very
        // next 8PM run should actually send instead of staying skipped for
        // a day it technically already "ran."
        console.log(`[SCHED] eod-yard-report: no recipients configured (Settings > Yard) for ${dateKey} — skipping`);
        return;
    }

    const { loadLoads } = require('./helpers/loads');
    const allLoads = loadLoads();
    const todays = allLoads.filter(l => l.date === dateKey);

    // Mark BEFORE sending — see dailyTruckerCheck's comment above for why
    // (a crash mid-send costs one skipped day, not a duplicate report).
    await markSent(key);

    const summaryText = buildYardReportText(dateKey, todays, allLoads);

    // Excel backup + daily inventory PDF — per the owner 2026-08-15 ("as a
    // backup, an excel should be created to track this inventory... everyday
    // a pdf should be created for inventory for that day and it should
    // stored in drive as report folder"). Piggybacks on this SAME nightly
    // job/toggle rather than a separate cron entry — it's the same "daily
    // inventory reporting" feature bundle the owner is turning on/off with one
    // switch (Settings > Yard > yard_report_enabled), just two more output
    // formats of the exact same data. Best-effort: a Drive hiccup here must
    // never block the email/WhatsApp send below, which is the part someone's
    // actually waiting to read tonight.
    // Hoisted so the email block below can attach it — see that block's
    // comment. Stays null if generation/upload fails; email send still
    // proceeds without it (best-effort, same as the try/catch already did).
    // Rebuild the live Google Sheet + this month's per-day workbook, and keep
    // their links for the email below. Changed 2026-08-19 per the owner: the
    // daily report no longer sends a PDF — "instead of pdf sending, i want
    // you to create a google sheet for overall inventory maintenance and
    // update on daily basis". The sheet is already kept current by the live
    // sync on every load change (helpers/sheetSync.js); this nightly call is
    // the belt-and-braces rebuild, and the thing that produces the links the
    // email needs. syncNow never throws — it returns null on failure, and the
    // email then simply goes out without links rather than not going at all.
    let sheetLinks = null;
    try {
        const { syncNow, monthKeyFor } = require('./helpers/sheetSync');
        sheetLinks = await syncNow([monthKeyFor(dateKey)]);
        if (sheetLinks) console.log(`[SCHED] eod-yard-report: Google Sheet + monthly workbook updated for ${dateKey}`);
    } catch (e) {
        console.error('[SCHED] eod-yard-report: sheet sync failed (email/WhatsApp send still proceeds):', e.message);
    }

    // The legacy Inventory-Backup.xlsx is still written — it's a different
    // artefact from the new per-month workbook (rolling "last 5 days +
    // Overall" item-type rollup vs a chronological per-day record), nothing
    // asked for its removal, and anyone with its link keeps working.
    // The daily inventory PDF is NO LONGER generated or uploaded: it existed
    // only to be attached to this email, and the email no longer carries
    // attachments.
    try {
        const { inventoryWorkbookBuffer } = require('./helpers/inventoryExcel');
        const { uploadInventoryBackupXlsx } = require('./helpers/drive');
        await uploadInventoryBackupXlsx(await inventoryWorkbookBuffer(allLoads));
        console.log(`[SCHED] eod-yard-report: inventory backup (xlsx) uploaded for ${dateKey}`);
    } catch (e) {
        console.error('[SCHED] eod-yard-report: inventory Excel backup failed (email/WhatsApp send still proceeds):', e.message);
    }

    // Make sure every one of today's loads actually HAS its PDFs before
    // trying to attach/link them — a load only gets PDFs once someone hits
    // "Generate PDF" on the card, so this generates on the fly for any load
    // still sitting at status:'open' rather than silently omitting it.
    //
    // ── THE GUARD ASKED FOR A FIELD THAT CANNOT EXIST (2026-10-10) ──────
    // It used to read `if (l.pdf_link && l.weights_pdf_link)`. A load with no
    // scale photos deliberately never GETS weights_pdf_link — helpers/
    // loadsPdf.js skips that document because there are no photos for it to
    // carry — so every photo-less load failed this test on its own evening
    // and had all of its documents rebuilt and re-uploaded to Drive for
    // nothing. On 2026-10-08 the third of those uploads failed, which is the
    // ⚠ the owner found on SAMPLE_130 the next morning, 36 seconds after this
    // job started.
    //
    // hasReportablePdfs asks the question this loop actually means: does the
    // load already hold what the email below LINKS? It lives next to the
    // weights-PDF rule it depends on, so the two cannot drift apart.
    const { generateAndStoreLoadPdfs, hasReportablePdfs } = require('./helpers/loadsPdf');
    const withPdfs = [];
    for (const l of todays) {
        if (hasReportablePdfs(l)) { withPdfs.push(l); continue; }
        try {
            const updated = await generateAndStoreLoadPdfs(l);
            withPdfs.push(updated || l);
        } catch (e) {
            console.error(`[SCHED] eod-yard-report: PDF generation failed for ${l.id}, reporting it without a PDF:`, e.message);
            withPdfs.push(l);
        }
    }

    // Email gets the actual PDF files as attachments — downloaded back from
    // Drive by ID via the same helper the rest of the app already uses to
    // re-read stored PDF bytes.
    // LINKS ONLY, no attachments — per the owner 2026-08-19. Previously this
    // downloaded every load's ticket + weights PDF back out of Drive and
    // attached them all, plus the inventory PDF; a busy day could produce a
    // 20+ MB email. Now the email carries the summary text and links to the
    // live Google Sheet, the month's per-day workbook, and each load's PDFs
    // (which still exist in Drive exactly as before — only the attaching
    // stopped, nothing was deleted).
    if (emails.length) {
        try {
            const linkLines = [];
            if (sheetLinks && sheetLinks.sheet && sheetLinks.sheet.webViewLink) {
                linkLines.push(`Overall inventory (live Google Sheet): ${sheetLinks.sheet.webViewLink}`);
            }
            if (sheetLinks && sheetLinks.months) {
                for (const m of sheetLinks.months) {
                    if (m.file && m.file.webViewLink) linkLines.push(`Daily loads — ${m.monthKey}: ${m.file.webViewLink}`);
                }
            }
            // Expense links only appear once expenses actually exist — see
            // runSync in helpers/sheetSync.js, which skips building them
            // entirely for a yard that doesn't use the tracker.
            if (sheetLinks && sheetLinks.expenseSheet && sheetLinks.expenseSheet.webViewLink) {
                linkLines.push(`Expenses (live Google Sheet): ${sheetLinks.expenseSheet.webViewLink}`);
            }
            if (sheetLinks && sheetLinks.expenseMonths) {
                for (const m of sheetLinks.expenseMonths) {
                    if (m.file && m.file.webViewLink) linkLines.push(`Daily expenses — ${m.monthKey}: ${m.file.webViewLink}`);
                }
            }
            const pdfLines = [];
            for (const l of withPdfs) {
                if (l.pdf_link) pdfLines.push(`  ${l.id}: ${l.pdf_link}`);
                if (l.weights_pdf_link) pdfLines.push(`  ${l.id} (weights): ${l.weights_pdf_link}`);
            }
            // Links suppressed on a zero-load day for the same reason the
            // summary is two lines — see buildYardReportText. The sheets haven't
            // changed if nothing was weighed.
            const quiet = !todays.length;
            const body = [
                summaryText,
                ...(!quiet && linkLines.length ? ['', ...linkLines] : []),
                ...(!quiet && pdfLines.length ? ['', "Today's load tickets:", ...pdfLines] : []),
            ].join('\n');
            const { sendEmail } = require('./helpers/gmail');
            await sendEmail({ to: emails.join(', '), subject: `${cfg.COMPANY_NAME} — Yard Report — ${dateKey}`, body });
        } catch (e) {
            console.error('[SCHED] eod-yard-report: email send failed:', e.message);
        }
    }

    // WhatsApp gets the text summary only — not the PDFs too (that'd be up
    // to N x 2 file messages landing in the group every night). Email is the
    // channel for the actual documents; WhatsApp is for a quick same-night read.
    for (const chatId of waTargets) {
        try { await _sendMessage(chatId, summaryText); }
        catch (e) { console.error(`[SCHED] eod-yard-report: WhatsApp send to ${chatId} failed:`, e.message); }
    }

    console.log(`[SCHED] eod-yard-report: sent for ${dateKey} — ${todays.length} loads, ${emails.length} email recipient(s), ${waTargets.length} WhatsApp target(s)`);
}

// ── 11:15PM — HER LIVE WORKBOOK, INTO SAMPLE YARD CO METALS ──────────────────────────
// the owner, 2026-09-24: "at everyday night,a bot should run which need to update
// my bills and invoices in website from live sheet..if anything is missing,
// enter that as well", and "Wire night job.Dont touch sample yard co yard.its for edge
// metals".
//
// SAMPLE YARD CO METALS ONLY. helpers/sheetSync.js is the YARD sync going the other way
// — loads and expenses OUT to Drive — and is untouched by this. Two syncs,
// two companies, opposite directions; CLAUDE.md rule 5.
//
// 11:15pm, half an hour after nightlyCutoffBackfill at 10:45 so the two are
// never mid-write on the same stores, and before autoArchive at 11pm has to
// share the hour... deliberately AFTER both, so a slow backfill cannot push
// this into the next day.
//
// DRY RUN until she says otherwise: runNightly writes only when BOTH
// opts.write is true AND SHEET_SYNC_WRITE=1 is in the environment. She asked
// to see a report first. Either way the email goes out, including on failure
// — a night it could not run is a night her ledgers did not get the new rows,
// and silence would read as "nothing to add".
// ── LAST NIGHT'S SHEET COMPARISON, KEPT FOR THE MORNING ──────────────────
// The 23:15 sync already fetches her workbook and computes a field-by-field
// comparison. The 07:30 ledger agent wants exactly that and must not fetch it
// again — two pulls of the same sheet eight hours apart is double the Google
// quota for one answer, and the second one can disagree with the first.
//
// In memory on purpose: if the process restarted overnight the agent simply
// runs sweep-only, which is a smaller report rather than a wrong one.
let lastSheetSyncReport = null;

async function nightlyMetalsSheetSync() {
    const job = require('./helpers/metalsSheetSyncJob');
    const result = await job.runNightly({ write: true });
    // Kept for the 07:30 ledger agent — see lastSheetSyncReport above. Set
    // here rather than fetched there, so her workbook is pulled once a night
    // and both jobs answer from the same comparison. A failed run leaves the
    // previous night's report in place rather than a half one: `report` is
    // absent on failure, and the agent running sweep-only is a smaller report
    // rather than a wrong one.
    if (result && result.report) lastSheetSyncReport = result.report;
    // ── A FAILURE MUST NOT READ LIKE A SUMMARY ────────────────────────────
    // This printed `result.error || summarise(...)`, so the night the job
    // threw "nothing planned to commit" the log said exactly that, in the
    // place a summary belongs — and it looked like a quiet, successful night
    // with nothing to add. It had written nothing for days (2026-09-25).
    const mode = result.dryRun ? '(dry run)' : '(live)';
    if (result.error) {
        console.error(`[SCHED] metals-sheet-sync ${mode} FAILED — NOTHING WAS WRITTEN: ${result.error}`);
    } else {
        const wrote = result.committed
            ? ` — wrote ${result.committed.bills} bill(s), ${result.committed.sales} invoice(s) as batch ${result.committed.batch}`
            : (result.dryRun ? '' : ' — nothing new to write');
        console.log(`[SCHED] metals-sheet-sync ${mode}: ${require('./helpers/metalsSheetSync').summarise(result.report)}${wrote}`);
        if ((result.refused || []).length) {
            console.error(`[SCHED] metals-sheet-sync: ${result.refused.length} row(s) could not be prepared and were NOT written`);
        }
    }
    try { await job.emailReport(result); }
    catch (e) { console.error('[SCHED] metals-sheet-sync email failed:', e.message); }
    return result;
}

async function nightlyQuickBooks() {
    const job = require('./helpers/quickbooksNightly');
    const out = await job.run();
    const s = job.summarise(out.result || {});
    if (out.error) console.error(`[SCHED] quickbooks FAILED — NOTHING WAS WRITTEN: ${out.error}`);
    else console.log(`[SCHED] quickbooks ${out.dryRun ? '(dry run)' : '(live)'}: entered ${s.made}, stuck ${s.blocked}, needs her ${s.asked}${s.errored ? `, errors ${s.errored}` : ''}${s.left ? `, left alone ${s.left} older than the cutover` : ''}`);
    // ── INTO THE DIGEST, NOT STRAIGHT TO HER INBOX ───────────────────────
    // the owner chose one 07:25 email over three. The sweep still runs at 00:00
    // and still WRITES at 00:00 — only the posting moved. job.emailReport is
    // untouched and still used by scripts/qb-run.js and the tests.
    //
    // A FAILURE is the exception and goes at once: an expired token at
    // midnight must not wait until 07:25, because those are seven hours in
    // which she believes her books are being kept and they are not.
    try {
        if (out.error) await job.emailReport(out);
        else await require('./helpers/qbDigest').record('sweep',
            { text: job.reportText(out, { csvName: require('./helpers/qbDigest').STUCK_CSV_NAME }),
              csv: (out.blocked && out.blocked.length) || (out.asked && out.asked.length) ? job.stuckCsv(out) : null,
              summary: s, ok: true });
    } catch (e) { console.error('[SCHED] quickbooks report failed:', e.message); }
    return out;
}

async function qbAgent() {
    const agent = require('./helpers/quickbooks/agent');
    // The agent writes only when both switches are on, exactly like the sweep
    // before it. Off means a survey and an email that says so.
    const live = String(process.env.QB_PROD_WRITES || '').toLowerCase() === 'on'
        && String(process.env.QB_SYNC || '').toLowerCase() === 'on'
        && String(process.env.QB_AGENT || '').toLowerCase() === 'on';
    const out = await agent.run({ really: live, reason: 'QB Agent nightly run' });
    const s = (out.survey || {}).invariants || {};
    const did = (out.did || []).find((d) => d.id === 'allocate');
    console.log(`[SCHED] qb-agent ${out.dryRun ? '(survey only)' : '(live)'}: placed ${did ? did.placed : 0}`
        + `, still loose ${s.unallocated ? s.unallocated.number : '?'}`
        + `, doubled ${s.duplicates ? s.duplicates.number : '?'}`
        + `, miscoded ${s.miscoded ? s.miscoded.number : '?'}`);
    // Same arrangement as the sweep above: the agent is unchanged, its own
    // emailReport is unchanged, only the delivery is pooled into the 07:25
    // digest. A run that could not survey still mails immediately.
    try {
        const open = Object.values(s).filter((v) => v && v.number > 0).length;
        if (out.error) await agent.emailReport(out);
        else await require('./helpers/qbDigest').record('agent',
            { text: agent.reportText(out), summary: { open }, ok: true });
    } catch (e) { console.error('[SCHED] qb-agent report failed:', e.message); }
    return out;
}

function start() {
    cron.schedule('0 8 * * *',    () => morningDigest().catch(e => console.error('[SCHED] digest:', e)), TZ);
    cron.schedule('15 8 * * *',   () => dailyTruckerCheck().catch(e => console.error('[SCHED] trucker-check:', e)), TZ);
    cron.schedule('30 9 * * *',   () => datesWatch().catch(e => console.error('[SCHED] dates-watch:', e)), TZ);
    cron.schedule('0 9-17 * * *', () => urgentWatch().catch(e => console.error('[SCHED] urgent:', e)),   TZ);
    cron.schedule('0 9-17 * * *', () => stallWatch().catch(e => console.error('[SCHED] stall:', e)),     TZ);
    cron.schedule('0 6 * * *',    () => pricelistFallback().catch(e => console.error('[SCHED] pricelist:', e)), TZ);
    cron.schedule('0 23 * * *',   () => autoArchive().catch(e => console.error('[SCHED] archive:', e)),  TZ);
    cron.schedule('0 7 * * *',    () => nightlyLogDigest().catch(e => console.error('[SCHED] log-digest:', e)), TZ);
    // ── AND SOMETHING HAS TO READ THE PULSE (2026-10-08) ──────────────────
    // A heartbeat nobody looks at is the same as no heartbeat. Three times a
    // day, and it SAYS NOTHING WHEN ALL IS WELL -- a monitor that reports
    // every morning that everything is fine is a monitor she learns to
    // scroll past, and then it may as well not exist. One message, only when
    // a job has failed, gone late, or never run at all.
    //
    // HONEST LIMIT, stated here because it would otherwise be assumed away:
    // this runs INSIDE the same process as the jobs it watches, so it catches
    // a JOB dying. It cannot catch the PROCESS dying -- if pm2 stops or the
    // VM goes down, nothing here fires, because nothing here is running.
    // That needs a check from outside the box, and it is not this.
    cron.schedule('5 7,13,20 * * *', () => healthWatch().catch(e => console.error('[SCHED] health-watch:', e)), TZ);
    // ── 05:40 — CAN PEOPLE ACTUALLY GET IN ───────────────────────────────
    // the owner, 2026-10-05: "Find a permanent solution to fix this foreveer",
    // after a customer in the US spent an afternoon on
    // ERR_CONNECTION_TIMED_OUT at the pre-HTTPS address while the server was
    // perfectly healthy.
    //
    // Nothing in this system had ever checked that its own public address
    // answers. Every other watcher looks INWARD — at ledgers, at the sheet,
    // at QuickBooks — and all of them were green while the front door was
    // unreachable for the people who mattered. The first thing to find out
    // was a customer.
    //
    // Five minutes ahead of the bank pull so that if the server is
    // unreachable she hears THAT first, rather than reading a bank report
    // from a machine nobody can log into.
    //
    // Silent when every address behaves. See helpers/entrances.js for which
    // failures qualify and why a declared-dead address is never attempted.
    cron.schedule('40 5 * * *',   () => require('./helpers/entrancesJob').run()
        .then((r) => { if (!r.ok) console.warn('[SCHED] entrances: ' + r.broken.length + ' address(es) not working'); })
        .catch(e => console.error('[SCHED] entrances:', e)), TZ);

    // ── 05:45 — THE BANK, BEFORE ANY AGENT LOOKS AT IT ───────────────────
    // the owner, 2026-10-05: "i should nt struggle at all during tax filing."
    // The matching screen has a Pull button because a person sometimes wants
    // one now; this is so she never needs it.
    //
    // 05:45 and not 06:00: the 06:30 integrity sweep and the 07:25/07:30
    // agents all read the ledgers, and a deposit that arrives after them is a
    // deposit they discussed without knowing about. Banks post overnight, so
    // by 05:45 yesterday has settled. It also keeps clear of the 06:00
    // pricelist job rather than sharing a minute with it.
    //
    // SILENT WHEN IT WORKS. The exception is the whole reason this is a job
    // and not a line: if the Plaid item dies, deposits simply stop arriving
    // and the matching screen looks calm and empty rather than broken.
    // Nothing else in the system would ever notice, so a dead feed — and a
    // row the bank withdrew after she had allocated it — do get an email.
    // See helpers/bankPullJob.js for which failures qualify and why.
    cron.schedule('45 5 * * *',   () => require('./helpers/bankPullJob').run()
        .then((r) => { if (r.ran) console.log(`[SCHED] bank-pull: +${r.added} ~${r.modified}${r.sent ? ' (emailed)' : ''}`); })
        .catch(e => console.error('[SCHED] bank-pull:', e)), TZ);
    // ── THE LEDGERS, CHECKED AGAINST THEMSELVES ──────────────────────────
    // the owner, 2026-09-26: "Is it possible to run an agent everyday in website
    // to find out any issue or discrepancy?"
    //
    // 06:30, ahead of the 07:00 log digest and the 08:00 morning digest, so
    // if all three have something to say they arrive oldest-first and she
    // reads them in the order they were produced.
    //
    // Silent when clean — see helpers/integritySweepJob.js. Everything it
    // notices, when it notices anything.
    // ── 07:30 — the ledger agent ─────────────────────────────────────────
    // the owner, 2026-10-01: an agent for bills and invoices, scanning regularly,
    // with its own daily email.
    //
    // AFTER the 06:30 sweep, so its findings are today's; and it reuses the
    // 23:15 sheet sync's report rather than fetching her workbook a second
    // time. BEFORE 08:00 so it lands with the morning digest instead of an
    // hour behind it.
    //
    // markSent/alreadySent are handed in: they live here, on top of
    // brain.proactive_sent, and the job deliberately names no module of its
    // own after a first version invented two that do not exist.
    // ── 07:25 — THE QUICKBOOKS AGENT, FIVE MINUTES AHEAD ─────────────────
    // the owner, 2026-10-01: "Assign one agent for quickbook next", "so
    // (bills+invoice) agent should talk to this agent."
    //
    // It runs FIRST so the ledger agent knows which blanks are stopping rows
    // entering her books, and chases those loudest. Five minutes rather than
    // the same minute: the dry sweep talks to QuickBooks, and a slow morning
    // must not make the ledger agent wait on it.
    //
    // The two are not chained. If this fails or QuickBooks is down, 07:30
    // runs anyway with no blocking information — the blanks still get filled,
    // they are just not marked urgent. Chaining them would turn one outage
    // into two.
    //
    // Dry run always: this job cannot push, cannot create a vendor, cannot
    // journal. QB_PROD_WRITES and QB_SYNC keep meaning what they meant.
    // ── 07:25 — BLOCKED ROWS, AND THEN THE ONE EMAIL ─────────────────────
    // Renamed from "QB agent": that name belongs to helpers/quickbooks/agent.js,
    // which is the one she asked for by it ("it is called agent qb") and the
    // one the QuickBooks page's QB Agent tab opens. This job reports what will
    // not go IN; that one audits what is already inside. Two different things
    // under one name made a question about "the QB agent" ambiguous.
    //
    // It posts the digest last, after recording its own part, so all three
    // nights' reports leave in a single envelope. The send is deliberately
    // chained rather than put on its own cron: a digest sent before this job
    // recorded would be missing the part it was waiting for.
    cron.schedule('25 7 * * *', () => require('./helpers/qbAgentJob')
        // A no-op sender, because this job must not post its own letter any
        // more. Recording happens from the RESULT below rather than from this
        // callback: run() skips the sender entirely when nothing is stuck, so
        // a quiet morning would never record a part and the digest would
        // report "blocked rows did not run" — a false alarm about the one
        // thing it exists to be honest about.
        .run({ alreadySent, markSent, send: async () => {} })
        .then(async (r) => {
            const digest = require('./helpers/qbDigest');
            // `skipped` means it already ran today; leave whatever it recorded
            // the first time rather than overwriting it with nothing.
            // ── IT REPORTS ONLY WHEN IT FAILED ───────────────────────
            // the owner: "why two qb Agents? one should be enough na." She was
            // right — its report said what the 00:00 sweep already says. The
            // job still runs, because the ledger agent at 07:30 needs the
            // blocking fields it works out; it just stopped writing a letter
            // about it.
            //
            // A FAILURE is still said, because then 07:30 is chasing without
            // knowing which blanks are holding up her books, and a quieter
            // ledger chase with no explanation is the kind of silence this
            // whole file exists to prevent.
            if (r && r.error) {
                await digest.record('blocked',
                    { ok: false, summary: null,
                      text: `The 07:25 blocked-rows check failed: ${String(r.error).slice(0, 200)}\n\n`
                          + 'The ledger agent ran at 07:30 without knowing which blanks are\n'
                          + 'holding rows out of QuickBooks, so its chase is less pointed today.\n'
                          + 'What is stuck is still listed under "Entered overnight" above.' });
            }
            return digest.send({ alreadySent, markSent });
        })
        .then((d) => console.log(`[SCHED] qb-digest: ${d.sent ? 'sent' : 'not sent'}`
            + `${d.why ? ' — ' + d.why : ''}${d.error ? ' — ' + d.error : ''}`))
        .catch(e => console.error('[SCHED] blocked-rows:', e)), TZ);

    // 07:30 — reads the 07:25 result off qbAgentJob.look() by itself; it is
    // not passed in, so a morning where 07:25 never ran is simply a morning
    // with no blocking marks rather than a crash on an undefined argument.
    cron.schedule('30 7 * * *', () => require('./helpers/ledgerAgentJob')
        .run({ alreadySent, markSent, sheetReport: lastSheetSyncReport })
        .catch(e => console.error('[SCHED] ledger-agent:', e)), TZ);

    // ── 07:45 — THE CLAIMS CHASE ─────────────────────────────────────────
    // the owner, 2026-10-02: "for handling claims-I want to have an advanced
    // agent because thats where we are losing money", and on the window:
    // "there is no specific window - the faster the better."
    //
    // AFTER the ledger agent at 07:30, so the three morning messages arrive
    // in one block rather than trickling, and last of them because it is the
    // one she is most likely to act on immediately — a recovery email to
    // write is a task, and tasks belong at the end of a briefing.
    //
    // No window to count down to means AGE is the whole mechanism: the chase
    // gets louder the longer something sits, and it does not stop. See
    // helpers/claimsAgentJob.js LOUDNESS.
    //
    // It writes nothing to the claims register and sends nothing to a
    // supplier. Chase and draft; a person still raises the recovery.
    cron.schedule('45 7 * * *', () => require('./helpers/claimsAgentJob')
        .run({ send: (t) => _sendToManager(t), alreadySent, markSent })
        .catch(e => console.error('[SCHED] claims-chase:', e)), TZ);

    // ── Booking Agent — does the carrier agree with our dates? ───────────
    // the owner, 2026-10-03: "Build Maersk api integration to Booking Agent."
    // Twice a day because lines move cutoffs during the working day, and a
    // morning-only check finds an afternoon change the next morning — after
    // the trucker has been dispatched. 07:15 lands before the QB / ledger /
    // claims block; 14:15 catches the day's changes while there is still time
    // to act. Silent when Maersk agrees; each disagreement is said once.
    // Read-only: it never writes bookings.json. Does nothing at all until
    // MAERSK_CONSUMER_KEY is set. See helpers/bookingAgent.js.
    cron.schedule('15 7,14 * * *', () => require('./helpers/bookingAgentJob')
        .run({ send: (t) => _sendToManager(t), alreadySent, markSent })
        .catch(e => console.error('[SCHED] booking-agent:', e)), TZ);

    // ── Follow-up Agent — did the truck actually turn up? ────────────────
    // the owner, 2026-11-06: "Have a followup agent", after:
    //   "if i book a shipment pickup with a logistics company,say pickup
    //    arranged @11/05 say on that particular day,it should follow up with
    //    the logistic company about the pickup eta na?if no response,it needs
    //    to follow up and communicate the same to my team"
    //
    // ── HOURLY, NOT ONCE A DAY, AND THAT IS THE WHOLE DESIGN ────────────
    // Every other agent here fires once and says its piece. This one has a
    // LADDER across the pickup day — 08:00 ask, 11:00 chase, 14:00 tell the
    // team — and a rung is only due if the one before it got no answer. A
    // daily slot could not express that; the agent has to be able to look at
    // the clock more than once. 8-15 covers the ladder with an hour either
    // side, so a missed tick is caught by the next one rather than lost.
    //
    // helpers/pickupAgent.js decides and will not fire a rung twice, so
    // running eight times a day sends at most three messages. The extra
    // ticks cost a file read.
    //
    // ── THE ONE AGENT THAT MAILS A SUPPLIER DIRECTLY ────────────────────
    // claimsAgentJob deliberately does not ("sends no mail to a supplier" —
    // its own header); it chases HER. This one chases THEM, because that is
    // what she asked for in so many words. So it gets the real senders, and
    // everything defensive in helpers/pickupAgent.js exists for that reason.
    //
    // sendToTeam is her team's WhatsApp group (cfg.getTeamGroupId), falling
    // back to the manager when no group is set — index.js already makes that
    // decision, and the escalation should not make a second one.
    cron.schedule('0 8-15 * * *', () => require('./helpers/followUpAgentJob')
        .run({
            sendEmail: async (m) => {
                const { sendTrackedEmail } = require('./helpers/pickupMail');
                return sendTrackedEmail(m);
            },
            sendWhatsapp: async (to, text) => _sendMessage(to, text),
            sendToTeam: async (text) => _sendToTeam(text),
            // Payment follow-ups tell HER (drafts only; nothing goes to a customer).
            sendToManager: async (text) => _sendToManager(text),
            // Reads the mailbox for a customer's remittance copy before chasing them (read-only).
            findRemittance: require('./helpers/remittanceMail').liveFinder(),
            // QuickBooks decides who still owes; if it cannot be read, nobody is chased.
            qbSurvey: require('./helpers/paymentTruth').liveSurvey(),
            // Money already in the bank feed (Plaid) but not matched yet holds the follow-up.
            findDeposit: require('./helpers/bankDepositCheck').liveFinder(),
            // When something MAY be a customer's payment, ASK her (yes = hold, no = carry on) rather than only report it.
            askAboutHold: async (info) => {
                const st = cfg.getSettings ? cfg.getSettings() : {};
                return actions.stagePaymentHeldQuestion((st.manager_number || cfg.MANAGER_NUMBER || '') + '@c.us', info);
            },
            // A customer email is STAGED on WhatsApp and goes only after her yes (workflow/actions.js).
            stageCustomerEmail: async (draft, step) => {
                const st = cfg.getSettings ? cfg.getSettings() : {};
                return actions.stagePaymentFollowupEmail((st.manager_number || cfg.MANAGER_NUMBER || '') + '@c.us', draft, step);
            },
        })
        .then((r) => {
            const line = require('./helpers/followUpAgentJob').summarise(r);
            // Quiet unless there is something a person must act on. Every
            // agent here that spoke daily regardless has had to be
            // quietened later.
            if (line) return _sendToManager(line);
        })
        .catch(e => console.error('[SCHED] follow-up:', e)), TZ);

    // the owner, 2026-10-12: "constantly monitoring cost". Hourly; speaks at most
    // once per Pacific day. See helpers/aiCostWatch.js.
    // the owner, 2026-11-15: a weekly READ-ONLY score of the marks she gave in data/evalset.txt (never rebuilds it).
    // Silent unless the numbers changed. See helpers/evalWeekly.js.
    cron.schedule('40 7 * * 1',   () => require('./helpers/evalWeekly').weeklyLine()
        .then((line) => line && _sendToManager(line))
        .catch(e => console.error('[SCHED] eval-weekly:', e.message)), TZ);
    cron.schedule('20 * * * *',   () => require('./helpers/aiCostWatch').check().catch(e => console.error('[SCHED] ai-cost-watch:', e)), TZ);
    // ── 05:55 — THE ROLLING QUICKBOOKS SNAPSHOT ─────────────────────────
    // the owner, 2026-10-28: "it should be a rolling date..from 01-01-2026 to
    // rolling date".
    //
    // helpers/quickbooks/snapshot.js has always been rolling — since
    // 2026-01-01, no upper bound, paged properly — and helpers/qbDocNumbers.js
    // calls its output "the nightly snapshot rows". NOTHING EVER RAN IT. Not
    // this file, not the 07:25 QuickBooks agent, not any script. The index on
    // disk was 23 days old and the Bill/Invoice rows 37 days old, and the row
    // files were a single unpaginated page of 1000 that stopped in early
    // September — so a duplicate check over 2026 was reading two thirds of the
    // year and could have called it clean.
    //
    // Read-only against QuickBooks: query calls only. Ahead of the integrity
    // sweep at 06:30, the bank auto-tick at 06:50 and the QuickBooks agent at
    // 07:25, so all three read today's books rather than last month's.
    cron.schedule('55 5 * * *',   () => require('./helpers/quickbooks/snapshot')
        .write({}).then((s) => console.log(`[SCHED] qb-snapshot: ${s.bills.length} bills, `
            + `${s.invoices.length} invoices since ${s.since} (${s.env})`))
        .catch(e => console.error('[SCHED] qb-snapshot:', e.message)), TZ);
    cron.schedule('30 6 * * *',   () => require('./helpers/integritySweepJob').run()
        .catch(e => console.error('[SCHED] integrity-sweep:', e)), TZ);
    // ── 07:05 — ONE AGENT FOR QUICKBOOKS, BOOKS AND BANK ────────────────
    // the owner, 2026-10-28: "MAKE IT VERY EASY.ASSIGN A AI TO THIS TO DO ALL
    // THE JOBS", then "AN AGENT ONLY FOR QB,BOOKS,BANK".
    //
    // It adds no check of its own. It reads what already exists and sends ONE
    // message: the bank rows the 06:50 tick could not be certain about,
    // helpers/booksAgent.js' per-company verdict, and the QuickBooks snapshot's
    // freshness plus anything entered twice. TWO of those had no scheduled
    // caller at all — booksAgent.js since 2026-10-15, and the duplicate finder
    // since this morning. Both were written, tested, and run by nobody, which
    // is the defect this file keeps being the fix for.
    //
    // Silent when clean, for the reason integritySweepJob states: a daily "all
    // fine" is one she stops opening, and then the morning it says something
    // she does not open that either.
    //
    // After 05:55 (snapshot) and 06:50 (bank tick) so it reports today's
    // position, and before the 07:25 QuickBooks agent, which talks to Intuit
    // and is a different question.
    // 07:05, not 07:00: the log digest and the unrecorded-payments chase are
    // both already on that minute, and three jobs starting together makes a
    // slow morning look like a hung one.
    cron.schedule('5 7 * * *',    () => require('./helpers/accountsAgent').send()
        .then((r) => console.log(`[SCHED] accounts-agent: ${r.sent ? 'sent to ' + r.to
            : 'not sent (' + r.why + ')'}`))
        .catch(e => console.error('[SCHED] accounts-agent:', e.message)), TZ);
    // ── 07:00 — PAYMENTS THAT LEFT THE BANK AND WERE NEVER RECORDED ──────
    // the owner, 2026-10-23: "They are forgetting to record the payment in
    // jarvis", and on whether to rely on reminders: catch it instead. Told
    // it needed Plaid, she said "You have pliad na.leverage that" — and she
    // was right, helpers/bankOut.js already labels these rows 'not_recorded'.
    //
    // 07:00, HALF AN HOUR AFTER the integrity sweep above, deliberately: the
    // overnight bank pull has landed by then, and a chase built on a feed
    // that has not refreshed would name rows she recorded yesterday.
    //
    // ONCE A DAY, NOT HOURLY. This messages a person, not a log. It is also
    // silent when nothing is wrong and never repeats a row it has already
    // chased — see helpers/unrecordedPayments.js, which is where both of
    // those rules live rather than here.
    // ── 06:50 — TICK OFF WHAT JARVIS IS CERTAIN OF (#187) ────────────────
    // the owner, 2026-10-08: "when Jarvis is certain a bank row matches a
    // payment already recorded, it should tick it off by itself (exact
    // single matches only) rather than wait for her."
    //
    // BEFORE the 07:00 unrecorded-payments chase on purpose. That job asks
    // a colleague about money that left the bank with nothing recorded; a
    // row ticked at 06:50 is one it must not then chase. Ten minutes is
    // slack, not a race — both read the stores fresh.
    //
    // A match CREATES NOTHING (helpers/bankLedger.js), every tick carries
    // how:'auto' and a history line, and all of it is reversible. That is
    // the whole licence for doing it unattended.
    cron.schedule('50 6 * * *',   () => require('./helpers/bankAutoTick').run()
        .then((r) => console.log('[SCHED] ' + require('./helpers/bankAutoTick').summary(r)))
        .catch(e => console.error('[SCHED] auto-tick:', e)), TZ);
    cron.schedule('0 7 * * *',    () => require('./helpers/unrecordedPayments').chase()
        .then(r => { if (r.sent) console.log(`[SCHED] unrecorded-payments: chased ${r.found.rows.length}`); })
        .catch(e => console.error('[SCHED] unrecorded-payments:', e)), TZ);
    cron.schedule('45 22 * * *',  () => nightlyCutoffBackfill().catch(e => console.error('[SCHED] cutoff-backfill:', e)), TZ);
    cron.schedule('15 23 * * *',  () => nightlyMetalsSheetSync().catch(e => console.error('[SCHED] metals-sheet-sync:', e)), TZ);
    // ── Freight / trucker invoice sweep, right after the sheet sync (the owner, 2026-10-08) ─────────────
    // "Every night along with the shipment sweep ... if found, upload it to the Jarvis website directly
    // against the party, and notify next day what the new additions are." 23:30 so it never overlaps
    // the 23:15 sync's writes; the note goes at 07:50, after the other morning mails. Imports into the
    // invoice register ONLY (helpers/partyInvoiceNightly.js) — no sheet write, no bills.
    // PARTY_INVOICE_SWEEP=off switches both off.
    cron.schedule('30 23 * * *',  () => require('./helpers/partyInvoiceNightly').runNightly()
        .then((r) => {
            if (r.skipped) return console.log(`[SCHED] party-invoice-sweep skipped: ${r.skipped}`);
            if (r.run.ok) console.log(`[SCHED] party-invoice-sweep: read ${r.run.read} line(s) from the last ${r.run.days} day(s) — ${r.run.added} added, ${r.run.updated} refreshed, ${r.run.kept_locked} left alone`);
            else console.error(`[SCHED] party-invoice-sweep FAILED — NOTHING WAS ADDED: ${r.run.error}`);
        })
        .catch(e => console.error('[SCHED] party-invoice-sweep:', e)), TZ);
    cron.schedule('50 7 * * *',   () => require('./helpers/partyInvoiceNightly').sendDigest()
        .catch(e => console.error('[SCHED] party-invoice-digest:', e)), TZ);
    // ── QuickBooks, 45 minutes after the sheet sync ───────────────────────
    // the owner, 2026-09-25, comparing Jarvis to a commercial product: "Their
    // QuickBooks integration will be cleaner — fix this." The gap was not the
    // checks, it was that nothing ran on its own. Ordered AFTER the sheet
    // sync on purpose: that job fills the ledgers, this one pushes what it
    // filled. Same switches as ever — off means a dry run that says so.
    cron.schedule('0 0 * * *',    () => nightlyQuickBooks().catch(e => console.error('[SCHED] quickbooks:', e)), TZ);
    // ── QB Agent, half an hour after the entry run ────────────────────────
    // the owner, 2026-10-02: "auto resolves discrepancy … whose only job is to
    // make qb perfect." It runs AFTER the sweep on purpose: the sweep puts
    // today's documents in, then the agent looks at the whole year and places
    // what it can. Needs QB_AGENT=on as well as the two existing switches —
    // a survey is free, writing is a decision.
    cron.schedule('30 0 * * *',   () => qbAgent().catch(e => console.error('[SCHED] qb-agent:', e)), TZ);
    cron.schedule('* * * * *',    () => taskRunner().catch(e => console.error('[SCHED] tasks:',  e)),    TZ);
    cron.schedule('*/5 * * * *',  () => quoteEmailReplyWatch().catch(e => console.error('[SCHED] quote-email-poll:', e)), TZ);
    cron.schedule('*/5 * * * *',  () => contactQuoteEmailReplyWatch().catch(e => console.error('[SCHED] contact-quote-email-poll:', e)), TZ);
    cron.schedule('*/5 * * * *',  () => generalEmailReplyWatch().catch(e => console.error('[SCHED] general-email-poll:', e)), TZ);
    cron.schedule('*/15 * * * *', () => emailWatcher.run().catch(e => console.error('[SCHED] email:', e)), TZ);
    // Payment detection (2026-08-22). Every 30 min rather than 15: payment
    // notices are far rarer than booking mail, and each candidate costs a
    // Gemini classification call. Its own in-process lock stops a slow run
    // overlapping the next tick.
    cron.schedule('*/30 * * * *', () => paymentWatcher.run().catch(e => console.error('[SCHED] payment-watch:', e)), TZ);
    // Needs-a-reply inbox scan — every 5 minutes, around the clock. the owner,
    // 2026-08-22: "i want email to be monitored all the time."
    //
    // Affordable at this frequency because every email is assessed by Gemini
    // exactly ONCE (deduped by message id), so cost tracks how much mail
    // arrives, not how often we look. The previous hourly schedule was not
    // saving anything; it was just adding up to an hour of delay.
    //
    // Notification rationing lives inside workflow/replyWatch.js, NOT here:
    // urgent mail is sent as soon as it is found, everything else is batched
    // to at most one digest an hour, and anything found overnight is held
    // rather than dropped. Detection is continuous; only delivery is paced.
    cron.schedule('*/5 * * * *', () => replyWatch().catch(e => console.error('[SCHED] reply-watch:', e)), TZ);
    // Retry manager notifications queued while WhatsApp was unavailable.
    // index.js flushes on reconnect; this covers the case where WhatsApp
    // never fires a 'ready' event at all — banned, or stuck in a bad session —
    // and is also what escalates a long outage to email.
    cron.schedule('*/5 * * * *', () => {
        // init() here too, not just in index.js's 'ready' handler. AUDIT
        // FINDING (2026-08-22): this cron relied on init having already
        // happened elsewhere in the process. If WhatsApp never becomes ready
        // — banned, or stuck on a bad session — that handler never fires, and
        // the outbox would hold the default no-op sender. Cheap to set every
        // tick and removes the ordering dependency entirely.
        const outbox = require('./helpers/managerOutbox');
        outbox.init({ sendToManager: _sendToManager });
        outbox.flush().catch(e => console.error('[SCHED] outbox-flush:', e.message));
    }, TZ);
    cron.schedule('45 23 * * *', () => {
        const settings = cfg.getSettings ? cfg.getSettings() : {};
        const managerChatId = (settings.manager_number || cfg.MANAGER_NUMBER || '') + '@c.us';
        require('./helpers/dailyLearning').run({ sendToManager: _sendToManager, setPending: actions.setPending, managerChatId }).catch(e => console.error('[SCHED] learning:', e));
    }, TZ);
    // Automatic deposits (ownership plan slice 4, helpers/depositAutoApply.js): learn from her undos, place the CERTAIN
    // deposits, send ONE daily message of what was placed and why. OFF unless JARVIS_AUTO_APPLY=1; a quiet day sends nothing.
    // 06:20 LA: after the 05:xx bank pull and before bankAutoTick at 06:50, so the two never write the bank ledger at once.
    cron.schedule('20 6 * * *', () => require('./helpers/depositAutoApply').runDaily({ sendToManager: _sendToManager }).catch(e => console.error('[SCHED] deposit-auto-apply:', e)), TZ);
    // Price watch (helpers/priceWatch.js): each new price goes to the learner, and up to 3 unusual ones are asked about on WhatsApp
    // ("normal CODE" / "check CODE"); her answers are what the learner learns from. OFF unless JARVIS_PRICE_WATCH=1. Changes no price.
    // 06:40 LA, after the 06:20 deposit run; a quiet day sends nothing.
    cron.schedule('40 6 * * *', () => require('./helpers/priceWatch').runDaily({ sendToManager: _sendToManager }).catch(e => console.error('[SCHED] price-watch:', e)), TZ);
    if (process.env.JARVIS_DAILY_METRICS === '1') cron.schedule('50 6 * * *', () => require('./helpers/dailyMetrics').record().catch(e => console.error('[SCHED] daily-metrics:', e)), TZ);
    // Weekly owner report (ownership plan step 6). Sundays 20:00 LA = Monday morning for her in India.
    // OFF unless JARVIS_OWNER_REPORT=1; sends to the manager only; read-only. Replaces no other message yet.
    cron.schedule('0 20 * * 0', () => require('./helpers/ownerReportJob').runWeekly({ sendToManager: _sendToManager }).catch(e => console.error('[SCHED] owner-report:', e)), TZ);
    // Nightly full replication of facts.json to Supabase.
    //
    // The per-write replicate() calls in helpers/json.js are fire-and-forget
    // and CAN fail — during a Supabase blip, a network drop, or a restart
    // mid-write. This pass is what makes that acceptable: it re-pushes every
    // fact, so any single dropped replication is repaired within a day.
    // Cheap (an upsert of a few hundred rows, keyed on the fact's own id, so
    // re-pushing an unchanged fact is a no-op).
    //
    // 03:30 — after the 23:45 learning review, so any facts she approved that
    // evening are included in the same night's backup.
    cron.schedule('30 3 * * *', () => {
        require('./helpers/factReplica').syncAll()
            .catch(e => console.error('[SCHED] fact-replica sync:', e.message));
    }, TZ);

    // ── nightly data backup ───────────────────────────────────────────────
    // the owner, 2026-09-02: "What if some day this app goes down?"
    //
    // Everything else that reaches Drive is a DERIVED report. payments.json
    // and petty_cash.json — who was paid what, and the cash ledger — existed
    // in one file on one machine and could not be rebuilt from a spreadsheet
    // of weights. This is the raw stores, dated, kept 30 days.
    //
    // 02:00, chosen to sit in the quiet window: after the 23:45 learning
    // review and the 23:00 archive, before the 03:30 fact replica. Nothing
    // else is writing, so the archive is a clean point-in-time copy rather
    // than a set of files caught mid-change.
    //
    // ── 2026-10-02: IT TELLS HER WHEN IT BREAKS ───────────────────────────
    // the owner: "Protect the data of sample yard co yard no matter what."
    //
    // This used to be runBackup() with a bare console.error catch. A Drive
    // token expires, backups stop, and nobody is told — she keeps believing
    // she has thirty dated copies of payments.json and finds out on the one
    // day it matters. Every other consequential job here emails; the one
    // guarding the money ledger did not.
    //
    // backupWatch.nightly writes a receipt, emails on any trouble, and sends
    // one heartbeat line on Mondays so the ABSENCE of a message is a signal
    // too. See its header for why "silent when clean" — right everywhere
    // else in this codebase — is wrong for backups specifically.
    //
    // The catch stays, and still only logs: if the alerting itself throws,
    // that must not take the scheduler down with it. /healthz is the backstop
    // for "the backup is not running at all", which no email can cover.
    cron.schedule('0 2 * * *', () => {
        require('./helpers/backupWatch').nightly()
            .catch(e => console.error('[SCHED] nightly data backup FAILED:', e.message));
    }, TZ);

    // Own timezone — America/New_York, not the shared LA `TZ` — see
    // eodYardReport's comment for why.
    cron.schedule('0 20 * * *', () => eodYardReport().catch(e => console.error('[SCHED] eod-yard-report:', e)), { timezone: 'America/New_York' });
    console.log('[SCHED] Jobs registered (8AM digest, 8:15AM trucker-check, hourly urgent+stall 9-17, 6AM pricelist, 11PM archive, 2AM data backup, 3:30AM fact backup, 15-min email watcher, minute task-runner, 8PM ET yard report — LA time unless noted)');
}

// nightlyLogDigest is exported so tests/log-digest.js can RUN it against a
// stubbed mailer rather than grepping this file for the shape of the call.
// Two checks that only grepped survived a mutation — one that truncated the
// email to 15 rows, one that dropped the monospace html — because the words
// they matched were still sitting in the comments.
module.exports = { init, start, morningDigest, healthWatch, datesWatch, urgentWatch, autoArchive, taskRunner, pricelistFallback, eodYardReport, buildYardReportText, nightlyLogDigest };