// Sample Yard Co trial: the yard app's API and dashboard only.
const fs = require('fs'), path = require('path');
for (const l of (fs.existsSync(path.join(__dirname, '.env')) ? fs.readFileSync(path.join(__dirname, '.env'), 'utf8') : '').split('\n')) {
    const m = l.match(/^([A-Z_]+)=(.*)$/); if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2];
}
const cfg = require('./config');
require('./trial-contacts')(cfg);   // truckers/suppliers in data/, not Supabase (must run before api.js loads the routes)
const { createApi } = require('./api');
createApi().listen(cfg.API_PORT, () => console.log('[TRIAL] Sample Yard Co yard app on :' + cfg.API_PORT));
