// ── helpers/payments.js — payments recorded against a load ─────────────────
//
// Per the owner 2026-08-28: a Pay button beside Edit/Delete opening a form with
// payment mode (Zelle / Wire / Cash / Cheque) and an amount; anything short of
// the load total is a PARTIAL payment with a pending balance, and the result
// has to show up on the invoice.
//
// A LEDGER, not a flag. "Partial, with a pending amount" only means anything
// if a load can be settled across several payments — pay half on collection
// and the rest on Friday — so this stores each payment as its own row and
// derives paid/pending by summing them. A single paid_amount field on the load
// would lose the history the moment a second payment arrived, and the history
// is the part anyone actually argues about later.
//
// ITS OWN STORE, and here that is about money rather than tidiness. Loads are
// re-saved WHOLESALE on every edit — editLoad in helpers/loads.js rebuilds the
// record from the fields it knows about — so a payments array hanging off the
// load would be one dropped field away from erasing a receipt. That exact
// class of bug has already happened in this repo once (pdf_link was silently
// discarded by editOutboundLoad, which is why patchOutboundLoad exists).
// Keeping payments outside the load write path means correcting a weight
// cannot touch what was paid.
//
// Nothing here deletes or edits a payment's amount in place: a wrong payment
// is deleted whole and re-entered, so there is no half-edited row.

const cfg = require('../config');
const { loadJson, mutateJson } = require('./json');

// Kept as constants and exported so the API, both clients, the PDF and the
// yard assistant read one list rather than five drifting copies of a dropdown.
//
// ── EVERY MODE THIS FILE WILL STORE ────────────────────────────────────────
// Zelle, Wire and Cheque are still here because payments ALREADY ON FILE carry
// them and helpers/banks.js's matcher keys on Zelle/Wire. Removing them from
// this list would leave those rows naming a mode the server no longer knows.
//
// It is NOT the list the yard's pay modal offers — see modesForKind below.
const PAYMENT_MODES = ['Cash', 'Bank transfer', 'Zelle', 'Wire', 'Cheque'];

// ── WHAT THE YARD MAY RECORD, FROM TODAY ───────────────────────────────────
// the owner, 2026-09-16, clarifying an earlier message: "whn i talked about
// receive payment-i was talking only about sample yard co yard .. in loads,there are two
// options na..create invoice and sale..in receive payment-i should have only
// cash and bank transfer".
//
// So a YARD load — a purchase she is paying for, or a sale she is being paid
// for — takes two modes and no others. Enforced here rather than only in the
// dropdown, because "the screen offers two" and "the yard records two" are
// different promises and she asked for the second one. The yard assistant
// records payments too (helpers/tools.js) and would otherwise keep happily
// filing a Zelle nobody can choose on screen.
//
// SAMPLE YARD CO METALS IS UNTOUCHED. Her message says Sample Yard Co Yard, twice. Bills,
// settlements and metals trucking keep the full list — narrowing those would
// be me deciding something she did not ask about, on the company whose books
// this app works hardest to keep separate.
//
// SAFE FOR WHAT IS ALREADY STORED. This file has no update path — only
// addPayment and deletePayment — so a yard payment recorded as Zelle last
// month is never re-validated and keeps reading as Zelle everywhere it
// appears. The narrowing applies to new entries only, which is the whole of
// what she asked for.
// ── WIDENED AGAIN, 2026-09-23 ──────────────────────────────────────────────
// the owner: "in receive payment,zelle,wire,cash etc should be there similar to
// loads" — then, asked which exactly: option one, "Remove just wire".
//
// So receive payment is Cash, Bank transfer, Zelle and Cheque. This REVERSES
// her 2026-09-16 narrowing quoted below. The old note is left standing word
// for word rather than rewritten: it records what she wanted in September and
// why the over-reach that followed it was mine, and editing it to agree with
// today would erase the only account of how that bug happened.
//
// WIRE IS DELIBERATELY ABSENT, and it is the one mode she named. A wire in
// and a Bank transfer in are the same movement by two names, and two names
// for one movement is two ways to answer "how did that money arrive" — the
// same reasoning that removed Bank transfer from a PURCHASE on 2026-09-17,
// pointing the other way.
//
// WHAT THIS DOES NOT TOUCH: 'Bank transfer' stays, so the "Paid to" question
// (PAID_VIA_BY_KIND below) still has a mode to fire on. Dropping it would
// have left that question unreachable and a <select> defaulting to a value
// not in its list — which is exactly how the 2026-09-17 breakage worked.
const YARD_LOAD_MODES = ['Cash', 'Bank transfer', 'Zelle', 'Cheque'];

// ── WHAT A PURCHASE MAY BE PAID BY ─────────────────────────────────────────
// the owner, 2026-09-17: "in load of invoice pay-remove bank transfer."
//
// So paying a supplier is Cash, Zelle, Wire or Cheque. Bank transfer was a
// second name for the same thing as Wire on this side, and two names for one
// movement is two ways to answer "how did that go out".
//
// PAYMENT_MODES itself is untouched, deliberately: every purchase already
// recorded as "Bank transfer" keeps reading as Bank transfer everywhere — the
// spend report, the bank matcher, the cards. What narrows is the list of
// modes a NEW purchase payment may choose from, not the vocabulary the file
// understands. Same shape as the receive-payment restriction of 2026-09-16.
const PURCHASE_MODES = ['Cash', 'Zelle', 'Wire', 'Cheque'];

// ── RECEIVE PAYMENT, NOT EVERY YARD PAYMENT ────────────────────────────────
// the owner, 2026-09-16: "whn i talked about receive payment-i was talking only
// about sample yard co yard ..in loads,there are two options na..create invoice and
// sale..in receive payment-i should have only cash and bank transfer".
//
// This set held 'purchase' as well, and that was my over-reach reading "yard"
// where she wrote "receive payment". RECEIVE PAYMENT IS A SALE — money coming
// in. Paying a supplier for a load is money going OUT, a different
// transaction, and she pays those by Zelle and Wire: the bank-account picker
// exists for exactly those two modes.
//
// What it cost, live, until 2026-09-17:
//   a supplier payment by Zelle, Wire or Cheque was REFUSED outright;
//   and the modal opens by selecting 'Zelle', which was no longer among the
//   options — a <select> set to a value it does not have goes to "", so a
//   dropdown she never touched posted an EMPTY mode and the save failed.
//
// Found by running the whole test suite rather than the dozen files I had
// been naming: tests/jarvis-profile.js had been CRASHING on this since the
// day it landed.
const YARD_LOAD_KINDS = new Set(['sale']);

// The modes a given load kind accepts. One function, so the validator, the
// bot tool and anything added later cannot disagree about the answer.
function modesForKind(loadKind) {
    const k = String(loadKind || 'purchase').trim() || 'purchase';
    if (YARD_LOAD_KINDS.has(k)) return YARD_LOAD_MODES.slice();   // a sale: receive payment
    if (k === 'purchase') return PURCHASE_MODES.slice();          // paying a supplier
    return PAYMENT_MODES.slice();                                 // Sample Yard Co Metals, truckers
}

// ── WHOSE MONEY PAID IT ────────────────────────────────────────────────────
// the owner, 2026-09-17: "in pay of create invoice-on selecting wire-it should
// ask me Payment via Sample Yard Co Yard/Sample Yard Co Metals", and on which modes: "Wire and
// Bank Transfer".
//
// The two companies pay for each other's things. Which one's account a
// transfer actually left is a fact the bank field does not carry — "Chase
// Bank" does not say whose Chase account.
// ── SAMPLE YARD CO HOLDINGS IS THE THIRD ONE (2026-09-24) ───────────────────────────
// the owner: "In loads pay,why wire ->Bofa ->Showing Sample Yard Co Yard or Sample Yard Co Metals?"
// and then "Bofa has only two accounts.Sample Yard Co Metals and Sample Yard Co Holdings".
//
// She is right, and it was a real defect rather than a wording one. BofA holds
// Sample Yard Co Metals and Sample Yard Co Holdings (helpers/pettyCash.js's BANK_OF has said so
// since 2026-09-21). The picker offered SAMPLE YARD CO YARD, which is not a BofA account
// at all, and did not offer SAMPLE YARD CO HOLDINGS, which is — so a wire out of
// BofA / Sample Yard Co Holdings could not be recorded correctly. It had to be filed
// against one of the other two or not at all.
const PAID_VIA = ['Sample Yard Co Yard', 'Sample Yard Co Metals', 'Sample Yard Co Holdings'];

// ── AND THE ANSWER DEPENDS ON THE BANK ─────────────────────────────────────
// Which entities can own money leaving a given bank. Derived from petty cash's
// own BANK_OF rather than restated here, so the two cannot drift: adding an
// account there changes this without an edit.
//
// CHASE IS SAMPLE YARD CO YARD'S — her answer, 2026-09-24, asked directly. So choosing
// Chase has exactly one possible owner and the screen need not ask at all.
//
// An unknown or blank bank falls back to ALL of them: this narrows a question,
// it never blocks a payment. A bank she typed under "Others" must not leave
// her unable to say whose money it was.
function paidViaOptionsFor(bank) {
    const b = String(bank == null ? '' : bank).trim();
    if (!b) return PAID_VIA.slice();
    if (/^chase/i.test(b)) return ['Sample Yard Co Yard'];
    let accounts = [];
    try {
        const petty = require('./pettyCash');
        accounts = (petty.SOURCES || []).filter((s) => petty.bankOf(s) === b);
    } catch (e) { accounts = []; }
    // Petty cash names its BofA buckets exactly as the paying entities are
    // named, which is why this maps across at all. Anything it does not
    // recognise is not narrowed.
    const owners = accounts.filter((a) => PAID_VIA.includes(a));
    return owners.length ? owners : PAID_VIA.slice();
}

// ── WHICH COMBINATIONS ASK ─────────────────────────────────────────────────
// Two directions, two questions, and they are NOT the same question:
//
//   A PURCHASE pays a supplier. "Payment via" — whose money went out.
//   the owner, 2026-09-17: "on selecting wire-it should ask me Payment via Sample
//   Yard/Sample Yard Co Metals". She then removed Bank transfer from a purchase
//   entirely ("in load of invoice pay-remove bank transfer"), so Wire is the
//   only transfer left there and the only mode that asks.
//
//   A SALE receives money. "Paid to" — which company it landed in. the owner,
//   2026-09-17: "For receive payment also,add paid to Sample Yard Co Yard,Sample Yard Co Metals",
//   and, asked which modes: "Bank transfer only".
//
//   CASH NEVER ASKS, on either side. Cash from a yard sale goes into Sample
//   Yard's petty cash box (her rule of 2026-09-02), so it is always the
//   yard's — asking would let her file a contradiction with her own ledger.
const PAID_VIA_BY_KIND = {
    purchase: new Set(['Wire']),
    sale: new Set(['Bank transfer']),
};

function paidViaRequired(loadKind, mode) {
    const allowed = PAID_VIA_BY_KIND[String(loadKind || '').trim()];
    return !!allowed && allowed.has(String(mode || '').trim());
}

// The two words the screen shows. A purchase sends money OUT and a sale takes
// it IN, and one label for both would be wrong on one of them.
function paidViaLabel(loadKind) {
    return String(loadKind || '').trim() === 'sale' ? 'Paid to' : 'Payment via';
}

// Returns '' when this combination does not ask. Throws when it does and she
// has not answered — her choice, over recording it as "Not recorded": a wire
// with no company against it cannot be filed.
function resolvePaidVia(loadKind, mode, value, bank) {
    const given = PAID_VIA.find((v) => v.toLowerCase() === String(value == null ? '' : value).trim().toLowerCase());
    if (!paidViaRequired(loadKind, mode)) {
        // Not asked for — but if a caller sent one anyway it is kept rather
        // than dropped, because a stated fact about the money should not
        // vanish because the form did not have a box for it.
        return given || '';
    }
    // ── NARROWED BY THE BANK (2026-09-24) ──────────────────────────────────
    // A wire out of BofA can only be Sample Yard Co Metals or Sample Yard Co Holdings; one out of
    // Chase can only be Sample Yard Co Yard. `bank` is optional so every existing caller
    // keeps working unchanged — without it the old, wider list applies, which
    // is what the voice path passed for a day before this argument existed.
    // CLAUDE.md: a new required field is a promise every caller can keep, and
    // this one cannot make that promise, so it is not required.
    const allowed = paidViaOptionsFor(bank);

    // NOT AUTO-FILLED, even when only one company banks there. A first cut
    // resolved a Chase wire to Sample Yard Co Yard on its own, which quietly relaxed
    // her rule that "a wire with no company against it cannot be filed" —
    // a refusal she asked for on 2026-09-17 and did not ask me to remove.
    // The SCREEN skips the question when there is only one answer and sends
    // that answer; the server still insists on being told.

    if (!given) {
        const where = String(loadKind || '').trim() === 'sale' ? 'a yard sale' : 'a yard purchase';
        throw new Error(`a ${mode} on ${where} needs "${paidViaLabel(loadKind)}": ${allowed.join(' or ')}`);
    }
    // ── A STATED ANSWER IS ACCEPTED, EVEN AGAINST THE MAPPING ──────────────
    // The first version of this THREW when the named company had no account
    // at the named bank. Existing payments pair Sample Yard Co Metals with Chase, so
    // that would have refused combinations already on file — and, worse, it
    // could refuse a real payment at six in the evening because the mapping
    // here is narrower than her actual banking.
    //
    // The defect she reported was that the form OFFERED Sample Yard Co Yard against
    // BofA and never offered Sample Yard Co Holdings. Narrowing what is offered fixes
    // that. Refusing what she explicitly states is a different and riskier
    // change, and not one she asked for.
    return given;
}

// ── WHOSE BOOKS A ROW BELONGS TO ─────────────────────────────────────────
// the owner, 2026-09-10: "Always remember Sample Yard Co Yard is different and Sample Yard Co Metals
// is different", and, asked directly, that Sample Yard Co Metals cash is separate from
// the yard's petty cash reserve.
//
// Petty cash is an SAMPLE YARD CO YARD ledger. A payment carrying one of these kinds is
// Sample Yard Co Metals and never touches it, whatever its mode. A SET rather than a
// second `!== 'bill'` test, because the third Metals kind arrived within the
// day and the fourth will not announce itself either.
const SAMPLE_METALS_KINDS = new Set(['bill', 'sale_cost', 'metals_trucking']);

// Money is compared to the cent. Floating point makes 4010 * 2.2 come out as
// 8822.000000000001, so a load paid exactly to the penny would otherwise
// report a pending balance of -0.000000000001 and never read as settled.
const CENT = 0.005;

const round2 = (n) => (typeof n === 'number' && isFinite(n) ? Math.round(n * 100) / 100 : null);
const num0 = (v) => { const n = Number(v); return isFinite(n) ? n : 0; };
const toNum = (v) => {
    const n = typeof v === 'number' ? v : parseFloat(v);
    return isFinite(n) ? n : null;
};

const listPayments = () => {
    const raw = loadJson(cfg.PAYMENTS_FILE, []);
    return Array.isArray(raw) ? raw : [];
};

// Advances are excluded by the load_id test itself — they carry none until
// they are applied, at which point the application is its own row with a real
// load_id. So an unapplied advance can never make a load look part-paid.
const paymentsForLoad = (loadId) => listPayments()
    .filter((p) => p.load_id === loadId)
    .sort((a, b) => String(a.paid_on || a.created_at || '').localeCompare(String(b.paid_on || b.created_at || '')));

function newPaymentId() {
    return `PAY_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

// ── Advances were REMOVED 2026-08-29, per the owner: "remove that advance
// concept." ────────────────────────────────────────────────────────────────
//
// What used to be here: a payment scoped to a seller instead of a load, held
// as credit and applied to loads later. Gone — no addAdvance, no applyAdvance,
// no /api/advances, no UI.
//
// LEGACY ROWS ARE STILL SAFE. Any is_advance record already written to
// payments.json carries load_id: null, so paymentsForLoad's load_id filter
// simply never matches it. It cannot corrupt a balance and cannot make a load
// look part-paid — it just sits in the file, inert and invisible. Rows created
// by APPLYING an advance are ordinary payment rows with a real load_id and
// keep working exactly as before; they are indistinguishable from any other
// payment apart from an applied_from field nothing reads any more.
//
// If an unapplied advance ever needs to be recovered, it is in payments.json
// with is_advance: true — the money was never lost, only the feature.

// ── SUPPLIER PREPAYMENT, SAMPLE YARD CO YARD (2026-10-01) ──────────────────────────
// ── ANY SELLER, AND IT STAYS SAMPLE YARD CO YARD'S OWN (2026-10-02) ────────────────
// the owner, after seeing the checkbox read "Hold as prepayment — credit Sample
// Metals Inc, not this load" on a yard load she had bought from Sample Yard Co Metals:
//
//   "Prepayment option should be separte for edge ayrd. it is not restricted
//    just for sample yard co metals. any seller"
//
// Two things, and both are rules rather than observations:
//
//   1. ANY SELLER. The company name in that label is simply whoever sold
//      that load — Sample Yard Co Metals happened to be the seller. There is no
//      company gate here and there must not be one: the only conditions are
//      that the load is a PURCHASE (money going out) and that a seller is
//      named. Pinned by tests/supplier-prepayment.js section F, because a
//      well-meant "only for known suppliers" filter is exactly the kind of
//      narrowing that looks like tidying.
//
//   2. IT IS NOT THE SAMPLE YARD CO METALS "ADVANCE". I offered to make the two words
//      match across the apps and she said no. They are different companies
//      (see CLAUDE.md rule 5) with genuinely different stores —
//      payments.json here, bill_payments.json for Sample Yard Co Metals bills — and
//      the shared vocabulary would be the first step towards someone
//      deciding the shared store is tidier too. Her word for Sample Yard Co Yard is
//      "prepayment"; Sample Yard Co Metals bills say "advance". Leave them apart.
//
// Recorded here, attributed, so the next person to notice the duplication
// reaches this note before re-proposing the merge. I proposed it once; it is
// her call and the call was no.

// the owner: "Add a supplier prepayment option in loads", then "no for edge
// yard" / "advance concept is for sample yard co yard right now", then the brief that
// decides the shape: "streamline the process".
//
// ── THIS IS THE SECOND ATTEMPT, AND THE FIRST ONE'S NOTES MATTER ─────────
// An advance feature shipped on 2026-08-29 and she removed it the SAME DAY
// ("remove that advance concept."). Reading that commit, what it shipped was
// THREE surfaces: a credit strip above the deck, a separate Record-advance
// form, and an apply panel inside the Pay modal. "Streamline the process" is
// the same instruction again, said plainly. So the concept is hers and kept;
// the ceremony is what goes.
//
// One place to put money in — the Pay form, with no load chosen. One place it
// comes out — an inline line in the Pay form when that seller is holding
// credit. No strip, no second form, nothing new to learn. Odoo settles a
// supplier prepayment the same way: the payment sits as an outstanding credit
// on the supplier and the bill offers it inline at the moment of paying,
// rather than on a screen of its own.
//
// ── WHAT THE FIRST VERSION GOT WRONG ABOUT CASH ──────────────────────────
// The old addAdvance wrote its own row with its own mutateJson, bypassing
// addPayment — so a CASH advance never came out of the petty cash box. But
// deleteByLoad's reversal loop matches `mode === 'Cash' &&
// !SAMPLE_METALS_KINDS.has(p.load_kind)`, and an advance carried no load_kind
// at all, so `has(undefined)` is false and the row WAS matched. Cash left the
// drawer unrecorded on the way in, and a reversal was attempted on the way
// out for an entry that had never been created.
//
// She pays suppliers in cash, so that is her box wrong in both directions.
// Fixed two ways here: the withdrawal goes through the SAME
// pettyCash.withdrawForPayment call an ordinary payment uses, and load_kind
// is set EXPLICITLY to 'purchase' rather than left undefined — a guard that
// works because a field is missing is a guard that breaks when someone adds
// the field.
//
// ── AND WHAT IT GOT RIGHT, KEPT VERBATIM ────────────────────────────────
//   · no load_id, so an unapplied prepayment can never make a load look
//     part-paid;
//   · never auto-applied — her choice, and the right one: money landing on a
//     load with nobody deciding cannot be unpicked later;
//   · remaining is DERIVED from what has been applied, never stored;
//   · over-applying is refused, not silently capped.
async function addPrepayment(input = {}) {
    const seller = String(input.seller || '').trim();
    if (!seller) throw new Error('a prepayment needs a supplier');
    const amount = round2(toNum(input.amount));
    if (amount == null) throw new Error('a payment amount is required');
    if (amount <= 0) throw new Error('a payment amount must be greater than zero');
    // Explicit, not inferred. A yard prepayment is money going OUT to a
    // supplier; stamping the kind makes every downstream allowlist test
    // (SAMPLE_METALS_KINDS, the spend report, the petty-cash recompute) read the
    // same answer as it would for an ordinary yard purchase payment.
    const loadKind = 'purchase';

    // ── ANY FORM OF PAYMENT, WITH EVERYTHING THAT FORM REQUIRES ──────────
    // the owner, 2026-10-01: "not only cash prepayment,advance can be in any
    // form of payment na". She is right, and my first cut was wrong in a way
    // that is worth spelling out: it ACCEPTED any mode and then dropped the
    // fields the non-cash modes depend on. A Wire prepayment saved with no
    // bank and no paid_via looks like it worked and is missing the two facts
    // that make a wire traceable.
    //
    // Three fixes, all of them "use what addPayment uses":
    //
    //   1. modesForKind('purchase'), not PAYMENT_MODES. She removed Bank
    //      transfer from paying a supplier on 2026-09-17 ("in load of
    //      invoice pay-remove bank transfer"); validating against the full
    //      list would have quietly let it back in on this one path.
    //   2. banks.resolveForMode, so a Zelle/Wire/Cheque prepayment records
    //      which account it left from and a bank on a CASH one is refused.
    //   3. resolvePaidVia, so Wire asks "Payment via Sample Yard Co Yard / Sample
    //      Metals" here exactly as it does everywhere else.
    //
    // (3) is the one CLAUDE.md warns about three times: a requirement that
    // lives in addPayment and is missed by a path that does not share it.
    // This path IS the new caller, and skipping the question would put a
    // prepayment in the books with no company against it.
    const allowedModes = modesForKind(loadKind);
    const mode = allowedModes.find((m) => m.toLowerCase() === String(input.mode || '').trim().toLowerCase());
    if (!mode) throw new Error(`payment mode must be one of: ${allowedModes.join(', ')}`);

    const banks = require('./banks');
    const bank = await banks.resolveForMode(mode, input.bank, { required: input.require_bank === true });
    const paidVia = resolvePaidVia(loadKind, mode, input.paid_via, bank);

    const touchesPettyCash = mode === 'Cash' && !SAMPLE_METALS_KINDS.has(loadKind);

    let cashEntry = null;
    let cashTaken = null;
    if (touchesPettyCash) {
        const petty = require('./pettyCash');
        const res = await petty.withdrawForPayment({
            amount,
            // No load to name, and withdrawForPayment stores `loadId || null`
            // so that is accepted. It does NOT take a seller — I tried
            // passing one and it is silently dropped, which is worse than not
            // passing it, so the supplier is stamped onto the entry after the
            // fact below rather than pretended at here.
            loadId: null,
            paymentId: null,
            date: input.paid_on,
            createdBy: input.created_by || null,
            allowPartial: input.allow_partial === true,
            cashSource: input.cash_source,
            allowBorrow: input.allow_borrow === true,
        });
        cashEntry = res.entry;
        cashTaken = res.taken;
    }

    const record = {
        id: `ADV_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        is_advance: true,
        // Kept as is_advance, NOT renamed to is_prepayment. There are legacy
        // rows on her VM carrying this flag and four code paths that filter on
        // it; a new name would make today's prepayments invisible to every one
        // of them and leave the old money orphaned under a dead field.
        load_id: null,
        load_kind: loadKind,
        seller,
        mode,
        amount,
        // Carried for the same reason an ordinary payment carries them: a
        // wire with no bank cannot be matched against a statement, and a
        // wire with no paid_via is money leaving an account with no company
        // named against it. Null for Cash, where neither is a true fact.
        bank,
        paid_via: paidVia,
        paid_on: input.paid_on || new Date().toISOString().slice(0, 10),
        reference: String(input.reference || '').trim() || null,
        note: String(input.note || '').trim() || null,
        cash_source: input.cash_source || null,
        petty_cash_entry_id: cashEntry ? cashEntry.id : null,
        cash_taken: cashTaken,
        created_at: new Date().toISOString(),
        created_by: input.created_by || null,
        client_request_id: require('./oncePerSave').normTicket(input.client_request_id),
    };

    let already = null;
    await mutateJson(cfg.PAYMENTS_FILE, [], (all) => {
        const list = Array.isArray(all) ? all : [];
        // Same one-save-one-record guard the load create paths use. A
        // prepayment is money out of the drawer; a double-tap that records it
        // twice is $3,000 of cash the book says left and did not.
        already = require('./oncePerSave').findSpent(list, record.client_request_id);
        if (already) return list;
        list.push(record);
        return list;
    }, { strict: true });
    return already || record;
}

const listPrepayments = (seller) => listPayments().filter((p) => p.is_advance
    && (!seller || String(p.seller || '').toLowerCase() === String(seller).toLowerCase()));

// How much of a prepayment is still unspent. DERIVED from what has been
// applied out of it and never stored, for the same reason load balances are
// derived: a stored remaining and its applications drift, and the drift is
// invisible until she is short.
function prepaymentRemaining(prepaymentId) {
    const all = listPayments();
    const adv = all.find((p) => p.id === prepaymentId && p.is_advance);
    if (!adv) return 0;
    const used = all
        .filter((p) => p.applied_from === prepaymentId)
        .reduce((a, p) => a + (toNum(p.amount) || 0), 0);
    return round2(num0(adv.amount) - used);
}

// Unapplied credit a supplier is holding, and which prepayments it came from.
function prepaymentCredit(seller) {
    const rows = listPrepayments(seller).map((a) => ({
        id: a.id, mode: a.mode, paid_on: a.paid_on, reference: a.reference,
        amount: round2(a.amount), remaining: prepaymentRemaining(a.id),
    })).filter((a) => a.remaining > CENT);
    return {
        seller: seller || null,
        available: round2(rows.reduce((a, r) => a + r.remaining, 0)) || 0,
        prepayments: rows,
    };
}

// Puts prepaid money against a specific load. Creates an ORDINARY payment row
// — it counts toward the balance, prints on the ticket and needs no special
// case anywhere downstream — carrying applied_from so the prepayment's
// remaining drops by the same amount.
//
// No petty cash movement here, deliberately: the cash left the drawer when the
// prepayment was recorded. Taking it again now would debit the box twice for
// one handful of notes.
async function applyPrepayment(input = {}) {
    const loadId = String(input.load_id || '').trim();
    if (!loadId) throw new Error('load_id is required');
    const prepaymentId = String(input.prepayment_id || '').trim();
    const remaining = prepaymentRemaining(prepaymentId);
    if (!remaining || remaining <= CENT) throw new Error('that prepayment has nothing left on it');
    const amount = round2(toNum(input.amount));
    if (amount == null || amount <= 0) throw new Error('a payment amount is required');
    // Refused rather than silently capped. Quietly applying less than asked
    // would leave her believing a load was settled when it was not.
    if (amount - remaining > CENT) throw new Error(`that prepayment only has ${remaining.toFixed(2)} left`);

    const adv = listPayments().find((p) => p.id === prepaymentId);
    const record = {
        id: newPaymentId(),
        load_id: loadId,
        load_kind: input.load_kind === 'sale' ? 'sale' : 'purchase',
        mode: (adv && adv.mode) || 'Cash',
        // Inherited from the prepayment, not re-asked. The money already
        // moved, by that mode, from that bank, on that company's account —
        // this row records where it landed, so asking again would invite a
        // second, different answer about one transfer that already happened.
        bank: (adv && adv.bank) || null,
        paid_via: (adv && adv.paid_via) || null,
        amount,
        paid_on: input.paid_on || new Date().toISOString().slice(0, 10),
        reference: (adv && adv.reference) || null,
        note: 'Applied from prepayment',
        applied_from: prepaymentId,
        // ── NOT A FRESH CASH MOVEMENT ────────────────────────────────────
        // petty_cash_entry_id stays null AND cash_taken stays null, so
        // deleteByLoad's reversal loop has no entry key to return and
        // reverseForPayment is never called for this row. Without this the
        // loop would match it (mode Cash, kind purchase) and try to put money
        // back that this row never took.
        petty_cash_entry_id: null,
        cash_taken: null,
        from_prepayment: true,
        created_at: new Date().toISOString(),
        created_by: input.created_by || null,
    };
    await mutateJson(cfg.PAYMENTS_FILE, [], (all) => {
        const list = Array.isArray(all) ? all : [];
        list.push(record);
        return list;
    }, { strict: true });
    return record;
}

// ── SETTLING A LOAD AGAINST A SALE, AND BACK ──────────────────────────────
// the owner, 2026-10-17: "when we pay load/sales-there should be a option to
// adjust against sale incase of load and against load in case of sale", and
// on what it means, in her words: "his seller is also a buyer, he owes you
// $3,000 on a sale, you're paying him $5,000 for a load, so you hand over
// $2,000 and the $3,000 is settled ... This happend".
//
// So it is a REAL contra, not a bookkeeping tidy-up. Two documents close and
// only the difference actually leaves the drawer.
//
// ── WHY THIS MOVES NO CASH, AND WHY THAT IS CORRECT ──────────────────────
// helpers/booksBuild.js builds `yard-purchase` and `yard-sale` straight off
// the LOAD records — this payments store never reaches it. So her P&L
// already carries the $5,000 purchase and the $3,000 sale; the settlement is
// a working-capital event, not an income one, and must not touch either.
// What it must not touch EITHER is cash: only the $2,000 genuinely moved,
// and that is recorded by the ordinary payment she makes alongside this.
//
// Both rows therefore carry petty_cash_entry_id: null and cash_taken: null,
// exactly as applyPrepayment does and for the same reason — deleteByLoad's
// reversal loop keys off those, so without them it would try to put back
// money that was never taken.
//
// ── TWO ROWS, ONE WRITE ──────────────────────────────────────────────────
// A settlement that recorded one side and not the other leaves her with a
// load that looks paid and a sale that still looks owed, or the reverse, and
// no way to tell which figure is the lie. So both rows go in a SINGLE
// mutateJson, and both carry the same settlement_id so the pair can always be
// found — and removed — together.
//
// NOT folded into addPayment. That function is reached by the pay modals on
// two clients AND by helpers/tools.js's record_payment, which is how she pays
// a supplier by TALKING to Jarvis. A new required field there has broken that
// caller twice (CLAUDE.md §1). This is a separate entry point; nothing
// existing changes, and a caller that knows nothing about settlements keeps
// working exactly as it did.
function settlementPartyOf(load, kind) {
    if (!load) return '';
    return String((kind === 'sale' ? load.buyer : load.seller) || '').trim();
}

// What a load still owes, through payableOf — NOT `amount`. A purchase with
// trucking deducted or a claim adjusted in owes less than its items came to,
// and settling against the gross would hand over money that is not due
// (helpers/loads.js's payableOf is the single reader for this, by decision).
//
// ── AND receivableOf ON A SALE, SINCE 2026-11-04 ─────────────────────────
// This line read `load.amount` for a sale, which was right while a sale
// could not carry trucking. It can now, and the owner's rule is "You haul,
// buyer is charged" — so a $500 sale hauled for $200 is $700 owed. Left as
// `amount`, recording the buyer's $700 would have read as a $200
// OVERPAYMENT, and a buyer who paid only the metal would have shown as
// settled in full with the freight still outstanding.
//
// Both sides now go through their own single reader, which is the whole
// reason those readers exist. A sale with no trucking — all of them until
// she enters the first — gets `amount` back from receivableOf, so this is
// the line it has always been.
function outstandingOn(loadId, kind) {
    const { getLoad, payableOf } = require('./loads');
    const { getOutboundLoad, receivableOf } = require('./outboundLoads');
    const load = kind === 'sale' ? getOutboundLoad(loadId) : getLoad(loadId);
    if (!load) return { load: null, owed: null };
    const total = kind === 'sale' ? receivableOf(load) : payableOf(load);
    const summary = paymentSummary(loadId, total);
    return { load, owed: summary.total == null ? null : round2(summary.total - summary.paid) };
}

// ── WHAT CAN THIS BE SETTLED AGAINST ─────────────────────────────────────
// The candidate list and the GUARD must be the same rule, so it lives here
// beside settleAgainst rather than in the route or the screen. If they drift,
// she gets offered a row and then told it is refused — which reads as a bug
// in the feature rather than a rule she has not met.
//
// Same reasoning as the payment modes travelling with /api/payments: the
// dropdown is built from the server's answer, so it cannot offer something
// the server would reject.
function settleOptions(loadId, loadKind) {
    const id = String(loadId || '').trim();
    const kind = String(loadKind || 'purchase').trim() === 'sale' ? 'sale' : 'purchase';
    const againstKind = kind === 'sale' ? 'purchase' : 'sale';

    const here = outstandingOn(id, kind);
    if (!here.load) return { ok: false, error: `no ${kind} found for ${id}`, options: [] };

    const party = settlementPartyOf(here.load, kind);
    if (!party) {
        return { ok: false, error: 'this document has no named party, so there is nobody to net against', options: [] };
    }

    const { normalizeName } = require('./canonicalName');
    const want = normalizeName(party);

    const all = againstKind === 'sale'
        ? require('./outboundLoads').loadOutboundLoads()
        : require('./loads').loadLoads();

    const options = [];
    for (const l of (all || [])) {
        if (!l || String(l.id) === id) continue;
        const name = settlementPartyOf(l, againstKind);
        if (!name || normalizeName(name) !== want) continue;
        const o = outstandingOn(String(l.id), againstKind);
        // Only what is actually still open. A fully settled document in the
        // list is a row she would pick and be refused on.
        if (o.owed == null || o.owed <= CENT) continue;
        options.push({
            id: String(l.id),
            kind: againstKind,
            date: l.date || null,
            party: name,
            outstanding: o.owed,
        });
    }
    // Newest first, the order every other list in this app uses.
    options.sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));

    return {
        ok: true,
        party,
        kind,
        against_kind: againstKind,
        outstanding: here.owed,
        // The most she could possibly settle is the smaller of the two sides,
        // and the screen needs that figure to cap its own box.
        max: options.length ? Math.min(here.owed == null ? 0 : here.owed, Math.max(...options.map((o) => o.outstanding))) : 0,
        options,
    };
}

async function settleAgainst(input = {}) {
    const loadId = String(input.load_id || '').trim();
    const againstId = String(input.against_id || '').trim();
    if (!loadId) throw new Error('load_id is required');
    if (!againstId) throw new Error('against_id is required — which document is this being settled against?');
    if (loadId === againstId) throw new Error('a load cannot be settled against itself');

    // The side being PAID decides everything else. Paying a purchase settles
    // against a sale; receiving on a sale settles against a purchase.
    const kind = String(input.load_kind || 'purchase').trim() === 'sale' ? 'sale' : 'purchase';
    const againstKind = kind === 'sale' ? 'purchase' : 'sale';

    const here = outstandingOn(loadId, kind);
    const there = outstandingOn(againstId, againstKind);
    if (!here.load) throw new Error(`no ${kind} found for ${loadId}`);
    if (!there.load) throw new Error(`no ${againstKind} found for ${againstId}`);

    // ── THE SAME PERSON, OR IT IS NOT A SETTLEMENT ───────────────────────
    // Netting Gomez's sale against Vega's load is not an adjustment, it is
    // two errors that happen to cancel. Compared through canonicalName so
    // "GOMEZ SCRAP" and "Gomez Scrap" are one man, the same rule the per-
    // seller and per-buyer groupings already use.
    const { normalizeName } = require('./canonicalName');
    const a = settlementPartyOf(here.load, kind);
    const b = settlementPartyOf(there.load, againstKind);
    if (!a || !b) throw new Error('both sides need a named party before they can be settled against each other');
    if (normalizeName(a) !== normalizeName(b)) {
        throw new Error(`these are different parties — "${a}" and "${b}". A settlement only nets what one person both owes and is owed.`);
    }

    const amount = round2(toNum(input.amount));
    if (amount == null || amount <= 0) throw new Error('a settlement amount is required');
    // Refused, never silently capped — the same rule applyPrepayment follows.
    // Quietly settling less than asked leaves her believing both documents
    // are closed when one is not.
    if (here.owed == null) throw new Error('this side has no total to settle against');
    if (there.owed == null) throw new Error('the other side has no total to settle against');
    if (amount - here.owed > CENT) {
        throw new Error(`this ${kind} only has ${here.owed.toFixed(2)} outstanding`);
    }
    if (amount - there.owed > CENT) {
        throw new Error(`that ${againstKind} only has ${there.owed.toFixed(2)} outstanding`);
    }

    const settlementId = newPaymentId();
    const paidOn = input.paid_on || new Date().toISOString().slice(0, 10);
    const now = new Date().toISOString();
    const row = (lid, lkind, otherId, otherKind) => ({
        id: newPaymentId(),
        load_id: lid,
        load_kind: lkind,
        // A settlement is its own mode. It is deliberately NOT 'Cash': the
        // spend report, the bank matcher and the petty-cash recompute all
        // read mode, and a row calling itself Cash that never touched the
        // drawer would show up as money she cannot find.
        mode: 'Settlement',
        bank: null,
        paid_via: null,
        amount,
        paid_on: paidOn,
        reference: null,
        note: `Settled against ${otherKind} ${otherId}`,
        settlement_id: settlementId,
        settled_against: otherId,
        settled_against_kind: otherKind,
        is_settlement: true,
        // Not a fresh cash movement — see the note above.
        petty_cash_entry_id: null,
        cash_taken: null,
        created_at: now,
        created_by: input.created_by || null,
    });

    const both = [row(loadId, kind, againstId, againstKind), row(againstId, againstKind, loadId, kind)];
    await mutateJson(cfg.PAYMENTS_FILE, [], (all) => {
        const list = Array.isArray(all) ? all : [];
        // ONE push of BOTH, inside one mutator, so there is no window in
        // which one side is settled and the other is not.
        list.push(...both);
        return list;
    }, { strict: true });

    return { settlement_id: settlementId, amount, party: a, rows: both };
}

// Removing a settlement removes BOTH sides. Anything else leaves one document
// claiming money that the other no longer says was settled.
async function deleteSettlement(settlementId) {
    const id = String(settlementId || '').trim();
    if (!id) throw new Error('a settlement id is required');
    let removed = 0;
    await mutateJson(cfg.PAYMENTS_FILE, [], (all) => {
        const list = Array.isArray(all) ? all : [];
        const kept = list.filter((p) => {
            const hit = p && p.settlement_id === id;
            if (hit) removed += 1;
            return !hit;
        });
        return kept;
    }, { strict: true });
    if (!removed) throw new Error('no such settlement');
    return { removed };
}

async function addPayment(input = {}) {
    const loadId = String(input.load_id || '').trim();
    if (!loadId) throw new Error('load_id is required');

    // ── ONE SAVE, ONE PAYMENT (2026-11-09) ───────────────────────────────
    // Found by tests/sample-yard-scenarios.js: two identical POSTs carrying the
    // SAME client_request_id both succeeded, and what she owed the seller
    // moved by $200 for two $100 payments.
    //
    // The guard already existed in this very file — addPrepayment has used
    // oncePerSave since prepayments landed. It was never extended here, to
    // the ordinary pay-the-seller path, while BOTH clients were already
    // sending the ticket (dashboard/app/13-loads-render.js:1307,
    // mobile-app/www/app/09-loads-deck.js:1343). They behaved as though they
    // were covered. They were not.
    //
    // ── OWNER WAS RIGHT THAT THE SCREENS STOP A DOUBLE TAP ──────────────
    // She pushed back on the first report of this: "when i pay once covering
    // the inv amount pay woud become invisible na". Checked, and true — both
    // pay modals disable the button on submit and the action disappears once
    // a load is settled. So a double tap cannot do this.
    //
    // What remains is the retry after a lost reply: Jarvis records the
    // payment, the reply never reaches the phone, the catch re-enables the
    // button, and she taps a payment that already went through. Narrower
    // than first reported, and still money leaving twice on a yard signal.
    //
    // ── BEFORE ANYTHING MOVES ────────────────────────────────────────────
    // Deliberately the first thing after the id check, ahead of the petty
    // cash withdrawal below. Checking after the cash was taken would mean a
    // repeat withdraws real money and then has to put it back, and that
    // reversal is one more thing that can fail.
    //
    // OPT-IN BY TICKET. A caller that sends no client_request_id behaves
    // exactly as it did — which is every other caller today
    // (helpers/salesSettlements.js, helpers/metalsTrucking.js,
    // helpers/billPayments.js, helpers/tools.js). Two genuinely separate
    // $100 cash payments to the same seller on the same day are still two
    // payments; only a repeat of the SAME save is refused.
    {
        const once = require('./oncePerSave');
        const ticket = once.normTicket(input.client_request_id);
        if (ticket) {
            const already = once.findSpent(listPayments(), ticket);
            // The ORIGINAL record is handed back, not an error. The client
            // asked for this payment to exist; it does. Telling it "duplicate"
            // would leave the screen showing a failure for money that is
            // correctly recorded, which is the same confusion the other way
            // round.
            if (already) return already;
        }
    }
    const amount = round2(toNum(input.amount));
    // Rejected rather than stored as null: a payment with no amount cannot be
    // summed, so it would sit on the ledger looking like a receipt while
    // contributing nothing to the balance — worse than not being there.
    if (amount == null) throw new Error('a payment amount is required');
    if (amount <= 0) throw new Error('a payment amount must be greater than zero');
    // ── WHOSE BOOKS, DECIDED BEFORE THE MODE IS CHECKED ──────────────────
    // load_kind used to be resolved further down, beside the petty-cash
    // branch. It moved up here because the ALLOWED MODES now depend on it.
    const loadKind = (() => {
        const k = String(input.load_kind || '').trim();
        if (!k || k === 'purchase') return 'purchase';
        if (['sale', 'trucker', 'bill', 'sale_cost', 'metals_trucking'].includes(k)) return k;
        throw new Error(`unknown load_kind "${k}" — add it here and to helpers/spendReport.js, do not let it default`);
    })();

    const allowed = modesForKind(loadKind);
    const mode = allowed.find((m) => m.toLowerCase() === String(input.mode || '').trim().toLowerCase());
    // Names the list THAT APPLIES, not every mode this file knows. Choosing
    // Zelle on a yard load and being told "must be one of: Cash, Bank
    // transfer, Zelle, Wire, Cheque" reads as a bug in the software rather
    // than an answer.
    if (!mode) throw new Error(`payment mode must be one of: ${allowed.join(', ')}`);

    // ── WHICH ACCOUNT IT LEFT ────────────────────────────────────────────
    // the owner, 2026-09-09: "I want to create an option for zelle,wire -->
    // options like BofA, Chase Bank, Others."
    //
    // BEFORE the petty-cash reservation below, deliberately. A bad bank must
    // fail while nothing has moved: reserving cash and then throwing would
    // leave the box short with no payment beside it, which is the exact
    // failure the reservation ordering further down was written to avoid.
    // Cash never has a bank anyway, so this costs that path nothing.
    //
    // A DISALLOWED value always throws — a bank on a cash payment is a false
    // statement, wherever it came from. A MISSING one depends on the caller:
    // require_bank is set by the API route — i.e. by the two pay FORMS, where
    // she has a dropdown in front of her. Callers that record a payment from a
    // spoken sentence leave it off; see helpers/banks.js for why the two are
    // deliberately not the same.
    const banks = require('./banks');
    const bank = await banks.resolveForMode(mode, input.bank, { required: input.require_bank === true });

    // ── WHOSE MONEY PAID THE SUPPLIER ────────────────────────────────────
    // the owner, 2026-09-17: "in pay of create invoice-on selecting wire-it
    // should ask me Payment via Sample Yard Co Yard/Sample Yard Co Metals. We need to keep track
    // of this also in report", and, asked which modes: "Wire and Bank
    // Transfer".
    //
    // A yard purchase is Sample Yard Co Yard's material, but the transfer that pays for
    // it does not always leave Sample Yard Co Yard's account. Which company actually
    // paid is a fact about the money, and until now it was nowhere — the bank
    // says WHICH ACCOUNT, not whose company it belongs to.
    //
    // ── SCOPED EXACTLY TO WHAT SHE ASKED ─────────────────────────────────
    // "in pay of create invoice" — a yard PURCHASE. Not a sale (Bank transfer
    // is one of only two modes a sale accepts; requiring this there would make
    // receiving money harder, which she did not ask for), not the Sample Yard Co Metals
    // kinds, not trucker bills. Cash and Cheque never ask: they are not
    // transfers between accounts.
    //
    // Asked which modes, she answered "Wire and Bank Transfer" — NOT Zelle,
    // though Zelle shares the bank picker. Her list, not the tidy one.
    //
    // REQUIRED, her choice over "save it as Not recorded": a wire with no
    // company against it cannot be filed. So the report has no gap in it by
    // construction, and old payments written before today simply carry
    // nothing — see helpers/spendReport.js, which buckets those visibly
    // rather than pretending they are Sample Yard Co Yard.
    const paidVia = resolvePaidVia(loadKind, mode, input.paid_via, bank);

    // ── CASH COMES OUT OF THE PETTY CASH BOX ──────────────────────────────
    // Per the owner 2026-09-02: "If i click pay in load and select cash, the
    // invoice amount should be adjusted against this."
    //
    // THE CASH IS RESERVED BEFORE THE PAYMENT IS WRITTEN, and the reservation
    // is reversed if that write fails. Two files cannot be updated atomically
    // here, so the question is which way round to fail, and the two are not
    // equally bad:
    //
    //   cash out, payment missing  -> the box shows less than it holds. Visible
    //                                 on the tab as a withdrawal with no
    //                                 payment beside it, and reversible.
    //   payment in, cash not taken -> the balance is overstated, so the NEXT
    //                                 payment is allowed to overdraw a box that
    //                                 is already empty. Nothing on screen says
    //                                 so, and the error compounds.
    //
    // So: reserve first. The reversal below closes the window in the ordinary
    // case; the ordering is what protects the case where the process dies
    // between the two writes.
    //
    // The cap is NOT applied silently. withdrawForPayment refuses when there is
    // not enough and returns `available`; the client shows that and asks; only
    // then does it come back with allow_partial. Her words: "make it as partial
    // payment and notify user" — the notification is the point, so it is a
    // precondition rather than an afterthought.
    // ── WHOSE CASH BOX, AND WHETHER THERE IS ONE ─────────────────────────
    // the owner, 2026-09-10, asked whether an Sample Yard Co Metals cash payment should
    // draw down the yard's Petty cash reserve: "No — Sample Yard Co Metals cash is
    // separate."
    //
    // So petty cash stays an SAMPLE YARD CO YARD ledger. A payment carrying
    // load_kind 'bill' is an Sample Yard Co Metals supplier payment and never touches
    // it, whatever its mode. Keyed on the kind rather than on a
    // skip_petty_cash flag on purpose: a flag is one spread of req.body away
    // from letting a client silently pay a yard load in cash without the box
    // moving, and this rule is about which company's books a row belongs to,
    // which load_kind already answers.
    //
    // It is resolved ABOVE, next to the mode check, because since 2026-09-16
    // the allowed MODES depend on it too — a yard load takes Cash or Bank
    // transfer, Sample Yard Co Metals still takes the full list. One resolution feeding
    // both, so the mode check and the cash branch cannot disagree about which
    // company this row belongs to.
    // ── WHICH WAY THE CASH IS MOVING ─────────────────────────────────────
    // the owner, 2026-09-16: "in sales-receive payment,mode should be cash/
    // account transfer.if its cash-it should get added to petty cash."
    //
    // It was already moving the box — in ONE direction. This branch called
    // withdrawForPayment for ANY cash payment on a yard load, and a yard load
    // can be a SALE. So money arriving was recorded as money leaving: take
    // $5,000 cash for a load of aluminium and the box went DOWN five thousand.
    //
    // It rarely even failed quietly. withdrawForPayment refuses when the box
    // holds less than the amount, so a $5,000 cash sale against a $300 box
    // was rejected outright with "Only 300.00 in petty cash" — a sale she
    // could not record at all, for a reason that made no sense from where she
    // was standing. That is almost certainly what prompted the request.
    //
    // A 'sale' is the yard SELLING metal, so its cash comes IN. Everything
    // else on a yard load — a purchase, a trucker bill — is cash going OUT.
    // Decided from load_kind, the same field that already decides whose books
    // the row belongs to, rather than from a flag a client could send.
    const touchesPettyCash = mode === 'Cash' && !SAMPLE_METALS_KINDS.has(loadKind);
    const cashComesIn = loadKind === 'sale';

    let cashEntry = null;
    let cashTaken = null;
    if (touchesPettyCash && cashComesIn) {
        const petty = require('./pettyCash');
        // No cap and no refusal — see depositForPayment. Cash in hand cannot
        // overdraw a box, and a balance test here would be the original bug
        // wearing a new hat.
        const res = await petty.depositForPayment({
            amount,
            loadId,
            paymentId: null,                 // stamped after the payment id exists
            date: input.paid_on,
            createdBy: input.created_by || null,
            // A customer's cash came from no bank. Passed through so she CAN
            // say otherwise (banking it straight away), but left unset it
            // lands in Unassigned, which is the truth.
            cashSource: input.cash_source,
        });
        cashEntry = res.entry;
        cashTaken = res.added;
    } else if (touchesPettyCash) {
        const petty = require('./pettyCash');
        const res = await petty.withdrawForPayment({
            amount,
            loadId,
            paymentId: null,                 // stamped after the payment id exists
            date: input.paid_on,
            createdBy: input.created_by || null,
            allowPartial: input.allow_partial === true,
            // ── WHICH POT OF CASH, AND WHETHER SHE SAID YES TO BORROWING ──
            // the owner, 2026-09-21. `cash_source` is NOT `bank`: banks.js
            // refuses a bank on a cash payment because "paid cash from Chase"
            // is not a true sentence about where the money left. This says
            // which trip to the bank the notes in the drawer came from, which
            // is a different fact and is why it has its own field.
            //
            // Blank is allowed all the way down and means Unassigned — the
            // APK and the voice path both predate this, and a payment she
            // cannot record is worse than one filed under unbanked cash.
            cashSource: input.cash_source,
            // Same shape as allow_partial above: refused first with the
            // figures, sent again only after she has seen them and agreed.
            allowBorrow: input.allow_borrow === true,
        });
        cashEntry = res.entry;
        cashTaken = res.taken;
    }

    const record = {
        id: newPaymentId(),
        load_id: loadId,
        // Which store the payable lives in. Ids are unique per store but not
        // across them, so without this a purchase and a sale could collide.
        //
        // 'trucker' added 2026-09-03 for the haulage bills. It has to be an
        // ALLOWLIST rather than the old `=== 'sale' ? 'sale' : 'purchase'`,
        // which silently coerced everything else to 'purchase': a trucker
        // payment would have been stored as a purchase, and then the spend
        // report — which splits on this field — would have labelled it
        // "Load TRK_001" and added it to what the yard paid for metal. The
        // grand total would still have been right, which is what makes that
        // class of bug last: nothing looks wrong until someone asks what a
        // month's haulage cost.
        //
        // Anything unrecognised still falls back to 'purchase', so records
        // written before this field existed keep their meaning.
        // ── 'bill' ADDED 2026-09-10, AND THE SILENT DOWNGRADE NAMED ──────
        // This is an allowlist, which is right — but anything not on it was
        // quietly relabelled 'purchase', and 'purchase' means a yard load.
        // helpers/billPayments.js passed 'bill' and got 'purchase' back, so a
        // supplier's container payment was filed as money spent at the yard.
        // Silent, and the grand total stayed correct the whole time.
        //
        // Still an allowlist — a typo must not invent a category — but an
        // unknown kind now says so instead of pretending to be a load.
        load_kind: loadKind,
        mode,
        // Null on Cash and Cheque, and null on every payment written before
        // 2026-09-09. Nothing migrates them: an old Zelle whose account nobody
        // recorded is UNKNOWN, and stamping a guess on it would be inventing
        // a fact about where money went. The report groups those as
        // "not recorded" rather than hiding them.
        bank,
        // Which company's money it was — '' on everything that does not ask,
        // and on every payment written before 2026-09-17. Nothing migrates
        // those: a wire whose paying company nobody recorded is UNKNOWN, and
        // stamping "Sample Yard Co Yard" on it would be inventing a fact about money.
        // The Spend report buckets them visibly, the same way it does a bank
        // nobody recorded.
        paid_via: paidVia,
        // What was ACTUALLY paid. On a capped cash payment this is less than
        // was asked for, and the rest stays outstanding — which is exactly
        // what "make it a partial payment" means. Stored as the real figure so
        // paymentSummary, the card, the ticket and the invoice all agree
        // without any of them knowing about petty cash.
        amount: cashTaken != null ? cashTaken : amount,
        // Set only on a cash payment: the ledger row this drew on. Lets the
        // Petty cash tab link a withdrawal back to the load it paid, and lets
        // deletePayment find what to refund without scanning.
        petty_cash_entry_id: cashEntry ? cashEntry.id : null,
        // Local day, not UTC. toISOString() rolls over at UTC midnight, which is
        // early evening at the yard — an evening payment was being stamped with
        // tomorrow's date. See todayLocal() in helpers/time.js.
        paid_on: input.paid_on || require('./time').todayLocal(),
        reference: String(input.reference || '').trim() || null,
        note: String(input.note || '').trim() || null,
        created_at: new Date().toISOString(),
        created_by: input.created_by || null,
        // The ticket is STORED, or the guard at the top of this function has
        // nothing to find on the second attempt. Null when the caller sent
        // none, which is every path except the two pay screens — findSpent
        // ignores a null, so those rows behave exactly as they always have.
        client_request_id: require('./oncePerSave').normTicket(input.client_request_id),
    };
    try {
    // ── STRICT: THIS WRITE EITHER HAPPENS OR SAYS SO ─────────────────────
    // mutateJson is forgiving by default — on failure it logs, returns
    // loadJson() and NEVER RUNS THE MUTATOR, handing back plausible-looking
    // data with no way to tell the write never landed. Its own note says the
    // paths where a lost write means lost DATA should opt in; this is one of
    // them, and 131 of 146 writes in this codebase had not.
    //
    // The catch covers mutator errors too, not just lock contention, so the
    // forgiving path also swallows bugs in the function above.
    //
    // No retry loop on top: LOCK_OPTS already backs off eight times (40ms to
    // 400ms), so a failure here is genuinely exceptional and a second layer
    // would be defensive code with nothing to defend against.
        await mutateJson(cfg.PAYMENTS_FILE, [], (all) => {
            const list = Array.isArray(all) ? all : [];
            list.push(record);
            return list;
        }, { strict: true });
    } catch (err) {
        // The payment did not land. Put the cash back, or the box would show
        // money gone for a payment that does not exist — see the ordering note
        // above. The reversal is stamped against the withdrawal's own id.
        if (cashEntry) {
            try {
                await require('./pettyCash').reverseForPayment(cashEntry.id, { createdBy: input.created_by || null });
            } catch (e) {
                // Both writes failed. Say so loudly and in full: this is the
                // one state a person has to reconcile by hand, and a silent
                // catch here is how it would be discovered weeks later.
                console.error(`[PAYMENTS] CASH RESERVED BUT NOT REFUNDED — petty cash entry ${cashEntry.id} took ${cashTaken} for load ${loadId} and the payment write failed. Refund also failed:`, e.message);
            }
        }
        throw err;
    }

    // Stamp the withdrawal with the payment it belongs to, now that the id
    // exists. Best-effort and deliberately not fatal: the money has already
    // moved correctly and the entry still carries load_id, so a failure here
    // costs a cross-reference, not a cent. Refunds fall back to the entry id.
    if (cashEntry) {
        try {
            await require('./pettyCash').stampPaymentId(cashEntry.id, record.id);
        } catch (e) {
            console.warn(`[PAYMENTS] could not link petty cash entry ${cashEntry.id} to payment ${record.id}:`, e.message);
        }
    }
    return record;
}

// Deleting a CASH payment puts the money back in the box. Per the owner's model
// the two are the same event seen from two sides, so undoing one has to undo
// the other — otherwise deleting a mistaken $400 cash payment would leave the
// box $400 short forever, with nothing on screen explaining why.
//
// Refunded as a REVERSAL row rather than by deleting the withdrawal: a ledger
// you can remove rows from is one nobody can reconcile. The pair stays
// visible — money out on the 2nd, money back on the 3rd.
//
// Order is deliberate and the mirror of addPayment. There the cash moved
// first, because an overstated balance is the dangerous direction. Here the
// payment is removed first for the same reason: if the refund then fails, the
// box reads LOW, which is safe and visible, rather than high.
//
// The refund is idempotent by design (see reverseForPayment), so a retry after
// a partial failure cannot pay the money back twice.
async function deletePayment(id) {
    let removed = false;
    const doomed = listPayments().find((p) => p && p.id === id) || null;
    await mutateJson(cfg.PAYMENTS_FILE, [], (all) => {
        const list = Array.isArray(all) ? all : [];
        const next = list.filter((p) => p.id !== id);
        removed = next.length !== list.length;
        return next;
    }, { strict: true });
    // An Sample Yard Co Metals cash payment never touched this box (see
    // touchesPettyCash above), so reversing one would credit the yard with
    // cash it never handled — inventing money, which is worse than losing it.
    //
    // Works in BOTH directions without a branch: reverseForPayment negates
    // whatever it finds, so deleting a cash PURCHASE payment puts money back
    // in the box and deleting a cash SALE receipt takes it back out.
    //
    // ── AND A ROW APPLIED FROM A PREPAYMENT MOVED NO NOTES ───────────────
    // Same reason as the twin guard in deleteByLoad: the cash left the drawer
    // when the prepayment was recorded, not when it was applied to this load.
    // Reversing here would credit the box with money it already gave out, and
    // the prepayment's remaining balance — derived from applications — goes
    // back up on its own when this row is removed, which is the correct and
    // complete undo.
    if (removed && doomed && !doomed.from_prepayment
        && doomed.mode === 'Cash' && !SAMPLE_METALS_KINDS.has(doomed.load_kind)) {
        // By the withdrawal's own id when we have it, else by payment id —
        // reverseForPayment accepts either, and the entry id is the one that
        // survives a payment written before the link was stamped.
        const key = doomed.petty_cash_entry_id || doomed.id;
        try {
            await require('./pettyCash').reverseForPayment(key, { createdBy: null });
        } catch (e) {
            console.error(`[PAYMENTS] deleted cash payment ${id} but could NOT return ${doomed.amount} to petty cash (${key}):`, e.message);
        }
    }
    return removed;
}

// Removes every payment for a load. Called when a load is deleted, so a
// deleted load cannot leave orphan receipts summing against nothing.
// Cascade from deleting a LOAD. Same refund rule — a load being deleted does
// not mean the cash was really spent, and the box has to come back to what it
// was. Note this is reachable today only for a load with no payments (the Pay
// and Delete buttons are mutually exclusive on the card since 2026-09-01), but
// the route still exists and the yard assistant can reach it, so the refund
// belongs here rather than in the button.
async function deletePaymentsForLoad(loadId) {
    let removed = 0;
    const doomed = listPayments().filter((p) => p && p.load_id === loadId);
    await mutateJson(cfg.PAYMENTS_FILE, [], (all) => {
        const list = Array.isArray(all) ? all : [];
        const next = list.filter((p) => p.load_id !== loadId);
        removed = list.length - next.length;
        return next;
    }, { strict: true });
    for (const p of doomed) {
        if (p.mode !== 'Cash' || SAMPLE_METALS_KINDS.has(p.load_kind)) continue;   // see deletePayment
        // ── A ROW THAT TOOK NO CASH GIVES NONE BACK ──────────────────────
        // Added with supplier prepayments, 2026-10-01. Applying a prepayment
        // to a load writes an ordinary Cash/purchase payment row, which the
        // two tests above match — but that row moved no notes: the cash left
        // the drawer when the PREPAYMENT was recorded. Without this, deleting
        // such a load tries to reverse a petty cash entry that was never
        // created, and `petty_cash_entry_id || p.id` makes it fall back to
        // the payment id, so it is not even a clean miss.
        //
        // HOW MUCH THIS ACTUALLY PROTECTS, measured rather than assumed: a
        // mutation deleting this line SURVIVED the suite, and the reason is
        // that pettyCash.reverseForPayment already bails on `if
        // (!taken.length) return list` — an unknown key matches no entry and
        // moves no money. So this is the second layer, not the one holding
        // the money up, and an earlier version of this comment claiming
        // cash could be "credited back" was overstating it. It stays because
        // it is free and because the day someone stamps a
        // petty_cash_entry_id onto applied rows, this is what stops a double
        // refund. The mutation that DOES bite is on reverseForPayment's own
        // guard, and that is the one in the catalogue.
        //
        // Keyed on from_prepayment rather than on a null entry id, because a
        // null entry id is ALSO what every payment written before
        // petty_cash_entry_id existed carries, and those legacy rows do still
        // want the id fallback. The flag marks the NEW shape, per CLAUDE.md.
        if (p.from_prepayment) continue;
        const key = p.petty_cash_entry_id || p.id;
        try {
            await require('./pettyCash').reverseForPayment(key, { createdBy: null });
        } catch (e) {
            console.error(`[PAYMENTS] load ${loadId} deleted but could NOT return ${p.amount} cash to petty cash (${key}):`, e.message);
        }
    }
    return removed;
}

// The figure every screen and the invoice quote. Derived, never stored, so it
// cannot drift from the payments it is supposed to summarise — and so that
// editing a load's price recalculates the balance instead of leaving a stale
// "paid in full" behind.
function paymentSummary(loadId, loadAmount) {
    const rows = paymentsForLoad(loadId);
    const paid = round2(rows.reduce((a, p) => a + (toNum(p.amount) || 0), 0)) || 0;
    const total = round2(toNum(loadAmount));

    // A load with no priced items has no total to settle against. Report what
    // was paid and say the balance is unknown rather than inventing one —
    // claiming "fully paid" because the total happens to be null would be a
    // lie with money attached.
    if (total == null) {
        return { paid, total: null, pending: null, status: paid > 0 ? 'paid_amount_unknown' : 'unpaid', payments: rows };
    }

    const pending = round2(total - paid);
    let status;
    if (paid <= CENT) status = 'unpaid';
    else if (pending > CENT) status = 'partial';
    else if (pending < -CENT) status = 'overpaid';
    else status = 'paid';
    return {
        paid,
        total,
        // Never negative on an overpayment — the overage is reported through
        // `status` and `over`, so a UI showing "pending" cannot show a
        // negative balance as though something were still owed.
        pending: pending > CENT ? pending : 0,
        over: pending < -CENT ? round2(-pending) : 0,
        status,
        payments: rows,
    };
}

module.exports = {
    settleAgainst, deleteSettlement, outstandingOn, settleOptions,
    PAYMENT_MODES, YARD_LOAD_MODES, PURCHASE_MODES, modesForKind,
    PAID_VIA, PAID_VIA_BY_KIND, paidViaRequired, paidViaLabel, resolvePaidVia, paidViaOptionsFor,
    // ── EXPORTED 2026-10-06, for helpers/entities.js ─────────────────────
    // Purely additive: nothing here changes, and no existing caller sees a
    // difference. helpers/entities.js needs to know whose books a payments
    // row belongs to, and this Set is the only place that is decided. It
    // REQUIRES this rather than keeping its own copy, so that adding a
    // fourth Sample Yard Co Metals kind above changes the company statements too —
    // a second hand-written list would not, and would be wrong silently.
    SAMPLE_METALS_KINDS,
    listPayments, paymentsForLoad, addPayment,
    deletePayment, deletePaymentsForLoad, paymentSummary,
    // Supplier prepayments, Sample Yard Co Yard — see addPrepayment's header for why
    // this is the second attempt and what the first one got wrong.
    addPrepayment, listPrepayments, prepaymentRemaining, prepaymentCredit, applyPrepayment,
};
