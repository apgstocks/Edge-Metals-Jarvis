// ── helpers/loadCompany.js — which of her three companies a load or sale is ──
// the owner, 2026-11-17: "in Loads, i want the buyer as option as Sample Yard Co Trading /
// Sample Yard Co Metals / Sample Yard Co Holdings. so as seller." Purchases: she picks the BUYER.
// Sales: she picks the SELLER. Then, asked how far it goes: "Money moving
// between companies is for another day. For now, loads/sales only."
//
// So this is a LABEL on the record. It is saved, shown, and used on the PO.
// It does NOT move the record between books, stock, payments or QuickBooks —
// helpers/entities.js still places both stores by store, exactly as before.
// Nothing here may be read as a ledger decision; if she later wants the books
// to follow it, that is its own change (entities.of, payments, booksBuild,
// stock) and it needs her yes.
const COMPANIES = ['Sample Yard Co Trading', 'Sample Yard Co Metals', 'Sample Yard Co Holdings'];
const DEFAULT_COMPANY = 'Sample Yard Co Trading';
const ALIAS = {
    'sample yard co trading': 'Sample Yard Co Trading', 'sample yard co trading inc': 'Sample Yard Co Trading', 'sample yard co yard': 'Sample Yard Co Trading',
    'sample yard co metals': 'Sample Yard Co Metals', 'sample yard co metals inc': 'Sample Yard Co Metals', 'sample yard co metals': 'Sample Yard Co Metals',
    'sample yard co holdings': 'Sample Yard Co Holdings', 'sample yard co holdings': 'Sample Yard Co Holdings',
};
const keyOf = (s) => String(s || '').toLowerCase().replace(/[.,]/g, ' ').replace(/\s+/g, ' ').trim();
// The canonical name for one of the three, or null for anything else.
function canon(s) { return ALIAS[keyOf(s)] || null; }

// What a PURCHASE's `buyer` becomes. A picked company wins. When the caller
// never mentions the picker (the APK already on her phone, the voice path) an
// edit must not quietly turn an Sample Yard Co Metals purchase back into Sample Yard Co Trading,
// so a known non-default company already on file is kept. A caller that DOES
// say 'Sample Yard Co Trading' changes it back, because it said so.
function chooseBuyer(entry, priorBuyer) {
    const picked = canon(entry.buyer_company);
    if (picked) return picked;
    const prior = canon(priorBuyer);
    if (entry.buyer_company === undefined && prior && prior !== DEFAULT_COMPANY) return prior;
    return entry.buyer || null;
}

module.exports = { COMPANIES, DEFAULT_COMPANY, canon, chooseBuyer };
