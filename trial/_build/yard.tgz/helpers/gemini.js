// ── helpers/gemini.js — Gemini JSON-only wrapper ─────────────────────────────
// One job: send prompt, get back parsed JSON or null. Never free text upstream.
// Model name comes from settings.json (hot-swappable) with env fallback.

const { GoogleGenerativeAI } = require('@google/generative-ai');
const cfg = require('../config');
const fs = require('fs');
const visionOcr = require('./visionOcr');
let sharp = null;
try { sharp = require('sharp'); } catch (err) {
    // Was a silent catch with no logging — every sharp-dependent function
    // below (locateRedDisplayByPixels, shrinkForLocate, cropToDisplay,
    // normalizeOrientation, trimDeadDigitZones) degrades to an immediate
    // no-op if sharp didn't load, and NONE of them logged that fact. That
    // means a broken/missing sharp install would look EXACTLY like every
    // symptom chased across this whole conversation: pixel locate always
    // "finding nothing confident" (returns null before ever reaching its own
    // diagnostic log), crop always taking ~0-1ms regardless of the box
    // (immediate bail before touching any pixels), and the EXIF-orientation
    // fix having zero effect (same immediate bail) -- all silently, with
    // nothing distinguishing "sharp is broken" from "this photo is
    // genuinely hard." This is now a loud, unmissable boot-time error
    // instead, specifically so that possibility can be ruled in or out in
    // seconds instead of another round of photo-by-photo guessing.
    console.error('[GEMINI] *** sharp failed to load - EVERY locate/crop function below will silently no-op:', err.message, '***');
}

let genAI = null;
function getClient() {
    if (!genAI) {
        if (!cfg.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY missing');
        genAI = new GoogleGenerativeAI(cfg.GEMINI_API_KEY);
        // the owner, 2026-10-12: every call is counted (tokens, job, cost) by
        // wrapping the client ONCE here. helpers/aiUsage.js returns the model's
        // answer untouched and can never be the reason a call fails; if the
        // wrapper itself cannot load, the plain client is used as before.
        try { genAI = require('./aiUsage').instrumentClient(genAI); } catch (e) { console.error('[AI-USAGE] not recording:', e.message); }
    }
    return genAI;
}

function getModelName() {
    try {
        const { loadSettings } = require('./json');
        // ── TRIMMED, AND BLANK MEANS "NOT SET" (2026-10-03) ──────────────
        // Was `loadSettings().gemini_model || cfg.GEMINI_MODEL`. A stored
        // value of '   ' is truthy, so it was returned as the model name and
        // every Gemini call in the process — classification, extraction, the
        // claim watcher, the inbox scan — would be made against a model
        // called three spaces and fail. Nothing writes that today; a text
        // field cleared with the space bar would, and the failure would look
        // like "the AI stopped working" with nothing pointing at a setting.
        //
        // This can only change the behaviour of a configuration that is
        // already wholly broken: a blank now falls through to the config
        // exactly as a missing key does.
        const v = loadSettings().gemini_model;
        const pinned = (typeof v === 'string') ? v.trim() : '';
        return pinned || cfg.GEMINI_MODEL;
    } catch { return cfg.GEMINI_MODEL; }
}

// Strip ```json fences and grab the outermost JSON object
function extractJson(text) {
    if (!text) return null;
    const cleaned = text.replace(/```json/gi, '').replace(/```/g, '').trim();
    const start = cleaned.indexOf('{');
    const end   = cleaned.lastIndexOf('}');
    if (start === -1 || end === -1 || end <= start) return null;
    try { return JSON.parse(cleaned.slice(start, end + 1)); } catch { return null; }
}

// Decide the final cutoff_date IN CODE, not by trusting the model to have
// resolved "which of several cutoffs" correctly on its own — a real carrier
// booking confirmation still came back with the doc cutoff despite an
// explicit prompt instruction telling it not to. port_cutoff_date and
// doc_cutoff_date are extracted as separate, label-scoped fields specifically
// so this can be a plain, deterministic, testable function instead of prose
// the model may or may not follow. Exported so it can be unit-tested without
// needing a live Gemini call.
function resolveCutoffDate(fields) {
    if (!fields) return null;
    return fields.port_cutoff_date || fields.cutoff_date || null;
}

// `schema` is an OPTIONAL zod schema. When given, a response that parses as
// JSON but has the wrong SHAPE is treated exactly like unparseable output —
// it burns a retry instead of being handed back to the caller.
//
// Added 2026-08-22 with the owner's approval. Until now every caller checked
// Gemini's output by hand, inconsistently: some verified a field existed,
// some assumed, and a response missing a field or carrying a string where a
// number belonged flowed straight into business logic. A retry is nearly
// free here and usually succeeds, since malformed output is typically a
// one-off generation glitch rather than a persistent failure.
//
// Deliberately OPTIONAL so this can spread gradually. Every existing caller
// passes no schema and behaves precisely as before — this cannot regress
// any current flow, only harden the calls that opt in.
// ── WHY THE LAST FAILURE IS RECORDED ─────────────────────────────────────
// the owner, 2026-09-07: "When i say send mail, its not doin that."
//
// Traced with tests/e2e-voice.js to workflow/actions.js:
//     const draft = await callGeminiJSON(prompt);
//     if (!draft) await _send(chatId, "Couldn't draft that email — try
//                                      rephrasing what it should say.");
//
// callGeminiJSON returns null for EVERY failure — no API key, quota
// exhausted, network down, three retries of unparseable JSON — and all of
// them came out as "try rephrasing what it should say". That blames her
// wording for an outage on this side, and the advice is useless: she would
// rephrase, and rephrase, and it would never once work.
//
// A caller cannot tell those apart from a bare null, so the reason is kept
// here for the caller to READ. Deliberately a module-level last-value rather
// than a changed return type: every existing caller keeps working unchanged,
// and the ones that want to explain themselves can.
let lastFailure = null;
function lastGeminiFailure() { return lastFailure; }

// ── A CALLER MAY ASK FOR A DIFFERENT MODEL (2026-10-02) ───────────────────
// the owner: "Use the best model in google for QB and Claims."
//
// Every one of the 45 callers shared one global model. That is right for most
// of them — a yes/no classification does not need a frontier model — and
// wrong for the two where being wrong costs money: reading a weight and a
// UNIT off a claim mail, and answering a question about what a party owes.
//
// OPTIONAL AND LAST, so all 45 existing calls are untouched: no fourth
// argument means getModelName(), exactly as before.
async function callGeminiJSON(prompt, retries = 2, schema = null, opts = {}) {
    lastFailure = null;
    const wanted = (opts && typeof opts.model === 'string' && opts.model.trim())
        ? opts.model.trim() : null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model  = getClient().getGenerativeModel({
                model: wanted || getModelName(),
                generationConfig: { temperature: 0.1, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent(prompt);
            const parsed = extractJson(result.response.text());
            if (parsed && schema) {
                const check = schema.safeParse(parsed);
                if (check.success) return check.data;
                // Log the shape complaint, not the payload — responses can
                // carry customer names, addresses and prices.
                const why = (check.error?.issues || []).map(i => `${(i.path || []).join('.') || '(root)'}: ${i.message}`).join('; ');
                console.warn(`[GEMINI] Response failed schema (attempt ${attempt + 1}): ${why}`);
                if (attempt < retries) { await new Promise(r => setTimeout(r, 400 * (attempt + 1))); continue; }
                return null;
            }
            if (parsed) return parsed;
            console.warn(`[GEMINI] Unparseable response (attempt ${attempt + 1})`);
        } catch (err) {
            console.error(`[GEMINI] Call failed (attempt ${attempt + 1}):`, err.message);
            lastFailure = /\b(429|quota|rate)\b/i.test(err.message) ? 'quota'
                : /\b(401|403|API key|credential)\b/i.test(err.message) ? 'auth'
                : 'unreachable';
            // Back off on rate limits
            if (attempt < retries) await new Promise(r => setTimeout(r, 800 * (attempt + 1)));
        }
    }
    // Never threw, never parsed: the model answered with something unusable.
    if (!lastFailure) lastFailure = 'unusable';
    return null;
}
async function extractBookingFieldsFromText(emailBodyText, retries = 2) {
    if (!emailBodyText || !emailBodyText.trim()) return null;
    const prompt = `You are a freight operations expert. Extract booking fields from this email body (a carrier booking confirmation or update). Return ONLY raw JSON — no markdown, no prose.

Schema (every field can be null if not present):
{
  "booking_number": null, "carrier": null, "port_of_loading": null, "port_of_discharge": null,
  "cutoff_date": null, "port_cutoff_date": null, "doc_cutoff_date": null,
  "erd_date": null, "etd": null, "eta": null, "vessel_voyage": null,
  "container_size": null, "container_number": null, "shipper": null, "consignee": null, "buyer": null
}

etd = Estimated Time of Departure, eta = Estimated Time of Arrival — these are
two DIFFERENT dates, do not confuse them or copy one into the other; leave
either null if the email doesn't actually state it.

Cutoff dates — carriers often list SEVERAL under one heading (e.g. a table
with rows like "Port Open", "Port", "Rail", "Warehouse", "Doc", "VGM"). Fill
these two SEPARATELY, by label, and do not guess:
- port_cutoff_date: the date next to a label containing "Port" (Port, Port
  Cutoff, CY Cutoff, Terminal Cutoff, Gate Cutoff) — the deadline the
  container must physically be at the terminal. If the document only has ONE
  cutoff and doesn't break it out by label at all, put that single value here.
- doc_cutoff_date: the date next to a label containing "Doc" (Doc, Document
  Cutoff, SI Cutoff, VGM Cutoff) — a paperwork deadline, usually earlier than
  port_cutoff_date. Leave null if the document doesn't separately call this out.
- cutoff_date: leave this at your best single guess too, as a fallback — but
  port_cutoff_date/doc_cutoff_date are what actually get used, so get THOSE
  right even if you're unsure about this one.

erd_date (Earliest Return Date — the earliest date the container can be
delivered/received at the terminal): carriers label this many different
ways — match by MEANING, not by the literal text "ERD": "ERD", "Earliest
Return Date", "Earliest Receiving Date", "Port 1st Receiving Date", "1st
Receiving Date", "First Receiving Date", "Port Receiving Date", "Earliest
Delivery Date", "Empty Pickup Date", "Earliest Empty Pickup", "Container
Availability Date", "Cargo Receiving Date". If a receiving window/range is
shown, use the EARLIEST (opening) date, never the cutoff/closing date.

Convert all dates to MM/DD/YYYY. Port fields must be city names only. Return the JSON object and nothing else.

Email body:
"""
${emailBodyText.slice(0, 6000)}
"""`;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model  = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent(prompt);
            const fields = extractJson(result.response.text());
            if (fields) {
                fields.cutoff_date = resolveCutoffDate(fields);
                return fields;
            }
            console.warn(`[GEMINI] Body extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            console.error(`[GEMINI] Body extraction failed (attempt ${attempt + 1}):`, err.message);
            if (attempt < retries) await new Promise(r => setTimeout(r, 800 * (attempt + 1)));
        }
    }
    return null;
}

// ── Multimodal: dedicated document classification (separate from extraction) ──
// A narrow, single-job call: "is this a booking confirmation, yes or no."
// Deliberately separate from extractPdfFields, where is_booking_confirmation
// is just one field among 13 others — the same failure class as the port/doc
// cutoff bug: a judgment buried inside a big compound schema doesn't get the
// model's full attention and isn't reliable enough on its own. Used as a
// SECOND, INDEPENDENT opinion before trusting extractPdfFields's own flag for
// anything as consequential as auto-creating a new booking record. Real
// report: invoices that merely mention a booking/container number were
// getting is_booking_confirmation:true from the bundled extraction call and
// silently creating phantom bookings.
async function classifyDocument(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');

    const prompt = `You are a freight operations expert. Look at this PDF and classify ONLY what kind of document it is — do not extract any fields. Return ONLY raw JSON, no markdown, no prose.

{
  "is_booking_confirmation": false, // true ONLY if this document itself IS a carrier booking confirmation or shipping instruction establishing a specific shipment booking — the kind of document a carrier (Maersk, MSC, carrier, HMM, ONE, etc.) issues to confirm a container booking, typically titled "BOOKING CONFIRMATION" or similar, showing vessel/voyage, port of loading/discharge, and cutoff dates.
  "is_invoice_or_other": false,     // true if this is an invoice, rate quote, bill, receipt, container release notice, arrival notice, demurrage/detention notice, customs document, or any other freight-adjacent document that is NOT itself a booking confirmation — even if it mentions a booking number, container number, vessel, or words like "booking"/"cutoff" somewhere in it. An invoice that references a booking number is still an invoice, not a booking confirmation.
  "document_type": null            // your best short label, e.g. "booking confirmation", "invoice", "rate quote", "arrival notice", "customs form"
}

Judge by what the document actually IS and what its title/purpose is — not by whether booking-shaped keywords or numbers appear somewhere in it. Return the JSON object and nothing else.`;

    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
            ]);
            const parsed = extractJson(result.response.text());
            if (parsed) return parsed;
            console.warn(`[GEMINI] Classification returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Classification failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1000 * (attempt + 1)));
                continue;
            }
            // Classification is a safety CHECK, not the primary extraction — a
            // hard failure here shouldn't crash the whole pipeline. Caller
            // treats null as "couldn't confirm" and fails safe (skip, don't create).
            if (attempt >= retries) return null;
        }
    }
    return null;
}

// ── Multimodal: extract booking fields from a PDF ─────────────────────────────
// Sends the PDF bytes directly to Gemini. Used by the Bookings tab.
// Fields extracted match the shape used by POST /api/bookings.
// Retries on transient failures (503 overload, network hiccups) — same pattern
// as callGeminiJSON so behavior is consistent across all Gemini paths.
async function extractPdfFields(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');

    const prompt = `You are a freight operations expert. Extract booking fields from this freight document (carrier confirmation, booking confirmation, or shipping instructions). Return ONLY raw JSON — no markdown, no prose.

    Schema (every field can be null if not present):
    {
      "is_booking_confirmation": false, // true ONLY if this document itself IS a carrier booking confirmation or shipping instruction establishing a specific shipment booking. false for invoices, rate quotes, container release notices, arrival notices, demurrage/detention notices, or any other freight document — even ones that mention a booking number in passing, or use words like "booking"/"cutoff" somewhere in the text. Judge by what the document actually IS, not by whether booking-shaped text appears in it.
      "booking_number": null,   // e.g. "BK-2602" or "HMMU6269419" — leave null if is_booking_confirmation is false, even if some reference number is visible
  "carrier": null,          // e.g. "MSC", "Maersk", "COSCO"
  "port_of_loading": null,  // city only, e.g. "Houston"
  "port_of_discharge": null,// city only, e.g. "Busan"
  "cutoff_date": null,      // MM/DD/YYYY — your best single guess, kept as a fallback only. port_cutoff_date/doc_cutoff_date below are what actually get used — get those right even if unsure about this one.
  "port_cutoff_date": null, // MM/DD/YYYY — the date next to a label CONTAINING "Port" (e.g. "Port", "Port Cutoff", "CY Cutoff", "Terminal Cutoff", "Gate Cutoff") — when the container must physically be at the terminal. Many carrier documents show a CUT-OFF DATE table with several rows: "Port Open", "Port", "Rail", "Warehouse", "Doc", "VGM" — use ONLY the "Port" row's value, never "Port Open", "Doc", or "VGM". If the document has just ONE cutoff with no such table, put that single value here instead.
  "doc_cutoff_date": null,  // MM/DD/YYYY — the date next to a label CONTAINING "Doc" (e.g. "Doc", "Document Cutoff", "SI Cutoff", "VGM Cutoff") — a paperwork deadline, usually earlier than port_cutoff_date. Leave null if the document doesn't separately call this out. Never copy this value into port_cutoff_date.
  "erd_date": null,         // MM/DD/YYYY — Earliest Return Date: the earliest date the container can be delivered/received at the terminal. Carriers label this MANY different ways — match by MEANING, not by the literal text "ERD": "ERD", "Earliest Return Date", "Earliest Receiving Date", "Port 1st Receiving Date", "1st Receiving Date", "First Receiving Date", "Port Receiving Date", "Earliest Delivery Date", "Empty Pickup Date", "Earliest Empty Pickup", "Container Availability Date", "Cargo Receiving Date". If a table shows a receiving window/range, use the EARLIEST (opening) date, never the cutoff/closing date.
  "etd": null,              // MM/DD/YYYY — Estimated Time of Departure
  "eta": null,              // MM/DD/YYYY — Estimated Time of Arrival (different date than etd — don't conflate)
  "vessel_voyage": null,    // e.g. "MSC AURORA 226E"
  "container_size": null,   // format "40HC" (single) or "40HC X 3" (three containers of 40HC). Multiple containers common in metals bookings.
  "container_number": null, // e.g. "TCLU8841207". If multiple, use first only; others assigned later per-container.
  "shipper": null,
  "consignee": null,
  "buyer": null             // often same as consignee
}

Convert all dates to MM/DD/YYYY. If the document uses DD/MM/YYYY, still output MM/DD/YYYY. Port fields must be city names only, no country or code. Return the JSON object and nothing else.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
            ]);
            const fields = extractJson(result.response.text());
            if (fields) {
                fields.cutoff_date = resolveCutoffDate(fields);
                console.log(`[GEMINI] PDF extraction: bkg=${fields.booking_number || '?'} carrier=${fields.carrier || '?'} cutoff=${fields.cutoff_date || '?'}`);
                return fields;
            }
            console.warn(`[GEMINI] PDF extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            // 503 (overload) and 429 (rate limit) are transient — worth retrying
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] PDF extraction failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            if (attempt >= retries) throw err;
            // Non-transient error — don't waste retries
            if (!transient) throw err;
        }
    }
    if (lastErr) throw lastErr;
    return null;
}

// ── Multimodal: read an ORDER off its PDF attachment ──────────────────────────
//
// THE LAST UNREAD INPUT (2026-10-03). Measured all day: every remaining
// is_order miss and 3 of 10 confidence caps were an attachment nothing opens.
// Her P.O.s say "Please see the attached file for the additional P.O." and the
// quantities live in the PDF.
//
// WHY A NEW EXTRACTOR RATHER THAN THE EXISTING ONE. scripts/probe-order-
// attachments.js ran the real machinery over six real order PDFs. The reading
// was not "the PDFs are unreadable" -- classifyDocument named every one of
// them correctly ("purchase order", "order confirmation", "purchase order
// confirmation"). It was that extractPdfFields is a BOOKING extractor: it asks
// for booking_number, carrier, cutoff, ERD, and on a purchase order it
// honestly returns nulls. Nothing was asking for the material, the tonnage or
// the price. The gap was a missing question, not a missing capability.
//
// EVERY HARD-WON RULE FROM TODAY IS RESTATED HERE, because this prompt is a
// second doorway into the same pricing path and a rule enforced on one side
// only is not enforced:
//   · a trade term is not a price basis (CIF/FOB say who pays freight)
//   · per_lb is a real answer -- she buys domestic scrap by the pound
//   · "5c" is five containers, "10c for Mr.Kim" is a commission
//   · an included commission never changes the rate
// The basis and the unit come back as the DOCUMENT'S OWN WORDS and all
// arithmetic is done in code. A model that converts is a model that can be
// wrong by 2204.62x.
async function extractOrderPdfFields(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');

    const prompt = `You are reading a PURCHASE ORDER or ORDER CONFIRMATION for a scrap-metal exporter. Extract what was ordered. Return ONLY raw JSON — no markdown, no prose.

{
  "is_order_document": false,  // true if this document IS an order: a purchase order, an order confirmation, a sales contract or a signed quotation that commits to buying material. false for an invoice, a packing list, a bill of lading, a booking confirmation, a statement, a rate sheet or a brochure. Judge by what the document IS, not by whether order-shaped words appear in it.
  "po_number": null,           // the order's own reference, exactly as printed, e.g. "EMI-02", "4302994", "PO-EM03/26", "MKED20260922-B"
  "buyer": null,               // the company BUYING the material. On a purchase order issued TO the exporter, that is the company that issued the document.
  "seller": null,              // the company selling. Usually Sample Yard Co Metals / Sample Yard Co Trading.
  "currency": null,            // e.g. "USD"
  "trade_terms": null,         // CIF, CFR, FOB, DDP, EXW — as printed
  "port_discharge": null,      // city only
  "payment_term": null,        // as printed, e.g. "T/T 7 days before arrival", "L/C at sight"
  "container_count": null,     // NUMBER of containers if the document states one. "3x40HC" means 3. "1x20ft" means 1.
  "container_size": null,      // e.g. "40HC", "20ft"
  "items": [
    {
      "desc": null,            // the material, as printed
      "qty": null,             // the NUMBER only, exactly as printed — do NOT convert it
      "qty_unit": null,        // the unit as printed: "MT", "lbs", "kg", "tons", "containers" — whatever the document says. If the figure is a number of CONTAINERS and not a weight, say "containers" here.
      "rate": null,            // the unit price, NUMBER only, exactly as printed — do NOT convert it
      "rate_basis": null,      // "per_mt" if the price is per metric tonne. "per_lb" if per pound ($/lb, "per pound", "cents a pound", "/#") — common on domestic scrap, and a perfectly good answer. "per_lot" if it is a total for the container or the whole order. "unknown" if the document does not make it clear.
      "rate_confidence": 0.0   // 0 to 1: how sure you are you read THIS number correctly off the page
    }
  ],
  "note": null                 // one short sentence on anything a human should check. null if nothing.
}

A TRADE TERM IS NOT A PRICE BASIS. "$3,200 CIF Incheon" and "2,520 CIF Busan" are PER METRIC TONNE prices. CIF/CFR/FOB/DDP tells you who pays the freight and nothing whatever about per-tonne versus per-lot. Reading "CIF" as evidence of a lot price is a real error that has happened here.

DO NOT CONVERT ANYTHING. Give the number and the unit exactly as the page prints them. If a line reads "92,594 lbs @ $0.42/lb", that is qty 92594, qty_unit "lbs", rate 0.42, rate_basis "per_lb" — not 42 MT and not $925/MT. The conversion is done in code, where it cannot be wrong.

A CONTAINER COUNT IS NOT A QUANTITY. "5c", "2c", "3x40HC", "5 cntrs" are numbers of CONTAINERS and belong in container_count. Never put them in an item's qty unless the document really is ordering by the container, in which case qty_unit must say "containers".

A COMMISSION STATED AS INCLUDED DOES NOT CHANGE THE PRICE. "(10c for Mr. Kim and 10c for Hynos included)" is a $10/MT commission already inside the figure. Report the stated price unchanged. Do not net it down and do not add a commission line.

READ ONLY WHAT IS THERE. Every field may be null, and null is always better than a guess — a wrong tonnage or price on this document becomes a wrong tonnage or price on an invoice to a customer. Return the JSON object and nothing else.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            // The SMART tier, not the workhorse: this reads figures that end up
            // on a priced document going to a customer, which is exactly the
            // boundary config.js draws for GEMINI_MODEL_SMART.
            const model = getClient().getGenerativeModel({
                model: require('../config').GEMINI_MODEL_SMART || getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
            ]);
            const fields = extractJson(result.response.text());
            if (fields) {
                const n = Array.isArray(fields.items) ? fields.items.length : 0;
                console.log(`[GEMINI] order PDF: po=${fields.po_number || '?'} buyer=${fields.buyer || '?'} items=${n} containers=${fields.container_count ?? '?'}`);
                return fields;
            }
            console.warn(`[GEMINI] order PDF returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] order PDF read failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            // An unreadable attachment must leave the email judged on its body,
            // exactly as it is today -- never crash the scan. Null, not throw.
            return null;
        }
    }
    if (lastErr) return null;
    return null;
}

// ── Multimodal: extract freight-billing line items from a carrier invoice PDF ──
// Used by the Verification tab's carrier sub-tab (the owner: "build verification
// .in that create sub tab as carrier") — a carrier freight invoice can bill
// several HBL/shipments in one PDF, so this returns an ARRAY of records, one
// per HBL, rather than one flat object like extractPdfFields above. Each
// record's amount gets cross-checked in helpers/invoiceVerify.js against the
// Invoice sheet's own Freight column for that HBL. Same retry/temperature-0/
// JSON-mode pattern as extractPdfFields and classifyDocument for consistency.
async function extractFreightInvoiceRecords(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');

    const prompt = `You are a freight billing expert. This PDF is a carrier's freight invoice (e.g. from carrier or another ocean carrier), which may bill ONE shipment or SEVERAL on the same invoice. Extract every line item. Return ONLY raw JSON — no markdown, no prose.

{
  "records": [
    {
      "hbl_no": null,       // the House Bill of Lading number this line item is billed against — e.g. "GLTOEH-23002". null if this invoice has no HBL reference at all for this line.
      "container_no": null, // container number for this line item, if shown, e.g. "HMMU6247533"
      "booking_no": null,   // booking/carrier reference number for this line item, if shown
      "description": null,  // short description of the charge, e.g. "Ocean Freight", "THC", "Documentation Fee" — if several charges roll up into one HBL's total, describe it as "Combined" or list them briefly
      "amount": 0           // the billed amount in US dollars for this HBL/line item, as a plain number (no $ or commas)
    }
  ],
  "invoice_no": null,   // the carrier's own invoice number for this PDF, if shown
  "invoice_date": null  // MM/DD/YYYY, if shown
}

If the same HBL appears on multiple lines (e.g. separate freight + THC charges), combine them into ONE record with the summed amount, since that HBL is cross-checked against a single Freight total on our side. Return the JSON object and nothing else.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
            ]);
            const parsed = extractJson(result.response.text());
            if (parsed && Array.isArray(parsed.records)) {
                console.log(`[GEMINI] Freight invoice extraction: ${parsed.records.length} record(s), inv#=${parsed.invoice_no || '?'}`);
                return parsed;
            }
            console.warn(`[GEMINI] Freight invoice extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Freight invoice extraction failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            if (attempt >= retries) throw err;
            if (!transient) throw err;
        }
    }
    if (lastErr) throw lastErr;
    return null;
}

// ── Multimodal: extract line items from a Commission Debit Note PDF ──────────
// Used by the Verification tab's Commission → Pan Metal sub-tab. Per the owner's
// worked example (real file: "Comm. Debit Note Edge_260804.pdf" from Pan
// Metal Co., Ltd): one PDF, one table, one row per order — Date, Order No.
// (e.g. "26MT10"), Customer, Item, Weight, Actual Price, Invoice Price,
// Comm./MT (the per-MT rate), Commission (the computed dollar amount),
// Vessel Arrival, Payment Date. helpers/invoiceVerify.js's
// crossCheckPanMetalRecords() is what actually recomputes weight×rate from
// OUR OWN sheet and compares it against this PDF's stated Commission — this
// function only extracts what's printed on the page.
async function extractCommissionDebitNoteRecords(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');

    const prompt = `You are a freight/commission billing expert. This PDF is a "Commission Debit Note" — a table billing commission on several orders, one row per order. Extract every row. Return ONLY raw JSON — no markdown, no prose.

{
  "records": [
    {
      "order_no": null,      // e.g. "26MT10" — the short order code, NOT a full invoice number
      "date": null,          // MM/DD/YYYY
      "customer": null,      // e.g. "HAEKWANG"
      "item": null,          // e.g. "TENSE"
      "weight": 0,           // in MT, as a plain number (e.g. 21.301) — strip the "MT" unit
      "actual_price": 0,     // plain number, no $ or commas
      "invoice_price": 0,    // plain number, no $ or commas
      "comm_per_mt": 0,      // the "Comm./MT" or "Commission/MT" rate, plain number
      "commission": 0,       // the billed commission dollar amount for this row, plain number
      "vessel_arrival": null,  // MM/DD/YYYY if shown
      "payment_date": null     // MM/DD/YYYY if shown
    }
  ],
  "company": null,       // the billing company's name, e.g. "Pan Metal Co., Ltd"
  "note_date": null,     // MM/DD/YYYY — the debit note's own date, usually near the bottom
  "total_commission": 0  // the grand total commission shown at the bottom, if any, plain number
}

Return the JSON object and nothing else.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
            ]);
            const parsed = extractJson(result.response.text());
            if (parsed && Array.isArray(parsed.records)) {
                console.log(`[GEMINI] Commission debit note extraction: ${parsed.records.length} record(s), company=${parsed.company || '?'}`);
                return parsed;
            }
            console.warn(`[GEMINI] Commission debit note extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Commission debit note extraction failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            if (attempt >= retries) throw err;
            if (!transient) throw err;
        }
    }
    if (lastErr) throw lastErr;
    return null;
}

// ── Multimodal: extract line items from a Jio Transport trucking invoice ────
// Used by the Verification tab's Transport → Jio sub-tab. Per the owner's
// worked example (real files: Invoice_8559.pdf, Invoice_8635.pdf) — one PDF
// per load, "W/O (Ref):" holds the container number, "Shipper 1:" the
// origin company, and a "RATES AND CHARGES" block lists individual line
// items (confirmed real labels: "Line Haul", "PORT FEE"/"PORT FEES", "ONE
// DAY CHASSI RENT") summing to "Total Rate:". Labels vary invoice to
// invoice (fee vs fees, chassi vs chassis) — Gemini buckets each line into
// line_haul / port_fees / chassis_rent by meaning, not exact text, and
// anything that doesn't fit one of those three (detention, storage,
// whatever else Jio bills) goes into other_charges as its own line so
// nothing silently vanishes into the wrong bucket.
async function extractJioInvoiceRecords(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');

    const prompt = `You are a trucking/drayage billing expert. This PDF is an invoice from Jio Transport Inc for hauling one or more containers. Extract one record per load/container billed. Return ONLY raw JSON — no markdown, no prose.

{
  "records": [
    {
      "invoice_no": null,     // e.g. "8559"
      "invoice_date": null,   // MM/DD/YYYY — the invoice's own date at the top, NOT the shipper/consignee dates further down
      "container_no": null,   // the container number — usually the "W/O (Ref):" field, or the "Description" under Load Details; a standard container number is 4 letters + 7 digits (e.g. "KOCU5148281")
      "shipper": null,        // the "Shipper 1" company name, e.g. "MAZARIEGOS RECYCLING" — company name only, not the city/state
      "line_haul": 0,         // the "Line Haul" line item, plain number, 0 if not present
      "port_fees": 0,         // "PORT FEE" or "PORT FEES" line item, plain number, 0 if not present
      "chassis_rent": 0,      // any chassis/chassi rent line item (e.g. "ONE DAY CHASSI RENT", "CHASSIS RENT"), plain number, 0 if not present
      "other_charges": [      // ANY other line item under Rates and Charges that isn't Line Haul, Port Fee(s), or Chassis Rent — e.g. detention, storage, fuel surcharge. Empty array if none.
        { "label": null, "amount": 0 }
      ],
      "net_amount": 0         // the "Total Rate:" figure — the actual grand total printed on the invoice, not a sum you compute yourself
    }
  ]
}

Return the JSON object and nothing else.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
            ]);
            const parsed = extractJson(result.response.text());
            if (parsed && Array.isArray(parsed.records)) {
                console.log(`[GEMINI] Jio invoice extraction: ${parsed.records.length} record(s)`);
                return parsed;
            }
            console.warn(`[GEMINI] Jio invoice extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Jio invoice extraction failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            if (attempt >= retries) throw err;
            if (!transient) throw err;
        }
    }
    if (lastErr) throw lastErr;
    return null;
}

// ── Multimodal: extract line items from a Sher Trucking invoice ─────────────
// Used by the Verification tab's Transport → Sher Trucking sub-tab. Added
// per the owner: "instead of container,booking number shoudl be compared...
// Create a tab called Sher in that date (from uplaoded),booking no,quantity
// ,chassis,others,Amount should be there." Unlike Jio, I don't have a real
// Sher Trucking invoice sample to ground this prompt against (Jio's prompt
// was written against Invoice_8559.pdf/Invoice_8635.pdf's actual text) —
// this is a best-effort field guess modeled on the same
// trucking-invoice shape Jio uses, keyed on Booking No. instead of
// container. Flagged to the owner: worth sending a real Sher invoice to
// confirm/tune this against, same way Jio's was verified.
async function extractSherTruckingInvoiceRecords(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');

    const prompt = `You are a trucking/drayage billing expert. This PDF is an invoice from Sher Trucking for hauling containers under an ocean carrier booking number. Extract one record per booking billed. Return ONLY raw JSON — no markdown, no prose.

{
  "records": [
    {
      "invoice_date": null,   // MM/DD/YYYY — the invoice's own date
      "booking_no": null,     // the ocean carrier's Booking No. this invoice is billing against
      "quantity": null,       // how many containers/loads this invoice is billing under that ONE booking number — an integer count, e.g. 2. null if not stated anywhere on the invoice.
      "chassis": 0,           // any chassis rental/rent charge, plain number, 0 if not present
      "other_charges": [      // ANY other line item that isn't chassis — e.g. line haul, port fees, detention, fuel surcharge. Empty array if none.
        { "label": null, "amount": 0 }
      ],
      "amount": 0             // the invoice's own total/net amount due — the actual grand total printed, not a sum you compute yourself
    }
  ]
}

Return the JSON object and nothing else.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
            ]);
            const parsed = extractJson(result.response.text());
            if (parsed && Array.isArray(parsed.records)) {
                console.log(`[GEMINI] Sher Trucking invoice extraction: ${parsed.records.length} record(s)`);
                return parsed;
            }
            console.warn(`[GEMINI] Sher Trucking invoice extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Sher Trucking invoice extraction failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            if (attempt >= retries) throw err;
            if (!transient) throw err;
        }
    }
    if (lastErr) throw lastErr;
    return null;
}

// ── Multimodal: extract line items from an AJ Transport invoice ─────────────
// Used by the Verification tab's Transport → AJ Transport sub-tab. Grounded
// against a real file (Invoice_6405_from_AJ_Transport_Inc.pdf): ONE invoice
// bills MULTIPLE containers, one "CONTAINER" activity row per container,
// each row's Description packing BOTH the container no. and the ocean
// carrier booking no. on one line (e.g. "LYGU0110485 EBKG17996190"),
// followed by a line like "LOADED- MARTINEZ- 8/11" or "LOADED - OPS Yard
// -8/17 (HARNESS WIRE)" — the shipper/origin name and the pickup date,
// squeezed into free text with no separate labeled fields for either. The
// invoice ALSO bills non-container line items (seen for real: "DRY RUN
// CHARGE", "CHARGE FOR EXTRA SCALE") that have no container of their own.
// Per the owner ("why DRY RUN CHARGE and CHARGE FOR EXTRA SCALE both are not
// there. if its there without any container whatever the container before
// that - that container's items are this"): these are NOT dropped anymore
// — each is attributed to the CONTAINER line immediately above it (the
// invoice always prints a non-container charge line right after the
// container it belongs to).
//
// Follow-up ("instead of others,add new columns for that booking,keep the
// column name in two words"): rather than one lumped "others" number, the
// two REAL charge types seen so far each get their own named field —
// dry_run_charge ("Dry Run") and extra_scale_charge ("Extra Scale"). A
// third field, other_charge, is kept as a genuine catch-all for anything
// that ISN'T one of those two known types — not shown as its own sheet
// column (goes into the existing "Others" column instead), specifically so
// a charge type that hasn't been seen yet on a real invoice still gets
// captured somewhere rather than silently vanishing again the way DRY RUN
// CHARGE/EXTRA SCALE did before this was fixed. If a new charge type
// starts showing up regularly, ask for its own named column same as these
// two.
// ── GARDUNO'S LOGISTICS — READ THE LINES, NOTHING ELSE ───────────────────
// the owner, 2026-10-04: "I want to upload all these invoices in Sample Yard Co Metals
// trucking under gardunos like AJ Transport".
//
// DELIBERATELY DUMBER THAN THE AJ TRANSPORT PROMPT ABOVE. That one asks the
// model to work out which charge belongs to which container and what each
// sums to — which cannot be tested without calling Gemini, and when it is
// wrong it is wrong in money, invisibly.
//
// A Garduno's invoice is regular: one line per BOOKING with its containers
// listed in the description, at a per-container rate, then a SCALE TICKETS
// line for the invoice. Expanding that into six container records is
// arithmetic, so it lives in helpers/gardunosInvoice.js where the suite can
// run it. The model's only job here is to transcribe the table.
//
// So: no attribution, no sums, no judgement. Read the rows.
async function extractGardunosInvoiceRecords(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');

    const prompt = `This PDF is an invoice from GARDUNO'S LOGISTICS INC, a drayage company, billed to Sample Yard Co Metals. Transcribe its line-item table EXACTLY as printed. Do NOT calculate anything, do NOT combine or split rows, do NOT work out which charge belongs to which container — return one entry per printed row, in the order they appear. Return ONLY raw JSON, no markdown, no prose.

{
  "invoice_no": null,     // e.g. "169 REVISED" — exactly as printed next to "Invoice no.", INCLUDING any word like REVISED
  "invoice_date": null,   // MM/DD/YYYY as printed next to "Invoice date"
  "due_date": null,       // MM/DD/YYYY as printed next to "Due date", or null
  "total": 0,             // the "Total" figure, plain number
  "balance_due": 0,       // the "Balance due" figure, plain number (0 when paid in full)
  "lines": [
    {
      "product": null,     // the "Product or service" cell, verbatim (e.g. "BKNG#PHX6A1731600" or "SCALE TICKETS")
      "description": null, // the whole "Description" cell, verbatim, keeping its line breaks as \n — it lists the container numbers, one per line
      "qty": 0,            // the Qty column, plain number
      "rate": 0,           // the Rate column, plain number
      "amount": 0          // the Amount column, plain number
    }
  ]
}

Return the JSON object and nothing else.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
            ]);
            const parsed = extractJson(result.response.text());
            if (parsed && Array.isArray(parsed.lines)) {
                console.log(`[GEMINI] Garduno's invoice extraction: ${parsed.lines.length} line(s)`);
                return parsed;
            }
            console.warn(`[GEMINI] Garduno's invoice extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Garduno's invoice extraction failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise((r) => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            if (!transient) break;
        }
    }
    throw new Error(`Garduno's invoice extraction failed${lastErr ? ': ' + lastErr.message : ''}`);
}

// ── EAGLE TRANS SHIPPING & LOGISTICS (EagleBrit) ───────────────────────────
// the owner, 2026-10-07: "yes.build". Same rule as the Garduno's prompt above: the
// model TRANSCRIBES, helpers/eagleInvoice.js does every sum. An XSINV invoice
// bills one booking in one total; there is no per-container amount to read.
async function extractEagleInvoiceRecords(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');
    const prompt = `This PDF is an INVOICE (XSINV/...) or CREDIT NOTE (XSCRN/...) from EAGLE TRANS SHIPPING & LOGISTICS LLC, an ocean freight forwarder, billed to Sample Yard Co Metals. Transcribe what is printed. Do NOT calculate, split or infer anything. Return ONLY raw JSON, no markdown.

{
  "invoice_no": null,    // the document number printed top right, e.g. "XSINV/172994" or "XSCRN/015704"
  "document_type": null, // "invoice" or "credit note"
  "invoice_date": null,  // "Date of Invoice", MM/DD/YYYY (the printed form is DD/MM/YYYY — convert it)
  "job_ref": null,       // "Our Job Ref", e.g. "UHSE/092987"
  "booking_no": null,    // "Booking Ref", e.g. "EBKG18168515"
  "mbl": null,           // "MBL"
  "hbl": null,           // "HBL"
  "containers": [],      // EVERY container number printed under Marks and Numbers (4 letters + 7 digits), one string each
  "charges": [ { "description": null, "amount": 0 } ], // each charge line e.g. FREIGHT, DOCUMENTATION FEE, with its printed amount (negative on a credit note)
  "total_due": 0,        // the "TOTAL DUE" figure, plain number, negative if shown negative
  "currency": "USD"
}

Return the JSON object and nothing else.`;
    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({ model: getModelName(), generationConfig: { temperature: 0, responseMimeType: 'application/json' } });
            const result = await model.generateContent([{ text: prompt }, { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } }]);
            const parsed = extractJson(result.response.text());
            if (parsed && typeof parsed === 'object') {
                console.log(`[GEMINI] Eagle invoice extraction: ${parsed.invoice_no || '(no number)'}, ${(parsed.containers || []).length} container(s)`);
                return parsed;
            }
            console.warn(`[GEMINI] Eagle invoice extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Eagle invoice extraction failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) { await new Promise((r) => setTimeout(r, 1200 * (attempt + 1))); continue; }
            if (!transient) break;
        }
    }
    throw new Error(`Eagle invoice extraction failed${lastErr ? ': ' + lastErr.message : ''}`);
}

async function extractAjTransportInvoiceRecords(pdfBase64, retries = 2) {
    if (!pdfBase64) throw new Error('pdfBase64 required');

    const prompt = `You are a trucking/drayage billing expert. This PDF is an invoice from AJ Transport Inc. It bills one or more containers under an "ACTIVITY" column. Most activity lines are labeled "CONTAINER" — each is its own container, in the order they appear top to bottom. Some activity lines are a DIFFERENT charge type with no container of their own (e.g. "DRY RUN CHARGE", "CHARGE FOR EXTRA SCALE", or similar) — these always appear directly after the CONTAINER line they belong to, before the next CONTAINER line. Attribute each such charge to the CONTAINER line immediately above it: sum the AMOUNT of every "DRY RUN CHARGE" line between one CONTAINER line and the next into that container's "dry_run_charge" field, every "CHARGE FOR EXTRA SCALE" line into "extra_scale_charge", and anything else non-CONTAINER into "other_charge". If a non-CONTAINER charge line appears before ANY container line (nothing above it to attach to), ignore it. Extract one record per CONTAINER line. Return ONLY raw JSON — no markdown, no prose.

{
  "invoice_no": null,      // e.g. "6405" — the invoice's own number, same for every record
  "invoice_date": null,    // MM/DD/YYYY — the invoice's own date, same for every record
  "records": [
    {
      "container_no": null,  // the container number on this CONTAINER line's description (e.g. "LYGU0110485") — a standard container number is 4 letters + 7 digits
      "booking_no": null,    // the booking number on the SAME line as the container number (e.g. "EBKG17996190") — usually right after the container number, on the same line
      "shipper": null,       // the origin/shipper name mentioned on the line below the container/booking (e.g. "MARTINEZ" from "LOADED- MARTINEZ- 8/11", or "OPS Yard" from "LOADED - OPS Yard -8/17 (HARNESS WIRE)") — just the name, not the date or the item in parentheses
      "pickup_date": null,   // the date on that same description line (e.g. "8/11", "8/17") — exactly as printed, do NOT add a year since the invoice doesn't state one for this field
      "rate": 0,             // this container line's own RATE column value, plain number
      "amount": 0,           // this container line's own AMOUNT column value, plain number
      "dry_run_charge": 0,   // sum of any "DRY RUN CHARGE" line(s) attributed to this container per the rule above — 0 if none
      "extra_scale_charge": 0, // sum of any "CHARGE FOR EXTRA SCALE" line(s) attributed to this container per the rule above — 0 if none
      "other_charge": 0      // sum of any OTHER non-CONTAINER charge line(s) attributed to this container that are neither of the above — 0 if none
    }
  ]
}

Return the JSON object and nothing else.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: 'application/pdf', data: pdfBase64 } },
            ]);
            const parsed = extractJson(result.response.text());
            if (parsed && Array.isArray(parsed.records)) {
                console.log(`[GEMINI] AJ Transport invoice extraction: ${parsed.records.length} record(s)`);
                return parsed;
            }
            console.warn(`[GEMINI] AJ Transport invoice extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] AJ Transport invoice extraction failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            if (attempt >= retries) throw err;
            if (!transient) throw err;
        }
    }
    if (lastErr) throw lastErr;
    return null;
}
// NOTE: callGeminiText() was removed here (2026-07-16 cleanup). It had been
// declared TWICE in this file — once above returning a trimmed string, once
// down here returning raw JSON text with its own separate GoogleGenerativeAI
// client and a hardcoded 'gemini-1.5-flash' fallback instead of cfg.GEMINI_MODEL
// (the second declaration silently won at runtime; the first was dead). Its
// only caller was helpers/llm-intent.js's extractManagerIntent(), which was
// itself dead code — never invoked from workflow/brain.js's actual process()
// pipeline (brain.js has its own handleManagerLLMFallback() that called it,
// but that function was never called either). Both were removed together.
// The live regex→Gemini fallback for manager/booking messages is
// workflow/brain.js: policyDecide() → aiDecide() → callGeminiJSON(), which
// already includes full chat context (session, last 5 messages, facts,
// business context). If a lighter-weight text-only Gemini call is needed
// again later, re-add it deliberately — don't restore this dead pair as-is.

// ── Multimodal: extract fields from a yard scale-ticket photo ────────────────
// Same pattern as extractPdfFields but for an image (JPEG/PNG) of a digital
// truck scale / weighbridge ticket. Deliberately its own function, not a
// branch inside extractPdfFields — different schema, different failure mode
// (a photographed screen/printed slip is far more likely to be blurry,
// glared, or at an angle than a clean PDF, so this always returns best-effort
// JSON with nulls rather than throwing on partial legibility).
async function extractScaleTicketFields(imageBase64, mimeType = 'image/jpeg', retries = 2) {
    if (!imageBase64) throw new Error('imageBase64 required');

    const prompt = `You are reading a photo of a digital truck scale (weighbridge) ticket — typically a scale readout screen or a printed slip. Extract the following fields. Return ONLY raw JSON — no markdown, no prose.

Schema (every field can be null if not legible or not present):
{
  "ticket_number": null,     // ticket/transaction ID printed on the ticket
  "gross_weight": null,      // number, in the unit shown (do not convert units)
  "tare_weight": null,       // number
  "net_weight": null,        // number — if not printed but gross and tare are both present, compute gross - tare
  "weight_unit": null,       // e.g. "lb", "kg", "ton"
  "date": null,               // MM/DD/YYYY as printed
  "time": null,               // as printed, e.g. "14:32"
  "truck_number": null,      // truck/license plate if shown
  "container_number": null,  // if shown
  "commodity": null,         // material description if shown, e.g. "scrap steel"
  "scale_location": null     // yard/facility name if shown on the ticket
}

If the image is blurry, cut off, glared, or not actually a scale ticket, still return your best-effort JSON with nulls for anything unreadable — never refuse, never return prose. Return the JSON object and nothing else.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: mimeType || 'image/jpeg', data: imageBase64 } },
            ]);
            const fields = extractJson(result.response.text());
            if (fields) {
                console.log(`[GEMINI] Scale ticket extraction: ticket=${fields.ticket_number || '?'} net=${fields.net_weight ?? '?'}`);
                return fields;
            }
            console.warn(`[GEMINI] Scale ticket extraction returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Scale ticket extraction failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            if (attempt >= retries) throw err;
            if (!transient) throw err;
        }
    }
    if (lastErr) throw lastErr;
    return null;
}


// ── Multimodal: transcribe a WhatsApp voice note ──────────────────────────────
// Added per the owner: "jarvis should talk" -> clarified to mean voice INPUT —
// she (or her team) sends a WhatsApp voice note instead of typing, and Jarvis
// understands and acts on it the same as a typed message. Deliberately the
// SMALLEST possible integration: this function only turns audio into text:
// index.js's message handler downloads a 'ptt'/'audio' message's bytes, calls
// this, and feeds the result into brain.process()'s existing `text` field —
// nothing about intent routing, pending-state handling, or any action in
// workflow/brain.js or workflow/actions.js needs to know a message started as
// audio at all. Same reasoning as the yard scale-ticket photo path just above
// this in the file: reuse the pipeline that already works for text, don't
// build a second one.
//
// Returns English text specifically (not just a verbatim transcript) — every
// downstream intent-matching/AI-decide step in brain.js already assumes
// English, and the owner's team includes non-English speakers (Korean suppliers
// etc. show up throughout this codebase's real data). Translating here, once,
// keeps that assumption true for voice the same way it already happens to be
// true for typed messages (people already type to Jarvis in English).
//
// Non-fatal by construction, like every other Gemini extraction in this file
// — if this throws, index.js's caller catches it and falls back to treating
// the message as if it had no usable text, exactly like a genuinely blank
// message would already be handled, rather than crashing the whole handler.
async function transcribeVoiceNote(audioBase64, mimeType, retries = 2) {
    if (!audioBase64) throw new Error('audioBase64 required');

    const prompt = `You are transcribing a WhatsApp voice note sent to a logistics/export company's assistant. Return ONLY raw JSON — no markdown, no prose.

Schema:
{
  "transcript": null,     // verbatim transcription, in whatever language was actually spoken
  "language": null,       // best guess at the spoken language, e.g. "English", "Hindi", "Korean"
  "english_text": null    // the same content translated into English (if already English, just repeat the transcript as-is — do not paraphrase or summarize, translate as literally as possible so instructions/numbers/names stay exact)
}

If the audio is silent, unintelligible, or just noise, return all three fields as null rather than guessing or refusing. Never return prose outside the JSON object.`;

    let lastErr = null;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: getModelName(),
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: mimeType || 'audio/ogg', data: audioBase64 } },
            ]);
            const fields = extractJson(result.response.text());
            if (fields) {
                console.log(`[GEMINI] Voice note transcribed (${fields.language || '?'}): "${String(fields.english_text || fields.transcript || '').slice(0, 80)}"`);
                return fields;
            }
            console.warn(`[GEMINI] Voice note transcription returned unparseable JSON (attempt ${attempt + 1})`);
        } catch (err) {
            lastErr = err;
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Voice note transcription failed (attempt ${attempt + 1}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) {
                await new Promise(r => setTimeout(r, 1200 * (attempt + 1)));
                continue;
            }
            if (attempt >= retries) throw err;
            if (!transient) throw err;
        }
    }
    if (lastErr) throw lastErr;
    return null;
}

// ── Multimodal: read a single weight number off a digital scale display ──────
// Used by the dashboard's Add New Load form — the gross/tare camera capture
// buttons snapshot the scale readout and POST here (via /api/vision/read-weight
// in api.js) for a fast, narrow extraction. Deliberately a separate, smaller
// prompt from extractScaleTicketFields: that one is for a full printed ticket
// with many fields; this is a live in-browser snapshot of just the number on
// the display, so the schema is minimal and the prompt is tuned for reading a
// single number off a 7-segment/LCD readout rather than a printed slip.
// Model choice for this specific digit-reading task, benchmarked live against
// the actual yard photo with a confirmed in-person ground-truth reading
// (71920 lb) after switching to the crop-zoom pipeline below:
//   gemini-3.1-flash-lite : wrong every run (37920 / 87920 / 881920 variants)
//   gemini-3.1-pro-preview: wrong (77920), and slow (~37s/request) — pro-tier
//                            reasoning didn't help on this specific dim/blurry
//                            digit pair, not worth the latency
//   gemini-3.6-flash      : correct (71920) on 4 of 5 runs at temperature 0 —
//                            clearly the best of what's available on this
//                            account, though not perfectly deterministic even
//                            at temp 0 on this hard a photo (~12-16s/request)
// Not 100% reliable — this is still a genuinely dim, angled, blurry photo —
// which is why the dashboard keeps a "check it matches the scale before
// saving" step regardless of model. Verified live via
// https://generativelanguage.googleapis.com/v1beta/models against this
// account's actual key to confirm gemini-3.6-flash is really available here
// before defaulting to it (gemini-2.5-pro showing up in that same list is why
// its earlier 404 was account/quota related, not that the model doesn't
// exist).
// FALLBACK_VISION_MODEL is the one CONFIRMED working on this account already
// (extractPdfFields/classifyDocument use it successfully) — used automatically
// if the primary 404s as unavailable, so a model getting deprecated out from
// under this account doesn't silently break weight-reading again without at
// least degrading gracefully instead of hard-failing.
function getVisionModelName() {
    return process.env.GEMINI_VISION_MODEL || 'gemini-3.6-flash';
}
const FALLBACK_VISION_MODEL = 'gemini-2.5-flash';
function isModelUnavailableError(err) {
    return /404|not found|no longer available|not supported/i.test(err.message || '');
}

// Locate only needs a coarse bounding box (4 fractions + a one-line reason)
// — a categorically easier task than the precise digit-legibility reading
// getVisionModelName() (gemini-3.6-flash) was specifically benchmarked and
// chosen for (~12-16s/request — see the comment above readWeightSinglePass).
// Running that same slow model for locate was the real reason "under 10s"
// was never achievable: locate sat fully synchronous on the critical path
// BEFORE Vision (the actual primary source of the weight number) ever got a
// crop to read. Locate uses the lighter, already-confirmed-working
// FALLBACK_VISION_MODEL instead — finding a large, visually distinct
// display region doesn't need the heaviest available model; only reading
// its exact digits does, and Cloud Vision OCR (not Gemini) does that job
// now. Overridable via env in case live testing shows this model missing
// boxes it used to find.
const LOCATE_MODEL = process.env.GEMINI_LOCATE_MODEL || FALLBACK_VISION_MODEL;

// Generic timeout wrapper so one slow leg of the pipeline can never hold the
// whole response hostage. Doesn't cancel the underlying call (the Gemini/
// Vision SDK calls here don't expose an abort signal) — it just stops US
// waiting on it past `ms`. If it resolves late, that late result is simply
// never used for this request; a warning is logged so a pattern of frequent
// timeouts is visible instead of silently eating latency budget forever.
function withTimeout(promise, ms, label) {
    let timedOut = false;
    const timeout = new Promise((resolve) => {
        setTimeout(() => { timedOut = true; resolve(null); }, ms);
    });
    return Promise.race([promise, timeout]).then((result) => {
        if (timedOut) console.warn(`[GEMINI] ${label} exceeded its ${ms}ms budget, moving on without it`);
        return result;
    });
}

// Added 2026-08-11 — classifies display type from Vision's own crop OCR
// text instead of a second Gemini call, so routing costs zero extra
// latency (see full reasoning at the call site in extractWeightFromImage).
// Deliberately keyword-based rather than fuzzy: false negatives just fall
// through to the existing, well-tested Vision-default path, so being
// conservative here is safe; false positives would wrongly route a real
// weighbridge photo to Gemini, which is the failure mode to avoid.
// Known compact bench/platform indicator brands. Added 2026-08-19 after
// testing a real Socome photo (true value 4210): the crop this classifier
// receives is deliberately trimmed down to just the lit digits, so the
// panel text that identifies the device ("Weighing indicator", "FUNC",
// "ON/OFF") is cropped AWAY before this ever runs — the whole-image OCR of
// that same photo read "socome / Weighing indicator / 42 10 / FUNC NITS",
// but the crop read only "4210". A brand name often survives in a tight
// crop when the button labels don't (it sits directly above the display),
// so matching it recovers the classification the other keywords miss.
const COMPACT_INDICATOR_BRANDS = /\b(socome|essae|contech|sansui|avery|citizen)\b/;

// visionText is the CROP's text; wholeImageText (optional) is the OCR of
// the full photo, which the pipeline already computes in parallel as a
// fallback read and previously never used for classification. Passing it
// matters because the identifying panel text lives OUTSIDE the digit crop
// — see the comment above. Either source is enough to classify.
function looksLikeCompactIndicatorFromVisionText(visionText, wholeImageText) {
    const t = `${visionText || ''}\n${wholeImageText || ''}`.toLowerCase();
    return /\bindicat/.test(t) || /\bon\/?off\b/.test(t) || /\bfunc\b/.test(t)
        || COMPACT_INDICATOR_BRANDS.test(t)
        || (/\bstable\b/.test(t) && /\btare\b/.test(t));
}

// Locate-only shrink — per the owner, the whole read was taking too long
// (>10s). The client already downscales to 1600px before upload, but that's
// sized for actually READING digits; locateDisplayBox only needs to find a
// bounding box, which doesn't need anywhere near that much resolution. This
// produces a small (~900px) copy for JUST the locate call — the box it
// returns is fractions (0-1) of image width/height, so it applies identically
// to the full-resolution original regardless of what size image found it,
// meaning digit-read accuracy is completely unaffected; only the locate
// call's upload+processing time drops. Falls back to the original image
// (same behavior as before this existed) if sharp is missing or the resize
// fails for any reason — can only make locate faster, never break it.
async function shrinkForLocate(imageBase64, mimeType) {
    if (!sharp) return imageBase64;
    try {
        const buf = Buffer.from(imageBase64, 'base64');
        const meta = await sharp(buf).metadata();
        if (!meta.width || meta.width <= 900) return imageBase64; // already small enough
        const outBuf = await sharp(buf).resize({ width: 900 }).jpeg({ quality: 80 }).toBuffer();
        return outBuf.toString('base64');
    } catch (err) {
        console.warn('[GEMINI] Locate-shrink failed, using original image for locate:', err.message);
        return imageBase64;
    }
}

// Bakes EXIF orientation into the actual pixels once, up front — see the
// detailed comment on extractWeightFromImage's call to this for the full
// root-cause story. Cheap no-op (one metadata() call, no re-encode) for the
// common case where there's no orientation tag or it's already "normal"
// (both real yard photos tested directly in this conversation came back
// this way) — only re-encodes when there's actually something to fix.
async function normalizeOrientation(imageBase64) {
    if (!sharp) return imageBase64;
    try {
        const buf = Buffer.from(imageBase64, 'base64');
        const meta = await sharp(buf).metadata();
        if (!meta.orientation || meta.orientation === 1) return imageBase64;
        const outBuf = await sharp(buf).rotate().jpeg({ quality: 95 }).toBuffer();
        console.log(`[GEMINI] Normalized EXIF orientation ${meta.orientation} (was ${meta.width}x${meta.height} stored) before locate/crop`);
        return outBuf.toString('base64');
    } catch (err) {
        console.warn('[GEMINI] EXIF orientation normalize failed, using original image as-is:', err.message);
        return imageBase64;
    }
}

// Stage 1, attempt #1 — a fast, deterministic, non-AI display locator. Every
// real yard photo seen so far (this account, this hardware) shows the
// vehicle weighbridge display as a bright, saturated RED LED/dot-matrix
// readout, while the compact bench/platform scale next to it is a backlit
// grey LCD — not red. That's a real, physical, color-based difference, not a
// guess: the exact same red threshold (r>140, r-g>60, r-b>60) is already
// proven in trimDeadDigitZones below, measured directly off a real photo of
// this display. A plain color-cluster search tells the two displays apart
// without needing to understand what either one IS, runs in tens of
// milliseconds fully locally (no network call, no model variance, no API
// cost), and is tried BEFORE ever calling the slower, occasionally-timing-out
// AI-based locateDisplayBox below. Returns null (caller falls back to the AI
// locate) if there's no confidently-sized, confidently-shaped red cluster —
// e.g. a non-red display, washed-out lighting, or a genuinely cluttered
// frame with no dominant red region.
// NOTE on method: an earlier version of this function found the bounding box
// by taking the longest lit run independently on each axis (row-sum profile,
// column-sum profile). Tested live against a real photo before shipping and
// it FAILED — the display's 4 small LB/KG/GR/NT arrow icons sit at the far
// left of the housing, and the independent per-axis projection let the box's
// x-range lock onto those tiny icons while the y-range came from the actual
// digits, producing a box that pointed at neither. Fixed by doing real
// connected-component labeling on the red-pixel mask (with a dilation pass
// first, since a dot-matrix digit's individual lit dots aren't literally
// touching pixel-to-pixel) and picking the component with the most total lit
// pixels — the digit block lights up far more pixels than the small arrow
// icons even though both are "red". Verified against the actual photo from
// this conversation: correctly boxes the full weighbridge housing and
// excludes the Fairbanks bench scale below it, in ~150-180ms.
// Refactored 2026-08-11 to take a color predicate instead of hardcoding red,
// after a real batch of 12 live photos showed a THIRD display type at this
// yard — a "Fairbanks IQ plus 710" indicator with a cyan/teal LCD readout,
// not red. Sampled real pixel data directly off two of those photos before
// writing this (not guessed): the digit cluster's actual average color came
// back RGB≈(40,165,195) — low red, high green+blue — cleanly separable from
// background noise (~0.2-0.3% of frame, same order of magnitude as the red
// display). All the core logic (dilation, connected-component labeling,
// picking the largest component) is unchanged from the original red-only
// version, which stays exactly as before via the thin wrapper below —
// only the color test and the minimum-lit-fraction threshold are now
// parameters, so the well-tested red path can't regress.
async function findDisplayBoxByColor(imageBase64, colorTest, minLitFraction, colorLabel) {
    if (!sharp) return null;
    try {
        const buf = Buffer.from(imageBase64, 'base64');
        const targetWidth = 500; // resolution is irrelevant here, only the region matters — keep this cheap
        const { data, info } = await sharp(buf)
            .resize({ width: targetWidth, withoutEnlargement: true })
            .removeAlpha()
            .raw()
            .toBuffer({ resolveWithObject: true });
        const { width: w, height: h, channels } = info;
        if (!w || !h) { console.warn('[GEMINI] Pixel locate: image had no dimensions'); return null; }

        const mask = new Uint8Array(w * h);
        let totalLit = 0;
        for (let y = 0; y < h; y++) {
            const rowBase = y * w * channels;
            for (let x = 0; x < w; x++) {
                const i = rowBase + x * channels;
                const r = data[i], g = data[i + 1], b = data[i + 2];
                if (colorTest(r, g, b)) { mask[y * w + x] = 1; totalLit++; }
            }
        }
        // Always-on (not gated behind DEBUG_WEIGHT_RAW) for the same reason
        // the locate-step logging below is always-on: this is exactly the
        // kind of "why did it fall back" question that was previously
        // unanswerable from the logs. Low-volume (once per photo).
        console.log(`[GEMINI] Pixel locate (${colorLabel}): ${totalLit} lit px of ${w * h} (${(totalLit / (w * h) * 100).toFixed(2)}%), need >=${(minLitFraction * 100).toFixed(2)}%`);
        if (totalLit < w * h * minLitFraction) return null; // essentially nothing this color in frame at all

        // Dilate by R pixels so a dot-matrix digit's individually-lit dots
        // (and the gaps between adjacent digit cells) merge into one
        // connected blob instead of being scattered specks. R=25 (at this
        // 500px-wide working resolution) is wide enough to bridge inter-digit
        // gaps and the dead/ghost-cell gap, verified against a real photo,
        // while still leaving a real gap between the digit block and the
        // separate LB/KG/GR/NT arrow-icon column so they don't merge into one
        // component.
        const R = 25;
        const dilated = new Uint8Array(w * h);
        for (let y = 0; y < h; y++) {
            for (let x = 0; x < w; x++) {
                if (!mask[y * w + x]) continue;
                const yStart = Math.max(0, y - R), yEnd = Math.min(h - 1, y + R);
                const xStart = Math.max(0, x - R), xEnd = Math.min(w - 1, x + R);
                for (let ny = yStart; ny <= yEnd; ny++) {
                    const base = ny * w;
                    for (let nx = xStart; nx <= xEnd; nx++) dilated[base + nx] = 1;
                }
            }
        }

        // Connected components (4-connectivity) over the dilated mask,
        // iterative flood fill (no recursion) — picks the component with the
        // most ORIGINAL (non-dilated) lit pixels, since the real digit block
        // lights far more pixels than a small icon even after both get
        // dilated the same amount.
        const labels = new Int32Array(w * h).fill(-1);
        let nextLabel = 0;
        const comps = [];
        const stack = [];
        for (let y = 0; y < h; y++) {
            for (let x = 0; x < w; x++) {
                const idx = y * w + x;
                if (!dilated[idx] || labels[idx] !== -1) continue;
                const label = nextLabel++;
                let minX = x, maxX = x, minY = y, maxY = y, litCount = 0;
                // origMinX/etc track bounds of the ORIGINAL (undilated) lit
                // pixels only — added 2026-08-11 alongside the edge-touch
                // check below. minX/maxX/minY/maxY above are bounds of the
                // DILATED component (correct for finding the crop box — the
                // dilation is what bridges gaps between digit segments) but
                // are NOT safe to use for "does this touch the frame edge":
                // dilation (R=25 at this ~500px analysis width, 5% of frame)
                // pads the box outward on every side regardless of where the
                // real content is, so a fully-in-frame display positioned
                // anywhere near the outer 5% would show dilated bounds
                // touching 0/w or 0/h even with real margin around it.
                // Verified directly: a photo that reads correctly (81528)
                // showed dilated minX=0 while genuinely having margin.
                let origMinX = Infinity, origMaxX = -Infinity, origMinY = Infinity, origMaxY = -Infinity;
                stack.push(idx); labels[idx] = label;
                while (stack.length) {
                    const cur = stack.pop();
                    const cy = (cur / w) | 0, cx = cur % w;
                    if (mask[cur]) {
                        litCount++;
                        if (cx < origMinX) origMinX = cx; if (cx > origMaxX) origMaxX = cx;
                        if (cy < origMinY) origMinY = cy; if (cy > origMaxY) origMaxY = cy;
                    }
                    if (cx < minX) minX = cx; if (cx > maxX) maxX = cx;
                    if (cy < minY) minY = cy; if (cy > maxY) maxY = cy;
                    if (cx > 0 && dilated[cur - 1] && labels[cur - 1] === -1) { labels[cur - 1] = label; stack.push(cur - 1); }
                    if (cx < w - 1 && dilated[cur + 1] && labels[cur + 1] === -1) { labels[cur + 1] = label; stack.push(cur + 1); }
                    if (cy > 0 && dilated[cur - w] && labels[cur - w] === -1) { labels[cur - w] = label; stack.push(cur - w); }
                    if (cy < h - 1 && dilated[cur + w] && labels[cur + w] === -1) { labels[cur + w] = label; stack.push(cur + w); }
                }
                comps.push({ litCount, minX, maxX, minY, maxY, origMinX, origMaxX, origMinY, origMaxY });
            }
        }
        if (!comps.length) { console.warn(`[GEMINI] Pixel locate (${colorLabel}): pixels found but no connected component formed`); return null; }
        comps.sort((a, b) => b.litCount - a.litCount);

        // Changed 2026-08-11: this used to commit to ONLY the single
        // largest component and either use it or give up. A real false
        // positive proved that's not safe — on one photo, a blurry window
        // reflection (323px) narrowly out-scored the actual display digits
        // (298px) and was the only candidate ever tried. A saturation-based
        // filter to reject the reflection was tried and reverted (too thin
        // a margin against a different genuine case at 0.40 vs the false
        // positive's 0.34 — see git history). This is the safer fix: return
        // the top few candidates (still each passing the same sanity-bounds
        // check as before) so the caller can actually TRY reading each one
        // and use whichever produces a real result, instead of a threshold
        // pre-judging which one is "real" before ever attempting to read it.
        //
        // Bug found in the SAME live test 2026-08-11: an unrestricted top-3
        // list let genuinely tiny, unrelated red specks (a wire glint, a
        // tail-light — a few dozen pixels) qualify as "candidates" just for
        // individually passing the same absolute sanity-bounds check the
        // single dominant component used to need. On one photo this caused
        // a 232px noise blob to get tried and accepted (a wrong, if flagged,
        // answer) INSTEAD of ever falling through to cyan, where the real
        // 11026px display cluster was waiting. Fix: only include a
        // secondary component if it's within 50% of the TOP component's
        // pixel count — close enough to plausibly be a genuine alternate
        // (like the 323-vs-298 reflection/display case this was built for),
        // not noise that merely cleared an absolute floor built for judging
        // a single dominant cluster.
        const candidates = [];
        const topLitCount = comps[0].litCount;
        for (const comp of comps) {
            if (candidates.length >= 3) break;
            if (comp.litCount < topLitCount * 0.5) break; // comps is sorted descending, so nothing after this qualifies either
            const boxW = (comp.maxX - comp.minX) / w, boxH = (comp.maxY - comp.minY) / h;
            if (boxW < 0.06 || boxH < 0.02 || boxW > 0.9 || boxH > 0.6) continue;
            const padX = boxW * 0.08, padY = boxH * 0.25;
            // Added 2026-08-11, corrected same day after a measured false
            // positive: whether the ORIGINAL (undilated) lit pixels run up
            // to the photo's LEFT/RIGHT edge — using origMinX/origMaxX, not
            // the dilated minX/maxX (see the connected-component loop above
            // for why the dilated bounds can't be used here). Digits read
            // left-to-right, so a display cut off by the frame loses digits
            // specifically off the left or right edge — every real case
            // this session (736 vs 73600, "truncated on right edge of image
            // frame", "cut off by the left edge") was horizontal. TOP/BOTTOM
            // edge-touching is deliberately NOT checked: a display sitting
            // high or low in an otherwise normal photo is just composition,
            // not missing data, and checking it produced false positives
            // with no corresponding evidence of an actual truncated read.
            const edgeMargin = w * 0.015;
            const touchesEdge = comp.origMinX <= edgeMargin || comp.origMaxX >= (w - edgeMargin);
            candidates.push({
                x_min: Math.max(0, comp.minX / w - padX),
                y_min: Math.max(0, comp.minY / h - padY),
                x_max: Math.min(1, comp.maxX / w + padX),
                y_max: Math.min(1, comp.maxY / h + padY),
                reason: `${colorLabel} cluster found by pixel color analysis (no AI call)`,
                litCount: comp.litCount,
                touchesEdge,
            });
        }
        console.log(`[GEMINI] Pixel locate (${colorLabel}): ${candidates.length} candidate box(es) passed sanity bounds (${comps.map(c => c.litCount).slice(0, 5).join(', ')} px, largest first)`);
        return candidates.length ? candidates : null;
    } catch (err) {
        console.warn(`[GEMINI] Pixel-based ${colorLabel} locate failed:`, err.message);
        return null;
    }
}

// Thin wrapper preserving the exact original red-only behavior/thresholds —
// nothing about the well-tested red path changed in the refactor above.
async function locateRedDisplayByPixels(imageBase64) {
    return findDisplayBoxByColor(
        imageBase64,
        (r, g, b) => r > 140 && (r - g) > 60 && (r - b) > 60,
        0.003,
        'red',
    );
}

// Added 2026-08-11 for the "Fairbanks IQ plus 710" cyan/teal LCD indicator
// (see the long comment above findDisplayBoxByColor for how this threshold
// was derived from real sampled pixel data, not guessed). Tried as a second
// fast attempt, after red and before the slow AI locate call — AI locate
// alone was measured taking 5.6-9.9s on these specific photos, which by
// itself ate the entire 9000ms accurate-path budget and threw away an
// otherwise-correct crop+read that finished just after the deadline. This
// avoids that slow call entirely for the common case.
async function locateCyanDisplayByPixels(imageBase64) {
    return findDisplayBoxByColor(
        imageBase64,
        (r, g, b) => g > 120 && b > 120 && (g - r) > 40 && (b - r) > 30,
        0.0015,
        'cyan',
    );
}

// Added 2026-08-12 — root cause found on a real photo (ground-truth 71920):
// the display's red digit pixels and unrelated red content elsewhere in
// frame (rust staining on nearby metalwork, in the case actually measured)
// sit close enough together that R=25 dilation (see findDisplayBoxByColor)
// fuses them into ONE oversized connected component. That merged blob
// correctly fails the sanity-bounds check (too tall to plausibly be a single
// display) and is correctly never offered as a candidate — but it was also
// the ONLY component anywhere near the top of the litCount ranking, so
// nothing else in the list was close enough to qualify either. Net effect:
// red locate returns zero usable candidates even though the real display's
// pixels are sitting right there, just fused into unusable company.
//
// Fix: when — and ONLY when — normal red locate found nothing, re-run
// connected components restricted to JUST that oversized component's own
// bounding box, at a smaller dilation radius (R=12 instead of 25). This is
// small enough to let the merged blob split back apart into its constituent
// pieces (verified on the real photo: splits into a wide-short piece near
// the top of the region — the actual digit strip — and a tall-narrow piece
// below it — the rust-stained frame) while still bridging the gaps within a
// single dot-matrix digit cluster.
//
// This is deliberately NOT folded into findDisplayBoxByColor's normal
// candidate list or its topLitCount-based ranking. Tested directly against
// a currently-CORRECT case (a different real photo where the same "oversized
// top component" signature occurs, but the true display is a cyan/teal
// indicator picked up by locateCyanDisplayByPixels instead): the recovery
// split on THAT photo also produces a plausible-looking, wide-short
// candidate, purely from red-tinted clutter — so if this were returned as
// red's answer with equal standing to a normal candidate, it would win
// before cyan is ever tried (the call site stops at the first non-empty
// candidate list) and silently replace a correct cyan read with a wrong red
// guess. Instead, the caller only reaches for this AFTER cyan has already
// been tried and failed to produce a plausible reading — see the locate
// step below. That ordering is what makes this safe to ship: it can only
// ever get tried in cases that are already failing today (empty red, empty
// or unusable cyan), so it cannot regress a photo that currently works.
async function getRedSplitRecoveryCandidates(imageBase64) {
    if (!sharp) return null;
    try {
        const buf = Buffer.from(imageBase64, 'base64');
        const targetWidth = 500;
        const { data, info } = await sharp(buf)
            .resize({ width: targetWidth, withoutEnlargement: true })
            .removeAlpha()
            .raw()
            .toBuffer({ resolveWithObject: true });
        const { width: w, height: h, channels } = info;
        if (!w || !h) return null;

        const colorTest = (r, g, b) => r > 140 && (r - g) > 60 && (r - b) > 60;
        const mask = new Uint8Array(w * h);
        for (let y = 0; y < h; y++) {
            const rowBase = y * w * channels;
            for (let x = 0; x < w; x++) {
                const i = rowBase + x * channels;
                if (colorTest(data[i], data[i + 1], data[i + 2])) mask[y * w + x] = 1;
            }
        }

        const dilate = (srcMask, R) => {
            const out = new Uint8Array(w * h);
            for (let y = 0; y < h; y++) {
                for (let x = 0; x < w; x++) {
                    if (!srcMask[y * w + x]) continue;
                    const yStart = Math.max(0, y - R), yEnd = Math.min(h - 1, y + R);
                    const xStart = Math.max(0, x - R), xEnd = Math.min(w - 1, x + R);
                    for (let ny = yStart; ny <= yEnd; ny++) {
                        const base = ny * w;
                        for (let nx = xStart; nx <= xEnd; nx++) out[base + nx] = 1;
                    }
                }
            }
            return out;
        };
        const connectedComponents = (srcMask, dilated) => {
            const labels = new Int32Array(w * h).fill(-1);
            let nextLabel = 0;
            const comps = [];
            const stack = [];
            for (let y = 0; y < h; y++) {
                for (let x = 0; x < w; x++) {
                    const idx = y * w + x;
                    if (!dilated[idx] || labels[idx] !== -1) continue;
                    const label = nextLabel++;
                    let minX = x, maxX = x, minY = y, maxY = y, litCount = 0;
                    stack.push(idx); labels[idx] = label;
                    while (stack.length) {
                        const cur = stack.pop();
                        const cy = (cur / w) | 0, cx = cur % w;
                        if (srcMask[cur]) litCount++;
                        if (cx < minX) minX = cx; if (cx > maxX) maxX = cx;
                        if (cy < minY) minY = cy; if (cy > maxY) maxY = cy;
                        if (cx > 0 && dilated[cur - 1] && labels[cur - 1] === -1) { labels[cur - 1] = label; stack.push(cur - 1); }
                        if (cx < w - 1 && dilated[cur + 1] && labels[cur + 1] === -1) { labels[cur + 1] = label; stack.push(cur + 1); }
                        if (cy > 0 && dilated[cur - w] && labels[cur - w] === -1) { labels[cur - w] = label; stack.push(cur - w); }
                        if (cy < h - 1 && dilated[cur + w] && labels[cur + w] === -1) { labels[cur + w] = label; stack.push(cur + w); }
                    }
                    comps.push({ litCount, minX, maxX, minY, maxY });
                }
            }
            comps.sort((a, b) => b.litCount - a.litCount);
            return comps;
        };

        const dilated25 = dilate(mask, 25);
        const comps25 = connectedComponents(mask, dilated25);
        if (!comps25.length) return null;
        const top = comps25[0];
        const topBoxW = (top.maxX - top.minX) / w, topBoxH = (top.maxY - top.minY) / h;
        const topFailsSanity = topBoxW < 0.06 || topBoxH < 0.02 || topBoxW > 0.9 || topBoxH > 0.6;
        if (!topFailsSanity) return null; // not the merged-blob case this exists for — nothing to recover

        const restricted = new Uint8Array(w * h);
        for (let y = top.minY; y <= top.maxY; y++) {
            for (let x = top.minX; x <= top.maxX; x++) {
                const idx = y * w + x;
                if (mask[idx]) restricted[idx] = 1;
            }
        }
        const dilated12 = dilate(restricted, 12);
        const subComps = connectedComponents(restricted, dilated12);
        const sane = subComps.filter((c) => {
            const boxW = (c.maxX - c.minX) / w, boxH = (c.maxY - c.minY) / h;
            return !(boxW < 0.06 || boxH < 0.02 || boxW > 0.9 || boxH > 0.6);
        });
        if (!sane.length) return null;

        // Prefer wide-short pieces (a real single-row digit display) over
        // tall-narrow ones (window frames, rust streaks, cabling) — measured
        // on the real recovery case: true display ~3.5:1 W/H, the frame
        // fragment it was fused with ~0.5:1. This ordering only affects
        // which recovery candidate gets TRIED FIRST among themselves; it
        // does not affect whether cyan gets tried first overall (it always
        // does — see call site).
        sane.sort((a, b) => {
            const aw = (a.maxX - a.minX) / w, ah = (a.maxY - a.minY) / h;
            const bw = (b.maxX - b.minX) / w, bh = (b.maxY - b.minY) / h;
            return (bw / bh) - (aw / ah);
        });

        return sane.slice(0, 3).map((c) => {
            const boxW = (c.maxX - c.minX) / w, boxH = (c.maxY - c.minY) / h;
            const padX = boxW * 0.08, padY = boxH * 0.25;
            return {
                x_min: Math.max(0, c.minX / w - padX),
                y_min: Math.max(0, c.minY / h - padY),
                x_max: Math.min(1, c.maxX / w + padX),
                y_max: Math.min(1, c.maxY / h + padY),
                reason: 'red split-recovery (oversized merged blob split apart at smaller dilation)',
                litCount: c.litCount,
                touchesEdge: false,
            };
        });
    } catch (err) {
        console.warn('[GEMINI] Red split-recovery failed:', err.message);
        return null;
    }
}

// Stage 1, attempt #2 (fallback) — find WHERE the vehicle weighbridge display
// is in the frame using Gemini, for photos the pixel-based locate above
// couldn't confidently handle. Root cause of a real misread on a real yard
// photo (confirmed ground-truth 71920, model read first 37920 then
// 87920): the display occupied a small fraction of a large overhead photo, so
// its leading digits were only a few pixels tall by the time the model saw
// them, and a genuinely dim/blank leading cell's residual dot-matrix glow got
// hallucinated as an extra digit, while the thin "1" digit next to it got
// dropped. Both misreads still nailed the last 3 digits every time (9,2,0) —
// consistent with a resolution/legibility problem concentrated exactly on the
// smallest, dimmest part of the crop, not a random OCR failure. Cropping
// tight to the display and upscaling before the digit-read pass gives the
// model far more effective pixels on exactly the part that was failing.
async function locateDisplayBox(imageBase64, mimeType) {
    // Prompt fixed 2026-08-11 after a real batch of 12 live photos showed
    // this rejecting an entire real display type outright. The OLD version
    // told the model to ignore "a compact bench/platform indicator with
    // physical buttons... and a brand name (Fairbanks...)" as "almost
    // always a separate, smaller scale for individual items" — that rule
    // was reverse-engineered from ONE yard's small companion Fairbanks
    // FB1150 platform scale (real readings: 312/352 lb, clearly individual
    // items) and wrongly generalized. This same yard also has a SEPARATE,
    // legitimate vehicle-weight indicator — a "Fairbanks IQ plus 710" — which
    // has physical buttons, a brand name, AND displays real truck-scale
    // gross weights (confirmed live: 28500, 80720, 28180, 79080 lb, all with
    // an explicit "Gross" mode label on screen). The old prompt rejected
    // every single one of these ("not a large remote vehicle weighbridge
    // display... a compact indicator with numerous physical buttons"),
    // forcing all of them down the much less reliable whole-image fallback,
    // which then picked garbage (the "710" model number, the "100000 lb"
    // capacity rating, digits merged with a nearby "lb" into "790801").
    // Form factor (buttons vs no buttons, branded vs unbranded) is NOT a
    // reliable signal for which display is the real vehicle weight — an
    // explicit Gross/Net/Tare mode label and a truck-scale magnitude are.
    const prompt = `Find the display in this yard photo that shows the WEIGHT OF THE ENTIRE VEHICLE/TRUCK (a load's gross or tare weight), not a small bench/platform scale weighing an individual item.
- Judge by what's actually shown, not the display's physical form factor. A vehicle-weight display can be a large remote/overhead red LED repeater OR a compact indicator unit with physical buttons and a brand name (Fairbanks, Rice Lake, Avery Weigh-Tronix, Mettler Toledo, Cardinal, etc) mounted near the scale — both are legitimate vehicle-weight displays if the number shown is truck-scale.
- Strong signals this IS the vehicle display: an explicit "Gross", "Net", or "Tare" mode label on screen, or a large number (thousands to tens of thousands, e.g. 20000-90000) consistent with a loaded truck.
- Strong signals this is NOT the vehicle display (a small companion item scale instead): a small number (tens to low hundreds, e.g. under 1000) with no Gross/Net/Tare mode label, or a list of several small per-item weights together.
- If more than one display is visible, pick the one whose displayed number and/or mode label indicates a full vehicle/load weight, regardless of which one looks more "official."

Return ONLY raw JSON, no markdown:
{
  "found": false,     // true only if you can confidently locate a vehicle/load weight display
  "x_min": null,       // left edge of a bounding box around the ENTIRE display housing (not just the digits), as a fraction 0-1 of image width
  "y_min": null,       // top edge, fraction 0-1 of image height
  "x_max": null,       // right edge, fraction 0-1 of image width
  "y_max": null,       // bottom edge, fraction 0-1 of image height
  "reason": null        // one short phrase on what you found/why
}
Give the box some margin around the housing rather than cropping tight to the digits themselves. If no vehicle/load weight display is visible at all, return found:false and null for the box fields.`;

    try {
        const model = getClient().getGenerativeModel({
            model: LOCATE_MODEL,
            generationConfig: { temperature: 0, responseMimeType: 'application/json' },
        });
        const result = await model.generateContent([
            { text: prompt },
            { inlineData: { mimeType: mimeType || 'image/jpeg', data: imageBase64 } },
        ]);
        if (process.env.DEBUG_WEIGHT_RAW) console.log('[DEBUG locate raw]', result.response.text());
        const fields = extractJson(result.response.text());
        // Always-on (not gated behind DEBUG_WEIGHT_RAW) — per the owner, every
        // real read was silently skipping the Vision OCR pipeline entirely
        // and falling back to the old whole-image Gemini single-pass read
        // (the exact unreliable behavior Vision OCR was built to replace),
        // and there was no way to tell WHY locate kept saying "not found"
        // without this. This is a warning-level, low-volume line (once per
        // photo, not per digit), worth always having visible in normal logs.
        if (!fields) { console.warn('[GEMINI] Locate step: model response was not valid JSON, falling back to whole image'); return null; }
        if (!fields.found) {
            // Added 2026-08-11 after a real batch-test image turned out to be
            // a screenshot of the dashboard's own "Add New Load" form (not a
            // yard photo at all) — locate correctly said found:false with
            // reason "not a photo of a physical yard or scale display," but
            // the caller still fell through to the whole-image Vision OCR
            // fallback, which grabbed "456" out of unrelated placeholder
            // text ("e.g. 456 Scrap Ave, Dallas, TX") and returned it as a
            // confident, unambiguous weight. Distinguish "this genuinely
            // isn't a scale photo at all" from "it's a real photo but I
            // couldn't confidently place a box" — only the latter should
            // fall through to the noisier whole-image guess; the former
            // should return no reading rather than mine irrelevant text for
            // a plausible-looking number. Deliberately conservative keyword
            // match (screenshot/app/form/UI/not a photo) — a false negative
            // here just falls through to the existing whole-image behavior
            // (no worse than today), a false positive would wrongly refuse a
            // real hard photo, which this narrow phrase set is built to avoid.
            const notAPhoto = /screenshot|not a photo|mobile app|application form|user interface|\bUI\b/i.test(fields.reason || '');
            console.warn(`[GEMINI] Locate step: model reported no display found (reason: "${fields.reason || 'none given'}"), ${notAPhoto ? 'and this does not look like a real yard photo at all — will not guess from whole-image text' : 'falling back to whole image'}`);
            return notAPhoto ? { found: false, notAPhoto: true, reason: fields.reason } : null;
        }
        // Be forgiving of the model returning fractions as strings ("0.155")
        // instead of numbers — same class of issue as the weight field itself.
        const toNum = (v) => typeof v === 'number' ? v : (typeof v === 'string' && v.trim() !== '' && !isNaN(v) ? parseFloat(v) : NaN);
        const x_min = toNum(fields.x_min), y_min = toNum(fields.y_min);
        const x_max = toNum(fields.x_max), y_max = toNum(fields.y_max);
        const nums = [x_min, y_min, x_max, y_max];
        if (nums.some(n => Number.isNaN(n) || n < 0 || n > 1)) {
            console.warn('[GEMINI] Locate step: model returned an out-of-range box, falling back to whole image:', JSON.stringify(fields));
            return null;
        }
        if (x_max <= x_min || y_max <= y_min) {
            console.warn('[GEMINI] Locate step: model returned an inverted/zero-size box, falling back to whole image:', JSON.stringify(fields));
            return null;
        }
        // Added after a real production log showed "Crop step took 1ms" with
        // no explanation — the model had returned a box that passed the
        // checks above (in-range, non-inverted) but was so thin it produced
        // a crop under cropToDisplay's own 20px minimum, which just returns
        // null silently. A degenerate near-zero-size box is functionally the
        // same failure as "no display found" and should be caught here, with
        // a reason logged, instead of failing several steps later with
        // nothing to explain why.
        if ((x_max - x_min) < 0.03 || (y_max - y_min) < 0.01) {
            console.warn(`[GEMINI] Locate step: model returned a degenerate near-zero-size box (${(x_max - x_min).toFixed(4)} x ${(y_max - y_min).toFixed(4)} of frame), falling back to whole image:`, JSON.stringify(fields));
            return null;
        }
        return { x_min, y_min, x_max, y_max, reason: fields.reason || null };
    } catch (err) {
        console.warn('[GEMINI] Display locate step failed, will read whole image instead:', err.message);
        return null;
    }
}

// Measured directly off a real failing photo (pixel brightness, not a guess):
// a dead/unlit LED cell showing only residual dot-matrix "ghost" glow peaked
// at a strict-bright-red column score of 40; genuine lit digit cells in the
// same photo peaked at 158 — 4x brighter. The model kept transcribing that
// ghost glow as a phantom leading digit (37920/87920/371920 instead of
// 71920) no matter how the prompt asked it to judge "is this really lit."
// Fixed at the pixel level instead of the prompt level: scan the located
// display crop column-by-column for genuine bright-red LED pixels, find
// where sustained brightness first reaches a healthy fraction of this
// image's own peak (adaptive per-photo, not a hardcoded absolute value —
// exposure varies shot to shot), and hard-crop everything before that point
// off so the model physically never sees the dead zone it kept
// hallucinating a digit from. Falls back to the untrimmed crop if the signal
// isn't clean enough to trust (never makes the crop worse than not trimming).
async function trimDeadDigitZones(sharpImg, cropW, cropH) {
    try {
        const { data } = await sharpImg
            .clone()
            .removeAlpha()
            .raw()
            .toBuffer({ resolveWithObject: true });
        const channels = 3;
        const colScore = new Float64Array(cropW);
        for (let x = 0; x < cropW; x++) {
            let count = 0;
            for (let y = 0; y < cropH; y++) {
                const i = (y * cropW + x) * channels;
                const r = data[i], g = data[i + 1], b = data[i + 2];
                if (r > 140 && (r - g) > 60 && (r - b) > 60) count++;
            }
            colScore[x] = count;
        }
        const peak = Math.max(...colScore);
        if (peak < 5) return null; // too dim overall to trust this analysis at all

        const threshold = peak * 0.35;
        const win = Math.max(15, Math.round(cropW * 0.03));
        const prefix = new Float64Array(cropW + 1);
        for (let x = 0; x < cropW; x++) prefix[x + 1] = prefix[x] + colScore[x];
        const rollAvg = (start) => (prefix[Math.min(cropW, start + win)] - prefix[start]) / win;

        // Find every contiguous above-threshold run, merging runs that are
        // close together (small gaps are just the dark space between
        // adjacent digit cells — still one "number").
        const runs = [];
        let inRun = false, runStart = 0;
        for (let x = 0; x <= cropW - win; x++) {
            const above = rollAvg(x) >= threshold;
            if (above && !inRun) { inRun = true; runStart = x; }
            if (!above && inRun) { inRun = false; runs.push([runStart, x + win]); }
        }
        if (inRun) runs.push([runStart, cropW]);
        if (runs.length === 0) return null;

        const mergeGap = win * 3;
        const merged = [runs[0].slice()];
        for (let i = 1; i < runs.length; i++) {
            const last = merged[merged.length - 1];
            if (runs[i][0] - last[1] <= mergeGap) last[1] = runs[i][1];
            else merged.push(runs[i].slice());
        }

        // UNION every merged run that's genuinely bright (not just the single
        // widest one). Ghost/residual-glow cells measured on a real photo
        // peaked at ~25% of that photo's brightest column (40 vs 158 — see
        // the comment above this function) — clearly separable from a real
        // lit digit, so a 50% floor safely excludes ghosts while keeping
        // every real digit group. This replaced a "keep only the longest
        // merged run" rule after it silently discarded an entire second
        // digit group on a real 2026-08-10 test photo: a fully bright "8"
        // (peak 312, 100% of that crop's max) sat far enough from the rest of
        // the number that it fell outside the merge distance, and picking
        // "longest" alone threw it away, cropping to a wrong-but-confident
        // number instead of the real one. Union broadly is safe on the
        // non-digit-label front (LB/KG/GR/NT can't pollute a digit-only
        // regex match) but NOT fully safe against a ghost cell that's
        // bright enough to survive this 50% floor — confirmed on a
        // different real photo the same day: extractWeightNumberFromCrop in
        // helpers/visionOcr.js is the actual guard against that now (plain
        // "longest digit run" alone isn't trustworthy on the crop path,
        // exactly like it never was on the whole image).
        const brightEnough = merged.filter((run) => {
            let peakInRun = 0;
            for (let x = run[0]; x < run[1]; x++) if (colScore[x] > peakInRun) peakInRun = colScore[x];
            return peakInRun >= peak * 0.5;
        });
        if (brightEnough.length === 0) return null;
        const runStart2 = Math.min(...brightEnough.map((r) => r[0]));
        const runEnd2 = Math.max(...brightEnough.map((r) => r[1]));

        // Generous margin back toward the edges so we don't shave a real
        // digit's edge off. The rolling window only crosses threshold once a
        // stroke's CORE is under it, so the run boundary sits inside the true
        // digit shape, not at its actual edge — a small margin wasn't enough
        // and a live test came back with the model reporting "leftmost digit
        // is cut off by the left image border." A full window's worth of
        // margin (not half) fixes that without reintroducing the ghost cell,
        // which sits much further away than one window width.
        const margin = win;
        const trimLeft = Math.max(0, runStart2 - margin);
        const trimRight = Math.min(cropW, runEnd2 + margin);
        if ((trimRight - trimLeft) < cropW * 0.25) return null;
        if (trimLeft === 0 && trimRight === cropW) return null; // nothing to trim

        return { left: trimLeft, width: trimRight - trimLeft };
    } catch (err) {
        console.warn('[GEMINI] Dead-zone trim analysis failed, skipping:', err.message);
        return null;
    }
}

// Stage 1.5 — crop to the located box (with padding), trim any dead/ghost
// LED zone off the left or right edge, and upscale, so stage 2 gets a
// zoomed-in, higher-effective-resolution view of ONLY the genuinely lit
// digits instead of it being a small part of a big yard photo plus a dim
// ghost cell it kept misreading. Degrades to null (caller falls back to
// reading the original image) if sharp isn't installed or the crop fails for
// any reason — never blocks a reading.
// opts.boost added 2026-08-11 — see the long comment at its call site in
// extractWeightFromImage for the real-photo evidence behind this. Applies a
// linear contrast stretch + sharpen AFTER the exact same crop/pad/trim
// geometry as the normal path, so it's strictly an additional rescue
// attempt on the identical pixels, never a different crop region — verified
// live against a real hard photo (47.jpeg) where Vision found NOTHING on
// the plain crop but returned a legible (if not perfect) reading on the
// boosted one, three separate contrast strengths tested directly against
// the raw Vision API before this was wired in.
// Added 2026-08-12 — builds Vision's input FROM THE LIT SIGNAL rather than
// from the photo's luminance, and derives its one parameter from the signal's
// own geometry so there is no exposure assumption and no tuned cutoff.
//
// Why this exists. Vision detects text on LUMINANCE, and pure red is only
// ~54/255 luminance, so a red LED display that looks vivid to the eye can be
// nearly flat to Vision on a dark housing or an underexposed shot. Measured on
// real crops from this pipeline, the lit-minus-background luminance gap ran
// from 101 (read perfectly) down to 20 (Vision returned NOTHING AT ALL) and 10
// (Vision read a dim ghost cell as a real digit). An earlier version of this
// code measured that gap and switched renderings below a cutoff of 25 — it
// worked on all five known photos, but the cutoff sat between a measured 20
// and 30, i.e. it was a line drawn through five points, and it would need
// re-tuning the moment a photo landed in between.
//
// The colour test that identifies lit pixels does not have that problem: it is
// relative (r-g, r-b), it is the same test the locate step already relies on to
// find displays at all, and a dim red dot still satisfies it. So rather than
// asking "is this image bright enough for Vision", synthesise an image Vision
// cannot fail on: lit pixels black, everything else white, full contrast by
// construction, whatever the exposure.
//
// The one remaining parameter is how much to close the mask, and that is
// measured, not guessed. A dot-matrix display's mask is hundreds of small
// blobs (individual LEDs) separated by gaps that must be bridged or OCR sees
// speckle; a large or solid-stroke display's mask is a few big blobs that must
// NOT be touched or adjacent strokes merge. The median blob area distinguishes
// them directly, and its own radius (sqrt(area/pi)) is exactly the distance
// needed to bridge to a neighbouring dot. Measured on the real crops:
//     design-6   575 blobs, median    5px -> R=1 -> 73600 clean
//     71920      162 blobs, median   18px -> R=2 -> 71920 clean
//     hardcase   228 blobs, median   24px -> R=3 -> 73600 clean
//     28500       42 blobs, median  336px -> R=8 -> 28500 clean
//     80720       25 blobs, median  499px -> R=8 -> 80720 clean
// All five read correctly, none needing a leading-digit strip, on a single
// Vision call — including the two that previously failed outright.
//
// Closing (dilate then erode) rather than plain dilation: dilation alone was
// measured to fatten dot-matrix digits into unreadable blobs (71920 -> 261,
// hardcase -> 8880). Closing fuses the gaps within a stroke and then returns
// strokes to their original thickness.
async function renderLitSignalForOcr(croppedBase64) {
    if (!sharp || !croppedBase64) return null;
    const { data, info } = await sharp(Buffer.from(croppedBase64, 'base64'))
        .removeAlpha().raw().toBuffer({ resolveWithObject: true });
    const { width: w, height: h, channels: c } = info;
    if (!w || !h) return null;

    const mask = new Uint8Array(w * h);
    let litCount = 0;
    for (let i = 0; i < w * h; i++) {
        const r = data[i * c], g = data[i * c + 1], b = data[i * c + 2];
        const isRed = r > 140 && (r - g) > 60 && (r - b) > 60;
        const isCyan = g > 120 && b > 120 && (g - r) > 40 && (b - r) > 30;
        if (isRed || isCyan) { mask[i] = 1; litCount++; }
    }
    // No lit signal at all means this crop isn't a lit display (or the colour
    // test doesn't cover it) — hand back null so the caller sends the original
    // crop and every existing fallback still applies unchanged.
    if (!litCount) return null;

    // Median blob size — the measurement that sets the radius.
    const seen = new Uint8Array(w * h);
    const sizes = [];
    const stack = [];
    for (let i = 0; i < w * h; i++) {
        if (!mask[i] || seen[i]) continue;
        let n = 0; stack.push(i); seen[i] = 1;
        while (stack.length) {
            const cur = stack.pop(); n++;
            const cy = (cur / w) | 0, cx = cur % w;
            if (cx > 0 && mask[cur - 1] && !seen[cur - 1]) { seen[cur - 1] = 1; stack.push(cur - 1); }
            if (cx < w - 1 && mask[cur + 1] && !seen[cur + 1]) { seen[cur + 1] = 1; stack.push(cur + 1); }
            if (cy > 0 && mask[cur - w] && !seen[cur - w]) { seen[cur - w] = 1; stack.push(cur - w); }
            if (cy < h - 1 && mask[cur + w] && !seen[cur + w]) { seen[cur + w] = 1; stack.push(cur + w); }
        }
        sizes.push(n);
    }
    if (!sizes.length) return null;
    sizes.sort((a, b) => a - b);
    const medianBlob = sizes[Math.floor(sizes.length / 2)];
    // Above this the strokes are already solid (measured: 336-499px on the
    // LCD indicators vs 5-24px on dot-matrix), so closing is capped rather
    // than scaled up indefinitely — the cap is what keeps a big solid display
    // from having its adjacent strokes welded together.
    const radius = Math.max(0, Math.min(8, Math.round(Math.sqrt(medianBlob / Math.PI))));

    const dilateMask = (src, R) => {
        if (R <= 0) return src;
        const out = new Uint8Array(w * h);
        for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
            if (!src[y * w + x]) continue;
            const y0 = Math.max(0, y - R), y1 = Math.min(h - 1, y + R);
            const x0 = Math.max(0, x - R), x1 = Math.min(w - 1, x + R);
            for (let ny = y0; ny <= y1; ny++) { const base = ny * w; for (let nx = x0; nx <= x1; nx++) out[base + nx] = 1; }
        }
        return out;
    };
    const erodeMask = (src, R) => {
        if (R <= 0) return src;
        const out = new Uint8Array(w * h);
        for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
            let keep = 1;
            const y0 = Math.max(0, y - R), y1 = Math.min(h - 1, y + R);
            const x0 = Math.max(0, x - R), x1 = Math.min(w - 1, x + R);
            for (let ny = y0; ny <= y1 && keep; ny++) { const base = ny * w; for (let nx = x0; nx <= x1; nx++) if (!src[base + nx]) { keep = 0; break; } }
            out[y * w + x] = keep;
        }
        return out;
    };

    const closed = radius > 0 ? erodeMask(dilateMask(mask, radius), radius) : mask;
    const grey = Buffer.alloc(w * h);
    for (let i = 0; i < w * h; i++) grey[i] = closed[i] ? 0 : 255; // black digits on white
    const out = await sharp(grey, { raw: { width: w, height: h, channels: 1 } }).jpeg({ quality: 97 }).toBuffer();
    return { base64: out.toString('base64'), radius, medianBlob, blobs: sizes.length };
}

async function cropToDisplay(imageBase64, mimeType, box, opts = {}) {
    if (!sharp || !box) return null;
    try {
        const buf = Buffer.from(imageBase64, 'base64');
        const img = sharp(buf);
        const meta = await img.metadata();
        const w = meta.width, h = meta.height;
        if (!w || !h) return null;

        // Padding around the model's box on each side, clamped to image bounds —
        // the box is around the housing already; a bit more margin protects
        // against a slightly-too-tight box cutting off a digit. Widened
        // specifically for AI-locate boxes 2026-08-11: reproduced live on a
        // real photo where the AI locate path (non-deterministic — a repeat
        // run on the identical photo produced a DIFFERENT, tighter box than
        // the first attempt) cropped off the leading "28" of "28460",
        // leaving just "460" — still numerically plausible on its own, so it
        // slipped through the range check as a confident, wrong, unflagged
        // answer. Pixel-locate boxes (red/cyan) already get their own
        // internal 8%/25% pad before reaching here and have shown no
        // truncation issue, so only the less-precise AI-locate path (no
        // "pixel color analysis" in its reason string) gets the wider margin.
        const isAiLocate = !(box.reason || '').includes('pixel color analysis');
        const padFrac = isAiLocate ? 0.22 : 0.12;
        const padX = (box.x_max - box.x_min) * padFrac;
        const padY = (box.y_max - box.y_min) * padFrac;
        let left = Math.max(0, Math.round((box.x_min - padX) * w));
        let top = Math.max(0, Math.round((box.y_min - padY) * h));
        let right = Math.min(w, Math.round((box.x_max + padX) * w));
        let bottom = Math.min(h, Math.round((box.y_max + padY) * h));
        let cropW = right - left, cropH = bottom - top;
        // Was a silent `return null` — a real production log showed "Crop
        // step took 1ms" with zero explanation for why the accurate path
        // failed. Now it says exactly what box produced the too-small crop,
        // so a degenerate box (from either locate method) is traceable
        // instead of just vanishing into "not ready in time."
        if (cropW < 20 || cropH < 20) {
            console.warn(`[GEMINI] Crop-to-display: box produced a too-small crop (${cropW}x${cropH}px) from box ${JSON.stringify(box)} on a ${w}x${h} image, skipping`);
            return null;
        }

        let finalExtract = { left, top, width: cropW, height: cropH };
        // opts.skipTrim added 2026-08-11 — see the long comment at its call
        // site in extractWeightFromImage for the real-photo evidence. Root
        // cause found by directly comparing the trimmed vs. untrimmed crop
        // bytes on a real hard photo (47.jpeg): the UNTRIMMED crop (2619px)
        // read fine on Vision ("81960"); the SAME crop after
        // trimDeadDigitZones cut it to 1585px and Vision then found ZERO
        // text on it, repeatably, at multiple resolutions/contrast levels.
        // trimDeadDigitZones is real and necessary for the bug it was built
        // for (a dim ghost cell hallucinated as a phantom leading digit —
        // see that function's own comments), so it stays on by default; this
        // is only an opt-out for the specific rescue path that already knows
        // the default crop failed Vision entirely.
        if (!opts.skipTrim) {
            const boxCrop = img.clone().extract({ left, top, width: cropW, height: cropH });
            const trim = await trimDeadDigitZones(boxCrop, cropW, cropH);
            if (trim) {
                finalExtract = { left: left + trim.left, top, width: trim.width, height: cropH };
                console.log(`[GEMINI] Trimmed dead/ghost LED zone off crop edge (${cropW}px -> ${trim.width}px wide)`);
            }
        }

        // Upscale so the crop has real detail to work with — target a
        // ~2000px-wide result (raised from 1400px per the owner: "send it in
        // high resolution to OCR"), capped at 4x to avoid manufacturing fake
        // detail out of a tiny crop (that cap is unchanged — this only gives
        // MEDIUM-sized crops, roughly 500-2000px wide, more effective
        // resolution than before; a crop already bigger than 2000px, or one
        // small enough to already hit the 4x cap, is unaffected). Quality
        // raised 92 -> 97 too: this crop is what Vision actually reads the
        // digits off of, so minimizing JPEG compression artifacts on the
        // sharp red-LED digit edges matters more here than file size.
        const scale = Math.min(4, Math.max(1, 2000 / finalExtract.width));
        let pipeline = img
            .extract(finalExtract)
            .resize({ width: Math.round(finalExtract.width * scale), kernel: 'lanczos3' });
        if (opts.boost) {
            // Values verified live (2026-08-11) against the raw Vision API on
            // a real crop that otherwise returned zero text: linear(1.6,-40)
            // + a light sharpen pulled Vision from "no text detected" to a
            // legible (if imperfect) digit string. Kept moderate rather than
            // the even-stronger (2.0,-60) variant also tested — that one
            // pushed the dim ghost/leading-zero cell bright enough to read as
            // a spurious extra "8", trading one error for another.
            pipeline = pipeline.linear(1.6, -40).sharpen({ sigma: 1.2 });
        }
        const outBuf = await pipeline.jpeg({ quality: 97 }).toBuffer();
        if (process.env.DEBUG_SAVE_CROP) fs.writeFileSync(process.env.DEBUG_SAVE_CROP, outBuf);
        return outBuf.toString('base64');
    } catch (err) {
        console.warn('[GEMINI] Crop-to-display step failed, will read whole image instead:', err.message);
        return null;
    }
}

async function readWeightSinglePass(imageBase64, mimeType = 'image/jpeg', retries = 2, opts = {}) {
    if (!imageBase64) throw new Error('imageBase64 required');
    const isCrop = !!opts.isCrop;

    const cropPreamble = isCrop ? `This image has ALREADY been cropped and zoomed tightly to a single vehicle weighbridge display — you don't need to search for it or compare it against another display, just read it. Because it's zoomed in, expect the digit cells to fill most of the frame.

7-vs-8/9 disambiguation on a zoomed dot-matrix cell: a "7" is an OPEN shape — a top bar plus one diagonal stroke down to the bottom, with genuinely empty (dark) space on the left side of the cell below the top bar. An "8" or "9" is CLOSED or partly closed — there's a second lit stroke on the left side too (forming a loop or partial loop), not just empty dark space. Before calling a digit "8", specifically check whether the lower-left of that cell is truly dark/empty (→ it's a "7") or has its own lit stroke (→ it's an 8/9).

` : '';

    const prompt = `${cropPreamble}You are an expert at reading digital scale (weighbridge) displays from photos — 7-segment LED, LCD, or similar digital readouts. Read the weight value shown as carefully as you would proofread a number you're about to bet money on.

IMPORTANT — this reading is for a LOAD: the weight of an entire vehicle/truck at a weighbridge, not a small item. Yard photos routinely show MORE THAN ONE digital display in frame, serving DIFFERENT purposes, and picking the wrong one is a real, common mistake:
- The VEHICLE WEIGHBRIDGE DISPLAY is what you want for a load reading: often a large remote/overhead signage-style display (commonly red LED digits, mounted high so a truck driver can read it from the cab, sometimes with unit indicator lights like LB/KG/GR/NT down one side, typically no physical buttons on it since it's just a repeater screen). For a whole-vehicle load, THIS is normally the correct number, even though it can be dimmer, angled, or harder to read than a closer compact box — don't downgrade it just because it's harder to read; read it carefully instead.
- A COMPACT BENCH/PLATFORM SCALE INDICATOR — a small desk/wall-mounted box with physical buttons (ZERO, TARE, GROSS/NET, PRINT, UNITS) and a brand name on the bezel (e.g. Fairbanks, Rice Lake, Avery Weigh-Tronix, Mettler Toledo, Cardinal) — is very often a DIFFERENT, smaller scale used for individual items (pallets, samples, small parts), not the vehicle itself. Look for context clues confirming this: a nearby posted list/sign of individual item weights (e.g. "Pallet Weight," a handwritten list of two/three-digit numbers), a small platform under the indicator rather than a vehicle-sized weighing area, or a reading far too small to plausibly be a loaded truck (a scrap-metal truck load is realistically in the thousands to tens of thousands of lb/kg, not double or triple digits).
- If you see BOTH a large remote/overhead vehicle-style display AND a small bench indicator, and they show DIFFERENT numbers, read the large vehicle display for the load weight — the small indicator is almost always for something else entirely, not a more-trustworthy repeat of the same number.
- If only one display is visible, read that one.

Once you've identified the correct display to read:
1. First, count the fixed digit CELLS (character positions) in the display housing, left to right, before reading any values — most weighbridge displays have a fixed number of cells (commonly 5 or 6) even when leading cells show no number. Then assign exactly one character (a digit, or blank) to each cell. Do not merge two adjacent cells into one digit, and do not drop a cell just because its digit looks visually simple (a lone vertical stroke, i.e. "1", is a full digit occupying its own cell — never absorb it into the neighboring digit).
2. Many of these displays are DOT-MATRIX LED (a grid of individual round LEDs per cell), not classic 7-segment bars. On a dot-matrix display, camera sensors very commonly pick up a faint residual glow from the UNLIT dots in a cell (the whole dot grid looks dimly visible even when that cell is truly off) — this is a common false-positive artifact, not a real digit. Leading cells on a weighbridge display are frequently blank (suppressed leading zeros/unused cells), showing only this faint all-dots glow. Do NOT read a dim, low-contrast, evenly-fuzzy glow as a digit shape (people mistake this ambient glow for an "8" or "3" since all dots being faintly on resembles a dense digit) — only assign a digit to a cell when its lit dots are CLEARLY, distinctly brighter than the ambient off-dot glow elsewhere in the same display and form an unambiguous number shape. If a leading cell is genuinely just dim ambient glow with no distinct bright numeral, treat that cell as blank, not as a digit.
3. For 7-segment displays specifically, watch for confusion between: 8 and 0, 5 and 6, 1 and 7, 3 and 9 — look at which segments are actually lit before deciding, don't guess from overall shape alone.
4. After your first pass, re-count: does the number of digits you read match the number of cells you counted in step 1 (minus any blank leading cells)? If you counted 6 cells and only produced 4 digits, you likely merged or dropped one — go back and check each cell individually, especially thin digits like "1" next to a wider neighbor like "7".
5. Note the decimal point position exactly as shown, and any thousands separator.
6. Note the unit label if printed near the number (lb, kg, kgs, ton, tonnes, etc.) — units are often small text or indicator lights near a corner of the display.
7. If glare, blur, a bad angle, or partial occlusion makes any digit genuinely ambiguous, do not guess — return null for the whole weight rather than a half-confident wrong number. A missing reading that gets manually entered is far cheaper than a wrong one that goes uncaught.

Return ONLY raw JSON — no markdown, no prose:
{
  "weight": null,        // number only, decimal point preserved, no thousands separators, e.g. 42350 or 42350.5 — null if not confidently legible
  "weight_unit": null,   // e.g. "lb", "kg", "ton" — null if no unit is visible
  "displays_seen": null, // brief note on what display(s) you found and which you chose, e.g. "large overhead weighbridge display (read) + compact Fairbanks bench indicator, ignored — nearby sign lists individual pallet weights" — helps confirm you scanned for multiple displays and picked correctly
  "raw_text": null       // exactly what you read off the display you chose, as plain text before parsing, e.g. "0 lb (Fairbanks indicator)" — helps a human verify against the photo later. Still fill this in even if weight ends up null, describing what you saw and why it wasn't confident.
}

Never refuse, never return prose outside the JSON.`;

    let lastErr = null;
    let modelName = getVisionModelName();
    let fellBack = false;
    for (let attempt = 0; attempt <= retries; attempt++) {
        try {
            const model = getClient().getGenerativeModel({
                model: modelName,
                generationConfig: { temperature: 0, responseMimeType: 'application/json' },
            });
            const result = await model.generateContent([
                { text: prompt },
                { inlineData: { mimeType: mimeType || 'image/jpeg', data: imageBase64 } },
            ]);
            if (process.env.DEBUG_WEIGHT_RAW) console.log('[DEBUG RAW]', result.response.text());
            const fields = extractJson(result.response.text());
            if (fields) {
                // Be forgiving of a model that ignores the "no thousands separator"
                // instruction — strip commas/spaces before treating it as a number.
                if (typeof fields.weight === 'string') {
                    const cleaned = fields.weight.replace(/[,\s]/g, '');
                    fields.weight = cleaned && !isNaN(cleaned) ? parseFloat(cleaned) : null;
                }
                console.log(`[GEMINI] Weight read (${modelName}): ${fields.weight ?? 'null'} ${fields.weight_unit || ''} (raw: "${fields.raw_text || ''}")`);
                return fields;
            }
            console.warn(`[GEMINI] Weight read returned unparseable JSON (attempt ${attempt + 1}, model ${modelName})`);
        } catch (err) {
            lastErr = err;
            // Model itself unavailable (deprecated/restricted on this account) —
            // switch to the confirmed-working fallback and retry immediately,
            // don't burn a transient-style backoff delay on a non-transient cause.
            if (isModelUnavailableError(err) && !fellBack && modelName !== FALLBACK_VISION_MODEL) {
                console.warn(`[GEMINI] ${modelName} unavailable on this account, falling back to ${FALLBACK_VISION_MODEL}:`, err.message);
                modelName = FALLBACK_VISION_MODEL;
                fellBack = true;
                continue;
            }
            const transient = /503|429|overloaded|unavailable|high demand/i.test(err.message);
            console.error(`[GEMINI] Weight read failed (attempt ${attempt + 1}, model ${modelName}${transient ? ', transient' : ''}):`, err.message);
            if (attempt < retries && transient) { await new Promise(r => setTimeout(r, 1000 * (attempt + 1))); continue; }
            if (attempt >= retries) throw err;
            if (!transient) throw err;
        }
    }
    if (lastErr) throw lastErr;
    return { weight: null, weight_unit: null, raw_text: null };
}

// NOTE: no longer called from extractWeightFromImage's main chain (removed
// when the fallback order was simplified for speed — see the comment above
// extractWeightFromImage). Left in place, unexported, in case a slow-but-
// thorough vote fallback is wanted again later; currently dead code.
// Self-consistency vote: on a genuinely hard photo (dim, angled, blurry),
// even a clean, correctly-cropped image with nothing but the right digits in
// frame still gets misread by the model on some fraction of calls — verified
// live on a real photo: the SAME clean crop came back correct on some calls
// and wrong on others, not because the crop was bad (confirmed by eye each
// time) but because the model's digit-level precision on this exact font/blur
// isn't perfectly reliable call to call, even at temperature 0. Reading it 3x
// and taking whatever at least 2 of 3 agree on is a standard fix for that
// kind of independent, non-repeating error — it doesn't help at all with a
// systematic mistake (which is why the dead-zone trim above still had to be
// a real fix, not just more voting), but it directly helps with a call that
// randomly flips a single digit sometimes and not other times.
function voteOnWeightReadings(results) {
    const valid = results.filter(r => r && r.weight != null);
    if (valid.length === 0) return results.find(r => r) || null;
    const counts = new Map();
    for (const r of valid) {
        const key = String(r.weight);
        if (!counts.has(key)) counts.set(key, []);
        counts.get(key).push(r);
    }
    let best = null;
    for (const group of counts.values()) {
        if (!best || group.length > best.length) best = group;
    }
    const winner = { ...best[0] };
    if (best.length < valid.length) {
        // No unanimous agreement — say so in the fields a human actually reads,
        // since this is exactly when the "check it matches the scale before
        // saving" UI warning matters most.
        const otherReadings = valid.filter(r => !best.includes(r)).map(r => r.weight);
        winner.raw_text = `${winner.raw_text || ''} [${best.length}/${valid.length} reads agreed on ${winner.weight}; other reads got: ${otherReadings.join(', ')} — double-check this one]`.trim();
    }
    return winner;
}

// Public entry point. Cloud Vision OCR is the PRIMARY, most trustworthy
// source of the actual digits (a purpose-built character-recognition model —
// deterministic, verified live to read the exact same image correctly on
// every call, unlike Gemini which flipped between right and wrong on repeat
// calls against an identical image) — this is business-critical (a wrong
// weight is a wrong invoice).
//
// PRIORITY, per the owner explicitly: "i cant afford to have mistakes" outranks
// the earlier "under 5 seconds" ask when the two conflict. Live evidence from
// a real yard photo on 2026-08-10 showed why that ordering matters: the
// cropped/accurate path missed its (then 4000ms) budget, so this fell back to
// reading the WHOLE, uncropped photo — which in that shot also contained a
// second display (a bench scale reading "403 lb") plus other numbers on a
// clipboard in frame. The whole-image path correctly flagged that result
// `ambiguous: true` instead of trusting it silently, which is exactly the
// point of that guard — but a flagged, likely-wrong number is still worse
// than just taking the extra second or two to get the accurate, isolated
// crop read in the first place. ACCURATE_PATH_BUDGET_MS below has been
// widened accordingly, and per-stage timing (locate/crop/vision-on-crop) is
// now logged so a future timing decision is made from real numbers, not
// another guess.
//   1. locateDisplayBox uses the lighter LOCATE_MODEL (see above) instead of
//      the heavyweight digit-reading model — finding a box is a coarser task
//      than reading exact digits.
//   2. The whole locate->crop->Vision-on-crop "accurate path" runs under an
//      ACCURATE_PATH_BUDGET_MS timeout, racing the whole-image Vision OCR
//      call kicked off immediately at the top. The accurate path is strongly
//      preferred (see priority note above) and gets a generous budget; the
//      whole-image reading is the fallback of last resort for when the
//      accurate path genuinely can't produce anything, not a routine
//      speed shortcut.
// The old "Gemini self-consistency vote on the crop" fallback (3 more slow
// Gemini calls) has been dropped from the middle of the chain — it only
// fired when Vision itself had nothing to read on the crop, which is rare,
// and it could add another 12-16s+ on top of everything else. The
// whole-image Gemini single-pass read remains as the final, rare last resort
// if BOTH Vision attempts come back empty.
// Added 2026-08-11. Root-cause analysis this session found that the single
// biggest driver of a wrong weight reading was never the OCR/candidate logic
// downstream — it was bad input: a display partially outside the photo
// frame, or dim/off-angle digits that a color-threshold locate step can't
// see. Every backend retry, cross-check, and race-condition fix this session
// improved the odds AFTER a bad photo was already submitted; none of them
// can recover digits that were never in the shot. The brief was explicit:
// this needs to run with no human checking the number afterward, so the
// only honest way to raise reliability further is to stop bad photos from
// ever entering the pipeline — reject them at the point of capture and have
// the app ask for a retake automatically, the same way a barcode scanner
// or a check-deposit camera refuses a bad frame instead of guessing at it.
// This does NOT ask a human to read or confirm the weight — it's a binary
// "is a full, in-frame display visible" gate, checked automatically.
//
// Deliberately pixel-only (no Gemini call): this needs to return in well
// under a second so a driver retaking a bad photo doesn't feel like the app
// hung. The full accurate path's AI-locate fallback is skipped here on
// purpose — a slightly higher false-retake rate is the right trade against
// a client-side check that takes 5-10s per attempt.
async function checkPhotoQuality(imageBase64, mimeType = 'image/jpeg') {
    if (!sharp) return { ok: true, reason: 'sharp_unavailable' }; // fail open, never block capture over a missing dependency
    try {
        const normalized = await normalizeOrientation(imageBase64);
        let candidates = await locateRedDisplayByPixels(normalized);
        let colorLabel = 'red';
        if (!candidates || !candidates.length) {
            candidates = await locateCyanDisplayByPixels(normalized);
            colorLabel = 'cyan';
        }
        // Deliberately NOT a hard reject. Measured directly: a real photo
        // that the fast pixel-only check finds nothing on can still be read
        // correctly by the full backend pipeline via its Gemini AI-locate
        // fallback (confirmed on the exact 28460 case this check was built
        // against). "Not found" here just means the fast color-threshold
        // heuristic came up empty at low analysis resolution — that is
        // weaker, noisier evidence than edge_cutoff below, which is a
        // specific positive signal. Rejecting on it would force retakes on
        // photos that were already fine, for no measured accuracy gain.
        if (!candidates || !candidates.length) {
            return {
                ok: true,
                reason: 'not_found_but_allowed',
                message: 'No confident display detected by the fast check — the fuller server-side pass may still recover a reading.',
            };
        }
        // Check EVERY returned candidate, not just the largest. The locate
        // step already returns up to 3 (see findDisplayBoxByColor) precisely
        // because the single biggest lit-pixel cluster is sometimes a false
        // positive (a reflection, a glint) that outscores the real display —
        // documented and fixed once already for the main read path. The same
        // trap applies here: if candidate 1 is a bright edge-touching blob
        // but candidate 2 is the real, fully-in-frame display, this gate
        // must not reject a genuinely good photo over the wrong candidate.
        //
        // Added same day, after a real false positive: a candidate can also
        // be a MERGED blob rather than a genuinely edge-touching one — the
        // dilation pass (R=25, meant to bridge gaps between digit segments)
        // can bridge two SEPARATE red objects into one connected component
        // if they're close enough at the ~500px analysis resolution (e.g.
        // the display plus an unrelated red LED elsewhere in the photo,
        // such as a security camera's indicator). That merge drags the
        // component's bounds far past the real display's actual extent,
        // making a fully-in-frame photo look edge-touching. Verified
        // directly on the false positive: every legitimate single-display
        // candidate measured this session has boxH under ~0.32 of frame
        // height; the merged blob measured 0.594 — nearly double. A
        // suspiciously tall box is treated as corrupted evidence, not
        // trusted either way, same as "not found": it's excluded from the
        // edge-touch search entirely rather than allowed to fail the photo.
        const PLAUSIBLE_MAX_BOX_HEIGHT = 0.35;
        const trustworthy = candidates.filter(c => (c.y_max - c.y_min) <= PLAUSIBLE_MAX_BOX_HEIGHT);
        if (candidates.length && !trustworthy.length) {
            console.log(`[GEMINI] Photo quality check (${colorLabel}): only implausibly tall candidate(s) found (likely two red objects merged by dilation) — treating as inconclusive, not a failure`);
            return {
                ok: true,
                reason: 'not_found_but_allowed',
                message: 'No confident display detected by the fast check — the fuller server-side pass may still recover a reading.',
            };
        }
        const clean = trustworthy.find(c => !c.touchesEdge);
        if (!clean) {
            return {
                ok: false,
                reason: 'edge_cutoff',
                message: 'Part of the display looks cut off at the edge of the photo. Back up or reposition so the whole number is visible, then retake.',
            };
        }
        console.log(`[GEMINI] Photo quality check (${colorLabel}): OK, ${candidates.indexOf(clean) === 0 ? 'largest' : `candidate ${candidates.indexOf(clean) + 1}`} candidate does not touch frame edge`);
        return { ok: true, reason: 'confident_box' };
    } catch (err) {
        console.warn('[GEMINI] Photo quality check failed, letting it through:', err.message);
        return { ok: true, reason: 'check_failed' }; // fail open — never let a bug in this gate block a real capture
    }
}

// opts.preCropped — set when the caller has ALREADY isolated the display
// (the mobile app's guided scanner, added 2026-08-17: the user aligns the
// display inside an on-screen box and only those pixels are uploaded). The
// only thing it changes is that the LOCATE stage is skipped: instead of
// searching this image for a display, the whole image IS treated as the
// located crop. Everything downstream — the lit-signal render, the dual
// Vision reads, the corroboration/cross-check logic — runs exactly as it
// always has, so accuracy behavior is unchanged; what's removed is the
// stage that costs the most and fails the most (the AI locate fallback
// alone measures 5.6-9.9s in this file's own logs).
// Minimal Gemini read used ONLY by the scanner agreement gate.
//
// Deliberately NOT readWeightSinglePass: that function carries the full
// pipeline prompt, retry logic and metadata extraction, and measured >4.3s
// in-path — too slow to fit a 5s budget alongside anything else, which is
// why the gate was timing out and never getting a second opinion. This is
// one call, one tightly-scoped prompt, no retries: measured ~2.2s.
//
// The prompt states the two things about THIS display that a general
// prompt gets wrong: the reading is exactly 4 digits, and the leading
// cells are permanently-lit "8.8." placeholders that are not part of the
// weight (confirmed by inspecting the photos — they are fully lit, not
// dim, which is why no brightness filter removes them).
async function leanGeminiWeightRead(imageBase64) {
    const expected = Number(process.env.EXPECTED_WEIGHT_DIGITS) || null;
    const digitRule = expected
        ? `The weight is exactly ${expected} digits.`
        : 'The weight is normally 3 to 5 digits.';
    const prompt = [
        'Close-up of a seven-segment LED weighing indicator.',
        'Read ONLY the large lit weight digits.',
        digitRule,
        "Cells on the LEFT may be permanently lit showing '8.' or '8.8.' — these are NOT part of the weight, ignore them.",
        'Ignore indicator lamps and labels (NET ZERO AC COUNT STABLE oz lb kg) and any button text.',
        'Reply with ONLY the digits. No units, no spaces. If unreadable reply UNKNOWN.',
    ].join('\n');
    try {
        const { GoogleGenerativeAI } = require('@google/generative-ai');
        const model = getClient()
            .getGenerativeModel({ model: cfg.GEMINI_MODEL || 'gemini-2.0-flash' });
        const res = await model.generateContent([prompt, { inlineData: { mimeType: 'image/jpeg', data: imageBase64 } }]);
        const out = (res.response.text() || '').trim();
        if (!/^\d{3,6}$/.test(out)) return null;
        const n = parseInt(out, 10);
        return Number.isFinite(n) ? n : null;
    } catch (err) {
        console.warn('[GEMINI] Lean gate read failed:', err.message);
        return null;
    }
}

async function extractWeightFromImageInner(imageBase64, mimeType = 'image/jpeg', retries = 2, opts = {}) {
    if (!imageBase64) throw new Error('imageBase64 required');
    const preCropped = !!opts.preCropped;
    // Normalize EXIF orientation ONCE, up front, before anything else touches
    // this image. Root cause found 2026-08-11: phone cameras commonly store a
    // photo in raw sensor orientation plus an EXIF tag saying how to rotate
    // it for correct viewing — Google's Vision/Gemini APIs handle that tag
    // correctly, but sharp (used by every locate/crop function below) does
    // NOT auto-apply it unless told to, which is why the whole-image Vision
    // fallback kept producing a reading while the sharp-based locate step
    // kept failing on the exact same photo: it was analyzing a sideways
    // image. Fixed once here instead of patching every function
    // individually — sharp's own .metadata() keeps reporting PRE-rotation
    // width/height even after .rotate() is chained (verified directly, not
    // assumed), so patching each function risked a width/height mismatch
    // between a box's coordinates and what actually gets extracted. One
    // normalize pass here means every downstream .metadata() call is simply
    // correct, no special-casing needed anywhere else.
    imageBase64 = await normalizeOrientation(imageBase64);
    mimeType = 'image/jpeg'; // normalizeOrientation always re-encodes as JPEG
    const t0 = Date.now();
    const elapsed = () => `${Date.now() - t0}ms`;

    // TOTAL wall-clock budget for one weight read, per the owner 2026-08-19
    // ("make it 5s"). Previously each stage had its OWN timeout (the
    // compact-indicator branch alone allowed 8s for Gemini) with nothing
    // capping the SUM, so a real read measured ~10-14s end to end.
    // Expressing it as one budget is what actually makes "5s" true: every
    // remaining wait below asks how much of the budget is left rather than
    // starting its own fresh clock.
    //
    // WHAT THIS TRADES AWAY, stated plainly: the Gemini cross-check is not
    // decoration on this display. Measured on the owner's own 10-photo Socome
    // corpus, Cloud Vision alone scores 7/10 with 2 confidently-wrong reads;
    // the cross-check is what has been catching those. When the budget
    // expires before Gemini answers, the pipeline still returns Vision's
    // number but marks it ambiguous, which surfaces in both UIs as a loud
    // "double-check against the scale before saving" warning. So the cost
    // of 5s is more flagged reads needing a human glance, NOT silently
    // wrong ones — the flag is the safety net that makes this acceptable.
    // Raise WEIGHT_READ_BUDGET_MS to buy back cross-checking; lower it for
    // speed at the cost of more flags.
    // A SCANNER capture (opts.preCropped) gets a much tighter budget than a
    // loose photo, because the hard part is already done. Measured on
    // the owner's 10-photo Socome corpus with the display framed the way the
    // scanner's box frames it — just the weight digits, no surrounding
    // panel — Cloud Vision alone read them in 389ms average. The same
    // photos left uncropped needed 5-17s and were LESS accurate, because
    // the pipeline was spending that time locating the display and then
    // arguing with Gemini about digits that a tight crop simply doesn't
    // get wrong.
    //
    // This is the real answer to "a person in the yard won't wait 10s":
    // the long reads were never the OCR being slow, they were the pipeline
    // compensating for a badly-framed image. Give it a good frame and the
    // compensation isn't needed.
    // opts.budgetMs — a caller that will ask again shortly wants a fast no
    // rather than a slow maybe. The live scanner sets it: it reads the same
    // display every 700ms, so a frame that cannot be read quickly is worth
    // abandoning, and the full slow pipeline is wasted effort on a frame that
    // is about to be replaced. Measured why this matters: a hopeless image
    // took 5.6s per attempt, so ten attempts spent nearly a minute before the
    // scanner gave up. Absent, behaviour is exactly as before.
    const TOTAL_BUDGET_MS = Number(opts.budgetMs)
        || Number(process.env.WEIGHT_READ_BUDGET_MS)
        || (opts.preCropped ? 5000 : 5000);
    // Never returns 0 — a tiny non-zero floor means a Gemini call that is
    // just about to resolve still gets a chance, instead of the budget
    // being spent entirely by an unlucky earlier stage.
    const remainingBudget = () => Math.max(600, TOTAL_BUDGET_MS - (Date.now() - t0));

    // ── SCANNER FAST PATH ────────────────────────────────────────────────
    // For a scanner capture the operator has already framed the display, so
    // the crop IS the answer — read it plainly and return.
    //
    // This deliberately BYPASSES the locate/lit-signal-render/ghost-strip/
    // rescue machinery below. That machinery exists to rescue a badly framed
    // photo, and measurement showed it actively HARMS a well-framed one:
    // on the owner's 10-photo Socome corpus, framed as the scanner frames them,
    //     plain Vision on the crop  -> 7/10 correct, 1 wrong, ~389ms
    //     same crops through the full pipeline -> 5/10 correct, 3 wrong, ~2s
    // The pipeline turned 3815 into 1815 and 3599 into 6656 by "improving"
    // an image that needed no improvement. Simpler is both faster AND more
    // accurate here, which is not the usual trade and is worth stating.
    //
    // Falls through to the full pipeline when Vision produces nothing
    // plausible, so a genuinely hard capture still gets the slow, careful
    // treatment rather than an immediate failure.
    if (opts.preCropped) {
        // RESOLVED 2026-08-27. The note that stood here said the integrated
        // path scored 6/10 while the standalone gate scored 8/10, that the
        // Vision leg "appears to be resolving null in here", and that
        // EXPECTED_WEIGHT_DIGITS had been checked and eliminated. Re-measured
        // end-to-end on the same 10 photos, all three of those were wrong:
        //   - The Vision leg was never resolving null. It was returning a
        //     ghost-contaminated number (83475 for a true 3475), which is
        //     in range and therefore looks like a confident read.
        //   - EXPECTED_WEIGHT_DIGITS was not eliminated, it was the whole
        //     gap. It is read in two places and set in none — no config
        //     default, no .env.example — so the rightmost-N rule that makes
        //     883475 resolve to 3475 has never once run in production.
        //   - The 6/10 vs 8/10 split was exactly that: with the variable
        //     unset the run scores 6/10, with it set to 4 it scores 8/10.
        // Setting it to 4 is NOT the fix — see the long note in visionOcr.js;
        // it would silently truncate the 5-digit weighbridge. The fix is the
        // ghost-prefix corroboration below, which reaches the same 8/10 with
        // the variable still off.
        // Current measured result, EXPECTED_WEIGHT_DIGITS unset:
        //     8/10 correct, 2 flagged, 0 wrong-and-unflagged
        //     median 1.8s, worst case 5.6s (both engines fail -> full pipeline)
        // The safety property has held in every run: nothing incorrect is
        // published without a "verify against the display" flag.
        const tFast = Date.now();
        try {
            // CONFIDENCE LANE. One Vision call, ~350ms, no second opinion.
            //
            // Vision reports a confidence per SYMBOL, and on this display the
            // permanently-lit placeholder cells score 0.35-0.74 while the real
            // digits score 0.95+. That makes the ghost removable
            // deterministically rather than by hoping a second engine happens
            // to disagree in the right direction — see the long note in
            // visionOcr.js, including why this is not the pooled-confidence
            // gate that was measured useless and abandoned.
            //
            // Measured on the Socome corpus: 7 of 10 photos come back
            // trustworthy and correct here at ~350ms, including all three
            // ghost photos that used to cost a full Gemini wait. The known
            // bad read (4896 for a true 4146) scores 0.50 and is NOT
            // trustworthy, so it falls through to the slower corroboration
            // path instead of being published — which is a better outcome
            // than the old one, where it was published-but-flagged.
            //
            // DOCUMENT_TEXT_DETECTION is what carries per-symbol confidence,
            // and it is not a tax: measured at a median 333ms against 416ms
            // for the plain TEXT_DETECTION call it replaces here.
            try {
                const withConf = await withTimeout(
                    visionOcr.detectTextWithConfidence(imageBase64),
                    Math.min(2000, remainingBudget()), 'Scanner confidence read',
                );
                const picked = withConf && withConf.runs ? visionOcr.extractWeightFromRuns(withConf.runs) : null;
                if (picked && picked.trustworthy) {
                    const confMs = Date.now() - tFast;
                    const ghostNote = picked.strippedGhost
                        ? ` after dropping the low-confidence leading "${picked.strippedGhost}" (placeholder cells)`
                        : '';
                    console.log(`[GEMINI] Scanner confidence lane: read ${picked.weight}${ghostNote} at min symbol confidence ${picked.minConf.toFixed(2)} in ${confMs}ms — accepting`);
                    return {
                        weight: picked.weight, alternate_weight: null, alternate_source: null, weight_unit: 'lb',
                        displays_seen: 'scanner crop — every digit read at high per-symbol confidence',
                        raw_text: `${withConf.text || picked.rawRun} (scanner confidence lane — min symbol confidence ${picked.minConf.toFixed(2)}${ghostNote})`,
                        ambiguous: false,
                    };
                }
                if (picked) {
                    console.log(`[GEMINI] Scanner confidence lane: read ${picked.weight} but min symbol confidence is only ${picked.minConf.toFixed(2)} — not trusting it alone, corroborating`);
                }

                // BURST AGREEMENT. Only reached when the primary frame was NOT
                // confident on its own, so this costs nothing on the ~7-in-10
                // scans that already answered above.
                //
                // The scanner sends several frames grabbed off the live
                // preview about 150ms apart. The weight on the display does
                // not change in that window; the sensor noise does. So two
                // frames landing on the same number is independent evidence,
                // in a way that re-rendering one frame is provably not — the
                // greyscale pass reproduces the plain read's ghost digit
                // exactly, which is why frames and not filters.
                //
                // Aimed squarely at the known failure: an overexposed capture
                // where the segments bleed together and Vision returns a
                // confident-looking 4896 for a true 4146. A neighbouring frame
                // with slightly different exposure reads it correctly, and two
                // frames agreeing beats one frame insisting.
                const extraFrames = Array.isArray(opts.extraFrames) ? opts.extraFrames.slice(0, 4) : [];
                if (extraFrames.length) {
                    const tBurst = Date.now();
                    const reads = await Promise.all(extraFrames.map(async (f) => {
                        try {
                            const wc = await withTimeout(visionOcr.detectTextWithConfidence(f), Math.min(2000, remainingBudget()), 'Scanner burst frame');
                            return wc && wc.runs ? visionOcr.extractWeightFromRuns(wc.runs) : null;
                        } catch (e) { return null; }
                    }));
                    const all = [picked, ...reads].filter((r) => r && r.weight != null);
                    // Count how many DISTINCT frames produced each number, and
                    // require the winner to be backed by at least two of them.
                    const tally = new Map();
                    for (const r of all) {
                        const cur = tally.get(r.weight) || { n: 0, bestConf: 0 };
                        cur.n += 1;
                        cur.bestConf = Math.max(cur.bestConf, r.minConf || 0);
                        tally.set(r.weight, cur);
                    }
                    let winner = null;
                    for (const [weight, v] of tally) {
                        if (v.n < 2) continue;
                        // A tie on count is broken by confidence, never by
                        // which frame happened to arrive first.
                        if (!winner || v.n > winner.n || (v.n === winner.n && v.bestConf > winner.bestConf)) {
                            winner = { weight, n: v.n, bestConf: v.bestConf };
                        }
                    }
                    const burstMs = Date.now() - tBurst;
                    if (winner) {
                        const total = all.length;
                        console.log(`[GEMINI] Scanner burst: ${winner.n} of ${total} frames read ${winner.weight} (best confidence ${winner.bestConf.toFixed(2)}) in ${burstMs}ms — accepting`);
                        return {
                            weight: winner.weight, alternate_weight: null, alternate_source: null, weight_unit: 'lb',
                            displays_seen: `${winner.n} of ${total} camera frames independently read the same number`,
                            raw_text: `burst of ${total} frames — ${winner.n} agreed on ${winner.weight}, best symbol confidence ${winner.bestConf.toFixed(2)}`,
                            ambiguous: false,
                        };
                    }
                    console.log(`[GEMINI] Scanner burst: ${all.length} frames produced ${tally.size} different numbers in ${burstMs}ms — no majority, corroborating`);
                }
            } catch (err) {
                console.warn('[GEMINI] Scanner confidence lane failed, falling through:', err.message);
            }

            // AGREEMENT GATE. Cloud Vision and Gemini read the same crop in
            // PARALLEL, and the number is published only when they
            // independently agree.
            //
            // Measured on the owner's 10-photo Socome corpus, framed as the
            // scanner frames them:
            //     agreed on 8/10 — and all 8 were CORRECT (no false accepts)
            //     disagreed on 2 — flagged instead of guessed
            // Vision alone was 8/10 with 1 confidently WRONG read (4396 for a
            // true 4146). The gate converts that wrong answer into a flag,
            // which is the whole point: on a weight ticket, "please check
            // this one" is recoverable and a silently wrong number is not.
            //
            // Parallel, so the cost is the slower of the two (~2.3s) rather
            // than the sum, and both are bounded by the budget.
            const visionP = withTimeout(visionOcr.detectText(imageBase64), Math.min(2000, remainingBudget()), 'Scanner Vision read')
                .then((t) => {
                    const ex = t ? visionOcr.extractWeightNumberFromCrop(t) : null;
                    return {
                        weight: ex && ex.weight != null ? ex.weight : null,
                        text: t,
                        // Carried through so the gate below can tell a clean
                        // read from a speculative one, and can see the other
                        // readings a ghost strip would give. Both were being
                        // dropped here, which is why the gate could only ever
                        // compare Vision's single guess against Gemini's.
                        viaLeadingStrip: !!(ex && ex.viaLeadingStrip),
                        candidates: (ex && ex.candidates) || [],
                    };
                }).catch(() => ({ weight: null, text: null, viaLeadingStrip: false, candidates: [] }));
            const geminiP = withTimeout(
                leanGeminiWeightRead(imageBase64),
                Math.min(4000, remainingBudget()), 'Scanner Gemini read',
            ).catch(() => null);

            // SECOND VISION RENDERING, for speed. Measured 2026-08-27 on the
            // Socome corpus: the Vision leg is a median 698ms and the Gemini
            // leg a median 1677ms, so Promise.all on both means every single
            // scan waits on Gemini. That 1.6s is a floor, not a tuning
            // problem — disabling thinking saved 80ms, shrinking the crop to
            // 480px saved nothing (they are already 8-33KB), gemini-3.6-flash
            // is SLOWER at 2.3-3.4s, and the 2.0 models are retired. The only
            // way to be faster is to stop waiting for it when we already have
            // enough evidence.
            //
            // TWO different renderings, because one is not enough. A binary
            // threshold rebuilds the separation between segments that a
            // low-contrast photo loses, but it goes blind on a dim crop —
            // measured, it returned nothing on 4 of the 10 photos. Greyscale
            // + normalise is the opposite: it produces a number on 9 of 10.
            // Running both, in parallel with the plain read, costs no extra
            // wall time (~350ms each, overlapped) and roughly doubles how
            // often the fast lane can fire.
            const renderAndRead = async (label, transform) => {
                // No sharp means no second rendering, which just costs speed:
                // the gate falls through to the Gemini wait exactly as before.
                if (!sharp) return null;
                try {
                    const buf = await transform(sharp(Buffer.from(imageBase64, 'base64'))).jpeg({ quality: 97 }).toBuffer();
                    const t = await withTimeout(visionOcr.detectText(buf.toString('base64')), Math.min(2000, remainingBudget()), `Scanner ${label} read`);
                    const ex = t ? visionOcr.extractWeightNumberFromCrop(t) : null;
                    return ex && ex.weight != null ? { weight: ex.weight, viaLeadingStrip: !!ex.viaLeadingStrip, label } : null;
                } catch (e) { return null; }
            };
            const secondVisionP = Promise.all([
                renderAndRead('threshold', (s) => s.greyscale().threshold(120)),
                renderAndRead('greyscale', (s) => s.greyscale().normalise()),
            ]);

            const [vis, renders] = await Promise.all([visionP, secondVisionP]);
            // Any rendering that landed on exactly the plain read corroborates
            // it. Renderings that disagree are ignored rather than treated as
            // a veto — measured, the greyscale pass returns confident garbage
            // on a crop it handles badly (6204 for a true 4223) while the
            // threshold pass reads it correctly, so letting either one veto
            // would surrender the speed win to the noisier of the two.
            // Nothing is accepted on a rendering's say-so alone; it only ever
            // confirms a number the plain read already produced.
            const second = renders.find((r) => r && vis.weight != null && r.weight === vis.weight) || null;

            // FAST LANE. Two independent renderings of the crop produced the
            // same number and Vision did not have to guess at a ghost cell to
            // get there — return now, ~450ms, without waiting on Gemini.
            //
            // The viaLeadingStrip exclusion is what makes this safe, and it
            // is not a guess: measured, a greyscale rendering REPEATS the
            // ghost error (plain 83475 / grey 83475 on a true 3475), so
            // Vision-vs-Vision corroboration is worthless on exactly the
            // ghost photos and would have published 2 wrong numbers as
            // confident. Ghosts are a correlated failure between renderings;
            // they are precisely what viaLeadingStrip marks, and they are
            // precisely what Gemini is good at. So the ghost cases still pay
            // the full Gemini wait, and everything else does not.
            //
            // The wrong-and-unflagged count stays 0 across the corpus under
            // this rule, which is the property that must not regress.
            if (vis.weight != null && !vis.viaLeadingStrip && second && !second.viaLeadingStrip) {
                const fastMs = Date.now() - tFast;
                console.log(`[GEMINI] Scanner fast lane: the plain and ${second.label} renderings both read ${vis.weight} in ${fastMs}ms — accepting without waiting for Gemini`);
                geminiP.catch(() => {});
                return {
                    weight: vis.weight, alternate_weight: null, alternate_source: null, weight_unit: 'lb',
                    displays_seen: 'two independent renderings of the scanner crop agreed',
                    raw_text: `${vis.text} (scanner fast lane — the plain and ${second.label} renderings agreed)`,
                    ambiguous: false,
                };
            }

            const gem = await geminiP;
            const ms = Date.now() - tFast;

            if (vis.weight != null && gem != null && vis.weight === gem) {
                console.log(`[GEMINI] Scanner agreement gate: Vision and Gemini both read ${vis.weight} in ${ms}ms — accepting`);
                return {
                    weight: vis.weight, alternate_weight: null, alternate_source: null, weight_unit: 'lb',
                    displays_seen: 'Cloud Vision + Gemini independently agreed on the scanner crop',
                    raw_text: `${vis.text} (scanner agreement gate — two independent reads agreed)`,
                    ambiguous: false,
                };
            }
            // GHOST-PREFIX CORROBORATION. The two engines can disagree for a
            // boring, well-understood reason: Vision kept a leading ghost
            // cell that Gemini dropped. Measured on the Socome corpus,
            // Vision read 83475 where Gemini read 3475, and 83939 where
            // Gemini read 3939 — in both cases Gemini was right and the gate
            // published Vision's wrong number with a flag.
            //
            // So before calling it a disagreement, check whether Gemini's
            // number is exactly one of the readings a ghost strip of
            // Vision's own text would produce, with a ghost-like prefix
            // (leading 8/9/0 — the permanently-lit "8.8." cells). If it is,
            // the two engines actually read the SAME digits and only differ
            // on the placeholder, so this is an agreement, not a conflict.
            //
            // Deliberately narrow: the prefix must look like ghost
            // contamination. That is what stops a genuine 5-digit weighbridge
            // reading from collapsing — 81460 only becomes 1460 if Gemini
            // independently said 1460, and stripping the "4" off a misread
            // 4896 is not eligible at all.
            //
            // Gated on viaLeadingStrip — i.e. only when VISION ITSELF already
            // signalled that its reading is speculative because the raw text
            // was out of range. Without that condition this rule opens a new
            // false accept: Vision reads a clean, correct 81460 off the
            // weighbridge, Gemini misreads it as 1460, the leading "8" looks
            // ghost-like, and the gate publishes 1460 as confident — a case
            // the old gate would have flagged. Requiring Vision to have
            // already doubted itself means the ghost hypothesis is only ever
            // applied where there is real evidence for it, and a clean
            // in-range read can still only be overturned by exact agreement.
            if (vis.viaLeadingStrip && vis.weight != null && gem != null && vis.weight !== gem) {
                const corroborated = (vis.candidates || []).find((c) => c.ghostLike && c.value === gem);
                if (corroborated) {
                    console.log(`[GEMINI] Scanner agreement gate: Vision read ${vis.weight} and Gemini read ${gem} in ${ms}ms — "${corroborated.prefix}" is a leading ghost cell, both engines read the same digits, accepting ${gem}`);
                    return {
                        weight: gem, alternate_weight: null, alternate_source: null, weight_unit: 'lb',
                        displays_seen: 'Cloud Vision + Gemini agreed on the digits once the leading ghost cell was discounted',
                        raw_text: `${vis.text} (scanner agreement gate — Vision's "${corroborated.prefix}" prefix is the display's permanently-lit placeholder)`,
                        ambiguous: false,
                    };
                }
            }

            // Disagreement, or only one engine produced a number. Return the
            // one we have but FLAG it — the UI shows a "check against the
            // scale" warning. Returning something beats making the operator
            // re-shoot when one engine read it fine.
            //
            // When Vision's number came from a speculative leading strip and
            // Gemini produced a plausible number of its own, prefer GEMINI's:
            // Vision's is a guess about which cells were real, Gemini's is a
            // direct read. This file already recorded the case that proves it
            // (Vision "817520" -> stripped to 17520; Gemini said 87520 and
            // the display, checked by eye, was 87520). Still flagged either
            // way — this only changes which of two uncertain numbers the
            // operator is shown first.
            const preferGemini = vis.viaLeadingStrip && vis.weight != null && gem != null && vis.weight !== gem;
            const only = preferGemini ? gem : (vis.weight != null ? vis.weight : gem);
            if (only != null) {
                console.log(`[GEMINI] Scanner gate DISAGREED in ${ms}ms (Vision ${vis.weight}, Gemini ${gem}) — returning ${only} flagged for review`);
                return {
                    weight: only,
                    alternate_weight: (vis.weight != null && gem != null && vis.weight !== gem) ? (only === vis.weight ? gem : vis.weight) : null,
                    alternate_source: (vis.weight != null && gem != null && vis.weight !== gem) ? (only === vis.weight ? 'Gemini' : 'Cloud Vision') : null,
                    weight_unit: 'lb',
                    displays_seen: 'scanner crop — the two independent reads did not agree',
                    raw_text: `${vis.text || ''} [Vision read ${vis.weight}, Gemini read ${gem} — they disagree, so verify against the display before saving]`,
                    ambiguous: true,
                };
            }
            console.log(`[GEMINI] Scanner gate: neither engine produced a plausible weight in ${ms}ms — falling through to the full pipeline`);
        } catch (err) {
            console.warn('[GEMINI] Scanner fast path failed, falling through:', err.message);
        }

        // opts.fastOnly — the caller is reading the display continuously and
        // another frame is already on the way.
        //
        // This is deliberately NOT a timeout. Nothing in flight gets cut off;
        // the slow pipeline simply never starts, because its whole purpose is
        // to wring an answer out of ONE image and this caller has a stream of
        // them. Spending 5s rescuing a frame that will be replaced in 700ms is
        // wasted work AND makes the scanner feel stuck — the frame after it
        // has a different exposure and a different blur, and is usually the
        // easier read anyway.
        //
        // Returns an empty read rather than throwing, so the live loop just
        // treats it as "nothing this time" and carries on. No abandonment, no
        // cut-off answer, no re-open.
        if (opts.fastOnly) {
            return {
                weight: null, alternate_weight: null, alternate_source: null, weight_unit: 'lb',
                displays_seen: 'live frame — no confident read, waiting for the next frame',
                raw_text: 'live scan frame produced nothing certain; the next frame will be read instead',
                ambiguous: true,
                fastOnlyMiss: true,
            };
        }
    }

    // Added 2026-08-11 to end a genuinely expensive class of confusion: the
    // client (dashboard AND the separately-bundled mobile APK) decides what
    // resolution to send, and NOTHING in these logs ever showed what
    // actually arrived. That cost hours — a client-side resolution fix was
    // shipped, deployed, and re-tested three times while it was impossible
    // to tell from the logs whether the photo being read was the new
    // full-resolution one or the old 1600px-capped one, because every other
    // number in the log (locate is done on a shrunk copy; crop widths are
    // easy to misread) looks similar either way. One line, printed before
    // anything else runs, makes "is the client fix actually live on this
    // device" a fact instead of an argument. Failures here are swallowed —
    // this is diagnostics, it must never break a real read.
    // lowResInput drives a real behavior change below (see the primary crop
    // call), not just logging — added 2026-08-11 after a live case (a photo
    // that arrived at 768x1024, source unknown — could be camera or
    // gallery, and per direct instruction that distinction shouldn't matter)
    // measured a wrong read (89520 vs true 81528) that a full-resolution
    // version of the same photo read correctly. Since the client's chosen
    // resolution can't always be controlled or even diagnosed from here, the
    // backend now adapts instead of just logging the problem: any input
    // under LOWRES_THRESHOLD gets the same contrast-boost+sharpen treatment
    // already proven to rescue marginal crops (previously rescue-path-only),
    // applied on the FIRST attempt instead of only after a failure.
    const LOWRES_THRESHOLD = 1400;
    let lowResInput = false;
    try {
        if (sharp) {
            const inMeta = await sharp(Buffer.from(imageBase64, 'base64')).metadata();
            const kb = Math.round((imageBase64.length * 3) / 4 / 1024);
            lowResInput = Math.max(inMeta.width || 0, inMeta.height || 0) < LOWRES_THRESHOLD;
            console.log(`[GEMINI] Received image: ${inMeta.width}x${inMeta.height}px, ~${kb}KB base64${lowResInput ? ` — below ${LOWRES_THRESHOLD}px, applying contrast-boost on the primary read` : ''} — if width is ~1600 the client is still applying the OLD downscale cap (expect full sensor resolution, typically 3000-4000px, from an up-to-date client)`);
        }
    } catch (err) {
        console.warn('[GEMINI] Could not read incoming image dimensions:', err.message);
    }

    // Started now, awaited later — a single Vision OCR call on the whole
    // photo, no Gemini locate step first. Kept as the last-resort fallback
    // for when the accurate path genuinely fails (box never found, crop
    // fails, or Vision finds nothing on the crop) — NOT a routine speed
    // shortcut; see the priority note above.
    // wholeImageTextSoFar is a non-blocking PEEK at that same result, used
    // only to classify the display type (see
    // looksLikeCompactIndicatorFromVisionText). Deliberately a peek rather
    // than an await: this call runs in parallel with the crop read, and
    // awaiting it on the fast path would make every read wait for the
    // slower of the two. By the time the crop has been read this has
    // almost always resolved; when it hasn't, it's simply null and
    // classification falls back to the crop text alone — i.e. exactly the
    // old behaviour, never worse.
    let wholeImageTextSoFar = null;
    const wholeImageVisionPromise = visionOcr.detectText(imageBase64).then((t) => {
        wholeImageTextSoFar = t;
        return t;
    }).catch((err) => {
        console.warn('[GEMINI] Whole-image Vision OCR failed:', err.message);
        return null;
    });

    // The more ACCURATE path — isolate the display, upscale it, then read it
    // with Vision — wrapped as one promise so it can be raced against a hard
    // time budget below instead of being awaited step-by-step with no limit.
    // Per-stage timestamps are logged so a slow real-world run tells us
    // exactly which stage to fix instead of just "it was slow somewhere."
    const accuratePathPromise = (async () => {
        const tLocateStart = Date.now();
        // Guided-scanner capture: the client already framed and cropped the
        // display, so there is nothing to locate — the full frame IS the
        // box. Expressed as a normal single candidate so every stage below
        // (crop, lit-signal render, dual Vision reads, cross-check) runs
        // completely unchanged; only the locate calls are bypassed.
        let candidates = preCropped
            ? [{ x_min: 0, y_min: 0, x_max: 1, y_max: 1, reason: 'client-side scanner bounding box' }]
            : await locateRedDisplayByPixels(imageBase64);
        let locateSource = preCropped ? 'client scanner bounding box (locate skipped)' : 'red pixel color analysis';
        // Try the fast, deterministic, no-network pixel locates first — red
        // (the overhead weighbridge repeater), then cyan (the "IQ plus 710"
        // indicator, added 2026-08-11). Only fall to the slow AI-based
        // locateDisplayBox (network call, measured 5.6-9.9s on real IQ710
        // photos — enough by itself to blow the whole accurate-path budget)
        // if NEITHER pixel approach can confidently place a box.
        if (!candidates || !candidates.length) {
            // Cyan is tried FIRST, exactly as before this change — that
            // ordering is load-bearing (see getRedSplitRecoveryCandidates'
            // comment): a real photo exists where red's merged-blob signature
            // looks identical whether the true display is red or cyan, and
            // only trying cyan first (and accepting its answer immediately
            // if it reads a plausible weight, via the existing per-candidate
            // loop below) keeps that case correct. Red split-recovery is
            // appended AFTER cyan's candidates, not instead of them, so it only
            // ever gets a turn once cyan has already been tried and failed —
            // it cannot preempt a working cyan read.
            const cyanCandidates = await locateCyanDisplayByPixels(imageBase64);
            const redRecoveryCandidates = await getRedSplitRecoveryCandidates(imageBase64);
            const merged = [...(cyanCandidates || []), ...(redRecoveryCandidates || [])];
            if (merged.length) {
                candidates = merged;
                locateSource = cyanCandidates && cyanCandidates.length
                    ? (redRecoveryCandidates && redRecoveryCandidates.length ? 'cyan pixel color analysis + red split-recovery fallback' : 'cyan pixel color analysis')
                    : 'red split-recovery (oversized merged blob split apart)';
            }
        }
        if (!candidates || !candidates.length) {
            const locateImg = await shrinkForLocate(imageBase64, mimeType);
            const aiBox = await locateDisplayBox(locateImg, mimeType);
            // aiBox can now be a { notAPhoto: true } sentinel (see
            // locateDisplayBox) instead of a real box or null — a real box
            // always has x_min etc, so check specifically rather than just
            // truthiness, which would otherwise treat the sentinel as a
            // (broken) candidate.
            if (aiBox && aiBox.notAPhoto) {
                console.log(`[GEMINI] Locate step (Gemini) took ${Date.now() - tLocateStart}ms (total ${elapsed()}) — not a scale photo at all, skipping the rest of the accurate path`);
                return { notAPhoto: true };
            }
            candidates = aiBox ? [aiBox] : null;
            locateSource = 'Gemini (pixel locate found nothing confident)';
        }
        // Added 2026-08-12 — found by actually LOOKING at the crop being fed
        // to OCR on the hardest remaining photo (true value 73600, misread as
        // 73500/79600 by BOTH Vision and Gemini across many runs). The crop
        // turned out not to be a display crop at all: it was a tall vertical
        // slice containing the real red weighbridge display CLIPPED THROUGH
        // THE DIGITS at its top edge, plus a Fairbanks bench indicator
        // reading 363, plus a printed pallet-weight sheet listing 312Lb /
        // 352Lb. That explains the whole "both models independently agree on
        // the same wrong number" mystery that defeated the cross-check and
        // voting work: they weren't failing to read digits, they were
        // faithfully reading digits whose tops had been sliced off (a "3"
        // with its top bar cut looks exactly like a 9 or 5).
        //
        // The bad box came from the CYAN locate matching the large bluish
        // window glass behind the equipment — 11026 "cyan" pixels, a box
        // 0.49 wide x 0.51 tall (nearly square, half the frame). A real
        // single-row weighbridge display is nothing like that shape; the red
        // split-recovery on the same photo produced [0.29,0.34-0.66,0.43],
        // a ~4:1 wide-and-short box sitting exactly on the real display. Both
        // were already in the candidate list — the correct one was simply
        // never reached, because the per-candidate loop below stops at the
        // first box that yields a plausible-looking number, and cyan was
        // ordered first.
        //
        // So this sorts by display-likeness rather than by which color
        // channel found it. Deliberately a SORT, not a filter: an earlier
        // attempt this session to REJECT candidates on aspect ratio was
        // tested and reverted because it discarded genuinely correct boxes
        // (real displays measured anywhere from ~1:1 on tight close-ups to
        // ~9:1 on wide shots, so no safe cutoff exists). Ordering is safe
        // where filtering wasn't — nothing is ever discarded, every
        // candidate is still tried in turn exactly as before, and a
        // single-candidate photo (the common case) is completely unaffected.
        // Ties broken by lit-pixel count, preserving the previous
        // biggest-first behavior among equally display-shaped boxes.
        if (candidates && candidates.length > 1) {
            const displayLikeness = (c) => {
                const bw = (c.x_max - c.x_min), bh = (c.y_max - c.y_min);
                if (!(bw > 0) || !(bh > 0)) return 0;
                return bw / bh;
            };
            candidates = [...candidates].sort((a, b) => {
                const d = displayLikeness(b) - displayLikeness(a);
                if (Math.abs(d) > 0.01) return d;
                return (b.litCount || 0) - (a.litCount || 0);
            });
            console.log(`[GEMINI] Candidate order (most display-shaped first): ${candidates.map(c => `${((c.x_max - c.x_min) / (c.y_max - c.y_min)).toFixed(1)}:1`).join(', ')}`);
        }
        console.log(`[GEMINI] Locate step (${locateSource}) took ${Date.now() - tLocateStart}ms (total ${elapsed()}), ${candidates ? candidates.length : 0} candidate box(es)`);
        if (!candidates || !candidates.length) return null;

        // Changed 2026-08-11 to try each candidate box in turn instead of
        // committing to only the first one — reproduced live on a real
        // photo where the top-scoring color cluster was actually a blurry
        // window reflection, not the display, and the genuine digit cluster
        // was the SECOND-largest component (298px vs the false positive's
        // 323px — a threshold-based rejection was tried and reverted, too
        // fragile a margin; see findDisplayBoxByColor). This is the safer
        // version of that fix: actually attempt to read each candidate and
        // use whichever one produces a real result, rather than guessing in
        // advance which one is "real."
        let lastAttempt = null;
        let weakAttempt = null; // a candidate that read SOMETHING but looked truncated — see below
        for (let i = 0; i < candidates.length; i++) {
            const box = candidates[i];
            const tag = candidates.length > 1 ? ` (candidate ${i + 1}/${candidates.length})` : '';
            if (process.env.DEBUG_WEIGHT_RAW) console.log(`[DEBUG box${tag}]`, JSON.stringify(box));

            const tCropStart = Date.now();
            // lowResInput -> boost: true (see the "Received image" block
            // above) applies the same contrast-stretch+sharpen used in the
            // rescue path on the FIRST attempt when the source photo itself
            // is small, instead of only after Vision already failed once.
            const croppedBase64 = await cropToDisplay(imageBase64, mimeType, box, { boost: lowResInput });
            console.log(`[GEMINI] Crop step${tag} took ${Date.now() - tCropStart}ms (total ${elapsed()})${lowResInput ? ' [contrast-boosted: low-res source]' : ''}`);
            if (process.env.DEBUG_WEIGHT_RAW) console.log('[DEBUG cropped len]', croppedBase64 && croppedBase64.length);
            if (process.env.DEBUG_DUMP_CROP && croppedBase64) {
                const dumpPath = candidates.length > 1 ? `${process.env.DEBUG_DUMP_CROP}.cand${i + 1}` : process.env.DEBUG_DUMP_CROP;
                require('fs').writeFileSync(dumpPath, Buffer.from(croppedBase64, 'base64'));
            }
            if (!croppedBase64) continue;

            // Kicked off together but not awaited together — the metadata
            // call (unit label / which-display reasoning) is non-essential
            // and has safe defaults below, so it shouldn't hold up the
            // weight itself.
            // Added 2026-08-12 — replaces guess-then-retry with measure-then-
            // decide, so the common case is ONE Vision call and the retries
            // below become a rarely-used safety net rather than the path.
            //
            // Vision detects text on LUMINANCE, not colour. A red LED display
            // that looks vivid to the eye can be nearly flat to Vision: pure
            // red is only ~54/255 luminance, and if the housing is dark and
            // the photo underexposed, lit digits and background end up almost
            // the same brightness. Measured on the real crops from this
            // pipeline (mean luminance of lit digit pixels minus mean
            // background luminance):
            //     28500    101  -> plain read works, 0.95 confidence
            //     80720     72  -> plain read works
            //     71920     30  -> plain read works
            //     hardcase  20  -> plain read returns NOTHING AT ALL
            //     design-6  10  -> plain read picks up a dim ghost cell
            //                      ("573500" -> strip-guessed to a wrong 73500)
            // The split is clean and the mechanism is physical, not
            // coincidental: below roughly 25 points of separation Vision
            // either finds no text or starts reading ambient dot-glow as
            // digits. A binary threshold rebuilds that separation — it maps
            // genuinely-lit dots to white and everything dimmer (ambient
            // glow, dead/ghost cells, dark housing) to black. Verified on
            // both low-contrast crops: threshold-120 reads 73600 correctly on
            // each, the hardcase WITHOUT needing the greyscale retry and
            // design-6 WITHOUT needing the leading-digit strip guess.
            //
            // Deliberately NOT applied above the cutoff: thresholding is
            // actively destructive on high-contrast crops (measured: it turns
            // 80720 into 10000 by wiping the LCD digits and leaving the
            // printed capacity label, and truncates 71920 to 1920). This is
            // the same lesson as the greyscale work — no single rendering
            // suits every display, so the rendering is chosen from the
            // image's own measured properties instead of applied blanket or
            // discovered by retrying.
            //
            // Only what is sent to VISION changes. Gemini keeps receiving the
            // original unmodified crop, since it reasons about the image
            // rather than thresholding it, and hasn't shown this failure.
            // Vision's own per-digit confidence for this candidate's read,
            // filled in by the primary detect call below. Declared out here
            // so it can travel with the attempt object to the cross-check
            // decision further down.
            let visionDigitConfidence = null;
            let visionInputBase64 = croppedBase64;
            try {
                const litRender = await renderLitSignalForOcr(croppedBase64);
                if (litRender) {
                    visionInputBase64 = litRender.base64;
                    console.log(`[GEMINI] Crop${tag} lit-signal render: ${litRender.blobs} lit blobs, median ${litRender.medianBlob}px -> closing radius ${litRender.radius} (total ${elapsed()})`);
                }
            } catch (err) {
                console.warn('[GEMINI] Lit-signal render failed, sending the raw crop to Vision:', err.message);
            }

            const tVisionStart = Date.now();
            // Uses the confidence-carrying variant for the PRIMARY read only
            // (the other detectText call sites are unchanged). The per-symbol
            // scores are what let a demonstrably-solid read skip the slow
            // Gemini cross-check further down, instead of every read paying
            // for it — see the early-exit block there.
            let visionDetail = null;
            const visionPromise = visionOcr.detectTextWithConfidence(visionInputBase64)
                .then((res) => {
                    visionDetail = res;
                    return res ? res.text : null;
                })
                .catch(() => visionOcr.detectText(visionInputBase64));

            // Corroborating read of the SAME crop in its original rendering,
            // fired in parallel. Added 2026-08-12 as the speed fix, after
            // measuring that Vision answers in 190-500ms while Gemini takes
            // 12-19s: a second Vision call is nearly free, and two
            // independent renderings agreeing on the same digits is far
            // stronger evidence than any single confidence score.
            //
            // This replaces a confidence-threshold gate that was tried and
            // abandoned on measurement: Vision's own per-digit confidence on
            // CORRECT reads ranged 0.46 (hardcase), 0.56 (71920), 0.63
            // (design-6), 0.74 (80720) to 0.95 (28500), while a known-WRONG
            // truncated read scored 0.83. Confidence simply does not track
            // correctness here, so any threshold either fires almost never or
            // fires on wrong answers. Agreement between renderings does track
            // it -- the lit-signal render and the raw crop fail in different
            // ways (that is exactly why the lit render was introduced), so
            // when both land on the same number independently, there is
            // nothing left for a third opinion to correct.
            const corroborationPromise = (visionInputBase64 === croppedBase64)
                ? Promise.resolve(null)
                : visionOcr.detectText(croppedBase64).catch(() => null);
            const geminiMetaPromise = readWeightSinglePass(croppedBase64, 'image/jpeg', retries, { isCrop: true }).catch((err) => {
                console.warn('[GEMINI] Metadata read on crop failed:', err.message);
                return null;
            });

            const visionText = await visionPromise;
            console.log(`[GEMINI] Vision-on-crop step${tag} took ${Date.now() - tVisionStart}ms (total ${elapsed()})`);
            if (process.env.DEBUG_WEIGHT_RAW) console.log('[DEBUG vision]', JSON.stringify({ visionText }));
            // extractWeightNumberFromCrop returns { weight, viaLeadingStrip }
            // (changed 2026-08-11) or null — visionWeight stays a plain
            // number everywhere below for backward compat with the many
            // existing usages; viaLeadingStrip is carried separately and
            // only consulted where it matters (the ambiguous-flagging
            // decision on the fast path below).
            let visionResult = visionOcr.extractWeightNumberFromCrop(visionText);
            let visionWeight = visionResult ? visionResult.weight : null;
            let visionWeightViaLeadingStrip = !!(visionResult && visionResult.viaLeadingStrip);
            let usedGrayRetry = false;

            // Added 2026-08-12 — measured directly against the real Vision
            // API on real crops from this pipeline, not assumed. On the
            // hardest photo (true 73600), the correctly-located, visually
            // clean crop returned a completely EMPTY result from Vision
            // (both TEXT_DETECTION and DOCUMENT_TEXT_DETECTION, repeatably)
            // — so the loop moved on and eventually accepted a worse
            // candidate's misread. The SAME crop, greyscaled and
            // contrast-normalised, returned "73600" with high per-symbol
            // confidence (0.72/0.95/0.83/0.99/0.99).
            //
            // Crucially this is a FALLBACK, not a replacement, because the
            // same experiment showed greyscale is NOT universally better and
            // would have caused a regression if applied by default: on the
            // 71920 crop, the plain colour crop reads "71920" correctly
            // while the greyscaled version collapses to garbage ("CO"). Red
            // LED digits on a dark housing carry real signal in the colour
            // channels that greyscaling can destroy. Only reaching for it
            // when the normal path produced NOTHING usable keeps every
            // currently-working photo on exactly its current code path
            // (measured: 80720 and 28500 unaffected either way), while
            // recovering the specific "Vision saw nothing at all" case.
            //
            // Deliberately NOT triggered when Vision returned a plausible
            // number, even a flagged/strip-corrected one: on the design-6
            // crop the plain read needs a strip ("573500" -> 73500, wrong)
            // but the greyscale read is messier still ("1973 600", which
            // parses to a confident, in-range, MORE wrong 1973). Falling
            // back on anything short of total failure would trade one wrong
            // answer for a worse one.
            if (visionWeight == null && sharp && croppedBase64) {
                try {
                    const grayBuf = await sharp(Buffer.from(croppedBase64, 'base64'))
                        .greyscale().normalise().jpeg({ quality: 97 }).toBuffer();
                    const grayText = await visionOcr.detectText(grayBuf.toString('base64'));
                    const grayResult = visionOcr.extractWeightNumberFromCrop(grayText);
                    if (grayResult && grayResult.weight != null) {
                        console.log(`[GEMINI] Vision found nothing on the plain crop${tag}, but a greyscale+normalised retry of the same crop read ${grayResult.weight} (total ${elapsed()})`);
                        visionResult = grayResult;
                        visionWeight = grayResult.weight;
                        visionWeightViaLeadingStrip = !!grayResult.viaLeadingStrip;
                        usedGrayRetry = true;
                    }
                } catch (err) {
                    console.warn('[GEMINI] Greyscale retry failed, continuing without it:', err.message);
                }
            }

            // Added 2026-08-12 — targeted at the one remaining known-wrong
            // photo (design-6, true 73600). There, Vision's raw read of the
            // plain crop is "573500": a ghost leading cell AND a wrong
            // hundreds digit. The leading-strip fallback turns that into a
            // plausible-looking 73500 and the pipeline returns a wrong number
            // (flagged, but wrong). Gemini sometimes catches it and sometimes
            // returns nothing at all, so leaning on the cross-check alone
            // makes this photo unstable run to run — which is exactly the
            // instability being complained about.
            //
            // Measured alternative, on the real crop against the real API:
            // a simple binary threshold of the SAME crop reads "73600"
            // CLEANLY — in range on its own, needing no strip at all
            // (threshold 120: 73600 @ 0.85 mean symbol confidence). A read
            // that lands in range with no correction is materially stronger
            // evidence than one that only becomes plausible after guessing
            // which leading digit was contamination — so when the strip
            // fallback fired, it's worth spending one or two extra Vision
            // calls to see if a different rendering of the same pixels
            // avoids the guess entirely.
            //
            // Scoped to viaLeadingStrip reads ONLY, which are rare and
            // already flagged low-confidence, so no currently-clean photo
            // pays for this or can be changed by it (verified: 71920, 80720
            // and 28500 all read clean on the plain crop and never enter
            // this branch). Thresholds tried in the order measured to work
            // best, and a variant is only adopted if it needs NO strip —
            // swapping one stripped guess for another would prove nothing.
            if (visionWeight != null && visionWeightViaLeadingStrip && sharp && croppedBase64) {
                for (const th of [120, 90]) {
                    try {
                        const thBuf = await sharp(Buffer.from(croppedBase64, 'base64'))
                            .greyscale().threshold(th).jpeg({ quality: 97 }).toBuffer();
                        const thText = await visionOcr.detectText(thBuf.toString('base64'));
                        const thRes = visionOcr.extractWeightNumberFromCrop(thText);
                        if (thRes && thRes.weight != null && !thRes.viaLeadingStrip && thRes.weight !== visionWeight) {
                            console.log(`[GEMINI] Vision's plain read needed a leading-digit strip (${visionWeight}), but a threshold-${th} rendering of the same crop read ${thRes.weight} cleanly with no strip — preferring the uncorrected read (total ${elapsed()})`);
                            visionResult = thRes;
                            visionWeight = thRes.weight;
                            visionWeightViaLeadingStrip = false;
                            break;
                        }
                    } catch (err) {
                        console.warn(`[GEMINI] Threshold-${th} retry failed, continuing:`, err.message);
                    }
                }
            }

            // Confidence of THE DIGITS THAT FORM THIS WEIGHT specifically —
            // not pooled across the crop's printed panel text, which was
            // measured to make the figure meaningless (see
            // detectTextWithConfidence). Null when the weight didn't come
            // from one clean digit run (e.g. it was reconstructed by a strip
            // or un-glue repair), which correctly reads as "no confidence
            // evidence" rather than a falsely reassuring number.
            visionDigitConfidence = (visionDetail && !visionWeightViaLeadingStrip)
                ? visionDetail.confidenceFor(visionWeight)
                : null;
            // Did the raw-crop rendering independently reach the same number?
            let corroboratedByPlainCrop = false;
            try {
                const corrText = await corroborationPromise;
                if (corrText && visionWeight != null) {
                    const corrRes = visionOcr.extractWeightNumberFromCrop(corrText);
                    if (corrRes && corrRes.weight === visionWeight && !corrRes.viaLeadingStrip) corroboratedByPlainCrop = true;
                }
            } catch (err) { /* corroboration is a bonus, never a requirement */ }
            if (process.env.DEBUG_CONF) console.log('[DEBUG conf]', JSON.stringify({ visionWeight, viaStrip: visionWeightViaLeadingStrip, conf: visionDigitConfidence, corroborated: corroboratedByPlainCrop }));
            const attempt = { visionWeight, visionWeightViaLeadingStrip, visionText, box, geminiMetaPromise, croppedBase64, usedGrayRetry, visionDigitConfidence, corroboratedByPlainCrop };
            lastAttempt = attempt;
            if (visionWeight != null) {
                // Added 2026-08-11 after a real production log: two candidate
                // boxes were found (1258px vs 679px lit pixels), the LARGER
                // one was tried first per the existing "biggest first" sort,
                // and it produced a plausible-looking but truncated "9373"
                // (correctly caught by the existing <10000 suspicious-short
                // flag below, but the SECOND candidate — quite possibly the
                // real display — was never even tried, since candidate 1
                // already "succeeded"). A bigger lit-pixel count does not
                // mean a candidate is more likely to be the real display —
                // that was already the whole reason multiple candidates get
                // tried at all (see the false-positive-reflection case
                // above) — so a candidate whose result already looks
                // truncated on ITS OWN terms shouldn't get to end the search
                // early either. Only applies to the weighbridge/default
                // classification (matching the real <10000 flag below) —
                // compact indicators legitimately read short (e.g. 2251) and
                // must not be held back waiting for a longer number that
                // will never come.
                const isCompactIndicator = looksLikeCompactIndicatorFromVisionText(visionText, wholeImageTextSoFar);
                const looksTruncated = !isCompactIndicator && visionWeight < 10000;
                if (!looksTruncated) {
                    if (i > 0) console.log(`[GEMINI] Candidate ${i + 1} produced a readable result after candidate(s) 1-${i} found nothing`);
                    return attempt;
                }
                if (!weakAttempt) weakAttempt = attempt;
                console.log(`[GEMINI] Candidate ${i + 1} read ${visionWeight} — shorter than a real weighbridge reading, holding it as a fallback and trying the next candidate first`);
                continue;
            }
            // Vision found nothing on this candidate — loop tries the next
            // one, if any. Extra cost is rare (usually only 1 candidate
            // exists at all) and only paid when the top candidate fails,
            // which is exactly the case worth spending more on.
        }
        // Changed 2026-08-11: this used to `return null` the instant
        // Vision-on-crop came back empty, which threw away a perfectly good,
        // tightly-isolated crop AND silently abandoned the geminiMetaPromise
        // already running in parallel on that same crop — forcing a fall-back
        // all the way to the much noisier whole-image OCR pass even when
        // Gemini's own read of the SAME crop might still succeed. Reproduced
        // live: a real weighbridge crop that's clearly legible to the human
        // eye (bright, high-contrast red digits) got a genuine "no text
        // detected" response from the Vision API itself (200 status, no
        // error, just an empty result) — not every Vision failure is a
        // hallucination; sometimes it just finds nothing. Now always returns
        // the last candidate's crop info so the caller can try Gemini's
        // parallel read on it before giving up entirely. Prefer a held-back
        // truncated-but-real reading (weakAttempt) over the literal last
        // candidate tried, which may have found nothing at all — a
        // suspicious-but-real number beats nothing.
        return weakAttempt || lastAttempt;
    })().catch((err) => {
        console.warn('[GEMINI] Crop-zoom accurate path failed:', err.message);
        return null;
    });

    // Widened from 4000ms after the 2026-08-10 test above showed the accurate
    // path missing that budget and falling back to an ambiguous whole-image
    // read on a photo with two displays in frame — per the owner, a wrong/
    // ambiguous number is worse than the extra latency. Still capped (not
    // unbounded) so a genuinely hung network call can't stall the response
    // forever; env-overridable for tuning without a redeploy.
    // Also bounded by the TOTAL budget (2026-08-19). Its own 9000ms cap
    // stays as an upper bound, but the accurate path can no longer consume
    // the entire read time and leave nothing for the cross-check that
    // follows — measured before this change: reads of 7.4s, 9.7s and 11.2s
    // against a 5s target, because this stage alone was allowed 9s.
    // A slice of the budget is deliberately reserved for the cross-check
    // rather than letting this stage spend all of it: on a compact
    // indicator the cross-check is the part that actually protects
    // correctness, so starving it is the worst way to save time.
    const ACCURATE_PATH_BUDGET_MS = Number(process.env.ACCURATE_PATH_BUDGET_MS) || 9000;
    const accurateBudget = Math.min(ACCURATE_PATH_BUDGET_MS, Math.max(1200, remainingBudget() - 1500));
    const accurate = await withTimeout(accuratePathPromise, accurateBudget, 'Locate+crop accurate path');
    // Wording fixed after a real log showed this saying "not ready in time"
    // when the path had actually FINISHED (in ~7.6s, under the then-9s
    // budget) and legitimately failed (a degenerate box produced a too-small
    // crop) — "not ready in time" implied a timeout that never happened and
    // pointed the wrong direction. withTimeout() above already logs its own
    // distinct warning on a genuine timeout; this line just reports outcome.
    console.log(`[GEMINI] Accurate (cropped) path ${accurate ? (accurate.notAPhoto ? 'determined this is not a scale photo at all' : (accurate.visionWeight != null ? 'succeeded' : 'located a crop but Vision found no text on it')) : 'did not produce a usable reading'} at ${elapsed()}`);

    // Added 2026-08-11 after a real batch-test image (a screenshot of the
    // dashboard's own "Add New Load" form) got mined by the whole-image
    // Vision fallback for a plausible-looking number ("456," pulled straight
    // out of unrelated placeholder text "e.g. 456 Scrap Ave, Dallas, TX")
    // and returned as a confident, unflagged weight. Gemini's locate step
    // already correctly recognized this wasn't a yard photo at all — that
    // signal is honored here by skipping every fallback (including the
    // final single-pass Gemini read) and returning no reading, rather than
    // continuing to guess from a photo that was never going to contain a
    // real weight in the first place.
    if (accurate && accurate.notAPhoto) {
        console.warn(`[GEMINI] Not a scale photo (per locate step) — returning no reading rather than guessing from irrelevant text`);
        return {
            weight: null,
            weight_unit: null,
            displays_seen: 'This does not appear to be a photo of a scale display',
            raw_text: null,
            ambiguous: false,
            not_a_scale_photo: true,
        };
    }

    // Added 2026-08-11: Vision-on-crop came back genuinely empty (not
    // garbled, not hallucinated — literally no text detected) despite a
    // valid, tightly-cropped display image existing. Rather than discard
    // that crop and fall straight to the noisier whole-image OCR, try
    // Gemini's already-in-flight parallel read of the SAME crop first —
    // see the long comment at the crop-path return site above for why this
    // case exists at all.
    if (accurate && accurate.visionWeight == null) {
        // Added 2026-08-11, per the owner ("find a way to fix this 1" — the
        // last unresolved hard photo in the 12-photo batch, 47.jpeg).
        // Root-caused by directly comparing crop bytes on the real photo
        // (not guessing): trimDeadDigitZones (built for a real, different
        // bug — a dim ghost cell hallucinated as a phantom leading digit)
        // was cutting THIS photo's crop from 2619px down to 1585px wide, and
        // that trimmed crop is what Vision found zero text on, repeatably,
        // at several resolutions/contrast levels. The UNTRIMMED crop at the
        // exact same box/padding read cleanly on Vision ("81960") on the
        // first try. So: retry Vision on the untrimmed crop before assuming
        // the display itself is unreadable. If that still finds nothing,
        // layer a contrast-stretch + sharpen on top of the untrimmed crop as
        // a second attempt (verified live to pull a different hard crop from
        // "no text" to legible). Both are local image-processing passes with
        // no extra API cost, tried BEFORE the slower Gemini-retry loop below
        // — if either recovers a real answer, Gemini retries never need to
        // run at all. NOTE: even the untrimmed crop reads this specific
        // photo's second digit inconsistently (Vision, Gemini, and my own
        // eye all had to work to disambiguate 8 vs 1 vs 7 on that one cell)
        // — this is a real display-legibility limit on a dim, angled photo,
        // not a pipeline bug, which is exactly why this whole rescue path
        // always returns ambiguous:true rather than silently trusting
        // whichever variant happens to answer.
        let rescueWeight = null, rescueText = null, rescueLabel = null;
        if (accurate.box) {
            const attempts = [
                { label: 'untrimmed crop', opts: { skipTrim: true } },
                { label: 'untrimmed + contrast-boosted crop', opts: { skipTrim: true, boost: true } },
            ];
            for (const attempt of attempts) {
                try {
                    const rescueCrop = await cropToDisplay(imageBase64, mimeType, accurate.box, attempt.opts);
                    if (!rescueCrop) continue;
                    const text = await visionOcr.detectText(rescueCrop);
                    // extractWeightNumberFromCrop returns { weight, viaLeadingStrip }
                    // or null (changed 2026-08-11) — viaLeadingStrip isn't
                    // consulted here since this whole rescue path already
                    // unconditionally flags ambiguous:true regardless.
                    const weightResult = visionOcr.extractWeightNumberFromCrop(text);
                    const weight = weightResult ? weightResult.weight : null;
                    console.log(`[GEMINI] Rescue attempt "${attempt.label}" (Vision-on-crop found nothing on plain crop): ${weight ?? 'still nothing'} (raw: "${text || ''}")`);
                    if (weight != null) { rescueWeight = weight; rescueText = text; rescueLabel = attempt.label; break; }
                } catch (err) {
                    console.warn(`[GEMINI] Rescue attempt "${attempt.label}" failed:`, err.message);
                }
            }
        }
        if (rescueWeight != null) {
            // Added 2026-08-11, per direct instruction: this used to return
            // the moment ANY Vision variant found ANY number, without ever
            // consulting Gemini even though geminiMetaPromise has been
            // running in parallel since the candidate loop started — never
            // actually trying "another model," just retrying the same one
            // on different crops. Real case that exposed this: Vision's
            // rescue read "973.72" off a 768px crop (a decimal, three
            // significant digits — nothing on this display type has ever
            // been a decimal; every confirmed real reading is a 5-digit
            // whole number) and it was returned as-is. Once Vision has
            // already needed rescuing on a crop, its credibility on THAT
            // crop is already reduced, so Gemini's independent read is
            // worth a bounded wait and a real comparison, not a footnote.
            // Widened 8000 -> 15000ms same night, after direct evidence: a
            // real case timed out at 8000ms using Vision's rescue answer
            // "973.72" (a decimal, no confirmed real reading on this display
            // has ever had one), and Gemini's actual read -- "73720", a
            // normal 5-digit whole number matching every real reading's
            // format -- arrived immediately after, too late to be used. This
            // is the exact same latency this file already measured and
            // documented for the OTHER Gemini crop cross-check earlier
            // tonight (GEMINI_CROSSCHECK_TIMEOUT_MS, ~12-16s/request) -- that
            // number should have been reused here from the start instead of
            // guessing a fresh, untested 8000ms.
            // Time bound removed 2026-08-12 for the same reason as the
            // fast-path cross-check below (see the long note there). This
            // path is reached only when Vision found NO text on the plain
            // crop and a rescue variant had to be used — by definition
            // already a low-confidence read — so timing out and publishing
            // the rescue number is strictly worse than waiting for Gemini's
            // independent read. Unbounded await is safe here for the same
            // reason: geminiMetaPromise has its own .catch() and resolves to
            // null on any API error rather than hanging.
            // Was an unbounded await until 2026-08-19 (the comment above
            // justified it on safety grounds, which held while there was no
            // overall time target). Now bounded by what's left of the total
            // budget; withTimeout resolves null on expiry and the code below
            // already handles "no committed number" by flagging.
            const geminiRescueCheck = await withTimeout(accurate.geminiMetaPromise, remainingBudget(), 'Gemini rescue cross-check (budget)');
            console.log(`[GEMINI] Rescue cross-check resolved at ${elapsed()}: ${geminiRescueCheck && geminiRescueCheck.weight != null ? geminiRescueCheck.weight : 'no committed number'}`);
            // Vetted through the same plausibility bounds + ghost-cell strip
            // as everywhere else Gemini's number can become primary (see the
            // fast-path cross-check below) — this path also PREFERS Gemini on
            // disagreement, so it had the identical hole: an impossible
            // number (over the hard 90,000 lb ceiling) could be published as
            // the final weight. Vetting collapses "173720" to the real 73720
            // and discards anything that can't be brought into range at all.
            const geminiRescueVetted = geminiRescueCheck && geminiRescueCheck.weight != null
                ? visionOcr.plausibleWeightOrStripped(geminiRescueCheck.weight)
                : null;
            const geminiRescueWeight = geminiRescueVetted ? geminiRescueVetted.weight : null;
            const geminiAgrees = geminiRescueWeight != null && geminiRescueWeight === rescueWeight;
            const geminiDisagrees = geminiRescueWeight != null && geminiRescueWeight !== rescueWeight;
            // Added 2026-08-11: geminiRescueCheck being null means the wait
            // genuinely timed out (withTimeout resolves null on timeout —
            // see its own definition). But Gemini can also respond WITHIN
            // budget and still explicitly decline a confident number
            // (weight: null) while its raw_text carries real, specific
            // information — a live case saw Gemini return raw_text
            // "??3720 lb (leading digits unreadable/fading due to LED
            // multiplex refresh rate)": a genuine physical explanation (LED
            // displays that multiplex/scan their digits can have one appear
            // dim or unlit in a single photo frame regardless of resolution
            // or which model reads it), not a vague failure. That was
            // previously discarded and reported as "did not return an
            // answer in time," which is both inaccurate (it DID answer,
            // just not with a number) and throws away a partial digit
            // pattern a human reviewer could actually use — e.g. this raw
            // text's trailing "3720" matches an earlier attempt's full,
            // confident "73720" read on a retry of the same case.
            // Renamed-in-meaning 2026-08-12: with the wait budget removed
            // above, a null here no longer means "ran out of time" — the
            // await now always runs to completion, so null can only mean the
            // Gemini call itself failed and its own .catch() resolved to
            // null. The note text below was updated to say that, rather than
            // continuing to blame a timeout that no longer exists.
            const geminiCallFailed = geminiRescueCheck === null;
            const geminiDeclinedWithNote = !geminiCallFailed && geminiRescueCheck && geminiRescueCheck.weight == null
                && geminiRescueCheck.raw_text && !/^n\/?a\b/i.test(geminiRescueCheck.raw_text.trim());
            // Prefer Gemini's number when the two disagree: Vision already
            // proved unreliable enough on this exact crop to need a rescue
            // attempt at all, so its rescued answer isn't more trustworthy
            // than a second, architecturally different model's independent
            // read of the same image — surfaced as primary, with Vision's
            // guess kept visible as the alternate rather than discarded.
            const finalWeight = geminiDisagrees ? geminiRescueWeight : rescueWeight;
            const finalAlt = geminiDisagrees ? rescueWeight : null;
            const note = geminiDisagrees
                ? ` [Vision found no text on the plain crop; a "${rescueLabel}" rescue read ${rescueWeight}, but Gemini's independent read of the same crop said ${geminiRescueWeight} instead — using Gemini's answer since Vision already needed rescuing here, but please verify against the actual display]`
                : ` [Vision found no text on the plain (trimmed) crop; retrying on a "${rescueLabel}" of the same box recovered a reading${
                    geminiAgrees ? ', and Gemini\'s independent read of the same crop agreed'
                    : geminiDeclinedWithNote ? `. Gemini could not confidently read a full number but noted: "${geminiRescueCheck.raw_text}" — compare against Vision's ${rescueWeight} before trusting either`
                    : geminiCallFailed ? ' (Gemini\'s cross-check call itself failed, so no second opinion was available)'
                    : ' (Gemini\'s cross-check did not return a usable answer)'
                  } — flagged for review since a display that needed this rescue path has already shown it's harder than usual to read]`;
            console.log(`[GEMINI] Weight read via ${geminiDisagrees ? 'Gemini (preferred over Vision rescue, disagreement)' : `Cloud Vision OCR (${rescueLabel} rescue)`} in ${elapsed()}: ${finalWeight}${note}`);
            return {
                weight: finalWeight,
                alternate_weight: finalAlt,
                alternate_source: finalAlt != null ? 'Cloud Vision OCR (rescue)' : null,
                weight_unit: 'lb',
                displays_seen: `${geminiDisagrees ? 'Gemini' : 'Cloud Vision OCR'} read of a ${rescueLabel} (locate reason: "${accurate.box.reason || ''}"), plain crop found no text`,
                raw_text: `${rescueText || ''} (Cloud Vision OCR, ${rescueLabel})${note}`,
                ambiguous: true,
            };
        }

        const GEMINI_META_TIMEOUT_MS = Number(process.env.GEMINI_META_TIMEOUT_MS) || 8000;
        let geminiMeta = await withTimeout(accurate.geminiMetaPromise, GEMINI_META_TIMEOUT_MS, 'Gemini crop metadata (Vision-on-crop found nothing)');

        // Added 2026-08-11, per the owner ("I want 100% accuracy, find some way
        // to fix"): confirmed live that Vision genuinely, deterministically
        // finds nothing on some crops (tested 4x identical + both
        // TEXT_DETECTION and DOCUMENT_TEXT_DETECTION directly against the
        // raw API — not a retry-able flake), but Gemini's own read of the
        // SAME crop, while inconsistent call-to-call, is not random noise —
        // repeated testing showed it converging on the same answer more
        // often than not (2 of 4 attempts matched exactly, a 3rd landed one
        // digit off on the specific cell that's genuinely hard to read even
        // by eye). A single Gemini attempt is therefore leaving real signal
        // on the table when it happens to land on a null/uncertain read.
        // Retries up to 2 more times and prefers a value that AGREES across
        // attempts (real corroboration) over just taking whichever came
        // first. Still always flagged ambiguous — there's no independent
        // Vision cross-check in this branch regardless of how many Gemini
        // attempts agree.
        //
        // Timeout capped tighter for retries specifically, per the owner's
        // call after seeing the real tradeoff live: an 8000ms budget per
        // attempt meant a run where every attempt failed cost 28s total
        // before falling back to the (wrong, but at least fast) whole-image
        // read — worse than the old single-attempt behavior on the failure
        // case, for an occasional win on the success case. 4000ms per retry
        // bounds the worst case to roughly half that while still giving
        // each attempt a real shot (successful reads in testing landed
        // between 1.5-5s).
        // Changed 2026-08-11, per the owner asking why this was taking so long:
        // these 2 retries used to run ONE AT A TIME, each awaited fully
        // before the next started — worst case 8000 (first attempt, above)
        // + 4000 + 4000 = 16000ms, entirely sequential, even though the two
        // retries don't depend on each other at all. Same 2 API calls, same
        // "prefer two attempts that agree" logic, just fired concurrently
        // instead of queued — cuts the worst case to 8000 + 4000 = 12000ms.
        // Not made fully eager (started before the first attempt is even
        // known to have failed) on purpose: that would spend 2 extra Gemini
        // calls even on the common case where the first attempt succeeds
        // quickly, trading API cost for a latency win that isn't needed
        // there.
        const GEMINI_RETRY_TIMEOUT_MS = Number(process.env.GEMINI_RETRY_TIMEOUT_MS) || 4000;
        if (!geminiMeta || geminiMeta.weight == null) {
            const seen = new Map(); // weight -> count
            if (geminiMeta && geminiMeta.weight != null) seen.set(geminiMeta.weight, 1);
            const retryPromises = accurate.croppedBase64
                ? [0, 1].map((attempt) => withTimeout(
                      readWeightSinglePass(accurate.croppedBase64, 'image/jpeg', retries, { isCrop: true }).catch(() => null),
                      Math.min(GEMINI_RETRY_TIMEOUT_MS, remainingBudget()),
                      `Gemini crop metadata retry ${attempt + 1} (Vision-on-crop found nothing)`
                  ))
                : [];
            const retryResults = await Promise.all(retryPromises);
            for (const retryMeta of retryResults) {
                if (retryMeta && retryMeta.weight != null) {
                    seen.set(retryMeta.weight, (seen.get(retryMeta.weight) || 0) + 1);
                    if (!geminiMeta) geminiMeta = retryMeta; // keep first successful as fallback shape
                    if (seen.get(retryMeta.weight) >= 2) { geminiMeta = retryMeta; break; } // two attempts agreed — use that
                }
            }
        }

        if (geminiMeta && geminiMeta.weight != null) {
            const note = ` [Vision found no text at all on this crop; Gemini's read of the same crop is used instead, with no Vision cross-check available — flagged for review]`;
            console.log(`[GEMINI] Weight read via Gemini (primary, cropped, Vision-found-nothing fallback) in ${elapsed()}: ${geminiMeta.weight}${note}`);
            return {
                weight: geminiMeta.weight,
                alternate_weight: null,
                alternate_source: null,
                weight_unit: geminiMeta.weight_unit || 'lb',
                displays_seen: geminiMeta.displays_seen || `Gemini read of located display (locate reason: "${accurate.box.reason || ''}"), Vision found no text`,
                raw_text: `${geminiMeta.raw_text || ''} (Gemini, Vision found nothing on this crop)${note}`,
                ambiguous: true,
            };
        }
        // Neither engine got anything off this crop after retries —
        // genuinely fall through to the whole-image pass below, same as
        // before.
    }

    if (accurate && accurate.visionWeight != null) {
        // Rework 2026-08-11, per the owner ("remove the timing constraint, find
        // some other way to do it very fast"): the previous version always
        // synchronously waited on a second full Gemini call (readWeightSinglePass
        // again, ~3.5-8s+, sometimes 8s+ and timing out) before responding,
        // on EVERY read, just to get a `displays_seen` classification string.
        // Live testing showed that wait alone pushed total latency to
        // 11-12s on ordinary weighbridge reads that didn't need Gemini's
        // opinion at all (Vision has been extensively proven reliable on
        // that display type all session).
        //
        // Fix: classify display type from Vision's OWN crop OCR text
        // (`accurate.visionText`), which we already have for free — no
        // extra API call, no extra wait, zero added latency. This works
        // because compact 7-segment bench/platform indicators (Socome-style)
        // print their own control-panel labels right on the fascia, which
        // Vision's OCR already picks up on the SAME crop it's reading
        // digits from (confirmed live: the Socome crop's Vision text
        // included "Weighing Indicato[r]", "STABLE", "COUNT", "TARE",
        // "ON/OFF FUNC UNITS" every single time across 3 repeated runs).
        // Weighbridge crops never contain that vocabulary — usually just
        // bare digits plus a unit label (e.g. "ZOSI...81460").
        const looksCompactIndicator = looksLikeCompactIndicatorFromVisionText(accurate.visionText, wholeImageTextSoFar);

        if (!looksCompactIndicator) {
            // FAST PATH — the common case. Vision is the proven-reliable
            // engine here, so respond immediately without waiting on
            // Gemini's metadata call at all (it's still kicked off in
            // parallel above for potential future use/logging, but nothing
            // downstream blocks on it — its .catch() already prevents an
            // unhandled-rejection warning if it's simply never awaited).
            // Added 2026-08-11: cross-check the digit count before trusting
            // this unflagged. Reproduced live: the AI-locate box (used when
            // pixel-locate can't confidently place one) is non-deterministic
            // — a repeat run on the IDENTICAL photo returned a tighter box
            // than the first attempt and cropped off the leading "28" of
            // "28460", leaving "460" — still inside the 200-90000 plausible
            // range on its own, so it slipped through as a confident,
            // unflagged, WRONG answer. No range check catches a truncated-
            // but-still-plausible number. Every confirmed genuine reading on
            // THIS path (the red/weighbridge display) has been 5 digits
            // (20000-90000+ lb) all session — nothing shorter has ever been
            // real. So: still return Vision's number (better than nothing,
            // and often still right), but flag it for a human glance if it's
            // suspiciously short for this specific display type, rather than
            // present a possibly-truncated number with false confidence.
            // Padding for the AI-locate path was also widened (see
            // cropToDisplay) to make this less likely to happen at all.
            const suspiciouslyShort = accurate.visionWeight < 10000;
            // Added 2026-08-11 after a real photo showed Vision reading a
            // crop as "817520" — the leading-digit-strip fallback in
            // extractWeightNumberFromCrop stripped the "8" to get the
            // in-range "17520" and this fast path returned it completely
            // unflagged, while Gemini's own parallel (unused-on-this-path)
            // read said "87520" instead. That fallback assumes contamination
            // is always a prepended ghost digit on the far left — true in
            // every case seen before, but not guaranteed, and it has no way
            // to tell the difference. So: whenever the strip fallback fired,
            // treat this exactly like the suspicious-short case (flag it),
            // regardless of the resulting digit count, instead of trusting a
            // rescued number as fully as a clean single in-range match.
            const viaStrip = accurate.visionWeightViaLeadingStrip;
            // Added 2026-08-11: lowResInput as a third flag trigger, after
            // directly measuring the gap it closes. A 768px source photo
            // (resolution unknown to be camera or gallery — that distinction
            // doesn't matter to the fix) produced "87588" for a true 81528 —
            // normal digit count, no strip needed, so neither check above
            // would have caught it; it would have returned fully confident
            // and wrong. Contrast-boosting the crop (see the primary crop
            // call above) helps but doesn't guarantee correctness at this
            // resolution — 1-vs-7 and 2-vs-8 on a 7-segment display can
            // become genuinely ambiguous once enough source detail is gone.
            // Since accuracy alone can't be fully restored after the fact,
            // visibility into the uncertainty is the honest fallback: always
            // get Gemini's second opinion on the same crop when the source
            // was low-res, regardless of how plausible Vision's number looks.
            const flagForReview = suspiciouslyShort || viaStrip || lowResInput;
            const reviewReason = suspiciouslyShort
                ? ' — shorter than every confirmed real reading on this display type, flagged for review in case of a truncated crop'
                : (viaStrip ? ' — Vision\'s raw read needed a leading-digit correction to become plausible, flagged for review since that correction isn\'t guaranteed correct'
                : (lowResInput ? ' — source photo was below the resolution this pipeline was validated at, flagged for review since digit accuracy can\'t be guaranteed' : ''));

            // When the strip fallback fired, Gemini's already-in-flight
            // parallel read of the SAME crop is worth a bounded wait here —
            // matching the same "surface both candidates" pattern already
            // used on the slow/compact-indicator path below, rather than
            // silently discarding it. Real case this was built for: Vision
            // said 17520 (post-strip), Gemini said 87520 on the same crop —
            // showing both lets a human resolve it in one glance instead of
            // walking back to the scale with only one (possibly wrong)
            // number to check against.
            // Changed 2026-08-11: this cross-check used to only fire for
            // viaStrip. Real production case: Vision cleanly read "736" (no
            // strip needed — suspiciouslyShort alone tripped flagForReview)
            // and this branch never ran, so the driver was left with a bare
            // unverified "736" and no second opinion, even though Gemini's
            // parallel read of the SAME crop was already in flight the whole
            // time. Widening the condition from viaStrip to flagForReview
            // means BOTH flagged cases now get Gemini's second opinion
            // surfaced as alternate_weight before returning, not just the
            // strip sub-case. Only affects already-flagged (rare, already
            // slow-tolerant) reads — clean in-range results never touch this.
            // Added 2026-08-12 — root cause of a real, confirmed miss:
            // Vision cleanly read "73500" for a photo whose true value was
            // 73600 — no strip needed, normal digit count, high-res source —
            // so flagForReview was FALSE and this whole cross-check block
            // used to be skipped entirely. Gemini's parallel read of the
            // SAME crop was already running in the background the whole
            // time (kicked off back when the crop was first ready) and was
            // simply thrown away unused, because nothing ever looked at it
            // on this path. That's the actual gap behind why the two fixes
            // above (widen the timeout, prefer Gemini on disagreement)
            // didn't catch every run of the same photo: those only fire once
            // Vision has ALREADY self-flagged uncertainty, and Vision does
            // not always do that when it's wrong.
            //
            // Fix: always check geminiMetaPromise now, not just when
            // flagForReview is already true — but with an important
            // difference in how much we're willing to WAIT for it. A
            // genuinely clean-looking Vision read has no a-priori reason to
            // be distrusted, so this must not cost real latency on the
            // common case (most reads are clean) — budget 0ms, which (via
            // withTimeout/Promise.race) only picks up Gemini's answer if it
            // HAPPENED to already resolve by this point (its own head start
            // sometimes covers it, per real timing observed: 4.4-6s for
            // Vision-on-crop vs Gemini's benchmarked 12-16s, so this is a
            // minority of calls, not most — deliberately not blocking
            // everyone else to catch that minority). An already-flagged read
            // keeps paying the full, patient GEMINI_CROSSCHECK_TIMEOUT_MS
            // wait exactly as before, since that path already accepted the
            // latency cost as worth it.
            //
            // On disagreement, the two cases are handled differently on
            // purpose: when Vision's original read was ALREADY weak
            // (viaStrip/suspiciouslyShort/lowResInput), prefer Gemini as
            // primary (existing, live-validated behavior — Vision was the
            // weaker signal from the start). When Vision's read was clean,
            // do NOT blindly swap to Gemini — Gemini is independently known
            // non-deterministic (see visionOcr.js header) and could just as
            // easily be the wrong one here; instead, elevate this read to
            // ambiguous/flagged-for-review and surface Gemini's number as
            // alternate_weight, turning a previously-invisible silent miss
            // into a visible, checkable one without risking a new class of
            // wrong "corrections" on reads that were actually fine.
            const wasOriginallyFlagged = flagForReview;
            let strippedAlt = null;
            let strippedNote = null;
            {
                // Widened 3000 -> 8000ms after a real miss: a live photo
                // where Vision's strip-corrected read (73500) was actually
                // wrong (confirmed true value 73600, one digit off — a
                // genuine Vision misread of 5-vs-6, not just the spurious
                // leading digit), and Gemini's parallel read HAD the correct
                // 73600 the whole time but got cut off by this timeout
                // before it could be surfaced as alternate_weight. Gemini
                // benchmarked at ~12-16s/request on this exact digit-reading
                // task (see readWeightSinglePass's model-choice comment) —
                // geminiMetaPromise is kicked off well before this point
                // (in parallel with Vision-on-crop, which itself typically
                // takes several seconds), so it already has a head start,
                // but 3000ms of ADDITIONAL wait after that head start was
                // measured too tight to catch a real, useful disagreement
                // that was already in flight. This only fires on the
                // less-common viaLeadingStrip path, so the extra worst-case
                // latency here is not paid on ordinary clean reads.
                // Widened again 8000 -> 15000ms: live-tested and STILL missed
                // a real, correct 73600 answer that came back at ~12.7s
                // total (Vision-on-crop's own ~6s head start plus Gemini's
                // full ~12-16s benchmark time barely fits in an 8000ms
                // ADDITIONAL wait). This path already only runs when Vision's
                // own read needed a correction (rare, already flagged
                // low-confidence), so paying up to ~20s total here to
                // reliably catch the cross-check is the right trade given
                // the owner's explicit priority ("i cant afford to have
                // mistakes" outranks speed when the two conflict).
                // Changed 2026-08-12 — this used to be 0ms (free/best-effort
                // only) on a clean-looking Vision read, to avoid taxing the
                // common case. Live-tested directly: on the real photo this
                // whole investigation is about, 0ms NEVER caught anything —
                // Gemini's read on this crop consistently needs longer than
                // the ~7-8s the clean path takes end-to-end on its own, so
                // there was never a window where it would "happen to already
                // be done." A real, non-zero wait is required to get any
                // benefit at all here, not a nicety — so given the owner's
                // explicit, repeated priority (accuracy over speed when they
                // conflict), clean reads now pay the same bounded wait as
                // already-flagged ones. Measured cost in practice is lower
                // than the worst case suggests: when Gemini agrees quickly
                // Promise.race resolves as soon as IT settles, not the full
                // budget (observed 5.0-5.2s total on two clean, correct
                // photos) — the full ~15-16s is only paid when Gemini
                // genuinely takes that long, which is also exactly the case
                // most worth waiting for.
                // Changed 2026-08-12 after losing this race by ~2ms in
                // production. Vision read a truncated "720" at 2101ms; the
                // cross-check waited its full 15000ms and gave up at
                // 17103ms; Gemini's read of the same crop — the CORRECT
                // 73720, already in range and needing no strip — landed
                // immediately after and was discarded. The pipeline then
                // published 720 as the weight: a number its own log line
                // simultaneously described as "shorter than every confirmed
                // real reading on this display type".
                //
                // Raising the fixed budget again (3000 -> 8000 -> 15000 ->
                // ...) is the wrong instinct; it taxes every flagged read to
                // chase a tail that keeps moving. The real asymmetry is that
                // when Vision's own number is one we ALREADY disbelieve
                // (suspiciouslyShort — a 3-digit reading on a weighbridge
                // that cannot physically be a truck load), the cross-check
                // is not a second opinion, it is the ONLY credible source we
                // have. Returning 720 has negative value: it is worse than
                // waiting, and worse than admitting we don't know.
                //
                // So that case gets a DEADLINE rather than an increment:
                // keep waiting until a total elapsed budget, not a fixed
                // additional one. Promise.race still resolves the instant
                // Gemini lands (measured 12-17s), so this costs nothing in
                // the normal case — it only stops us from timing out 2ms
                // before the answer we were waiting for. Ordinary flagged
                // reads, where Vision produced a plausible number and Gemini
                // is genuinely just a second opinion, keep the existing
                // bounded wait.
                // TIME BOUND REMOVED 2026-08-12, per the owner's direct
                // instruction. The production log that prompted it makes the
                // case better than any argument: Vision read a truncated
                // "720" at 2101ms, this cross-check gave up at exactly
                // 17103ms after its 15000ms budget, and Gemini's read of the
                // same crop — the CORRECT 73720, in range, needing no strip —
                // arrived immediately after and was thrown away. The pipeline
                // then published 720, a number its own log line
                // simultaneously called shorter than any real reading on this
                // display type.
                //
                // The budget had already been raised 3000 -> 8000 -> 15000
                // chasing exactly this, losing each time to a tail that moved
                // again. That is the wrong shape of fix. Every read reaching
                // this branch is ALREADY FLAGGED — Vision is itself saying its
                // answer isn't trustworthy — so there is no version of
                // "give up early" that beats waiting: the fallback is
                // publishing a number we already disbelieve.
                //
                // Safe to await unbounded: geminiMetaPromise is created with
                // its own .catch() at the call site (resolves to null on any
                // API error) and readWeightSinglePass carries its own
                // retry/backoff, so a failure surfaces as null rather than
                // hanging forever. It costs nothing in the normal case
                // either — the await resolves the moment Gemini answers
                // (measured 12-17s); it simply no longer races a stopwatch it
                // was never guaranteed to beat.
                const crossCheckLabel = wasOriginallyFlagged
                    ? `Gemini crop metadata (cross-check — ${viaStrip ? 'leading-digit strip' : 'suspiciously short read'})`
                    : 'Gemini crop metadata (cross-check on an otherwise-clean read)';

                // Added 2026-08-12 — the speed fix, and deliberately NOT a
                // timeout. Removing the wait budget was right (a late correct
                // answer beats a fast wrong one), but it made every read pay
                // Gemini's 12-19s even when Vision's answer was never in
                // doubt. A clock can't tell those apart; evidence can.
                //
                // Vision returns a per-symbol confidence score that this
                // codebase was discarding entirely. It is the only signal
                // available BEFORE consulting a second model that says
                // whether Vision itself was sure. So: when the read is clean
                // on every existing check (no ghost-cell strip, not
                // implausibly short, source not low-res) AND Vision's own
                // weakest digit clears the bar, the cross-check adds nothing
                // worth 15 seconds and is skipped. Anything less than that —
                // any flag at all, or any shaky digit — still waits as long
                // as Gemini needs, unbounded, exactly as before.
                //
                // The bar is set from measured confidences on real crops, not
                // picked: correct reads on this pipeline scored 0.83-0.95
                // minimum digit confidence, so 0.80 sits below every
                // confirmed-good read while still refusing anything visibly
                // shaky. Env-overridable, and raising it simply buys back
                // more cross-checking at the cost of latency.
                //
                // Note this is not a substitute for the cross-check finding
                // silently-wrong clean reads — that protection is why the
                // block runs on unflagged reads at all. It narrows it to the
                // reads where Vision showed doubt, which is where every
                // silent miss measured this session actually originated.
                const conf = accurate.visionDigitConfidence;
                const confidentEnoughToSkip = !wasOriginallyFlagged && accurate.corroboratedByPlainCrop;
                if (confidentEnoughToSkip) {
                    console.log(`[GEMINI] Skipping the Gemini cross-check: two independent renderings of the same crop (lit-signal and raw) both read ${accurate.visionWeight} with no correction needed — returning at ${elapsed()} instead of waiting ~15s for a second opinion with nothing to correct`);
                }
                const crossCheck = confidentEnoughToSkip ? null : await (async () => {
                    const budget = remainingBudget();
                    console.log(`[GEMINI] Waiting up to ${budget}ms (what's left of the ${TOTAL_BUDGET_MS}ms budget) for Gemini's independent read of the same crop — ${wasOriginallyFlagged ? `Vision's ${accurate.visionWeight} is already flagged` : 'the raw-crop rendering did not independently confirm this number'} (Vision's weakest digit for it scored ${conf == null ? 'unknown' : conf.toFixed(2)}) (total ${elapsed()})`);
                    // Was an UNBOUNDED wait until 2026-08-19. If it now runs
                    // out, withTimeout resolves null and the code below
                    // already treats "no committed number" as "flag it",
                    // so a timeout degrades to a flagged read rather than a
                    // wrong one.
                    return withTimeout(accurate.geminiMetaPromise, budget, 'Gemini cross-check (budget)');
                })();
                console.log(`[GEMINI] Cross-check resolved at ${elapsed()}: ${crossCheck && crossCheck.weight != null ? crossCheck.weight : 'no committed number'} [${crossCheckLabel}]`);
                // Added 2026-08-12 — Gemini's number now goes through the
                // SAME plausibility bounds and ghost-cell leading-digit strip
                // that every Vision read goes through. Real production miss
                // this fixes: Vision managed only a truncated "720" on the
                // crop, so this branch correctly preferred Gemini — but
                // Gemini had read "173720", including the dim leading ghost
                // cell as a "1", and that was published as the final weight
                // despite being above the hard 90,000 lb ceiling and
                // therefore impossible. Stripping the ghost digit gives
                // 73720, which matches the display in the photo. If nothing
                // in range can be recovered, plausibleWeightOrStripped
                // returns null and we simply don't adopt Gemini's number,
                // rather than replacing one wrong answer with an impossible
                // one.
                if (crossCheck && crossCheck.weight != null && crossCheck.weight !== accurate.visionWeight) {
                    const vetted = visionOcr.plausibleWeightOrStripped(crossCheck.weight);
                    if (vetted && vetted.weight !== accurate.visionWeight) strippedAlt = vetted.weight;
                }
                // Added 2026-08-12 — root cause found on a real photo (true
                // value confirmed 73600): Vision's leading-digit-stripped read
                // was wrong in a way that ISN'T a spurious leading digit (a
                // genuine 5-vs-6 misread on the hundreds digit), and Gemini's
                // parallel read of the same crop, when it landed in time,
                // plainly said "73600 lb" in raw_text — but its structured
                // `weight` came back null, because Gemini's own prompt tells
                // it to return null rather than guess when ANY digit looks
                // ambiguous (here: whether there's an extra leading cell, a
                // different question from the hundreds-digit value it was
                // actually confident about). The check above only looks at
                // `.weight`, so a correct answer sitting in `.raw_text` was
                // being silently thrown away — same bug class already fixed
                // on the separate "Vision found nothing" rescue path
                // (geminiDeclinedWithNote there); this cross-check needed the
                // same treatment, since it's a different code path that
                // shares the same gap. Deliberately NOT auto-parsed into a
                // number and substituted as alternate_weight — Gemini's own
                // free text can mention other numbers (capacity ratings,
                // model numbers) that would be unsafe to regex-extract blind
                // (see the "100000.1 vs 80720" bug this exact file already
                // hit once). Surfaced verbatim instead, same as the rescue
                // path, so a human sees both numbers and Gemini's own caveat
                // rather than either a silently-discarded correct answer or
                // an unsafely auto-extracted one.
                const declinedNote = crossCheck && crossCheck.weight == null && crossCheck.raw_text
                    && !/^n\/?a\b/i.test(crossCheck.raw_text.trim())
                    ? crossCheck.raw_text
                    : null;
                if (declinedNote) strippedNote = declinedNote;
            }

            // Added 2026-08-12 — this used to always keep Vision's read as
            // `weight` even when strippedAlt shows Gemini flatly disagreed,
            // only ever surfacing Gemini's number as a secondary
            // alternate_weight for a human to notice. Confirmed on the real
            // 73600-vs-73500 case: that left the AUTOMATICALLY-returned
            // number wrong even though the correct one was sitting right
            // there in alternate_weight, unused.
            //
            // preferGemini only applies when Vision's own read was ALREADY
            // the weaker signal (wasOriginallyFlagged) before Gemini was
            // even consulted — the exact same precedence already used (and
            // live-validated) on the separate "Vision found nothing" rescue
            // path a few hundred lines above (geminiDisagrees there). When
            // Vision's read was clean (not wasOriginallyFlagged) and Gemini
            // disagrees anyway, do NOT swap primary — Gemini is
            // independently non-deterministic (see visionOcr.js header) and
            // a clean Vision read has no a-priori reason to be distrusted
            // more than a fresh, possibly-hallucinated Gemini disagreement.
            // Instead this case only ELEVATES to ambiguous/flagged, turning
            // a previously totally-invisible potential miss into a visible,
            // checkable one — accuracy-over-speed without trading one
            // silent failure mode for a new one.
            const geminiDisagreed = strippedAlt != null;

            // Added 2026-08-12 — real disagreement resolution instead of a
            // coin-flip pick between two single, individually-unreliable
            // reads. Confirmed live: on the same crop, across different
            // calls, Vision said 73500 and Gemini said 73600 on one run, 79500
            // on another — neither side is trustworthy enough on its own to
            // just prefer blindly, including the "prefer Gemini when Vision
            // was already weak" rule two commits ago, which only works when
            // Gemini's single answer happens to be the correct one. Reuses
            // voteOnWeightReadings (previously dead code, built for exactly
            // this "a model's digit-level precision isn't perfectly reliable
            // call to call" problem) as a real tie-breaker: get a THIRD
            // independent read of the same crop and take a majority vote,
            // rather than trusting whichever of two disagreeing answers
            // happened to be tried first. Only paid when there's already a
            // disagreement worth resolving (rare) — never on an agreeing or
            // single-source read.
            //
            // Narrowed 2026-08-12, same day, after this vote was measured to
            // REGRESS a real case it had no business touching. On design-6
            // (true 73600) Vision's raw read was "573500" — a ghost leading
            // cell AND a wrong hundreds digit — which the leading-strip
            // fallback turned into 73500. Gemini read the same crop as 73600
            // (correct). The commit before this one preferred Gemini there
            // and got it RIGHT; adding the vote made it WRONG, because a
            // second Gemini call happened to side with Vision's 73500 and
            // outvoted the correct answer 2-1.
            //
            // The flaw is treating all three readings as equal witnesses.
            // When Vision's own raw text already showed corruption (it needed
            // a leading-digit strip to become plausible at all), Vision is
            // demonstrably compromised ON THIS SPECIFIC CROP — it is not an
            // independent peer, and letting it win a majority is unsound.
            // So the vote is now restricted to CLEAN disagreements only
            // (Vision produced a normal, unflagged read and Gemini still
            // disagreed) — the case where the two really are peers and a
            // third opinion is the honest arbiter. When Vision was already
            // flagged, fall back to the live-validated prefer-Gemini rule
            // from the previous commit instead of voting.
            let voteWinner = null;
            let voteReadings = null;
            if (geminiDisagreed && !wasOriginallyFlagged) {
                const TIEBREAK_TIMEOUT_MS = Number(process.env.GEMINI_TIEBREAK_TIMEOUT_MS) || 15000;
                const tieBreakPromise = readWeightSinglePass(accurate.croppedBase64, 'image/jpeg', 1, { isCrop: true }).catch((err) => {
                    console.warn('[GEMINI] Tie-breaker read failed:', err.message);
                    return null;
                });
                const tieBreak = await withTimeout(tieBreakPromise, Math.min(TIEBREAK_TIMEOUT_MS, remainingBudget()), 'Gemini tie-breaker read (3rd opinion on disagreement)');
                voteReadings = [
                    { weight: accurate.visionWeight, raw_text: 'Vision' },
                    { weight: strippedAlt, raw_text: 'Gemini (1st read)' },
                    (tieBreak && tieBreak.weight != null) ? { weight: tieBreak.weight, raw_text: 'Gemini (2nd/tie-break read)' } : null,
                ].filter(Boolean);
                voteWinner = voteOnWeightReadings(voteReadings);
            }
            // A real majority (more than half of however many readings we
            // actually got — 2 of 2 if the tie-break call failed/timed out,
            // 2 of 3 or 3 of 3 if it landed) counts as resolved: treat the
            // extra verification work as real evidence, not just another
            // guess, and stop flagging for human review. A genuine 3-way
            // split (no majority at all) is the one case nothing here can
            // resolve — stays ambiguous, all three readings surfaced so a
            // human isn't left guessing which of three numbers is real.
            const voteMajorityCount = voteWinner && voteReadings
                ? voteReadings.filter((r) => String(r.weight) === String(voteWinner.weight)).length
                : 0;
            // Changed 2026-08-12, same real test run that justified building
            // this in the first place: a simple >50% majority is NOT safe
            // enough to clear the ambiguous flag on its own. Observed live:
            // 2 of 3 independent reads (Vision + 2 separate Gemini calls)
            // converged on the SAME WRONG digit (79600, true value 73600) —
            // a systematic misread this specific crop's rendering provokes
            // in multiple models, not the independent random-flip error this
            // vote was originally built to catch. A 2/3 majority in that
            // case would have marked a wrong answer as resolved/unambiguous
            // — worse than doing no voting at all, since it INCREASES false
            // confidence instead of reducing it. Requiring full unanimity
            // (every reading that came back agrees) before ever clearing the
            // flag keeps the safety property intact: voting can still pick
            // which number to report as the best guess among disagreeing
            // reads, but never gets to claim certainty it doesn't actually
            // have.
            const voteResolved = voteWinner && voteReadings && voteMajorityCount === voteReadings.length;
            const voteLosers = voteWinner && voteReadings
                ? [...new Set(voteReadings.filter((r) => String(r.weight) !== String(voteWinner.weight)).map((r) => r.weight))]
                : [];

            // Three-way selection, in order of how much evidence backs it:
            //   1. A clean-disagreement vote actually ran -> use its winner.
            //   2. No vote ran because Vision was ALREADY flagged as weak and
            //      Gemini disagreed -> prefer Gemini (the live-validated rule
            //      from the previous commit; this is the design-6 case, where
            //      Vision's raw text openly showed ghost-cell corruption).
            //   3. Otherwise -> Vision's own read, unchanged.
            const preferGeminiOnFlagged = !voteWinner && wasOriginallyFlagged && geminiDisagreed;
            const finalWeight = voteWinner ? voteWinner.weight
                : (preferGeminiOnFlagged ? strippedAlt : accurate.visionWeight);
            const finalAlt = voteWinner ? (voteLosers.length ? voteLosers[0] : null)
                : (geminiDisagreed ? (preferGeminiOnFlagged ? accurate.visionWeight : strippedAlt) : null);
            const finalAltSource = voteWinner ? (voteLosers.length ? 'disagreeing read' : null)
                : (geminiDisagreed ? (preferGeminiOnFlagged ? 'Cloud Vision OCR' : 'Gemini') : null);
            // Only a resolved (unanimous) vote can clear the flag. Everything
            // else that involved a disagreement stays ambiguous — including
            // the prefer-Gemini case, where we're picking the more likely of
            // two numbers but have no independent confirmation of it.
            const finalAmbiguous = geminiDisagreed ? !voteResolved : flagForReview;
            const cleanDisagreeNote = (!wasOriginallyFlagged && geminiDisagreed)
                ? ` — Gemini's independent read of the same crop disagreed with Vision's otherwise-clean reading`
                : '';
            const voteNote = voteWinner && voteReadings
                ? (voteResolved
                    ? ` [${voteMajorityCount}/${voteReadings.length} independent reads agreed on ${voteWinner.weight}${voteLosers.length ? ` (other read: ${voteLosers.join(', ')})` : ''}]`
                    : ` [no majority across ${voteReadings.length} independent reads: ${voteReadings.map((r) => r.weight).join(', ')} — genuinely unresolved, please verify against the actual display]`)
                : '';

            console.log(`[GEMINI] Weight read via ${voteWinner ? `majority vote (${voteMajorityCount}/${voteReadings.length})` : 'Cloud Vision OCR (primary, cropped, fast path)'} in ${elapsed()}: ${finalWeight}${reviewReason}${cleanDisagreeNote}${voteNote}${strippedNote ? ` (Gemini could not fully commit but noted: "${strippedNote}")` : ''}`);
            // Bracketed note must fire whenever there's ANYTHING to flag —
            // the original reviewReason (suspiciouslyShort/viaStrip/
            // lowResInput) OR the new clean-disagree/vote notes, which have
            // no reviewReason of their own (that variable is only ever built
            // from the three original triggers). Using reviewReason alone
            // here would silently drop those notes entirely — the exact kind
            // of gap this whole round of fixes exists to close.
            const anyNoteToShow = !!reviewReason || !!cleanDisagreeNote || !!voteNote || !!strippedNote;
            return {
                weight: finalWeight,
                alternate_weight: finalAlt,
                alternate_source: finalAltSource,
                weight_unit: 'lb',
                displays_seen: `${voteWinner ? 'majority vote across Vision + Gemini' : 'Cloud Vision OCR'} read of located display (locate reason: "${accurate.box.reason || ''}")`,
                raw_text: `${accurate.visionText} (Cloud Vision OCR, fast path — classified as weighbridge/default from Vision's own crop text, no Gemini wait)${anyNoteToShow ? ` [${(reviewReason || cleanDisagreeNote).replace(/^ — /, '')}${voteNote}${strippedNote ? `; Gemini's own read of the same crop noted: "${strippedNote}" — compare against Vision's ${accurate.visionWeight} before trusting either` : ''} — please verify against the actual display]` : ''}`,
                ambiguous: finalAmbiguous,
            };
        }

        // SLOW PATH — only compact indicators pay this cost, since Vision
        // is proven UNRELIABLE on this display type (hallucinated a blank
        // leading cell into "8" — "82258" instead of "2251" — reproduced
        // live 3x). We genuinely need Gemini's actual digit value here,
        // there's no way around waiting for it on this branch. It was
        // kicked off in parallel back when the crop was first ready, so
        // most of its latency is already absorbed by the time Vision's OCR
        // + this text classification finished (~1.3-4.6s head start
        // observed live) — the timeout below is a safety cap, not the
        // expected wait.
        // Bounded by whatever is LEFT of the total budget (2026-08-19), not
        // its own fresh 8s clock — that fixed 8s on top of an already-elapsed
        // ~2s crop read is exactly what produced the ~10s reads measured on
        // the Socome. GEMINI_META_TIMEOUT_MS still acts as an upper bound so
        // an unusually large budget can't make this branch wait forever.
        const GEMINI_META_TIMEOUT_MS = Number(process.env.GEMINI_META_TIMEOUT_MS) || 8000;
        const compactWait = Math.min(GEMINI_META_TIMEOUT_MS, remainingBudget());
        console.log(`[GEMINI] Compact indicator: waiting up to ${compactWait}ms for Gemini (total so far ${elapsed()}, budget ${TOTAL_BUDGET_MS}ms)`);
        const geminiMeta = await withTimeout(accurate.geminiMetaPromise, compactWait, 'Gemini crop metadata');
        const preferGemini = !!(geminiMeta && geminiMeta.weight != null);

        const primaryWeight = preferGemini ? geminiMeta.weight : accurate.visionWeight;
        const altWeight = preferGemini ? accurate.visionWeight : null;
        const altSource = preferGemini ? 'Cloud Vision' : null;

        // If Gemini's call also failed/timed out here, we have NO trustworthy
        // reading at all for a display type Vision is proven wrong on — must
        // flag rather than silently hand back Vision's likely-wrong number.
        const ambiguous = !preferGemini;
        const note = preferGemini
            ? ` [display classified as a compact indicator from Vision's own OCR text — Gemini used as primary here instead of Vision, which hallucinates on this display type; Vision's read was ${accurate.visionWeight}]`
            : ` [display classified as a compact indicator, where Vision is known-unreliable, but Gemini's second-opinion read did not return in time — Vision's read (${accurate.visionWeight}) returned anyway as a best-effort fallback, flagged for review]`;
        console.log(`[GEMINI] Weight read via ${preferGemini ? 'Gemini' : 'Cloud Vision OCR (fallback)'} (primary, cropped, slow path) in ${elapsed()}: ${primaryWeight}${note}`);
        return {
            weight: primaryWeight,
            alternate_weight: altWeight,
            alternate_source: altSource,
            weight_unit: (geminiMeta && geminiMeta.weight_unit) || 'lb',
            displays_seen: (geminiMeta && geminiMeta.displays_seen) || `Cloud Vision OCR read of located display (locate reason: "${accurate.box.reason || ''}")`,
            raw_text: `${accurate.visionText} (Cloud Vision OCR)${note}`,
            ambiguous,
        };
    }

    // Accurate path didn't produce a usable Vision reading within budget
    // (locate too slow/failed, crop failed, or the crop's Vision read came
    // back empty) — use the whole-image Vision OCR kicked off at the very
    // top instead of waiting any further.
    const wholeVisionText = await wholeImageVisionPromise;
    // A whole, uncropped photo can legitimately contain more than one number
    // (a bench-scale item reading, a date, a truck ID) — extractWeightNumber's
    // "longest digit run" heuristic is only safe on an isolated crop, so the
    // whole-image path uses extractPlausibleWeightFromFullImage instead, which
    // constrains to a plausible truck-load range and flags ambiguity rather
    // than silently guessing. See helpers/visionOcr.js for the full reasoning.
    const wholeVisionResult = visionOcr.extractPlausibleWeightFromFullImage(wholeVisionText);

    // Added 2026-08-11 after a measured, reproducible miss on a
    // WhatsApp-compressed photo (true weight 28460): the accurate path's
    // crop read came back empty, this whole-image fallback mined "41516"
    // out of unrelated full-photo text and returned it — while Gemini's
    // read of the actual CROP, already in flight, resolved moments later
    // with the correct 28460 and was thrown away unused. Reading the whole
    // photo is the weakest source we have (it is explicitly a "largest
    // plausible number in the frame" guess, not a display read), so it must
    // not win a race against a real read of the isolated display that is
    // already running. Wait for it here, bounded, and prefer it. This only
    // costs latency on a path that has ALREADY failed to read the crop —
    // never on a normal successful read.
    //
    // Second half of the same finding: on that photo the accurate path had
    // not merely failed, it had TIMED OUT — the red pixel locate found
    // nothing usable, so it fell through to Gemini's AI locate, which alone
    // took 9848ms and blew the 9000ms ACCURATE_PATH_BUDGET_MS. The budget
    // returns null and moves on, but the path keeps running: it produced a
    // correct crop and Gemini's "28460" at ~11.8s, about 2.7s after this
    // fallback had already committed to the wrong 41516. So before settling
    // for whole-image mining, give the still-running accurate path a bounded
    // second chance to land. Same trade as above: extra latency only on a
    // path that was about to return the weakest answer we produce.
    let lateAccurate = accurate;
    if (!lateAccurate) {
        const ACCURATE_PATH_GRACE_MS = Number(process.env.ACCURATE_PATH_GRACE_MS) || 8000;
        lateAccurate = await withTimeout(accuratePathPromise, Math.min(ACCURATE_PATH_GRACE_MS, remainingBudget()), 'Locate+crop accurate path (grace period before whole-image fallback)');
        if (lateAccurate && lateAccurate.visionWeight != null) {
            console.log(`[GEMINI] Accurate path landed during the grace period in ${elapsed()}: ${lateAccurate.visionWeight} — using it instead of whole-image OCR${wholeVisionResult.weight != null ? ` (${wholeVisionResult.weight})` : ''}`);
            return {
                weight: lateAccurate.visionWeight,
                alternate_weight: wholeVisionResult.weight != null && wholeVisionResult.weight !== lateAccurate.visionWeight ? wholeVisionResult.weight : null,
                alternate_source: wholeVisionResult.weight != null && wholeVisionResult.weight !== lateAccurate.visionWeight ? 'Cloud Vision OCR (whole image)' : null,
                weight_unit: 'lb',
                displays_seen: `Cloud Vision OCR read of located display, landed after the accurate-path budget (locate reason: "${(lateAccurate.box && lateAccurate.box.reason) || ''}")`,
                raw_text: `${lateAccurate.visionText} (Cloud Vision OCR on the display crop, after grace period)`,
                ambiguous: true,
            };
        }
    }

    if (lateAccurate && lateAccurate.geminiMetaPromise) {
        const GEMINI_WHOLEIMAGE_RESCUE_TIMEOUT_MS = Number(process.env.GEMINI_WHOLEIMAGE_RESCUE_TIMEOUT_MS) || 12000;
        const cropRead = await withTimeout(
            lateAccurate.geminiMetaPromise,
            Math.min(GEMINI_WHOLEIMAGE_RESCUE_TIMEOUT_MS, remainingBudget()),
            'Gemini crop metadata (rescue before falling back to whole-image OCR)',
        );
        if (cropRead && cropRead.weight != null) {
            console.log(`[GEMINI] Weight read via Gemini's crop read in ${elapsed()}: ${cropRead.weight} — preferred over the whole-image OCR guess${wholeVisionResult.weight != null ? ` (${wholeVisionResult.weight})` : ''}, since a read of the isolated display beats mining the largest plausible number out of the full photo`);
            return {
                weight: cropRead.weight,
                alternate_weight: wholeVisionResult.weight != null && wholeVisionResult.weight !== cropRead.weight ? wholeVisionResult.weight : null,
                alternate_source: wholeVisionResult.weight != null && wholeVisionResult.weight !== cropRead.weight ? 'Cloud Vision OCR (whole image)' : null,
                weight_unit: cropRead.weight_unit || 'lb',
                displays_seen: cropRead.displays_seen || 'Gemini read of the located display crop (Vision found nothing on that crop)',
                raw_text: `${cropRead.raw_text || ''} (Gemini read of the display crop — used instead of whole-image OCR, which found ${wholeVisionResult.weight != null ? wholeVisionResult.weight : 'nothing usable'})`,
                ambiguous: true,
            };
        }
    }

    if (wholeVisionResult.weight != null) {
        const ambiguityNote = wholeVisionResult.ambiguous
            ? ` [more than one plausible weight-sized number was found in the full photo (${wholeVisionResult.candidates.join(', ')}) — no display could be isolated first, so this is the largest of them; PLEASE VERIFY against the actual weighbridge display before trusting it]`
            : '';
        console.log(`[GEMINI] Weight read via Cloud Vision OCR (whole image) in ${elapsed()}: ${wholeVisionResult.weight}${wholeVisionResult.ambiguous ? ' — AMBIGUOUS, multiple candidates, flagged for review' : ''}`);
        return {
            weight: wholeVisionResult.weight,
            weight_unit: 'lb',
            displays_seen: `Cloud Vision OCR read of the full photo (no display could be located/cropped in time)${ambiguityNote}`,
            raw_text: `${wholeVisionText} (Cloud Vision OCR, whole image)${ambiguityNote}`,
            // Explicit boolean, not just text buried in raw_text/displays_seen —
            // added after discovering the caller (mobile-app + dashboard
            // processWeightImage) only ever showed a generic "check it matches
            // the scale" message on-screen and logged raw_text/displays_seen to
            // the browser console only, which nobody at a yard station is going
            // to open. The frontend now checks this field directly to show a
            // loud, distinct on-screen warning instead of a message a busy
            // operator can tune out.
            ambiguous: !!wholeVisionResult.ambiguous,
        };
    }

    console.warn(`[GEMINI] Vision OCR found nothing on either path by ${elapsed()}, falling back to Gemini single-pass read (last resort, will be slow)`);
    return readWeightSinglePass(imageBase64, mimeType, retries);
}

// HARD DEADLINE BACKSTOP, per the owner 2026-08-19 ("make it 5s").
//
// Every individual wait inside extractWeightFromImageInner is now bounded by
// the same total budget, which brought 8 of 10 real Socome photos to land at
// almost exactly 5.0s. Two still overran (11.1s and 17.0s) through paths with
// their own internal retry/backoff loops that a per-await cap doesn't reach.
// Rather than keep hunting individual call sites — each one a chance to miss
// another — this guarantees the ceiling structurally: whatever happens
// inside, the caller gets an answer within the budget.
//
// On expiry it returns NO weight rather than a partial guess. That is
// deliberate: the reads that overrun are exactly the ones where the pipeline
// is still arguing with itself about which number is right, so publishing
// whichever value happened to be in hand would be publishing the least
// trustworthy kind of answer. Both UIs already render a null weight as
// "Couldn't read a number — enter manually", which is a safe, honest
// outcome and far better than a wrong weight on a ticket.
async function extractWeightFromImage(imageBase64, mimeType = 'image/jpeg', retries = 2, opts = {}) {
    const budget = Number(opts.budgetMs)
        || Number(process.env.WEIGHT_READ_BUDGET_MS)
        || (opts.preCropped ? 5000 : 5000);
    // Small grace on top of the internal budget so the internal logic — which
    // can still return a good flagged answer — normally wins the race, and
    // this backstop only fires when something genuinely overran.
    const hardDeadline = budget + 600;
    let timer = null;
    const deadline = new Promise((resolve) => {
        timer = setTimeout(() => resolve({
            weight: null,
            alternate_weight: null,
            alternate_source: null,
            weight_unit: 'lb',
            displays_seen: `read exceeded the ${budget}ms budget`,
            raw_text: `The weight read did not complete within ${budget}ms and was stopped. No number is being reported rather than an unverified one — re-take the photo or enter the weight manually.`,
            ambiguous: true,
            timedOut: true,
        }), hardDeadline);
        if (timer.unref) timer.unref();
    });
    try {
        return await Promise.race([extractWeightFromImageInner(imageBase64, mimeType, retries, opts), deadline]);
    } finally {
        if (timer) clearTimeout(timer);
    }
}

// ── WHICH MODEL IS ACTUALLY RUNNING (#159, 2026-10-03) ───────────────────
// #159 says the workhorse is legacy and should move. Working out HOW to move
// it turned up the reason it had not: changing cfg.GEMINI_MODEL, or the
// GEMINI_MODEL env var, very likely does nothing on the live server.
//
// getModelName() reads loadSettings().gemini_model FIRST. loadSettings() is
// loadJson(SETTINGS_FILE, {...defaults}), and loadJson returns the FILE AS IT
// IS — it does not merge the defaults into it. On its own that would be fine:
// a settings file with no gemini_model key falls through to the config.
//
// But PUT /api/settings saves `{ ...loadSettings(), ...req.body }`. So the
// first time anyone ever saved ANY setting — the team group id, an email bcc,
// the yard report addresses — the whole default object was written out with
// it, and 'gemini-2.5-flash-lite' was frozen into data/settings.json. From
// that moment the config default and the env var are both dead letters, and
// a deploy that "moves the workhorse off the legacy model" moves nothing.
//
// That is a silent config failure of exactly the shape the JARVIS_PASSWORD
// block in api.js exists to prevent, so this is the equivalent: it reports
// what each tier will really use and WHERE the value came from. It decides
// nothing and changes no model — a stored pin is still honoured, because
// someone may have set it on purpose and quietly ignoring it would be the
// same class of mistake in the other direction.
//
// THE LEGACY WARNING IS NOT COSMETIC. Google is "limiting access to the 2.5
// models to users who have actively used them in the past"; this project has,
// so it still works today, but it is a model on the way out being used by
// unattended watchers — claim mail, the inbox scan — where a 404 would be
// noticed late or not at all.
const LEGACY_MODELS = /^gemini-2\.5/;

// ── READS THE FILE, NOT loadSettings() ───────────────────────────────────
// Found by this report's own test, and it is worse than the frozen-pin story
// above. loadSettings() is loadJson(SETTINGS_FILE, {...defaults}) and the
// DEFAULT OBJECT itself contains
//
//     gemini_model: process.env.GEMINI_MODEL || 'gemini-2.5-flash-lite'
//
// so loadSettings().gemini_model is never undefined — not even on a server
// with no settings file at all. Which means the `|| cfg.GEMINI_MODEL` in
// getModelName() is DEAD CODE: cfg.GEMINI_MODEL is never what decides. The
// value always comes from either the stored file or that default's own env
// lookup, and the config constant is decorative.
//
// Asking loadSettings() therefore cannot tell a deliberate stored pin from
// the default handing back the same string, so this reads the file and looks
// for the key. A report that cannot distinguish those two would have called
// every server "pinned" and been useless.
function storedPin() {
    try {
        const fs2 = require('fs');
        if (!fs2.existsSync(cfg.SETTINGS_FILE)) return null;
        const raw = JSON.parse(fs2.readFileSync(cfg.SETTINGS_FILE, 'utf8'));
        if (!raw || typeof raw !== 'object') return null;
        // A missing key gives undefined, which the typeof below rejects — so
        // there is no hasOwnProperty test here. One was written, and no
        // control could make it bite, because it could not: it is the same
        // condition twice. Removed rather than left looking load-bearing.
        const v = raw.gemini_model;
        return (typeof v === 'string' && v.trim()) ? v.trim() : null;
    } catch { return null; }
}

function effectiveModels() {
    const pinned = storedPin();

    // ── ASK THE FUNCTION THE CALLERS ASK ─────────────────────────────────
    // getModelName(), not a second computation of the same thing. The first
    // version worked it out itself as `pinned || cfg.GEMINI_MODEL` and was
    // WRONG whenever the env var was what decided: cfg is cached at module
    // load, while loadSettings()'s default reads process.env live. So the
    // report said one model and the callers used another — a monitor that
    // can disagree with the thing it monitors is worse than none.
    const workhorse = getModelName();
    const fromEnv = !!(process.env.GEMINI_MODEL || '').trim();
    return {
        workhorse,
        // Which of the three possible sources actually decided it. 'settings'
        // means the config and the env var are both being ignored.
        workhorseFrom: pinned ? 'settings' : (fromEnv ? 'env' : 'config'),
        // Only meaningful when workhorseFrom is 'settings': what the config
        // WOULD have given, so the gap is visible rather than inferred.
        configWouldGive: cfg.GEMINI_MODEL,
        pinned,
        smart: cfg.GEMINI_MODEL_SMART,
        vision: getVisionModelName(),
        visionFallback: FALLBACK_VISION_MODEL,
        // Named rather than counted: a count goes stale and nobody updates it.
        legacy: [
            ['workhorse', workhorse],
            ['vision', getVisionModelName()],
            ['vision fallback', FALLBACK_VISION_MODEL],
            ['smart', cfg.GEMINI_MODEL_SMART],
        ].filter(([, m]) => LEGACY_MODELS.test(String(m || ''))).map(([k, m]) => `${k}=${m}`),
    };
}

// The boot line, and the same text for scripts/gemini-model-report.js, so the
// two can never say different things about the same server.
function modelReportLines() {
    const e = effectiveModels();
    const out = [];
    out.push(`[GEMINI] workhorse ${e.workhorse} (from ${e.workhorseFrom}) · smart ${e.smart} · vision ${e.vision}`);
    // ── FIRES WHENEVER IT IS PINNED, NOT ONLY WHEN THEY DISAGREE ─────────
    // The first version only spoke up once the pin and the config differed —
    // which is to say, only after somebody had already changed config.js,
    // deployed it, and had it do nothing. The dangerous state is the pin
    // EXISTING, because that is when the config is inert; the two agreeing
    // today is what makes it invisible. So it says so either way, and only
    // the second sentence changes.
    if (e.workhorseFrom === 'settings') {
        out.push(`[GEMINI] NOTE: the workhorse is PINNED in data/settings.json to ${e.pinned}. `
            + (e.pinned === e.configWouldGive
                ? `config.js happens to agree (${e.configWouldGive}), so this looks fine and is not: `
                  + 'the stored value wins, and editing config.js or GEMINI_MODEL will change nothing '
                  + 'until that key is removed from the settings file.'
                : `config.js says ${e.configWouldGive} and is being IGNORED — remove the key from the `
                  + 'settings file for the config to take effect.'));
    }
    if (e.legacy.length) {
        out.push(`[GEMINI] WARNING: still on a 2.5-family model — ${e.legacy.join(', ')}. `
            + 'Google is limiting access to the 2.5 models; unattended watchers use these.');
    }
    return out;
}

// getClient/getModelName exported 2026-09-16 for helpers/packingList.js.
// Every extraction in this file builds its own model with its own prompt and
// generationConfig; a new one doing the same thing needs the client, and the
// alternative was a ninth near-identical extract* function living here, far
// from the store it feeds.
module.exports = {
    extractOrderPdfFields, getClient, getModelName, effectiveModels, modelReportLines, callGeminiJSON, extractJson, lastGeminiFailure, extractPdfFields, extractBookingFieldsFromText, resolveCutoffDate, classifyDocument, extractScaleTicketFields, extractWeightFromImage, checkPhotoQuality, extractFreightInvoiceRecords, extractCommissionDebitNoteRecords, extractJioInvoiceRecords, extractSherTruckingInvoiceRecords, extractAjTransportInvoiceRecords, extractGardunosInvoiceRecords, extractEagleInvoiceRecords, transcribeVoiceNote };