// ── helpers/embeddings.js — Semantic memory via Supabase + pgvector ─────────
// v2: replaced the original flat-JSON + in-process cosine-scan implementation
// with a real vector database (Postgres + the open-source pgvector extension,
// hosted on Supabase's free tier). Same reasoning as before — this is genuine
// RAG, not keyword matching — now on infrastructure that doesn't accumulate
// forever in a JSON file and actually indexes for fast similarity search.
//
// Deliberately uses @google/genai (the newer Gemini SDK) ONLY here, not
// @google/generative-ai (which helpers/gemini.js uses for everything else).
// Reason: reliable control over embedding output dimension (768, via
// Matryoshka truncation) is confirmed to work on the newer SDK; the older
// one's support for this is undocumented/inconsistent. Keeping this as an
// isolated dependency means zero risk to the existing, stable JSON-generation
// path in gemini.js.
//
// External function signatures (storeEmbedding, searchSimilar) are UNCHANGED
// from the v1 flat-JSON version — helpers/memory.js and helpers/context.js
// need no edits at all for this swap.

const cfg = require('../config');

const EMBED_MODEL = 'gemini-embedding-001';
const EMBED_DIMENSIONS = 768; // must match the `vector(768)` column in Supabase — see supabase_setup.sql
const DEFAULT_TOP_K = 3;
const DEFAULT_MIN_SIMILARITY = 0.55;

function getSupabase() {
    return require('./supabase').getSupabase();
}

let genAI = null;
function getGenAI() {
    if (!genAI) {
        if (!cfg.GEMINI_API_KEY) throw new Error('GEMINI_API_KEY missing');
        const { GoogleGenAI } = require('@google/genai');
        genAI = new GoogleGenAI({ apiKey: cfg.GEMINI_API_KEY });
    }
    return genAI;
}

// REAL BUG, found 2026-08-16 while investigating production log spam
// ("[EMBEDDINGS] search failed (non-fatal): Value must be a list given an
// array path requests[]" — that error text comes straight from Google's
// backend rejecting the malformed request this function was sending).
// Confirmed directly against the installed @google/genai@0.3.1 SDK's own
// type definitions (node_modules/@google/genai/dist/genai.d.ts):
// EmbedContentParameters requires `contents` (plural — a ContentListUnion,
// e.g. a single string or an array), not `content` (singular) — the wrong
// key name meant the SDK never got a valid request body, hence the
// batch-endpoint-shaped validation error at the API level. The response
// side had the matching bug: EmbedContentResponse carries `embeddings`
// (plural array, one ContentEmbedding per input), not a singular
// `embedding` — so even if the request had somehow succeeded, reading
// `response.embedding.values` would still have come back undefined and
// thrown the "Embedding returned 0 dims" error below instead.
// Every call to Gemini's embedding API through this file has been failing
// silently since this was written — storeEmbedding() and searchSimilar()
// both catch and log "(non-fatal)", by design, so nothing crashed, but
// semantic memory (session-summary recall) has effectively never worked.
async function embedText(text, taskType = 'RETRIEVAL_DOCUMENT') {
    const response = await getGenAI().models.embedContent({
        model: EMBED_MODEL,
        contents: text,
        config: { taskType, outputDimensionality: EMBED_DIMENSIONS },
    });
    const vector = response?.embeddings?.[0]?.values;
    if (!Array.isArray(vector) || vector.length !== EMBED_DIMENSIONS) {
        throw new Error(`Embedding returned ${vector?.length ?? 0} dims, expected ${EMBED_DIMENSIONS}`);
    }
    return vector;
}

// Store a piece of text (session summary, etc.) as searchable long-term
// memory. Failure here is non-fatal by design — memory is a nice-to-have,
// never a dependency for the app's core operation.
// LABELS (2026-11-14, memory layer 1): who a memory came from (origin: the role
// of the chat it was formed in) and which company it belongs to. Written only
// when JARVIS_MEMORY_LABELS=1, AFTER the two columns exist (supabase_labels.sql).
// If the columns are missing the insert is retried without them, so turning the
// flag on early can never stop memories being saved.
const labelsOn = () => process.env.JARVIS_MEMORY_LABELS === '1';
async function storeEmbedding({ chatId, text, type = 'summary', origin = null, company = null }) {
    const clean = String(text || '').trim();
    if (!clean) return;
    try {
        const vector = await embedText(clean, 'RETRIEVAL_DOCUMENT');
        const row = { chat_id: chatId, text: clean, type, embedding: vector };
        const labelled = labelsOn() && (origin || company);
        if (labelled) { if (origin) row.origin = origin; if (company) row.company = company; }
        let { error } = await getSupabase().from('memory_embeddings').insert(row);
        if (error && labelled && /origin|company|column/i.test(String(error.message || ''))) {
            console.warn('[EMBEDDINGS] label columns missing, saving without labels (run supabase_labels.sql)');
            delete row.origin; delete row.company;
            ({ error } = await getSupabase().from('memory_embeddings').insert(row));
        }
        if (error) throw error;
    } catch (e) {
        console.error('[EMBEDDINGS] store failed (non-fatal):', e.message);
    }
}

// Semantic search via the match_memory_embeddings Postgres function (see
// supabase_setup.sql). Returns [] on any failure rather than throwing, so a
// memory-layer hiccup never blocks the actual conversation.
async function searchSimilar(queryText, { chatId = null, topK = DEFAULT_TOP_K, minSimilarity = DEFAULT_MIN_SIMILARITY } = {}) {
    const clean = String(queryText || '').trim();
    if (!clean) return [];
    try {
        const queryVector = await embedText(clean, 'RETRIEVAL_QUERY');
        const { data, error } = await getSupabase().rpc('match_memory_embeddings', {
            query_embedding: queryVector,
            match_threshold: minSimilarity,
            match_count: topK,
            filter_chat_id: chatId,
        });
        if (error) throw error;
        return (data || []).map(row => ({
            id: row.id, chatId: row.chat_id, text: row.text, type: row.type,
            created_at: row.created_at, similarity: row.similarity,
            origin: row.origin || null, company: row.company || null,
        }));
    } catch (e) {
        console.error('[EMBEDDINGS] search failed (non-fatal):', e.message);
        return [];
    }
}

// ── DELETE (2026-08-25, memory architecture phase 1) ───────────────────────
// Added because nothing in this codebase could remove a vector row, which
// meant a fact deleted from facts.json lived on here forever and was
// re-surfaced by searchSimilar on the very next message. See
// helpers/json.js's deleteFactById header for the full incident.
//
// Matched on exact text + type rather than on a fact id, because that is
// what storeEmbedding actually persists — there is no fact_id column today.
// A schema with a real foreign key is the right long-term answer (phase 2);
// this closes the live hole without a Supabase migration the owner would have
// to run by hand before the fix took effect.
//
// Deliberately NOT silent about the outcome: this returns the number of
// rows deleted so a caller can tell "cleaned up" from "couldn't reach the
// store". Everything else in this file returns [] or undefined on failure,
// which is right for a nice-to-have read path and wrong for a deletion the
// manager explicitly asked for.
async function deleteEmbeddingsByText(text, type = null) {
    const clean = String(text || '').trim();
    if (!clean) return 0;
    let q = getSupabase().from('memory_embeddings').delete().eq('text', clean);
    if (type) q = q.eq('type', type);
    const { data, error } = await q.select('id');
    if (error) throw error;
    const n = (data || []).length;
    console.log(`[EMBEDDINGS] deleted ${n} vector row(s) for a retracted ${type || 'memory'}`);
    return n;
}

module.exports = { storeEmbedding, searchSimilar, deleteEmbeddingsByText };
