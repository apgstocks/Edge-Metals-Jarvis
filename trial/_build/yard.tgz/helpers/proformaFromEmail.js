// ── helpers/proformaFromEmail.js — read an order out of an email ─────────────
//
// the owner, 2026-08-23: "Check mail from Joey and send proforma to her — it
// should check mail and prepare proforma according to that."
//
// WHAT THIS IS NOT DOING, because most of it was already built.
//
// workflow/replyWatch.js (her rework, 2026-08-22) already reads arbitrary
// inbound mail, strips quoted history and signatures via email-reply-parser,
// and puts a schema'd Gemini judgement over the clean text. This file does not
// repeat any of that. It reuses extractLatestMessage() for the body and
// follows assess()'s exact shape — callGeminiJSON with a zod schema, then
// normalise every field by hand so the result does not depend on whether an
// optional package happens to be installed.
//
// All that is genuinely new here is the SCHEMA: a purchase order has fields a
// reply-assessment does not care about (material, quantity, rate, currency,
// incoterms), and pulling those out is a different question from "is someone
// waiting on me".
//
// CONFIDENCE IS LOAD-BEARING, NOT DECORATION.
//
// replyWatch holds low-confidence items back rather than pinging about them.
// The same discipline matters more here, because the output is a priced
// document going to a customer. A model that has half-guessed a rate from an
// ambiguous email must say so, and the caller must be able to tell the
// difference between "the email says $340/MT" and "there is a 340 in here
// somewhere". So every field carries its own confidence, and anything the
// email does not actually state comes back null rather than inferred.
//
// Nothing in this file sends anything. It returns a draft for a human to look
// at — see workflow/actions.js's proforma flow for the confirmation step.

const { callGeminiJSON } = require('./gemini');

// zod, loaded defensively — same posture as replyWatch.js. A missing package
// degrades to unvalidated JSON that the normaliser below still cleans up; it
// never crashes the command.
let OrderSchema = null;
try {
    const { z } = require('zod');
    OrderSchema = z.object({
        is_order: z.coerce.boolean(),
        confidence: z.coerce.number().min(0).max(1).optional().default(0),
        consignee: z.string().nullable().optional().default(null),
        currency: z.string().nullable().optional().default(null),
        trade_terms: z.string().nullable().optional().default(null),
        port_discharge: z.string().nullable().optional().default(null),
        payment_term: z.string().nullable().optional().default(null),
        container_count: z.coerce.number().nullable().optional().default(null),
        items: z.array(z.object({
            desc: z.string(),
            qty: z.coerce.number().nullable().optional().default(null),
            rate: z.coerce.number().nullable().optional().default(null),
            rate_confidence: z.coerce.number().min(0).max(1).optional().default(0),
            // 'per_lb' ADDED 2026-10-03, AND IT WAS A MONEY BUG, NOT A TIDY-UP.
            // Measured while auditing auto-send: on Joey's "Confirmation of
            // one container of Chrome wheels ... at $0.42/lb" the model
            // returned rate_basis "per_lb", which was not in this enum, so the
            // whole extraction FAILED SCHEMA three times and the order was
            // lost. On "$0.42 per pound" for auto batteries it instead did the
            // helpful thing and coerced the value into an allowed option --
            // "per_mt". $0.42/lb vs $0.42/MT is a factor of 2,204.62.
            //
            // An enum that gives the model no honest option does not prevent a
            // basis error, it MANUFACTURES one. She buys domestic scrap by the
            // pound and exports by the tonne, so per-lb is her normal case,
            // not an edge.
            // A STRING, NOT AN ENUM, AND THAT IS THE REAL LESSON HERE.
            // Adding 'per_lb' fixed the case I had measured and the audit
            // immediately threw a THIRD value I had not: the whole extraction
            // still died three attempts deep on
            //   "expected one of per_mt|per_lb|per_lot|unknown".
            // An enum on a free-text field the model fills is a tripwire --
            // every vocabulary she or a counterparty uses that I have not
            // enumerated destroys the entire order rather than degrading one
            // field. The whitelist in extractOrderFromEmail already maps
            // anything unrecognised to 'unknown', which blocks the rate from
            // pricing. That is the correct failure: lose the basis, keep the
            // order.
            rate_basis: z.string().optional().default('unknown'),
        })).optional().default([]),
        missing: z.array(z.string()).optional().default([]),
        note: z.string().nullable().optional().default(null),
    });
} catch (e) {
    console.warn('[PROFORMA-MAIL] zod not installed — Gemini output will be normalised without schema validation.');
}

function buildOrderPrompt({ from, subject, body, date }) {
    return `You are reading ONE email sent to a scrap-metal exporter, deciding whether it is asking for a PROFORMA INVOICE (a priced quote for a shipment) and, if so, pulling out exactly what it states.

FROM: ${from || '(unknown)'}
DATE: ${date || '(unknown)'}
SUBJECT: ${subject || '(none)'}

BODY:
"""
${String(body || '').slice(0, 6000)}
"""

Return JSON only.

is_order: true ONLY if the sender is asking to buy material, asking for a proforma/PI, confirming an order, or giving quantities and/or prices for a shipment they want. false for a general enquiry with no material or quantity, a reply about an EXISTING shipment, an invoice or payment message, or marketing.

THE RULE THAT MATTERS MOST: report only what the email ACTUALLY STATES. Never infer, complete, or tidy up a number. If the email does not give a rate, rate is null — do not carry one over from a price list, a previous order, or your own sense of what scrap costs. A null is useful; a plausible invention is dangerous, because this becomes a priced document sent to this customer.

consignee: the company that is BUYING — the one the proforma will be addressed to. This is very often NOT the sender. Orders here routinely arrive from an agent or broker writing on a buyer's behalf, sometimes naming commissions for other people entirely ("$10 c for Hynos"). In "Buyerco confirmed 2 containers", the consignee is Buyerco, not whoever sent the mail and not Hynos. Return the buying company as written. If the email genuinely doesn't name one, return null — do NOT fall back to the sender, and do not treat a person's first name as a company unless the email plainly uses it that way.
currency: "USD", "EUR" etc, only if stated. null otherwise.
trade_terms: e.g. "CIF Busan", "FOB Los Angeles", only if stated.
port_discharge: destination port/country, only if stated.
payment_term: e.g. "T/T 100% against shipping documents", only if stated.
container_count: number of containers, only if stated as a number. "5c", "2c", "10c" and "5 cntrs" MEAN FIVE/TWO/TEN CONTAINERS -- that is how this customer writes it, and the number belongs HERE, never in an item's qty. A REAL AND DANGEROUS MISREAD: "Buyerco confirmed 5c of Auto casting tense at $2,520 CIF Busan" was extracted as qty 5 METRIC TONNES with container_count null, which prices five containers of material at $12,600 instead of about $276,000. If a count like that appears, container_count is the count and qty stays null unless a tonnage is separately stated. BEWARE the other "c": in "(10c for Mr. Kim and 10c for Hynos included)" the 10c is a COMMISSION of $10 per tonne included in the price, not ten containers -- a number followed by "for <a person or company>" is a commission, not a count.

items: one entry per distinct material.
  desc: the material as the sender wrote it ("auto cast", "aluminium combo").
  qty: metric tonnes for that material if stated, else null. Only a figure actually given in TONNES (or lbs/kg you can convert). A container count is NOT a quantity -- see container_count above.
  rate: the price figure as written, whatever basis it is on. null if none.
  rate_basis: "per_mt" if that figure is plainly a price PER METRIC TONNE. A TRADE TERM IS NOT A BASIS: "$3,200 CIF Incheon", "2,520 CIF Busan", "$995 FOB" are all PER METRIC TONNE prices in this business, and CIF/CFR/FOB/DDP tells you who pays the freight, nothing whatever about per-tonne versus per-lot. All 759 rows of this company's invoice history are priced per metric tonne on CIF terms. Reading "CIF" as evidence of a lot price is a real error that has happened: it blocked a confirmed container of chrome wheels at $3,200 CIF Incheon. "per_lb" if it is a price PER POUND ($/lb, "per pound", "cents a pound", "/#") — this is common on domestic scrap and you must say so rather than converting it yourself. "per_lot" if it is a total for the shipment, the container, or the whole order. "unknown" if the email does not make the basis clear. Be honest here rather than helpful — "unknown" is a perfectly good answer and is much safer than a wrong guess, because a per-lot figure used as a per-tonne rate multiplies the invoice by the tonnage.
  rate_confidence: 0.0-1.0, how sure you are of the FIGURE itself (not its basis). Use 0.9+ only when the email plainly ties that number to that material.

A COMMISSION STATED AS *INCLUDED* DOES NOT CHANGE THE RATE. the owner, 2026-10-03: "Do not include commission." Her mail from Joey reads "$2,520 CIF Busan (10c for Mr.Kim and 10c for Hynos included)" and "$3,200 CIF incheon (10c for Mr. Kim and 10c for Hynos included)" -- a $10/MT commission to each agent, already inside the figure. VERIFIED AGAINST HER OWN INVOICES: she bills Joey/Buyerco Autocasting Tense at $2,520.00, five rows of it, the confirmed figure exactly. The commission is settled separately and never appears on, and is never deducted from, the proforma. So: put the STATED price in rate, unchanged. Do NOT net it down to $2,500. Do NOT add a commission line item. Do NOT mention the commission in note -- it is normal, it needs no checking, and this document goes to the buyer.

WHEN AN EMAIL CONTAINS SEVERAL PRICES: a message may quote a price to the end buyer, subtract agent commissions, and then state what WE receive ("your price is X"). The figure that belongs on our proforma is the one presented as ours. Put that in rate, and say in note what the other figures were and why you chose this one, so a human can check the choice.

missing: field names a proforma needs that this email does not give, from: consignee, material, quantity, rate, trade_terms, port_discharge, container_count.
note: one short sentence on anything a human should check — an ambiguous number, a total-vs-unit price, two materials sharing one price. null if nothing.
confidence: 0.0-1.0 overall, how sure you are this is an order and you read it correctly.

{ "is_order": false, "confidence": 0.0, "consignee": null, "currency": null, "trade_terms": null, "port_discharge": null, "payment_term": null, "container_count": null, "items": [], "missing": [], "note": null }`;
}

const num = (v) => {
    const n = typeof v === 'number' ? v : parseFloat(String(v ?? '').replace(/[^0-9.\-]/g, ''));
    return Number.isFinite(n) ? n : null;
};

// Normalises by hand for the same reason assess() does: the shape must not
// depend on whether zod loaded.
// ── "5c" MEANS FIVE CONTAINERS (2026-10-03) ────────────────────────────────
// From her real mail: "Buyerco confirmed 5c of Auto casting tense at $2,520
// CIF Busan (10c for Mr.Kim and 10c for Hynos included)". The first 5c is a
// CONTAINER COUNT; both 10c are a $10/MT COMMISSION included in the price.
//
// The model first read the count as a quantity of 5 TONNES -- five containers
// of material priced at $12,600 instead of about $276,000, and the draft came
// back with needs: [] and nothing assumed, i.e. CLEAN. That is the worst shape
// a bug can have here. Prompting fixed the qty misread but the model then
// abstained on the count rather than risk the commission reading, which is the
// right instinct and still leaves containerCount defaulting silently to 1.
//
// So the idiom is recovered in CODE, where it is a fixed pattern and not a
// judgement: a small number followed by "c", NOT followed by "for <someone>".
const CONTAINER_IDIOM = /\b(\d{1,2})\s*c(?:ntrs?|ontainers?)?\b(?!\s*(?:for|to)\b)/gi;
function containerCountFromText(text) {
    const t = String(text || '');
    const hits = [];
    for (const m of t.matchAll(CONTAINER_IDIOM)) {
        const n = Number(m[1]);
        // A container count on one order; 30 containers of anything is not
        // this idiom, and 0 is not a count.
        if (n >= 1 && n <= 30) hits.push(n);
    }
    // Only when the text is unambiguous about it. Two different counts means
    // this needs a human, not a guess.
    const uniq = [...new Set(hits)];
    return uniq.length === 1 ? uniq[0] : null;
}

// Words that mean the note is raising something OTHER than commission.
const NOTE_SUBSTANCE = /\b(per[- ]?lot|per[- ]?tonne|per[- ]?mt|per[- ]?lb|total|lot price|two materials|both materials|ambiguous|unclear|quantity|tonnage|container count|which figure|conflict|discrepan)/i;
function scrubCommissionNote(note) {
    const t = note ? String(note).trim() : null;
    if (!t) return null;
    if (!/commission/i.test(t)) return t;
    if (NOTE_SUBSTANCE.test(t)) return t;
    return null;
}

// ── READING THE ORDER OFF ITS ATTACHMENT (2026-10-03) ──────────────────────
//
// The last unread input. helpers/gemini.js extractOrderPdfFields does the
// reading; this does the MERGING, and it is kept pure so it can be tested
// without a model, a mailbox or a network.
//
// MEASURED ON FIVE REAL ORDER PDFs before any of this was written, and every
// rule below comes from one of them:
//
//   EMI-01 (Metalworks)      po MTC-100126-EMI-01, 2 containers, Steel Scrap HMS,
//                         40 MT at $330/MT, FAS. The EMAIL BODY said none of
//                         this -- it said "please see the attached file".
//   PO 4302994 (Eccomelt) 40,000 LB of 356 wheels at $1.65/LB, and then three
//                         lines of "1 LB" at $1.61/$1.15/$1.05. Those are
//                         PRICE TIERS for downgrades, not things being bought.
//   PO/EM03/26 (Tiyansh)  three materials at 2850/2250/1700 with qty null and
//                         "Total combo load quantity is 20 MT across the
//                         three materials" in prose.
//
// THREE RULES, in order of how much damage they prevent:
//
//  1. FILL BLANKS ONLY. What the email said always wins. The attachment is
//     evidence about what the email left out, never a correction of what it
//     stated -- a buyer who writes a revised price in the covering mail means
//     it, and the PDF may be the superseded version.
//  2. NOTHING IS CONVERTED BY THE MODEL. It returns the page's own number and
//     the page's own unit; the arithmetic happens here. Today's per_lb bug was
//     worth 2204.62x, and a model that converts is a model that can be wrong
//     by that much silently.
//  3. A PLACEHOLDER LINE IS NOT AN ORDER LINE. "1 LB" at a tier price would
//     otherwise become a priced row on a document.
const LB_PER_MT = 2204.62;
// Under this many pounds is not a shipment. Eccomelt's tier rows are exactly
// 1 LB; 50 is wide enough to catch any similar convention and far below the
// ~40,000 lb a real container line carries.
const PLACEHOLDER_LB = 50;
function qtyToMt(qty, unit) {
    const n = Number(qty);
    if (!Number.isFinite(n) || n <= 0) return { mt: null, why: null };
    const u = String(unit || '').trim().toLowerCase();
    if (/^(mt|m\/?t|metric\s*ton(ne)?s?|tonnes?)$/.test(u)) return { mt: n, why: null };
    if (/^(lbs?|pounds?|#)$/.test(u)) {
        if (n < PLACEHOLDER_LB) return { mt: null, why: 'placeholder' };
        return { mt: Math.round((n / LB_PER_MT) * 1000) / 1000, why: `${n} lb from the attached order = ${Math.round((n / LB_PER_MT) * 1000) / 1000} MT` };
    }
    if (/^(kgs?|kilos?|kilograms?)$/.test(u)) return { mt: Math.round((n / 1000) * 1000) / 1000, why: `${n} kg from the attached order = ${n / 1000} MT` };
    // "tons" ALONE IS AMBIGUOUS -- a short ton is 0.907 MT and a long ton is
    // 1.016, a 12% spread on every line. Refuse it rather than pick one.
    if (/ton/.test(u)) return { mt: null, why: 'ambiguous-ton' };
    // "containers" is a count, not a weight (the model is told to say so).
    return { mt: null, why: null };
}

// Returns a NEW order object. `pdf` is extractOrderPdfFields' output, or null.
function mergePdfOrder(order, pdf, { filename = null } = {}) {
    const base = { ...(order || {}) };
    if (!pdf || pdf.is_order_document !== true) return base;
    const from = filename ? `the attached ${filename}` : 'the attached order';
    const notes = [];
    const take = (key, val) => {
        if (base[key] == null || base[key] === '' ) {
            if (val != null && val !== '') { base[key] = val; notes.push(key); }
        }
    };
    take('consignee', pdf.buyer);
    take('currency', pdf.currency);
    take('trade_terms', pdf.trade_terms);
    take('port_discharge', pdf.port_discharge);
    take('payment_term', pdf.payment_term);
    take('container_count', Number(pdf.container_count) > 0 ? Number(pdf.container_count) : null);

    // ── ITEMS ─────────────────────────────────────────────────────────────
    // Only when the email gave none, or gave them with no figures. Matching a
    // PDF's line list against the email's by description is a guessing game
    // this does not play: either the body described the order or it did not.
    const emailItems = Array.isArray(base.items) ? base.items : [];
    const emailHasFigures = emailItems.some((i) => i && (i.qty != null || i.rate != null));
    if (!emailHasFigures) {
        const containers = Number(base.container_count) > 0 ? Number(base.container_count) : 1;
        const kept = [];
        let dropped = 0, ambiguous = 0;
        for (const it of (Array.isArray(pdf.items) ? pdf.items : [])) {
            if (!it || !String(it.desc || '').trim()) continue;
            const { mt, why } = qtyToMt(it.qty, it.qty_unit);
            if (why === 'placeholder') { dropped++; continue; }
            if (why === 'ambiguous-ton') ambiguous++;
            let qty = mt;
            let perContainer = null;
            // A TONNAGE ON A MULTI-CONTAINER ORDER IS THE TOTAL. EMI-01 reads
            // "40 MT" across 2 containers, and the proforma prices PER
            // container. Flagged rather than done quietly: if the document
            // meant 40 per box this halves her invoice, and that is exactly
            // the kind of thing a human must see.
            if (qty != null && containers > 1) {
                perContainer = Math.round((qty / containers) * 1000) / 1000;
                qty = perContainer;
            }
            kept.push({
                desc: String(it.desc).trim(),
                qty,
                rate: Number.isFinite(Number(it.rate)) && Number(it.rate) > 0 ? Number(it.rate) : null,
                rate_confidence: Number.isFinite(Number(it.rate_confidence)) ? Number(it.rate_confidence) : 0.9,
                rate_basis: ['per_mt', 'per_lb', 'per_lot', 'unknown'].includes(it.rate_basis) ? it.rate_basis : 'unknown',
                from_attachment: true,
                qty_note: why && why !== 'placeholder' && why !== 'ambiguous-ton' ? why : null,
                qty_per_container_of: perContainer != null ? containers : null,
            });
        }
        if (kept.length) {
            base.items = kept;
            base.is_order = true;
            notes.push(`${kept.length} item(s)`);
            if (dropped) notes.push(`${dropped} placeholder line(s) ignored`);
            if (ambiguous) notes.push(`${ambiguous} line(s) priced in "tons", which is ambiguous — left without a quantity`);
        }
    }
    if (pdf.po_number && !base.po_number) base.po_number = String(pdf.po_number).trim();
    if (notes.length) {
        const added = `Read from ${from}: ${notes.join(', ')}.`;
        base.note = base.note ? `${base.note} ${added}` : added;
        base.from_attachment = true;
    }
    // The document's own note is worth carrying -- on Eccomelt's PO it is what
    // explains the 1 LB rows, and on Tiyansh's it carries the combo total that
    // is nowhere in the line items.
    if (pdf.note) base.attachment_note = String(pdf.note).trim();
    return base;
}

async function extractOrderFromEmail(email) {
    const res = await callGeminiJSON(buildOrderPrompt(email), 2, OrderSchema, null, { model: require('../config').GEMINI_MODEL_SMART });
    if (!res || typeof res.is_order === 'undefined') return null;
    const items = (Array.isArray(res.items) ? res.items : [])
        .map((it) => ({
            desc: String(it && it.desc || '').trim(),
            qty: num(it && it.qty),
            rate: num(it && it.rate),
            rate_confidence: typeof (it && it.rate_confidence) === 'number' ? it.rate_confidence : 0,
            rate_basis: ['per_mt', 'per_lb', 'per_lot', 'unknown'].includes(it && it.rate_basis) ? it.rate_basis : 'unknown',
        }))
        .filter((it) => it.desc);
    const out = {
        is_order: res.is_order === true || res.is_order === 'true',
        confidence: typeof res.confidence === 'number' ? res.confidence : 0,
        consignee: res.consignee ? String(res.consignee).trim() : null,
        currency: res.currency ? String(res.currency).trim() : null,
        trade_terms: res.trade_terms ? String(res.trade_terms).trim() : null,
        port_discharge: res.port_discharge ? String(res.port_discharge).trim() : null,
        payment_term: res.payment_term ? String(res.payment_term).trim() : null,
        // The model abstains on this more often than it is wrong, so the
        // idiom is recovered here rather than left to default to 1 in silence.
        container_count: num(res.container_count) || containerCountFromText(email && email.body),
        items,
        missing: Array.isArray(res.missing) ? res.missing.map(String) : [],
        // A NOTE THAT IS ONLY ABOUT COMMISSION IS NOISE. the owner: "Do not
        // include commission." The prompt says not to mention it and the model
        // still does, in two of her three real confirmations -- it is the most
        // salient odd-looking thing in the email, so it keeps getting raised.
        // It reaches her read-back, not the PDF, so this is noise rather than
        // a leak; but a read-back that flags the normal case trains her to
        // skim the one place she is meant to read carefully.
        //
        // Dropped only when commission is ALL the note says. A note that also
        // raises a second price, a unit ambiguity or a shared price still has
        // something worth checking and survives intact.
        note: scrubCommissionNote(res.note),
    };

    // ── THEN THE ATTACHMENT, IF THE BODY LEFT A HOLE ───────────────────────
    // Only when it would change the answer. "Please see the attached file for
    // the additional P.O." leaves no material, no tonnage and no price, and
    // that is the case worth a smart-model call on a 200KB PDF; an email that
    // states its own figures is not.
    //
    // Caller-supplied bytes (email.pdfs = [{ filename, base64 }]) so this
    // function stays free of Gmail: replyWatch and actions each already have a
    // client and the message id, and the eval harness and the tests can hand
    // in a fixture.
    const pdfs = Array.isArray(email && email.pdfs) ? email.pdfs.filter((p) => p && p.base64) : [];
    if (pdfs.length) {
        const noFigures = !out.items.some((i) => i.qty != null || i.rate != null);
        // ── AND ONLY ON MAIL THAT LOOKS LIKE AN ORDER ──────────────────────
        // The first version of this guard was `noFigures || !out.consignee`,
        // which is true of almost every email, so the audit immediately showed
        // SIX smart-tier PDF reads on booking confirmations and statements --
        // a cost I had added to every attachment in the scan loop. (To its
        // credit the reader returned items=0 on all six and invented nothing;
        // the problem was the spend and the latency, not the answers.)
        //
        // Narrowed to the measured case: the model already called it an order,
        // or the body POINTS AT the attachment -- which is literally how hers
        // read: "Please see the attached file for the additional P.O."
        const points = /\b(see|find|attach(?:ed|ing)?|enclosed|per)\b[^.]{0,40}\b(attach(?:ed|ment)?|file|pdf|p\.?\s?o\.?|order|contract)\b/i
            .test(String(email.body || ''));
        if ((out.is_order || points) && (noFigures || !out.consignee)) {
            const { extractOrderPdfFields } = require('./gemini');
            // FIRST ATTACHMENT ONLY. An order mail carries one order document;
            // the rest are weight tickets, photos and specs, and reading five
            // PDFs per email at the smart tier is a cost with no measured
            // return. If this proves wrong it will show up as an order whose
            // figures are in the second file, and that is a measurement, not
            // a guess.
            const fields = await extractOrderPdfFields(pdfs[0].base64).catch(() => null);
            if (fields) return mergePdfOrder(out, fields, { filename: pdfs[0].filename });
        }
    }
    return out;
}

// Anything at or below this is treated as "I think I read this, but check it"
// rather than a usable figure. Deliberately generous — a rate is the one field
// where being wrong is expensive, and the cost of asking is one message.
const RATE_TRUST = 0.75;

// ── Standard container loading ────────────────────────────────────────────
// the owner, 2026-08-24: "by default only 21 MT for auto cast, if both Al combo
// and Regular combo/steel combo — then it should be 13 followed by 9 MT
// respectively."
//
// These are how a container is actually loaded, not guesses: a container takes
// 21 MT of auto cast on its own, or 13 MT of aluminium combo alongside 9 MT of
// regular/steel combo when the two ship together.
//
// This is the ONLY place a quantity may be supplied that the email did not
// state, and it exists because she gave the rule explicitly. It is still
// marked as assumed and called out in the read-back — the distinction between
// "the customer said 21" and "we always load 21" matters when someone is
// checking a document before it goes out, and one of those is worth querying.
//
// Anything outside these patterns still comes back with no quantity and stops,
// rather than being rounded to whatever looks close.
const norm = (d) => String(d || '').toUpperCase().replace(/[^A-Z]/g, '');
const isAutoCast = (d) => norm(d).includes('AUTOCAST');
const isAlCombo = (d) => /^(?=.*(?:ALUMINIUM|ALUMINUM|\bAL\b|^AL))(?=.*COMBO)/.test(norm(d)) || /ALCOMBO|ALUMINIUMCOMBO|ALUMINUMCOMBO/.test(norm(d));
const isSteelCombo = (d) => /REGULARCOMBO|STEELCOMBO/.test(norm(d));

// Fills quantities from the loading convention where it applies. Returns the
// items with { qty, qty_assumed } set; never overwrites a quantity the email
// actually gave.
function applyStandardQuantities(items) {
    const hasAl = items.some((i) => isAlCombo(i.desc));
    const hasSteel = items.some((i) => isSteelCombo(i.desc));
    const pairLoad = hasAl && hasSteel;
    return items.map((it) => {
        if (it.qty != null) return { ...it, qty_assumed: false };
        let qty = null;
        let why = null;
        let warn = null;
        // ORDER MATTERS. The PAIR rule wins over history, because history is
        // measured from SINGLE-material containers: "Al Combo loads 22.65 MT"
        // is true on its own and wrong for a box sharing with steel combo.
        if (pairLoad && isAlCombo(it.desc)) qty = 13;
        else if (pairLoad && isSteelCombo(it.desc)) qty = 9;
        // HER OWN INVOICES, next. Attached by groundRates (see
        // helpers/loadingHistory.js). This is the answer to "All these would
        // be saved in jarvis memory" -- it IS remembered, from 759 invoice
        // rows, per material, rather than from one number generalised to all.
        else if (it.standard_qty != null && items.length === 1) {
            qty = it.standard_qty;
            why = it.standard_qty_reason || null;
            warn = it.standard_qty_warning || null;
        }
        // 21 only when auto cast is the whole load — an auto-cast line sharing
        // a container with something else is not the 21 MT pattern. Kept as
        // the fallback for when the sheet cannot be read at all; history
        // independently measures this material at 21.9-22.1 MT.
        // 21, or 22 under an L/C -- the two figures she gave, and the same
        // direction the history-derived default takes. This branch only runs
        // when the sheet cannot be read at all; `lc_order` is stamped on the
        // item by groundRates so this stays a pure function of its input.
        else if (isAutoCast(it.desc) && items.length === 1) qty = it.lc_order ? 22 : 21;
        return { ...it, qty, qty_assumed: qty != null, qty_reason: why, qty_warning: warn };
    });
}

// Turns an extraction into the payload helpers/proformaPdf.js already accepts,
// filling only what the email actually said and reporting what it did not.
// Rates below RATE_TRUST are stripped out and listed as unconfirmed, so a
// half-read number can never quietly become a price on the document.
// Re-judges every rate against real price history BEFORE the draft is built,
// so a model guess about per-MT vs per-lot never decides anything on its own.
// See helpers/ratePlausibility.js for why: the model called $2,420/MT for auto
// casting tense a lot total, and 202 rows of her own invoices say it is an
// ordinary rate.
// A LETTER OF CREDIT CHANGES THE NOMINAL QUANTITY. Her sheet carries 68 L/C
// rows against 612 TT ones, so this is a real second case and not an edge.
// Matched on the terms as they are actually written there and in her mail:
// "L/C", "LC", "letter of credit".
// HER DECLARED STANDARD, in her own words: "by default if its a single
// thing,its quantity is 21 MT", "Unless it is an LC where we need to put
// 22 MT". One place, so a change is one line.
const STANDARD_LOAD_MT = 21;
const STANDARD_LOAD_LC = 22;
// How far her invoice history may sit from the declared standard before the
// read-back says so. 25% is deliberately well outside the "+/- 10% on
// weights" the proforma prints: this is meant to catch a material that loads
// nothing like 21 MT (wheels, at 14), not ordinary container-to-container
// variation (auto cast runs 18.5-25.6 and must not warn).
const LOADING_DISAGREEMENT = 0.25;
const LC_TERMS = /\b(?:l\s*\/?\s*c|letter\s+of\s+credit)\b/i;
function isLcOrder(order) {
    return LC_TERMS.test(String((order && (order.payment_term || order.terms)) || ''));
}

async function groundRates(order) {
    const { judgeRate } = require('./ratePlausibility');
    const { standardLoadFor } = require('./loadingHistory');
    const lc = isLcOrder(order);
    const items = [];
    for (const it of (order.items || [])) {
        // CONVERT BEFORE JUDGING, and this ordering was a bug the first time.
        // judgeRate OVERWRITES rate_basis with its own verdict, so a per_lb
        // figure arrived at toProformaDraft already relabelled 'unknown' and
        // the conversion never fired -- meaning the per-lb fix worked only for
        // materials with NO price history, the exact opposite of what is
        // wanted. Converting here also means history grounding compares a
        // per-MT figure against per-MT invoices, which is the only comparison
        // that means anything.
        let pre = { ...it };
        if (pre.rate_basis === 'per_lb' && pre.rate != null) {
            pre.rate_converted_from_lb = Number(pre.rate);
            pre.rate = Math.round(Number(pre.rate) * 2204.62 * 100) / 100;
            pre.rate_basis = 'per_mt';
        }
        const j = await judgeRate(pre.desc, pre.rate, pre.rate_basis).catch(() => null);
        let next = j ? { ...pre, rate_basis: j.basis, rate_reason: j.reason, rate_confirmed: !!j.confirmed } : { ...pre };
        next.lc_order = lc;
        // THE QUANTITY IS GROUNDED THE SAME WAY THE RATE IS. Done here, in the
        // async grounding step that both callers already run, so
        // toProformaDraft stays synchronous -- changing its signature would
        // have reached workflow/actions.js:8025 and replyWatch.js:3247 and
        // every test that builds a draft directly.
        if (next.qty == null) {
            // ── SHE DECLARES THE STANDARD; HISTORY ARGUES WITH IT ──────────
            // the owner, 2026-10-03: "chrome wheels - it should also be 21mt",
            // after being shown that her invoices put a chrome-wheels
            // container at 14.01 MT.
            //
            // I checked the measurement again before changing anything, and it
            // holds: a wheels container is ONE invoice line, and every one of
            // them weighs 13.9-15.8 MT -- MRKU6215437 at 14.007, HMMU6815119
            // at 13.989, KOCU4183842 at 14.288, three of those Joey's own
            // boxes. So 21 contradicts nine of her own shipped containers by
            // about 50%, far outside the "+/- 10% on weights" the proforma
            // itself prints.
            //
            // SHE STILL GETS 21, because the proforma is her document and a
            // nominal pre-shipment quantity is a commercial convention, not a
            // measurement. What changes is that the measurement is not thrown
            // away -- it becomes a WARNING on the read-back instead of the
            // number. Policy from her, challenge from the data: that is the
            // right split, and it is the one shape that gives her the figure
            // she asked for without losing the fact that could stop a 7 MT
            // overstatement on a letter of credit.
            next.standard_qty = lc ? STANDARD_LOAD_LC : STANDARD_LOAD_MT;
            next.standard_qty_reason = `${next.standard_qty} MT is the standard ${lc ? 'L/C ' : ''}quantity for one container`;
            const load = await standardLoadFor(next.desc).catch(() => null);
            if (load) {
                const off = Math.abs(next.standard_qty - load.measured) / load.measured;
                if (off > LOADING_DISAGREEMENT) {
                    next.standard_qty_warning = `${next.standard_qty} MT is the standard, but ${load.label} has only ever loaded to a median ${load.measured} MT across ${load.n} container(s) (${load.min}-${load.max} MT) — ${Math.round(off * 100)}% out, and the document prints +/- 10%`;
                } else {
                    next.standard_qty_reason += ` — ${load.label} has loaded to a median ${load.measured} MT across ${load.n} past container(s), which agrees`;
                }
            }
        }
        items.push(next);
    }
    return { ...order, items };
}

function toProformaDraft(order, { fallbackConsignee } = {}) {
    const unconfirmed = [];
    const grounded = [];
    const assumed = [];
    const needs = [];
    const items = applyStandardQuantities(order.items || []).map((it) => {
        // A rate is usable ONLY if we're confident of the figure AND it is
        // plainly per metric tonne. rate_basis was added 2026-08-24 after a
        // real email — "2 containers of auto casting tense at 2,450 ... Your
        // price is $2,420 CIF Busan" — where the model correctly picked 2,420,
        // scored it 0.9 confident, and said in its own note that it looked
        // like a LOT TOTAL rather than a per-tonne rate. Confidence alone
        // therefore passed it straight through. A per-lot figure used as a
        // per-tonne rate multiplies the invoice by the tonnage: 2,420 becomes
        // 2,420 x 21 x 2 containers = $101,640 for a $2,420 order.
        let basis = it.rate_basis || 'unknown';
        let rate = it.rate;
        // A PER-POUND PRICE IS REAL MONEY AND MUST BE CONVERTED, NOT GUESSED.
        // The conversion is exact arithmetic (1 MT = 2204.62 lb), so it is
        // done in code -- but the result is listed as an ASSUMPTION, never
        // silently trusted, because the thing being assumed is that "$0.42"
        // meant per pound. She sees the working and can correct it.
        //
        // WHY THIS HOLE EXISTED EVEN WITH judgeRate: history grounding does
        // catch a stray $0.42 when there ARE past invoices for that material
        // (0.42 falls far outside 0.3x-3x of any per-MT median, so basis comes
        // back 'unknown' and the figure is blocked). With NO history for the
        // material, judgeRate returns the model's own basis unchanged -- and
        // the coerced 'per_mt' was then trusted. New material + per-lb quote
        // was the live path to a 2,204x underpriced proforma.
        let converted = null;
        // Already converted upstream by groundRates (the normal production
        // path). Surface it so it can never be sent without her seeing the
        // working, but let the grounded figure price the line: the arithmetic
        // is exact and judgeRate has checked it against her own invoices.
        if (it.rate_converted_from_lb != null) {
            assumed.push(`${it.desc}: the email quoted $${it.rate_converted_from_lb}/lb, which is $${it.rate}/MT (x2204.62) — confirm that reading before this goes out`);
        }
        if (basis === 'per_lb' && it.rate != null) {
            converted = Math.round(Number(it.rate) * 2204.62 * 100) / 100;
            rate = converted;
            basis = 'per_mt_converted';
        }
        const figureOk = rate != null && it.rate_confidence >= RATE_TRUST;
        const trusted = figureOk && basis === 'per_mt';
        // When history CONFIRMED the rate, say so — a figure checked against 42
        // past invoices is a different thing from one nobody questioned, and
        // she should be able to see which she's looking at.
        // Only a reason that CONFIRMS belongs in grounded. "No past per-MT
        // invoice to check this against" is the opposite of grounding, and
        // printing it there would show her an absence of evidence as evidence.
        if (trusted && it.rate_reason && it.rate_confirmed) grounded.push(it.rate_reason);
        else if (trusted && it.rate_reason) unconfirmed.push(it.rate_reason);
        if (converted != null) {
            assumed.push(`${it.desc}: the email quoted $${it.rate}/lb, which is $${converted}/MT (x2204.62) — confirm that reading before this goes out`);
        }
        if (rate != null && !trusted) {
            if (it.rate_reason) { unconfirmed.push(it.rate_reason); }
            else unconfirmed.push(basis === 'per_mt_converted'
                ? `${it.desc}: "$${it.rate}/lb" converted to $${converted}/MT — a converted price is never sent unchecked`
                : basis === 'per_lot'
                ? `${it.desc}: "${it.rate}" reads as a total for the lot, not a per-MT rate`
                : basis === 'unknown'
                    ? `${it.desc}: "${it.rate}" — the email doesn't make clear whether that's per MT or a total`
                    : `${it.desc}: read "${it.rate}" but not confidently`);
        }
        // NEVER invent a quantity. The first version defaulted a missing qty
        // to 21 MT, which silently turned "the email doesn't say how much"
        // into a priced line on a document going to a customer.
        if (it.qty == null) needs.push('quantity');
        // A standard that disagrees with her own shipments is NOT an
        // assumption, it is a doubt -- so it goes to unconfirmed, which is
        // what blocks an auto-send gate and prints with a warning mark.
        // ── PROVENANCE, BECAUSE A FIGURE OFF A PDF IS NOT A FIGURE SHE SAW
        // SOMEONE TYPE. The body said "please see the attached file"; every
        // number here was read off that file by a model, so it is shown as
        // read-from-attachment and never as grounded.
        if (it.from_attachment) {
            if (it.qty_per_container_of) {
                // The one that can halve or double an invoice.
                unconfirmed.push(`${it.desc}: the attached order states ${Math.round(it.qty * it.qty_per_container_of * 1000) / 1000} MT across ${it.qty_per_container_of} containers, so ${it.qty} MT per container — confirm that is how it was meant`);
            }
            if (it.qty_note) assumed.push(`${it.desc}: ${it.qty_note}`);
            if (it.rate != null) assumed.push(`${it.desc}: $${it.rate} read off the attached order, not stated in the email`);
        }
        if (it.qty_assumed && it.qty_warning) unconfirmed.push(it.qty_warning);
        if (it.qty_assumed) assumed.push(it.qty_reason
            ? `${it.desc}: ${it.qty} MT assumed — the email didn't say, and ${it.qty_reason}`
            : `${it.desc}: ${it.qty} MT assumed from standard container loading — the email didn't say`);
        return { desc: it.desc, qty: it.qty, rate: trusted ? rate : 0, qty_assumed: !!it.qty_assumed };
    });
    // The document's own caveat. On Eccomelt's PO it is what explains the 1 LB
    // rows; on Tiyansh's it carries the 20 MT combo total that appears nowhere
    // in the line items.
    if (order.attachment_note) unconfirmed.push(`the attached order says: ${order.attachment_note}`);
    if (!items.length) needs.push('material');
    if (items.some((i) => !i.rate)) needs.push('rate');
    // The SENDER IS NOT THE BUYER, and must never quietly become one. On a
    // real run the model returned no consignee for an email that plainly said
    // "Buyerco confirmed 2 containers", and the fallback put the agent's
    // name — Joey — on the document instead. Orders here routinely arrive
    // from an agent writing on a buyer's behalf, so this is the normal shape
    // of the data, not an edge case. If no buying company was read, ask.
    // A SILENT DEFAULT OF 1 CONTAINER IS A PRICE ERROR OF (n-1) CONTAINERS.
    // containerCount multiplies the whole total below, so defaulting it
    // without saying so understated a five-container order by 80% while the
    // draft reported nothing missing and nothing assumed.
    if (!(order.container_count && order.container_count > 0)) {
        assumed.push('1 container assumed — the email did not say how many');
    }
    if (!order.consignee) needs.push('consignee');
    // The model's own "missing" list is authoritative too — it said qty was
    // missing on that same real email while the code cleared needs to empty
    // and offered to send. Trusting only our own derived checks threw away a
    // signal the model had already given us.
    // ...but never let it contradict direct evidence. On the real Buyerco
    // email the model listed "material" as missing while the email plainly
    // said "auto casting tense" and we had it in items — it seems to have
    // meant the GRADE was underspecified. Reporting "missing: material" to
    // someone looking at an email that names the material reads as a bug and
    // teaches her to distrust the whole list. So a model claim is only
    // accepted where our own check hasn't already settled the question.
    const MAP = { qty: 'quantity', quantity: 'quantity', rate: 'rate', price: 'rate', material: 'material', consignee: 'consignee' };
    const haveMaterial = items.length > 0;
    const haveAllQty = items.length > 0 && items.every((i) => i.qty != null);
    const haveAllRates = items.length > 0 && items.every((i) => i.rate);
    // Consignee needed its own guard too — missed in the first pass, and it
    // showed up immediately: an email that named no buying company made the
    // model list "consignee" as missing, which blocked a draft that had a
    // perfectly good consignee from the sender fallback. Same rule as the
    // rest: a model claim never overrides something we can see for ourselves.
    const haveConsignee = !!order.consignee;
    for (const m of (order.missing || [])) {
        const k = MAP[String(m).toLowerCase()];
        if (!k) continue;
        if (k === 'material' && haveMaterial) continue;
        if (k === 'quantity' && haveAllQty) continue;
        if (k === 'rate' && haveAllRates) continue;
        if (k === 'consignee' && haveConsignee) continue;
        needs.push(k);
    }
    return {
        consignee: order.consignee || '',
        // Kept only so the question can be helpful ("is it for Joey?"), never
        // used as the answer.
        sender_hint: fallbackConsignee || null,
        containerCount: order.container_count && order.container_count > 0 ? Math.round(order.container_count) : 1,
        items,
        trade_terms: order.trade_terms || '',
        port_discharge: order.port_discharge || '',
        payment_term: order.payment_term || '',
        needs: [...new Set(needs)],
        unconfirmed,
        grounded,
        assumed,
        note: order.note || null,
        confidence: order.confidence,
    };
}

module.exports = { extractOrderFromEmail, toProformaDraft, groundRates, buildOrderPrompt, applyStandardQuantities, containerCountFromText, scrubCommissionNote, isLcOrder, mergePdfOrder, qtyToMt, RATE_TRUST, 
    // Exported for tests ONLY. The enum inside it is what silently lost Joey's
    // order: a rate_basis the schema does not allow fails validation three
    // times and the whole extraction returns nothing. A unit test against
    // toProformaDraft cannot see that, because it never goes through here.
    OrderSchema: () => OrderSchema };
