// ── helpers/bills.js — what a container of metal cost ────────────────────
// the owner, 2026-09-09: "i want to build a bill tab which contains
// Source/Destination, Carrier, TRUCKING, Date, SUPPLIER, Invoice no, Booking
// no, Container no, Seal no, item Description, GROSS, Truck, container,
// Chassis, Boxes, Total, Net weight(lbs), Net weight(MT), supplier price,
// Supplier invoice amount, Trucking, Advance, Balance in one tab"
//
// SAMPLE YARD CO METALS, NOT SAMPLE YARD CO YARD — her first sentence. This is the freight side:
// a purchase bill per container, against a booking that already exists. The
// yard's own loads/inventory/petty-cash ledgers are a different business and
// share nothing with this file.
//
// ── EVERY NUMBER THAT CAN BE DERIVED, IS ─────────────────────────────────
// Her answer when asked: net comes from the tares, not from typing. So six of
// the twenty-three columns are computed here and nowhere else:
//
//   Total            = truck + container + chassis + boxes   (the tares)
//   Net weight (lbs) = gross − Total
//   Net weight (MT)  = lbs ÷ 2204.62
//   Supplier amount  = net × supplier price   (unit inferred — see below)
//   Balance          = amount − trucking − advance
//
// SERVER-SIDE, so the website, the app and anything printed agree. The same
// reasoning as helpers/payments.js's PAYMENT_MODES: three implementations of
// one sum is two chances to disagree about money.
//
// ── THE PRICE UNIT IS INFERRED, AND THAT NEEDS SAYING OUT LOUD ───────────
// Her rule, verbatim: "if price is in cents or less than 10 dollars, go with
// net lbs*price else net mt*price". Scrap is quoted either way — $0.32/lb or
// $700/MT — and the magnitude tells you which she meant.
//
// It is a good heuristic and it is still a GUESS ABOUT MONEY. Getting it
// wrong does not shade a total by a few percent; lbs and MT differ by 2204,
// so a mis-keyed price produces a figure wrong by three orders of magnitude,
// in a column she pays from.
//
// So the unit that was used is RETURNED WITH THE AMOUNT and shown on the row
// — her choice when asked, and the only thing that makes a bad inference
// visible at a glance rather than buried in a total. And `price_unit` can be
// set explicitly on the record, which overrides the inference entirely: the
// day she buys something at $8/MT, she can say so.

const cfg = require('../config');
const { loadJson, mutateJson } = require('./json');

// One short ton is 2000 lb; a METRIC ton is 2204.62262 lb. Scrap contracts in
// the US quote both, and using the wrong one is a 10% error in her favour or
// against it. Spelled out rather than left as a magic number.
const LB_PER_MT = 2204.62262;

// Below this, a price is read as dollars per POUND. Her rule.
const PER_LB_CEILING = 10;

const round2 = (n) => (typeof n === 'number' && isFinite(n) ? Math.round(n * 100) / 100 : null);
// Weights keep three decimals: an MT figure rounded to two loses about a
// kilogram, and she reconciles these against a weighbridge ticket.
const round3 = (n) => (typeof n === 'number' && isFinite(n) ? Math.round(n * 1000) / 1000 : null);

// Null, not zero. A missing tare is NOT a zero tare — a container with no
// chassis weight recorded is a bill somebody has not finished, and treating
// the gap as 0 silently inflates the net weight and therefore the amount.
// Every caller below is written to notice the null.
function num(v) {
    if (v === null || v === undefined || v === '') return null;
    const n = typeof v === 'number' ? v : parseFloat(String(v).replace(/[$,\s]/g, ''));
    return isFinite(n) ? n : null;
}

// ── THE ARITHMETIC ───────────────────────────────────────────────────────
// Pure, exported, and tested on its own. Takes the raw fields she typed and
// returns everything derived from them, plus what is missing — because a bill
// that cannot be computed has to say why rather than show a confident zero.
// ── SEVERAL GRADES IN ONE CONTAINER ──────────────────────────────────────
// the owner, 2026-09-10: "Also in bill what if i have multiple items in same
// container." Asked how the weights work, she chose: "Each item has its own
// weight and price."
//
// So a bill can carry a list. Al combo 12,000 lb at $0.32 and Auto cast
// 17,000 lb at $0.28 are two lines, two prices, and the bill amount is their
// sum — not one blended price, which is the shortcut that makes a container
// look profitable while one grade inside it loses money.
//
// The item weights SHOULD add up to the container net (gross − tares). When
// they do not it is REPORTED, never refused: the packing list and the
// weighbridge disagree by a few pounds as a matter of course, and a form that
// refuses a real bill is a form she works around. `weight_gap` is that
// difference, and the table shows it.
//
// The single-item shape still works untouched: `description` + `supplier_price`
// with no items is one grade, which is most bills, and nothing about them
// changes.
// ── AND EACH GRADE HAS ITS OWN WEIGHBRIDGE TICKET ────────────────────────
// the owner, 2026-09-10: "What if i have different weights like gross ,tare etc..
// for diff item in same container", and, asked how they are weighed: "Each
// grade is its own weighbridge ticket."
//
// So the weighing moves DOWN to the line. Each item may carry its own gross
// and its own tares, and its net is that ticket's arithmetic — gross minus
// what was under it. The container's gross, tares and net then become the SUM
// of its tickets rather than something typed, because a total that is both
// typed and derived is a total that will disagree with itself.
//
// THE TRAP THIS AVOIDS, stated because it is invisible once it happens: truck,
// container and chassis tares belong to a WEIGHING, not to a grade. Recording
// one gross for the container and then a chassis tare against each of three
// grades subtracts that chassis three times, and the net comes out hundreds of
// pounds light with every individual figure looking reasonable. Keying the
// tares to the ticket is what makes that impossible rather than merely
// unlikely.
//
// A line may still carry a plain `weight` and no ticket — that is this
// morning's shape, one weighing for the container split on paper, and it
// still works. A line that has BOTH is using the ticket: the arithmetic wins
// over the assertion.
const ITEM_TARES = ['truck', 'container', 'chassis', 'boxes'];

function cleanItems(input) {
    const out = [];
    for (const it of (Array.isArray(input) ? input : [])) {
        if (!it) continue;
        const description = String(it.description || '').trim();
        const price = num(it.price);
        const gross = num(it.gross);
        const tare = {};
        for (const k of ITEM_TARES) tare[k] = num(it[k]);
        const hasTicket = gross !== null || ITEM_TARES.some((k) => tare[k] !== null);
        const tareTotal = ITEM_TARES.reduce((sum, k) => sum + (tare[k] || 0), 0);
        // Its own net when it has its own ticket; otherwise the figure she
        // typed against the line.
        const weight = hasTicket
            ? (gross === null ? null : round3(gross - tareTotal))
            : num(it.weight);
        if (!description && weight === null && price === null && !hasTicket) continue;   // a blank row
        if (!description) throw new Error('an item needs a description — what grade is it?');
        const id = String(it.id || '').trim()
            || `ITM_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
        // Same magnitude rule as the bill's own price, and overridable the
        // same way: under $10 is per lb, $10+ is per MT.
        const unit = it.price_unit === 'lb' || it.price_unit === 'mt'
            ? it.price_unit
            : (price === null ? null : (price < PER_LB_CEILING ? 'lb' : 'mt'));
        const mt = weight === null ? null : round3(weight / LB_PER_MT);
        let amount = null;
        if (price !== null && unit) {
            amount = unit === 'lb'
                ? (weight === null ? null : round2(weight * price))
                : (mt === null ? null : round2(mt * price));
        }
        // ── A LINE MAY STATE ITS OWN AMOUNT ──────────────────────────────
        // Added 2026-09-24. A line's amount is normally weight x price, but a
        // supplier who deals in whole loads gives neither: Hugo's tab says
        // "53 trailer loaded — $19,750.60" and nothing else. Same principle
        // as supplier_invoice_amount on the bill: a figure she states wins
        // over arithmetic this file cannot do. Only consulted when the
        // arithmetic came out empty, so nothing that already works changes.
        if (amount === null) { const stated = num(it.amount); if (stated !== null) amount = round2(stated); }
        out.push({
            id, description, weight, price, price_unit: unit, weight_mt: mt, amount,
            // The ticket, kept on the line so the container's totals can be
            // rebuilt from the lines and never stored twice.
            gross: hasTicket ? gross : null,
            truck: tare.truck, container: tare.container,
            chassis: tare.chassis, boxes: tare.boxes,
            tare_total: hasTicket ? round3(tareTotal) : null,
            weighed: hasTicket,
            // Which of ITS tares are blank. Same rule as the container's:
            // reported, never treated as zero.
            missing_tares: hasTicket ? ITEM_TARES.filter((k) => tare[k] === null) : [],
        });
    }
    return out;
}

// ── WHAT THE HAULAGE IS ACTUALLY MADE OF ─────────────────────────────────
// the owner, 2026-09-10: "There should be a provision to view the detailed split
// on amount on clicking that row..Rate Line Haul Others Dry Run Extra Scale
// ..Here there should be note on others so that we can expand and view it
// more detail".
//
// One number for haulage answers "how much" and never "why", and "why" is the
// question when a trucker's invoice arrives $340 above the quote.
//
// ── THE PARTS ARE HER SPREADSHEET'S, NOT MY GUESS ───────────────────────
// She first listed "Rate Line Haul Others Dry Run Extra Scale" and I took
// Rate for a dollar line. Then she sent the sheet she actually keeps, whose
// columns are Line Haul, Port Fees, Chassis Rent, Others, Net Amount — with
// Line Haul at 650 on every row. So Rate IS Line Haul: the agreed price of
// the move. Port Fees and Chassis Rent are what a drayage invoice really
// carries and I had invented neither.
//
// Dry Run and Extra Scale are kept because she named them and they are real
// events — a truck sent and turned away, a second weighing — even though her
// sheet folds them into Others today.
//
// OTHERS stays a list, because the next thing is different every time and a
// column named Others with no detail behind it is a number nobody can
// defend. Each one carries a NOTE, required for the same reason the sales
// charge note is: the line that cannot be explained is the one that gets
// written off.
const TRUCKING_PARTS = ['line_haul', 'port_fees', 'chassis_rent', 'dry_run', 'extra_scale'];

// Labels, so the form and the expanded row read the way her sheet does
// rather than the way the keys are spelled.
const TRUCKING_PART_LABELS = {
    line_haul: 'Line Haul', port_fees: 'Port Fees', chassis_rent: 'Chassis Rent',
    dry_run: 'Dry Run', extra_scale: 'Extra Scale',
};

function cleanTruckingOthers(input) {
    const out = [];
    for (const o of (Array.isArray(input) ? input : [])) {
        if (!o) continue;
        const what = String(o.what || '').trim();
        const amount = round2(num(o.amount));
        const note = String(o.note || o.why || '').trim();
        if (!what && amount === null && !note) continue;         // a blank row
        if (!what) throw new Error('an other charge needs a name — what is it for?');
        if (amount === null) throw new Error(`"${what}" needs an amount`);
        if (!note) throw new Error(`"${what}" needs a note saying what it was — that is the whole point of it being an Other`);
        const id = String(o.id || '').trim()
            || `TRK_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
        out.push({ id, what, amount, note });
    }
    return out;
}

function cleanTruckingSplit(input) {
    const t = input || {};
    const out = {};
    let any = false;
    for (const k of TRUCKING_PARTS) {
        const v = num(t[k]);
        out[k] = v;
        if (v !== null) any = true;
    }
    // The trucker's OWN invoice number — her sheet's "Invoice No." column, and
    // not the supplier's invoice_no already on the bill. Two documents, two
    // numbers, and one field for both would make the pair unreconcilable.
    out.invoice_no = String(t.invoice_no || '').trim() || null;
    // Her "Last Verified": who checked this against the trucker's invoice and
    // when. Recorded rather than computed — it is a statement about a human
    // having looked, which nothing here can infer.
    //
    // ── AND IT STAYS HAND-TYPED. DO NOT WIRE VERIFICATION TO IT. ─────────
    // the owner, 2026-09-20, asked whether running the AJ Transport verification
    // would land in Metals trucking; told it does not and that this date is
    // typed by hand, she answered "verified on is good". So the gap is the
    // feature.
    //
    // The AJ Transport / carrier / Sher / Jio runs compare a hauler's PDFs
    // against the Sample Yard Co Metals Invoice SHEET and log the passing rows to a tab
    // on that workbook — see helpers/invoiceVerify.js, which requires nothing
    // but ./invoiceSheet and so cannot write here even by accident. Making a
    // passing cross-check stamp this field would replace "a person checked
    // this" with "a machine matched two numbers", which is a different claim
    // wearing the same word.
    out.verified_on = String(t.verified_on || '').trim() || null;
    if (out.invoice_no || out.verified_on) any = true;

    out.others = cleanTruckingOthers(t.others);
    if (out.others.length) any = true;
    out.present = any;
    out.others_total = round2(out.others.reduce((s, o) => s + (o.amount || 0), 0)) || 0;
    // Present-but-unpriced is possible: an invoice number logged before the
    // figures are known. That is a total of null, not zero — the same
    // distinction the haulage list draws between "priced at nothing" and
    // "nobody has filled this in".
    const anyMoney = TRUCKING_PARTS.some((k) => out[k] !== null) || out.others.length > 0;
    out.total = !anyMoney ? null
        : round2(TRUCKING_PARTS.reduce((s, k) => s + (out[k] || 0), 0) + out.others_total);
    out.parts = TRUCKING_PARTS
        .filter((k) => out[k] !== null)
        .map((k) => ({ key: k, label: TRUCKING_PART_LABELS[k], amount: out[k] }));
    return out;
}

function compute(input) {
    const b = input || {};
    const gross = num(b.gross);
    const tare = {
        truck: num(b.truck),
        container: num(b.container),
        chassis: num(b.chassis),
        boxes: num(b.boxes),
    };

    // Present tares only. A bill with three of the four filled in is still
    // worth totalling — she enters them as the weighbridge gives them — but
    // the row must say which are missing rather than quietly treat them as 0.
    const missing = Object.keys(tare).filter((k) => tare[k] === null);
    const total = Object.keys(tare).reduce((s, k) => s + (tare[k] || 0), 0);

    let netLb = gross === null ? null : round3(gross - total);
    let netMt = netLb === null ? null : round3(netLb / LB_PER_MT);

    const price = num(b.supplier_price);
    // Explicit beats inferred, always. `price_unit` is how she overrides the
    // magnitude rule for the case it gets wrong.
    const unit = b.price_unit === 'lb' || b.price_unit === 'mt'
        ? b.price_unit
        : (price === null ? null : (price < PER_LB_CEILING ? 'lb' : 'mt'));

    let amount = null;
    if (price !== null && unit) {
        if (unit === 'lb') amount = netLb === null ? null : round2(netLb * price);
        else amount = netMt === null ? null : round2(netMt * price);
    }

    // ── ITEMS WIN OVER THE SINGLE PRICE ──────────────────────────────────
    // If she has broken the container into grades, the sum of the lines IS
    // the amount. Falling back to net x one price when items exist would
    // quietly ignore everything she typed into them.
    let items = [];
    try { items = cleanItems(b.items); } catch (e) { items = []; }
    const itemsWeight = items.length
        ? round3(items.reduce((s, i) => s + (i.weight || 0), 0)) : null;

    // ── WHEN THE LINES CARRY THE TICKETS, THE CONTAINER IS THEIR SUM ─────
    // Her answer, 2026-09-10: "Each grade is its own weighbridge ticket." So
    // the container's gross, tares and net stop being typed and start being
    // added up. Both would otherwise be editable and the pair would drift —
    // and the one she reads is the container total, which is the one that
    // would be wrong.
    //
    // Anything she typed at container level is KEPT and reported as a
    // conflict rather than overwritten. The same rule as the supplier invoice
    // amount: a figure she entered herself is a statement, and a disagreement
    // with it is a conversation, not something to silently correct.
    const weighed = items.filter((i) => i.weighed);
    const fromTickets = weighed.length > 0;
    const sumOf = (k) => round3(weighed.reduce((s, i) => s + (i[k] || 0), 0));
    const itemsAmount = items.length && items.every((i) => i.amount !== null)
        ? round2(items.reduce((s, i) => s + i.amount, 0)) : null;
    if (itemsAmount !== null) amount = itemsAmount;
    // The ticket totals take over here, AFTER the single-weighing figures
    // above have been worked out, so the typed ones survive for the conflict
    // report below.
    const typedGross = gross;
    const typedNet = netLb;
    let grossUsed = gross;
    let tareUsed = total;
    if (fromTickets) {
        grossUsed = sumOf('gross');
        tareUsed = round3(weighed.reduce((s, i) => s + (i.tare_total || 0), 0));
        netLb = round3(weighed.reduce((s, i) => s + (i.weight || 0), 0));
        netMt = round3(netLb / LB_PER_MT);
    }

    // Reported, not refused — see cleanItems. Meaningless once the lines ARE
    // the weighing, because the container is their sum by construction: null
    // rather than a permanent 0, so a zero in this field always means she
    // split a weighing and it balanced.
    const weightGap = (!fromTickets && items.length && netLb !== null && itemsWeight !== null)
        ? round3(netLb - itemsWeight) : null;
    // She typed a container gross AND the lines carry tickets. One of the two
    // is wrong and this file is not in a position to say which.
    const weightConflict = (fromTickets && typedGross !== null && typedNet !== null
        && Math.abs(typedNet - netLb) >= 0.001) ? round3(typedNet - netLb) : null;
    // A supplier invoice amount she typed herself WINS over the computed one.
    // The supplier's invoice is the document of record; if it disagrees with
    // our arithmetic that is a conversation to have, not a number to overwrite.
    const stated = num(b.supplier_invoice_amount);
    const amountUsed = stated !== null ? stated : amount;

    // ── THE SPLIT DECIDES THE TOTAL ──────────────────────────────────────
    // Once there is a split, the haulage figure is its sum and stops being
    // typed. Anything she typed is KEPT and reported, never overwritten —
    // same rule as the container weight and the supplier invoice amount.
    let split = { present: false, others: [], others_total: 0, total: null };
    try { split = cleanTruckingSplit(b.trucking_split); } catch (e) { /* reported on save */ }
    const typedTrucking = num(b.trucking_amount);
    const trucking = (split.present && split.total !== null) ? split.total : typedTrucking;
    const truckingConflict = (split.present && typedTrucking !== null && split.total !== null
        && Math.abs(typedTrucking - split.total) >= 0.005)
        ? round2(typedTrucking - split.total) : null;

    // ── BALANCE IS WHAT IS STILL OWED ────────────────────────────────────
    // Her formula on 2026-09-09 was "Amount − Trucking − Advance". She then
    // removed Advance as a column, and on 2026-09-10, asked what Balance
    // should mean once payments exist, chose "Amount − Trucking − Paid".
    //
    // So the column changed question: it used to answer "what did this
    // container come to", it now answers "what do I still owe on it". Worth
    // being explicit about, because a column that quietly changes meaning is
    // one she reads the old way for a month.
    //
    // `paid` is passed IN rather than looked up here — helpers/billPayments.js
    // requires helpers/bills.js to validate allocations, so reaching back the
    // other way would be a require cycle. listWithTotals resolves it once for
    // the whole table instead of once per row.
    const paid = num(b.paid) || 0;

    // ── WHAT THE SUPPLIER IS ACTUALLY OWED ───────────────────────────────
    // the owner, 2026-09-10: "So bill amount shoud be one thing after deducting
    // trucking,it should get auto adjusted na".
    //
    // It already was — Balance has been amount − trucking − paid since this
    // morning. What was missing is the STEP IN BETWEEN. Reading "Bill amount
    // 8,388" beside "Balance 7,188" with no third figure, the only way to see
    // where the 1,200 went is to do the subtraction yourself, and a number you
    // have to reconstruct is one you eventually stop checking.
    //
    // So the chain is named at every link:
    //   amount        what the metal came to
    //   − trucking    haulage she pays on the supplier's behalf
    //   = net_payable what the supplier is owed
    //   − paid
    //   = balance     what is still outstanding
    //
    // amount deliberately stays the SUPPLIER'S INVOICE FIGURE and is not
    // reduced in place. It is the number on their document; netting trucking
    // into it would mean her Bills tab and their invoice never agree again,
    // and reconciling that later is impossible rather than merely tedious.
    const netPayable = amountUsed === null ? null
        : round2(amountUsed - (trucking || 0));
    // The third term, restored 2026-09-19. Null-safe: a bill with no advance
    // must read exactly as it did before the column existed.
    const advance = num(b.advance) || 0;
    const balance = netPayable === null ? null : round2(netPayable - paid - advance);

    return {
        items,
        items_weight: itemsWeight,
        items_amount: itemsAmount,
        // True when the lines carry their own weighbridge tickets, so the
        // container figures below are sums and the form shows them read-only.
        weights_from_items: fromTickets,
        weight_conflict: weightConflict,
        // Non-zero means the grades do not add up to the container. A few
        // pounds is ordinary; a few hundred is a typo.
        weight_gap: weightGap,
        // The container's own figures: typed when there is one weighing,
        // summed from the lines when each grade has its own ticket.
        gross_used: grossUsed,
        total: fromTickets ? tareUsed
            : (gross === null && !Object.keys(tare).some((k) => tare[k] !== null) ? null : round3(total)),
        net_lb: netLb,
        net_mt: netMt,
        price_unit: unit,
        // What the arithmetic says, kept even when she typed her own amount —
        // so a disagreement between our sum and the supplier's invoice is
        // visible instead of lost.
        computed_amount: amount,
        amount: amountUsed,
        net_payable: netPayable,
        trucking_split: split,
        trucking_amount_used: trucking,
        trucking_conflict: truckingConflict,
        amount_is_stated: stated !== null,
        amount_differs: (stated !== null && amount !== null && Math.abs(stated - amount) >= 0.01)
            ? round2(stated - amount) : null,
        balance,
        paid: round2(paid),
        missing_tares: missing,
        // ── INCOMPLETE IS A STATE, NOT AN ERROR ──────────────────────────
        // the owner, 2026-09-10: "if i start adding atleast one value in bill,it
        // should get autosaved."
        //
        // That settles a question I had answered wrongly. addBill used to
        // THROW without a date and a supplier — my rule, never hers — and an
        // hour earlier I extended it so an edit could not blank either. Both
        // are incompatible with how she actually works: a bill is filled in as
        // the information arrives, and the weighbridge ticket, the supplier
        // invoice and the trucker's number turn up on different days.
        //
        // So the store stopped refusing and started REPORTING, which is the
        // rule this file already followed for tares: a bill that cannot be
        // computed says why rather than showing a confident zero, and a bill
        // that is not finished says so rather than being impossible to keep.
        incomplete: ['date', 'supplier'].filter((k) => !String(b[k] || '').trim()),
    };
}

const list = () => {
    const raw = loadJson(cfg.BILLS_FILE, []);
    return Array.isArray(raw) ? raw : [];
};

// ── NEWEST BILL AT THE TOP OF THE TABLE ─────────────────────────────────────
//
// the owner, 2026-09-25: "Also latest bill should come at the top".
//
// ── WHY THIS IS NOT IN list() OR listWithTotals() ───────────────────────────
// It would have been one line in either, and it would have been wrong. Those
// two are reached by THIRTY-THREE callers, and at least one of them decides
// money by position: helpers/saleInvoiceFlow.js's billByContainer() does
//
//     bills.listWithTotals().find((b) => cont(b.container_no) === c)
//
// — the FIRST match wins. Reverse the order underneath it and a container
// with two bills starts building its invoice from the other one: a different
// supplier, a different price, on a document that goes to a customer. Nobody
// asked for that and nobody would have seen it until the invoice was wrong.
// helpers/ledgerExport.js and helpers/data/dataMirror.js read the same list
// too, so a sort there also silently reorders her exports and the tables
// Jarvis answers questions from.
//
// So the ORDER IS THE TABLE'S, and only the table's: api.js's GET /api/bills
// calls this after filterRows, and nothing else does. Every other caller sees
// exactly the list it has always seen.
//
// ── UNDATED ROWS GO LAST, NOT FIRST ─────────────────────────────────────────
// A bill with no date yet is `incomplete` (see compute()) — it is not the
// newest one, it is the one still being filled in. Sorting it to the top
// because an empty string compares low would put her least-finished rows
// where she expects her most recent, which is the opposite of the ask.
//
// Stable within a date: bills sharing a day keep the order they were entered,
// because there is nothing better to sort them by and a table that reshuffles
// rows it has no reason to reshuffle is one she cannot keep her place in.
function newestFirst(rows) {
    return (Array.isArray(rows) ? rows : [])
        .map((r, i) => ({ r, i }))
        .sort((a, b2) => {
            const da = String((a.r && a.r.date) || '').trim();
            const db = String((b2.r && b2.r.date) || '').trim();
            if (!da && !db) return a.i - b2.i;
            if (!da) return 1;          // undated sinks
            if (!db) return -1;
            if (da === db) return a.i - b2.i;   // stable within a day
            return da < db ? 1 : -1;            // ISO dates sort as strings
        })
        .map((x) => x.r);
}

function newId() {
    return `BILL_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

// The columns she named, in her order, so the table and the store cannot
// disagree about what a bill is. `key` is the stored field; `label` is what
// she called it; `derived` marks the six this file computes.
// ── AND WHAT THE FORM NEEDS, WHICH IS NOT THE SAME THING ─────────────────
// the owner, 2026-09-10, on the first version of the add form: "This is ugly and
// not user friendly." She was right, and one line of the screenshot was worse
// than cosmetic: TRUCKING appeared TWICE, on two identical empty boxes.
//
// That is not a mistake in her list — she has two of them, and in the TABLE
// their position tells you which is which (one sits beside Carrier, the other
// beside Advance). Stacked in a form grid, position says nothing.
//
// So a column carries three extra things, and the table keeps using `label`:
//   formLabel — what the field is called when it stands alone, out of order
//   unit      — lbs, $ — the thing that makes a number checkable
//   group     — so 23 fields arrive as four short sections instead of a wall
//
// Kept HERE rather than in the client for the same reason COLUMNS is here at
// all: the store defines what a bill is, and a second list in the dashboard
// is a copy that drifts.
const COLUMNS = [
    { key: 'supplier',         label: 'Supplier',           group: 'purchase', suggest: true },
    { key: 'carrier',          label: 'Carrier',            group: 'shipment', placeholder: 'MSC, Maersk…' },
    { key: 'booking_no',       label: 'Booking no',         group: 'container' },
    { key: 'container_no',     label: 'Container no',       group: 'container', placeholder: 'MSKU1234567' },
    { key: 'seal_no',          label: 'Seal no',            group: 'container' },

    // the owner, 2026-09-10: "In bill,i want photos field where url can be
    // pasted." One per line — a container gets photographed several times and
    // one box for one link would have her keeping the rest somewhere else.


    { key: 'date',             label: 'Date',               group: 'shipment', date: true },
    // the owner, 2026-09-10: "Swap places of route and supplier". Route sits
    // where Supplier was and Supplier where Route was — her reading order,
    // not mine. The group each belongs to went with it.
    { key: 'route',            label: 'Source/Destination', group: 'shipment',
      formLabel: 'Route', placeholder: 'HOUSTON / BUSAN' },
    { key: 'invoice_no',       label: 'Invoice no',         group: 'shipment' },
    { key: 'description',      label: 'Item description',   group: 'items', suggest: true,
      placeholder: 'Auto cast, shredded…' },

    // ── THE CONTAINER WEIGHING COLUMNS ARE TABLE-ONLY NOW ────────────────
    // the owner, 2026-09-11: "CONTAINER WEIGHING · lbs REMOVE". The group that
    // held them on the FORM is gone — each grade carries its own weighbridge
    // ticket and the container's figures are the sum of those.
    //
    // They stay in COLUMNS and in TABLE_ORDER because bills already saved
    // carry them and she still reads them across the row. So they are marked
    // tableOnly and their `group` is dropped: a column claiming membership of
    // a group that does not exist is an orphan, and a bills-sales assertion
    // caught exactly that. This is the mirror of `carrier`, which is on the
    // form and NOT in the table (see the note above TABLE_ORDER).
    { key: 'gross',            label: 'Gross',              tableOnly: true, unit: 'lbs', num: true },
    // ── SHORT ENOUGH NOT TO WRAP ─────────────────────────────────────────
    // the owner, 2026-09-10: "alignmnet not proper". "Container tare" and
    // "Chassis tare" wrapped onto two lines while Gross, Truck and Boxes did
    // not, so those two inputs sat a line lower than the other three — five
    // boxes in a row, at two different heights.
    //
    // Fixed by naming, not by CSS: the section header already says "Weights ·
    // lbs" and Gross is listed separately, so "tare" was doing no work on
    // four of the five labels. A label that cannot wrap cannot misalign.
    { key: 'truck',            label: 'Truck',              tableOnly: true, unit: 'lbs', num: true },
    { key: 'container',        label: 'Container',          tableOnly: true, unit: 'lbs', num: true },
    { key: 'chassis',          label: 'Chassis',            tableOnly: true, unit: 'lbs', num: true },
    { key: 'boxes',            label: 'Boxes',              tableOnly: true, unit: 'lbs', num: true },
    { key: 'total',            label: 'Total',              tableOnly: true, unit: 'lbs', derived: true, formLabel: 'Total tare' },
    { key: 'net_lb',           label: 'Net weight (lbs)',   tableOnly: true, unit: 'lbs', derived: true },
    { key: 'net_mt',           label: 'Net weight (MT)',    tableOnly: true, unit: 'MT',  derived: true },

    { key: 'supplier_price',   label: 'Supplier price',     group: 'purchase', unit: '$', num: true,
      formLabel: 'Supplier price', hint: 'under $10 is read as per lb, $10+ as per MT' },
    // Stored under `amount`, but the field she TYPES is
    // supplier_invoice_amount — compute() prefers hers over the computed one.
    // `writeKey` is what the form must post; without it this column had no
    // input at all and the stated-amount branch was unreachable.
    { key: 'amount',           label: 'Supplier invoice amount', group: 'purchase', unit: '$', derived: true,
      writeKey: 'supplier_invoice_amount', num: true, formLabel: 'Invoice amount',
      hint: 'leave blank to use the computed figure' },
    // ── THE TRUCKER SITS WITH WHAT THE TRUCKING COST ─────────────────────
    // the owner, 2026-09-10: "Trucker needs to there next to Trucking Amount in
    // bill." It used to live up beside Carrier, which is where her original
    // column list put it — who hauled it and what the haul cost were at
    // opposite ends of a 22-column table.
    //
    // AND IT IS CALLED "Trucker" NOW. Her word, and it retires the workaround
    // underneath the original complaint: two different columns were both
    // headed "Trucking", so the form needed a separate formLabel to tell them
    // apart. One of them having its own name fixes that at the source instead.
    { key: 'trucking_company', label: 'Trucker',            group: 'trucking',
      placeholder: 'who hauled it' },
    { key: 'trucking_amount',  label: 'Trucking',           group: 'trucking', unit: '$', num: true,
      formLabel: 'Trucking cost' },
    // ── ADVANCE: REMOVED 2026-09-10, ASKED FOR AGAIN 2026-09-19 ──────────
    // Both decisions are hers and both are kept here, because a note saying
    // only "she asked for this removed" is a note that gets it removed again.
    //
    //   2026-09-10, "Remove advance on this". It was in her original 23 and
    //   came out, taking the third term of her balance formula with it:
    //   "Amount − Trucking − Advance" became "Amount − Trucking".
    //
    //   2026-09-19, after importing a year of real shipments and spotting
    //   $21,791.80 sitting in the Trucking column on BMOU5185697: "Advance
    //   someti,es while truclimg othr wwise.include a col cslled advance."
    //
    // What changed in between is the DATA. Her sheet has one column headed
    // "Advance /Trucking" holding both things — median $800, which is
    // haulage, and 79 rows over $10,000, several of them larger than the
    // supplier's whole invoice, which are money already paid. With no advance
    // column there was nowhere for the second kind to go, so the import put
    // all of it in Trucking and her ledger claimed $120,000 of haulage on a
    // single container.
    //
    // ── AND IT SITS WITH `paid`, NOT WITH `trucking` ─────────────────────
    // An advance is money that has LEFT — so it comes off the balance, not
    // off what the supplier is owed. net_payable stays "amount less
    // trucking", which is what their invoice minus the haulage says, and the
    // advance reduces what is still outstanding. Putting it in net_payable
    // would make her Payable column disagree with the supplier's own
    // document, which is the thing the note above amount is at pains to
    // prevent.
    { key: 'advance',          label: 'Advance',            group: 'money', unit: '$', num: true,
      formLabel: 'Advance paid', hint: 'money already sent to the supplier for this container' },
    // The middle link in the chain, so the trucking deduction is visible
    // rather than something she reconstructs between two other columns.
    { key: 'net_payable',      label: 'Payable',            group: 'money', unit: '$', derived: true,
      hint: 'bill amount less trucking — what the supplier is owed' },
    // ── WHAT HAS ACTUALLY GONE OUT ────────────────────────────────────────
    // the owner, 2026-09-29: "What if i want to see the paid amount for bills".
    //
    // `paid` has been computed on every row since bill payments existed —
    // withTotals() returns it and Balance already subtracts it — but it has
    // never been a COLUMN. So the screen showed the RESULT of paying a
    // supplier and never the payment itself: Payable, Advance, Balance, and
    // the amount that moved nowhere to be seen. Reading it off meant
    // subtracting Balance from Payable in her head, and getting that wrong is
    // how a supplier gets paid twice.
    //
    // tableOnly AND derived, deliberately, and this is the part that matters:
    // `paid` is the SUM OF THE PAYMENT RECORDS in bill_payments.json. If it
    // were an ordinary field in the 'money' group it would appear on the bill
    // form as a box, and a figure typed there would sit on the row overriding
    // the real total — withTotals reads `b.paid` first (line ~391). A bill
    // could then claim to be settled with no payment behind it, and the money
    // would balance nowhere. It is not in WRITABLE either; both together, so
    // neither one alone is load-bearing.
    { key: 'paid',             label: 'Paid',               tableOnly: true, derived: true,
      unit: '$', num: true,
      hint: 'total of the payments recorded against this bill — not typed' },
    { key: 'balance',          label: 'Balance',            group: 'money', unit: '$', derived: true },

    // Its own row at the end, full width. Sitting in the middle of the
    // Shipment column, a three-line textarea pushed everything below it out
    // of step with the column beside it.
    { key: 'photos',           label: 'Photos',             group: 'links',
      formLabel: 'Photo links', textarea: true,
      placeholder: 'paste one link per line', hint: 'http/https links only' },
];

// The order she READS them in, which is the order she gave and not the order
// the form groups them. The table walks this; the form walks GROUPS.
// ── CARRIER IS ON THE FORM BUT NOT IN THE TABLE ──────────────────────────
// the owner, 2026-09-10: "on bill after saving,i dont want carrier to be
// displayed.on edit it can be there."
//
// So it is absent from TABLE_ORDER and still present in COLUMNS — the form
// walks COLUMNS, the table walks this. It is still STORED and still comes off
// the booking on pre-fill; it just is not one of the columns she reads across.
// Nothing about the record changed, which is why it is still there to edit.
// ── PHOTOS LAST ──────────────────────────────────────────────────────────
// the owner, 2026-09-10: "in bills post saving,i want photo column to be there
// at the last". It sat fifth, between Invoice no and Booking no — a column of
// "#1 #2" links wedged among the paperwork numbers she reads across. At the
// end it is somewhere to go rather than something to scroll past.
const TABLE_ORDER = ['route', 'date', 'supplier', 'invoice_no',
    'booking_no', 'container_no', 'seal_no', 'description', 'gross', 'truck',
    'container', 'chassis', 'boxes', 'total', 'net_lb', 'net_mt',
    'supplier_price', 'amount', 'trucking_company', 'trucking_amount', 'advance',
    // Payable − Paid − Advance = Balance, and the columns now read in that
    // order, so the arithmetic on the screen is the arithmetic in withTotals.
    'net_payable', 'paid', 'balance',
    'photos'];

// ── FILTERS, AND SEVERAL AT ONCE ─────────────────────────────────────────
// the owner, 2026-09-10: "also i want filter.ultiple filters can also be
// applied."
//
// SERVER-SIDE, like everything else here, and for a reason beyond consistency:
// summary() has to agree with what she is looking at. Filtering in the browser
// would leave the totals row summing rows that are no longer on screen, which
// is a worse bug than having no filter at all — she would read a balance that
// belongs to a different set of bills.
//
// EVERY FILTER IS AN "AND". That is what "multiple filters can also be
// applied" means: supplier Eccomelt AND booking 272766480 AND this month
// narrows; it does not accumulate matches. Any field left blank is not a
// filter at all rather than a filter matching nothing.
//
// `q` is a free-text sweep across the text columns — the one box that finds a
// container number without her having to know which field it lives in.
const FILTERABLE = ['supplier', 'carrier', 'booking_no', 'container_no',
    'trucking_company', 'invoice_no', 'seal_no', 'route', 'description'];

// MM/DD/YYYY (how she types and how bookings.json stores) to a sortable
// YYYY-MM-DD, so a range comparison is a string comparison. Anything it
// cannot read returns null and is simply not range-filtered — a date it does
// not understand must not silently drop the row.
function sortableDate(v) {
    const s = String(v || '').trim();
    let m = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(s);
    if (m) return `${m[3]}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}`;
    m = /^(\d{4})-(\d{1,2})-(\d{1,2})$/.exec(s);
    if (m) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
    return null;
}

// ── WHAT IS STILL MISSING FROM A BILL ───────────────────────────────────────
// the owner, 2026-09-19: "if i say show me unfilled bills-it should show".
//
// `incomplete` in compute() is deliberately NOT reused and deliberately NOT
// widened. It drives the "◦ still needs" marker on the ledger row and means
// something narrow — a bill with no date or no supplier, the two things that
// stop it being identifiable at all. Widening it would change a marker on
// every row of a screen she reads daily, which is not what she asked for.
//
// This is the broader question, in its own function: what would stop me
// calling this bill finished? Four things, because they are the four an
// unfinished bill is actually waiting on — the weighbridge ticket, the
// supplier's invoice, the container number and the basic identity. Her own
// words for why they arrive separately are in compute(): "a bill is filled in
// as the information arrives, and the weighbridge ticket, the supplier invoice
// and the trucker's number turn up on different days."
function missingFor(row) {
    const b = row || {};
    const blank = (k) => !String(b[k] === null || b[k] === undefined ? '' : b[k]).trim();
    const out = [];
    if (blank('date')) out.push('date');
    if (blank('supplier')) out.push('supplier');
    if (blank('container_no')) out.push('container no');
    // The weighbridge half. A gross with no tare still computes a net, so the
    // gross is what is actually missing when nothing has been weighed.
    if (blank('gross')) out.push('weights');
    // The money half. EITHER a price or a typed amount is enough — she prices
    // most containers per pound and occasionally agrees a flat figure, and
    // demanding both would mark finished bills as unfinished.
    //
    // `supplier_invoice_amount`, NOT `amount`. `amount` is DERIVED (weight x
    // price, or her stated figure when she typed one) and does not exist on a
    // raw row at all, so checking it marked every flat-priced bill as waiting
    // on a price it already had. The stored field is the one she fills in, and
    // it is the one that is present whether or not withTotals has run.
    if (blank('supplier_price') && blank('supplier_invoice_amount')) out.push('price');
    return out;
}

// `fields` lets another store reuse this with its OWN columns. Sales has
// customer, HBL and reference where a bill has supplier and container — and
// passing bills' list would have made the Sales search box find nothing,
// silently. Defaults to a bill's fields so existing callers are unchanged.
function filterRows(rows, q = {}, fields = FILTERABLE) {
    const FILTERABLE = fields;
    const has = (v) => v !== undefined && v !== null && String(v).trim() !== '';
    const norm = (v) => String(v === null || v === undefined ? '' : v).toLowerCase();
    const text = has(q.q) ? norm(q.q).trim() : null;
    const from = has(q.from) ? sortableDate(q.from) : null;
    const to = has(q.to) ? sortableDate(q.to) : null;

    return (rows || []).filter((r) => {
        for (const f of FILTERABLE) {
            if (!has(q[f])) continue;
            if (!norm(r[f]).includes(norm(q[f]).trim())) return false;
        }
        if (text && !FILTERABLE.some((f) => norm(r[f]).includes(text))) return false;
        // ── TWO FILTERS THAT ARE NOT TEXT ────────────────────────────
        // Put here rather than in a Jarvis-only code path so ONE definition of
        // "unfilled" serves the ledger screen, the export and the assistant.
        // Three answers to "which bills are unfinished" would eventually
        // disagree, and she would be the one to find out.
        //
        // Absent means NOT A FILTER, like every other field above — a false or
        // an empty string must not silently become "only the finished ones".
        if (has(q.unfilled) && String(q.unfilled) !== 'false') {
            if (!missingFor(r).length) return false;
        }
        if (has(q.unpaid) && String(q.unpaid) !== 'false') {
            // `balance` is added by withTotals. On a raw row it is undefined,
            // and an undefined balance is not evidence of anything — the row
            // is kept rather than being claimed as paid.
            if (r.balance !== undefined && r.balance !== null && !(Number(r.balance) > 0.005)) return false;
        }
        if (from || to) {
            const d = sortableDate(r.date);
            // A row with an unreadable date is kept, not dropped. Dropping it
            // would hide a bill from a date range it might well belong to,
            // and a hidden bill is one she stops chasing.
            if (d) {
                if (from && d < from) return false;
                if (to && d > to) return false;
            }
        }
        return true;
    });
}

// The values actually present, so the dropdowns can only offer something that
// will match. A filter list built from a hardcoded set offers choices that
// return nothing, which reads as broken.
// ── THE LIST LEARNS ITSELF ───────────────────────────────────────────────
// the owner, 2026-09-10: "Supplier should be dynamically listed in text box.
// first time,when we type,it needs to added to the list,next time when i tye,
// it should start showing matching case." And then: "so as Item description".
//
// No new store, and nothing to maintain. The list of suppliers she uses IS
// the set of distinct suppliers on her bills — so typing one adds it the
// moment the bill saves, and it is offered from then on. A separate
// "supplier list" would be a second thing to keep in step, and the first time
// it disagreed with the bills nobody would know which was right.
//
// carrier and trucking_company get the same treatment for free; they were
// already faceted for the filter dropdowns.
function facets(rows) {
    const out = {};
    for (const f of ['supplier', 'carrier', 'trucking_company', 'description']) {
        out[f] = [...new Set((rows || []).map((r) => String(r[f] || '').trim()).filter(Boolean))].sort();
    }
    return out;
}

// ── HER GROUPING, 2026-09-10 ─────────────────────────────────────────────
// "I want Date,Route,Carrier,Invoice no in one group,next booking no,
// container no,seal no in another group,then supplier,supplier price,bill
// amount in one group.Trucker related thing as another,items and weights in
// another."
//
// Five groups, in that order. It reads as the questions actually get answered:
// what shipment is this, which box, who sold it and for how much, who hauled
// it, and what was in it.
// `keys` states the order INSIDE a group, so it is her order rather than an
// accident of where a line sits in the COLUMNS array — which is the kind of
// thing that silently reshuffles the day someone adds a column in the middle.
const GROUPS = [
    { id: 'shipment', label: 'Shipment',
      keys: ['date', 'route', 'carrier', 'invoice_no'] },
    { id: 'container', label: 'Container',
      keys: ['booking_no', 'container_no', 'seal_no'] },
    { id: 'purchase', label: 'Purchase',
      keys: ['supplier', 'supplier_price', 'amount'] },
    { id: 'trucking', label: 'Trucking',
      keys: ['trucking_company', 'trucking_amount'] },
    // ── NOTHING BUT THE LINE EDITOR ──────────────────────────────────────
    // the owner, 2026-09-11: "CONTAINER WEIGHING · lbs REMOVE, Item description
    // IN BILL" — take both off the bill form.
    //
    // `keys: []` IS LOAD-BEARING AND MUST NOT BE DELETED. groupColumns falls
    // back to `COLUMNS.filter(c => c.group === groupId)` when a group has no
    // keys, and `description` still carries `group: 'items'`, so dropping the
    // empty array would quietly put the field straight back on the form.
    // Empty list, not absent list.
    { id: 'items',    label: 'Items and weights', full: true, keys: [] },
    // ── THE CONTAINER WEIGHING GROUP IS GONE ─────────────────────────────
    // It asked for gross and four tares for the container as a whole. Every
    // grade now carries its own weighbridge ticket, and the container's
    // figures are the SUM of those (weights_from_items) — so the group was
    // asking for numbers it was about to overwrite.
    //
    // The COLUMNS and the arithmetic in compute() are deliberately UNTOUCHED:
    // bills already saved carry container-level weights, and the table still
    // shows them. What is removed is the way to type them, not the way to
    // read them. The form now guarantees at least one item line so there is
    // never a bill with no line to hold the weight — see paintItems.
    { id: 'money',    label: 'Money' },
    { id: 'links',    label: 'Photos', full: true },
];

// Her 23, in her order, for the table.
// ── WHICH COLUMNS THE TABLE SHOWS BEFORE YOU CLICK (2026-10-02) ───────────
// the owner, with a screenshot of the bills table: "It looks unprofessional and
// ugly.i want this to be neat.when i click the bill,if it has multiple
// rows,i want this to expand".
//
// TABLE_ORDER is 25 columns. Every cell is nowrap, so the table was always
// wider than the screen and scrolled sideways — and the actions cell is
// sticky to the right, so it floated OVER the scrolled content. That is the
// credit badge landing on top of the seal number in her screenshot.
//
// THE CHOICE LIVES HERE, NOT IN THE CLIENT. The first version kept this list
// in dashboard/index.html and tests/bills-sales.js went red: "the table is
// built from the SERVER columns, not a second list here — 23 hand-typed
// headings is 23 chances to put Chassis where Boxes goes." A key list is the
// same hazard one step removed: rename a column here and the client silently
// stops showing it, with nothing going red. So the columns mark themselves
// and the client just filters on the flag.
//
// The set is HERS. An earlier cut dropped route and net_lb and
// tests/ledger-render.js caught it on the guard that names the columns she
// asked for. Both are back.
const CORE_KEYS = ['route', 'date', 'supplier', 'container_no', 'invoice_no',
    'net_lb', 'amount', 'paid', 'balance'];

const tableColumns = () => TABLE_ORDER.map((k) => COLUMNS.find((c) => c.key === k))
    .filter(Boolean)
    // `core` is additive: every existing reader sees the same 25 columns in
    // the same order, and only a client that looks for the flag narrows.
    .map((c) => (CORE_KEYS.includes(c.key) ? { ...c, core: true } : c));

// The columns of one group, in the order the group states — falling back to
// COLUMNS order for the groups that never needed one.
// ── THE SAME CONTAINER TWICE UNDER ONE BOOKING ───────────────────────────
// helpers/sales.js has had this since the container-grain rebuild; bills did
// not, and the asymmetry is worse here than there. helpers/margin.js keys on
// booking + container, so two bills for one container do not double-count —
// the second OVERWRITES the first, and the container reads as cheaper than it
// was. Meanwhile helpers/metalsTrucking.js keys on the bill id and lists both
// hauls. One duplicate, two tabs disagreeing, no warning anywhere.
//
// Reported, never refused, for the same reason as on the sales side: it is
// usually a typo and occasionally real, and this file cannot tell which.
// ── THE SAME GRADE TWICE ON ONE CONTAINER ────────────────────────────────
// Keyed on booking|container until 2026-09-19, when the owner corrected the
// assumption the whole join was built on: "booking never makes it unique.
// sometimes diff container under same booking.sometimes diff items in same
// container."
//
// The grade is part of the key now, the same as helpers/sales.js — the two
// sides are joined for margin, so two answers to "is this a duplicate" would
// disagree about the same container. A blank grade is still a grade.
const gradeKey = (r) => String((r && (r.description || r.item)) || '').trim().toUpperCase();
function duplicates(rows) {
    const seen = new Map();
    for (const r of (rows || [])) {
        const bk = String(r.booking_no || '').trim().toUpperCase();
        const cn = String(r.container_no || '').trim().toUpperCase();
        if (!bk || !cn) continue;
        const k = `${bk}|${cn}|${gradeKey(r)}`;
        if (!seen.has(k)) seen.set(k, { booking_no: r.booking_no, container_no: r.container_no,
                                        item: (r.description || r.item) || null, ids: [] });
        seen.get(k).ids.push(r.id);
    }
    return [...seen.values()].filter((d) => d.ids.length > 1);
}

function groupColumns(groupId) {
    const g = GROUPS.find((x) => x.id === groupId);
    if (g && Array.isArray(g.keys)) {
        return g.keys.map((k) => COLUMNS.find((c) => c.key === k)).filter(Boolean);
    }
    return COLUMNS.filter((c) => c.group === groupId);
}

// Fields a client may write. Everything else on a stored bill is derived or
// housekeeping, and accepting it from a request would let a client post a
// balance that does not follow from its own weights.
// `supplier_invoice_amount` is listed EXPLICITLY, and it has to be. Her
// "Supplier invoice amount" column is stored under the key `amount`, which is
// marked derived — so the filter below excluded it and there was no way for
// her to type the figure off the supplier's invoice at all. compute()'s
// stated-amount-wins branch, and the amount_differs warning that goes with
// it, were both unreachable through the API: dead code guarding nothing.
//
// Found 2026-09-10 by the test that checks her 23 columns are all writable
// or computed. The arithmetic had been right the whole time and one of her
// columns simply could not be filled in.
const WRITABLE = COLUMNS.filter((c) => !c.derived).map((c) => c.key)
    .concat(['supplier_invoice_amount', 'price_unit', 'note', 'items', 'trucking_split']);

// ── A PASTED LINK IS RENDERED, SO IT IS CHECKED ──────────────────────────
// These come back out into the table as clickable links. A "javascript:..."
// URL pasted into that field would run when clicked, so ONLY http and https
// survive — anything else is dropped rather than stored and rendered.
//
// Split on newlines, commas and whitespace, because "paste one per line" is
// what the box says and not necessarily what a paste from Drive or WhatsApp
// produces. De-duplicated, order kept.
function cleanPhotos(v) {
    if (v === null || v === undefined || v === '') return [];
    const parts = Array.isArray(v) ? v : String(v).split(/[\s,]+/);
    const out = [];
    for (const raw of parts) {
        const u = String(raw || '').trim().replace(/[),.]+$/, '');
        if (!u) continue;
        let ok = false;
        try { ok = /^https?:$/.test(new URL(u).protocol); } catch (e) { ok = false; }
        if (ok && !out.includes(u)) out.push(u);
    }
    return out;
}

function clean(input) {
    const out = {};
    for (const k of WRITABLE) {
        if (!Object.prototype.hasOwnProperty.call(input || {}, k)) continue;
        const v = input[k];
        out[k] = typeof v === 'string' ? v.trim() : v;
    }
    // Typed as a number where it is one, so the arithmetic never depends on a
    // client having sent the right JSON type.
    for (const k of ['gross', 'truck', 'container', 'chassis', 'boxes',
                     'supplier_price', 'supplier_invoice_amount', 'trucking_amount']) {
        if (k in out) out[k] = num(out[k]);
    }
    if ('photos' in out) out.photos = cleanPhotos(out.photos);
    // Validated on the way IN, so an item with no description fails while she
    // still remembers what she meant to type — not silently dropped from a
    // total she reads a week later.
    if ('items' in out) out.items = cleanItems(out.items);
    // Validated on the way IN so an Other with no note fails while she still
    // remembers what it was, rather than becoming an unexplained line later.
    if ('trucking_split' in out) out.trucking_split = cleanTruckingSplit(out.trucking_split);
    return out;
}

// A stored row plus everything derived from it. One function, so no caller
// can render a bill without its arithmetic.
function withTotals(b) {
    return { ...b, ...compute(b) };
}

function listWithTotals() {
    // One pass over the payments for the whole table, not one per row.
    let paid = {};
    try { paid = require('./billPayments').paidByBill(); }
    catch (e) { console.warn('[BILLS] could not read payments:', e.message); }
    return list().map((b) => withTotals({ ...b, paid: paid[b.id] || 0 }));
}

// ── ONE IMPLEMENTATION OF "WHAT IS A VALID BILL" ────────────────────────────
// Extracted from addBill 2026-09-19 so the spreadsheet importer can check 568
// rows BEFORE writing any of them, without carrying a second copy of these
// rules that would drift the first time one changed. addBill calls it too, so
// there is exactly one answer to what a bill must have.
//
// Builds the row; does not write it.
function prepareBill(input = {}) {
    const rec = clean(input);
    // Deliberately NOT refused for a missing date or supplier — see the
    // `incomplete` note in compute(). What IS refused is a bill with nothing
    // in it at all.
    if (!Object.values(rec).some((v) => v !== null && v !== undefined && String(v).trim() !== ''
                                        && !(Array.isArray(v) && !v.length))) {
        throw new Error('a bill needs at least one value');
    }
    return {
        id: newId(),
        ...rec,
        created_at: new Date().toISOString(),
        created_by: input.created_by || null,
    };
}

async function addBill(input = {}) {
    const rec = clean(input);
    // Deliberately NOT refused for a missing date or supplier — see the
    // `incomplete` note in compute(). What IS refused is a bill with nothing
    // in it at all: "at least one value" is her own threshold, and a row
    // created by opening a form and closing it again is litter.
    if (!Object.values(rec).some((v) => v !== null && v !== undefined && String(v).trim() !== ''
                                        && !(Array.isArray(v) && !v.length))) {
        throw new Error('a bill needs at least one value');
    }
    const row = {
        id: newId(),
        ...rec,
        created_at: new Date().toISOString(),
        created_by: input.created_by || null,
    };
    // ── STRICT: THIS WRITE EITHER HAPPENS OR SAYS SO ─────────────────────
    // mutateJson is forgiving by default — on failure it logs, returns
    // loadJson() and NEVER RUNS THE MUTATOR, handing back plausible-looking
    // data with no way to tell the write never landed. Its own note says the
    // paths where a lost write means lost DATA should opt in; this is one of
    // them, and 131 of 146 writes in this codebase had not.
    //
    // The catch covers mutator errors too, not just lock contention, so the
    // forgiving path also swallows bugs in the function above.
    //
    // No retry loop on top: LOCK_OPTS already backs off eight times (40ms to
    // 400ms), so a failure here is genuinely exceptional and a second layer
    // would be defensive code with nothing to defend against.
    await mutateJson(cfg.BILLS_FILE, [], (all) => {
        const rows = Array.isArray(all) ? all : [];
        rows.push(row);
        return rows;
    }, { strict: true });
    return withTotals(row);
}

async function editBill(id, input = {}) {
    const patch = clean(input);
    let found = null;
    let problem = null;
    await mutateJson(cfg.BILLS_FILE, [], (all) => {
        const rows = Array.isArray(all) ? all : [];
        const i = rows.findIndex((r) => r.id === id);
        if (i === -1) return rows;
        // PATCH, not replace. helpers/loads.js carries a comment about
        // editLoad rebuilding a record wholesale and dropping pdf_link; a bill
        // has twenty-three columns and the same mistake here would silently
        // erase a seal number nobody was editing.
        const merged = { ...rows[i], ...patch, updated_at: new Date().toISOString() };
        // The date/supplier guard that used to live here is GONE, on
        // purpose — see compute()'s `incomplete` note. Autosave writes a bill
        // the moment she types one value, so a rule requiring two specific
        // fields would make her own workflow unsaveable. What is missing is
        // reported on the row instead.
        rows[i] = merged;
        found = rows[i];
        return rows;
    }, { strict: true });
    if (problem) throw new Error(problem);
    if (!found) throw new Error(`no bill ${id}`);
    return withTotals(found);
}

async function deleteBill(id) {
    let gone = false;
    await mutateJson(cfg.BILLS_FILE, [], (all) => {
        const rows = Array.isArray(all) ? all : [];
        const i = rows.findIndex((r) => r.id === id);
        if (i === -1) return rows;
        rows.splice(i, 1);
        gone = true;
        return rows;
    }, { strict: true });
    if (!gone) throw new Error(`no bill ${id}`);
    return true;
}

// Column totals for the foot of the table. Only the ones that mean anything
// added up — summing a price per pound across containers is a number with no
// meaning, and putting it under a column invites someone to read it.
function summary(rows) {
    const r = (rows || []).map(withTotals);
    const sum = (k) => round2(r.reduce((s, x) => s + (num(x[k]) || 0), 0));
    return {
        count: r.length,
        net_lb: round3(r.reduce((s, x) => s + (x.net_lb || 0), 0)),
        net_mt: round3(r.reduce((s, x) => s + (x.net_mt || 0), 0)),
        amount: sum('amount'),
        trucking_amount: sum('trucking_amount'),
        advance: sum('advance'),
        balance: sum('balance'),
    };
}

module.exports = {
    COLUMNS, GROUPS, TABLE_ORDER, tableColumns, CORE_KEYS, WRITABLE, LB_PER_MT, PER_LB_CEILING, prepareBill,
    FILTERABLE, filterRows, facets, sortableDate, cleanPhotos, missingFor,
    compute, withTotals, list, listWithTotals, newestFirst, addBill, editBill, deleteBill, summary,
    cleanItems,
    groupColumns,
    cleanTruckingSplit, cleanTruckingOthers, TRUCKING_PARTS, TRUCKING_PART_LABELS,
    duplicates,
};
