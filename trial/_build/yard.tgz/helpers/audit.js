// ── helpers/audit.js — what the top-level profile did ─────────────────────
//
// the owner, 2026-09-03, asked whether a profile that can erase a paid load
// should leave a record: "yes — log every privileged action."
//
// WHY THIS EXISTS AT ALL
// ----------------------
// Every other record in this system describes something that happened in the
// yard. This one describes something that happened to the RECORDS. A Jarvis
// session can delete a load that has money against it, and when it does, the
// load, its items, its payments and its Drive folder all go. Ask afterwards
// "was there ever a load SAMPLE_47, and did we pay Acme 12,000 for it" and
// without this file there is nothing left to ask.
//
// APPEND-ONLY, AND NOTHING HERE DELETES
// -------------------------------------
// There is no removeEntry, no trim, no retention window. That is not an
// oversight to be tidied up later: a log the privileged profile can prune is
// not evidence, it is a draft. The file grows by a handful of rows a year in
// normal use — the whole point is that walking past a lock should be rare.
//
// It also records ATTEMPTS THAT WERE REFUSED, not just successes. A run of
// refusals against the delete guard is the shape of someone probing, and it is
// exactly what a success-only log would throw away.
//
// WRITTEN BEFORE THE ACT, NOT AFTER
// ---------------------------------
// Callers log the intent, do the thing, then stamp the outcome. Logging after
// the fact means a crash mid-delete leaves the load half-gone and no trace of
// who asked for it — the one case where the log matters most is the one it
// would miss. An entry that says "started, never finished" is information; a
// missing entry is not.
//
// STRICT WRITES
// -------------
// mutateJson defaults to strict:false and SWALLOWS errors, returning the
// unmodified data, which from the outside is indistinguishable from success.
// For a file whose only job is to be there afterwards, a silent write failure
// is the worst possible bug, so every write here is strict and the caller is
// told when it fails.

const { loadJson, mutateJson: mutateJsonRaw } = require('./json');
const cfg = require('../config');

const mutateJson = (file, dflt, fn) => mutateJsonRaw(file, dflt, fn, { strict: true });

// The locks a privileged session can walk past. Kept as a closed list so a
// typo becomes a visible 'unknown-action' row rather than a category nobody
// ever greps for.
const ACTIONS = [
    'categorise-bank-line',        // a bank withdrawal booked to an account she picked
    'undo-categorise-bank-line',
    // ── UNTYING A BANK ROW FROM A RECORDED PAYMENT ───────────────────────
    // 2026-10-27, with the unmatch button (#234). Unlike the two above it
    // reverses no journal entry — a match creates nothing — so this entry is
    // not here to explain a figure. It is here to answer "who untied this",
    // which matters precisely BECAUSE the overnight auto-tick ties rows with
    // nobody watching: an undo of something Jarvis did by itself must be
    // attributable to the person who did it.
    //
    // Registered rather than left to log as 'unknown-action'. It logged that
    // way for the first hour it existed, which is what the allowlist is for.
    'unmatch-bank-row',
    // A customer deposit Jarvis placed on an invoice BY ITSELF (helpers/depositAutoApply.js), and her undo of one.
    // The detail carries the reasons it gave, because nobody can reconstruct them afterwards.
    'auto-apply-deposit',
    'undo-auto-apply-deposit',
    // She picked the payment herself instead of taking Jarvis's. Logged
    // because the detail carries what Jarvis WOULD have tied it to and the
    // gap she confirmed — the two things nobody can reconstruct afterwards.
    'match-bank-row-by-hand',
    'delete-paid-load',           // a load with payments against it
    'delete-paid-trucker-bill',   // a trucker bill with payments against it
    'delete-payment',             // one payment removed from an SAMPLE YARD CO YARD load
    // ── SAMPLE YARD CO METALS, WHICH IS A DIFFERENT COMPANY ────────────────────────
    // the owner, 2026-09-10: "Always remember Sample Yard Co Yard is different and Sample
    // Metals is different." Kept as their own actions rather than folded into
    // delete-payment above, so a question about one company's books can be
    // answered from this log without reading every entry's detail. An advance
    // is separate again: deleting one un-applies credit from containers that
    // were showing as settled.
    'delete-bill-payment',        // a supplier payment removed from Sample Yard Co Metals
    'delete-bill-advance',        // a supplier advance removed, un-applying its credit
    'delete-sales-receipt',       // a customer receipt removed, reopening its containers
    'delete-sale-cost',           // a freight or commission settlement removed
    'delete-metals-trucking',     // an Sample Yard Co Metals haulage payment removed
    'resign-paid-load',           // signature replaced after money moved
    'edit-locked-load',           // the edit-unlock prompt satisfied by this profile
    // ── DOCUMENTS ────────────────────────────────────────────────────────
    // Not a lock being walked past — any admin may do this — but a shipping
    // document that was handed to a driver, removed from the system. Which
    // one went, and who removed it, outlives the record itself.
    'delete-bol',                 // a saved bill of lading form (the PDF is kept)
    'delete-packing-list',        // a container's packing list
    // the owner, 2026-09-17: "add delete option in saved proforma/invoice/bol/
    // packing list". The ARCHIVED PDF — the file itself, which may already be
    // in a broker's inbox. The only trace of a deleted commercial invoice is
    // otherwise that it is not there any more.
    'delete-saved-document',      // an archived proforma/invoice/BOL/packing PDF
    // the owner, 2026-10-12: "i want clean up option in documents.i dont want to
    // store old invoices". A BULK removal of saved invoice forms, packing list
    // records and proforma PDFs older than a cutoff she chose. One entry per
    // run, with the rule and the list in detail, because the individual
    // documents will not be there to ask about afterwards.
    'cleanup-saved-documents',
    // ── A SPREADSHEET IMPORT ────────────────────────────────────────────
    // the owner, 2026-09-19, asking for an upload button. One press creates
    // hundreds of financial records at once and the undo removes them again,
    // so both belong in the log that exists to answer "who did that": a
    // question about an import is otherwise a question about 568 rows that
    // all appeared at the same second with nothing saying why.
    'import-workbook',            // bills and invoices created from a spreadsheet
    'undo-import', 'merge-suppliers', 'undo-supplier-merge', 'merge-names', 'undo-name-merge',                // one import removed whole
    // ── A PLAN THE AGENT APPLIED ────────────────────────────────────────
    // the owner, 2026-10-08: "make it log every change we are doing in qb/books
    // so that we can check it later." One sentence of hers becomes several
    // writes across two stores, and the entry is the only place her WORDS,
    // the plan they were read as, the figures either side and the undo all
    // sit together. Separate from the deletes above because the question
    // "what did the agent do" must be answerable without reading every
    // entry's detail — and because a plan that was REFUSED is worth keeping
    // too, which none of the others are.
    'ledger-plan',                // a multi-step correction proposed by the agent
];

function listEntries() {
    const rows = loadJson(cfg.AUDIT_LOG_FILE, []);
    return Array.isArray(rows) ? rows : [];
}

function nextId(rows) {
    let max = 0;
    for (const r of rows) {
        const m = /^AUD_(\d+)$/.exec((r && r.id) || '');
        if (m) max = Math.max(max, parseInt(m[1], 10));
    }
    return `AUD_${String(max + 1).padStart(4, '0')}`;
}

// Records that a privileged action is ABOUT to happen. Returns the entry so
// the caller can stamp the outcome on it.
//
// `subject` is the thing acted on (a load id, a payment id). `detail` is
// whatever will be impossible to reconstruct afterwards — for a load delete
// that means the seller, the date, the amount and the payments, because in a
// few milliseconds none of them will exist anywhere else.
async function record({ action, subject, actor, role, ip, detail }) {
    const entry = {
        id: null,                       // assigned under the lock
        at: new Date().toISOString(),
        action: ACTIONS.includes(action) ? action : 'unknown-action',
        requested_action: action,       // kept verbatim even when unrecognised
        subject: subject == null ? null : String(subject),
        actor: actor || 'unknown',
        role: role || 'unknown',
        ip: ip || null,
        detail: detail == null ? null : detail,
        outcome: 'started',
    };
    await mutateJson(cfg.AUDIT_LOG_FILE, [], (rows) => {
        const list = Array.isArray(rows) ? rows : [];
        entry.id = nextId(list);
        list.push(entry);               // push, not unshift — oldest first, so
        return list;                    // the file reads as a timeline
    });
    return entry;
}

// Stamps how it ended. Never rewrites anything else on the row, and never
// removes it: a refused or failed attempt stays in the file exactly as
// visibly as a successful one.
async function complete(entry, outcome, extra) {
    if (!entry || !entry.id) return null;
    let out = null;
    await mutateJson(cfg.AUDIT_LOG_FILE, [], (rows) => {
        const list = Array.isArray(rows) ? rows : [];
        const row = list.find((r) => r && r.id === entry.id);
        if (row) {
            row.outcome = outcome;
            row.completed_at = new Date().toISOString();
            if (extra) row.result = extra;
            out = row;
        }
        return list;
    });
    return out;
}

// Convenience for the refusal path, where there is no act to follow: one row,
// finished on arrival.
async function refused({ action, subject, actor, role, ip, detail, reason }) {
    const entry = await record({ action, subject, actor, role, ip, detail });
    return complete(entry, 'refused', { reason });
}

module.exports = { ACTIONS, listEntries, record, complete, refused };
