// ── helpers/plaid.js — the bank feed, and nothing else ────────────────────
//
// the owner, 2026-10-05, choosing where bank rows come from: the Plaid feed, at
// https://dashboard.plaid.com/overview. Her account; her keys.
//
// ── NO DEPENDENCY ────────────────────────────────────────────────────────
// Plaid's official SDK is a wrapper over four JSON POSTs. package.json has no
// plaid entry and this file does not add one: adding a dependency to her
// server means `npm install` on the VM is now part of deploying a bank fix,
// and the SDK's surface is wider than what is used here. Node 20 has fetch.
// If the SDK is ever wanted, this file is the one place to swap.
//
// ── THE ACCESS TOKEN IS THE WHOLE RISK ───────────────────────────────────
// config.js says it plainly at line 342: bank-item.json holds the Plaid
// ACCESS TOKEN, it is "the standing ability to pull this account's history,
// it does not expire on its own, and it must never appear in an API response
// or a log line."
//
// So, in this file:
//   · the token is read from disk and passed to Plaid. It is never returned
//     by any function here, never put in an Error message, and never logged.
//   · redact() strips it, the client secret and the client id from anything
//     on its way to a log or an HTTP response, and every throw goes through
//     it. Plaid's own error bodies echo request fields back, which is how a
//     secret ends up in a log without anyone writing it there.
//   · tests/plaid.js asserts that, by searching every thrown message and
//     every returned object for the fixture token.
//
// ── TRANSACTIONS/SYNC, NOT TRANSACTIONS/GET ──────────────────────────────
// /transactions/get takes a date range and re-sends everything in it, which
// means a nightly pull re-downloads the same month forever and any row the
// bank later amended arrives as a silent overwrite. /transactions/sync is
// cursor-based: it returns added, MODIFIED and REMOVED since the last
// cursor. The modified and removed lists are the whole reason to prefer it —
// helpers/bankLedger.js has a drift notion precisely because a bank restates
// rows, and this is the endpoint that admits it.

const fs = require('fs');
const path = require('path');
const cfg = require('../config');
const { loadJson, mutateJson } = require('./json');

const HOSTS = {
    sandbox: 'https://sandbox.plaid.com',
    development: 'https://development.plaid.com',
    production: 'https://production.plaid.com',
};

function env() {
    const e = String(cfg.PLAID_ENV || 'sandbox').trim().toLowerCase();
    // Anything unrecognised is SANDBOX, never production. A typo in an env
    // var must not be the thing that points a nightly job at her real bank.
    return HOSTS[e] ? e : 'sandbox';
}
function host() { return HOSTS[env()]; }

function configured() {
    return !!(cfg.PLAID_CLIENT_ID && cfg.PLAID_SECRET);
}

function ITEM_FILE() { return process.env.BANK_ITEM_FILE || cfg.BANK_ITEM_FILE; }

// ── redaction ────────────────────────────────────────────────────────────
// Applied to every string that leaves this file. Not a nicety: Plaid returns
// the request body back inside some error payloads, so the secret can arrive
// in an error message without anyone having written it there.
function redact(text) {
    let s = typeof text === 'string' ? text : JSON.stringify(text == null ? '' : text);
    for (const secret of [cfg.PLAID_SECRET, cfg.PLAID_CLIENT_ID]) {
        if (secret && String(secret).length > 5) {
            s = s.split(String(secret)).join('[redacted]');
        }
    }
    // Any access token, whoever issued it. Plaid's are access-<env>-<uuid>,
    // and the shape is matched rather than the specific value so a token
    // this process has never seen is still stripped.
    s = s.replace(/access-(sandbox|development|production)-[A-Za-z0-9-]+/g, 'access-[redacted]');
    s = s.replace(/public-(sandbox|development|production)-[A-Za-z0-9-]+/g, 'public-[redacted]');
    s = s.replace(/link-(sandbox|development|production)-[A-Za-z0-9-]+/g, 'link-[redacted]');
    return s;
}

const fail = (msg) => { throw new Error(redact(msg)); };

// ── READ ONLY, ENFORCED — NOT A CONVENTION ───────────────────────────────
// the owner, 2026-10-08: "Also i want read only access for plaid account from
// jarvis.never write".
//
// Jarvis was ALREADY read-only in practice — `products: ['transactions']`
// grants history and nothing else, and no money-movement endpoint is called
// anywhere in this repo. But "no caller happens to do it" is not a rule, it
// is a coincidence that holds until someone adds a feature. Plaid's API has
// endpoints that move real money (/transfer/authorization/create,
// /transfer/create, /payment_initiation/payment/create) and endpoints that
// alter her Items. Reaching any of them is one `call('/transfer/create')`
// away, and the thing that would stop it is this list.
//
// So the allowlist is the rule, and it is checked BEFORE the network call.
// A new endpoint does not work until someone adds it here, which makes the
// decision visible in a diff instead of invisible in a feature.
//
// ── THE ONE PERMITTED WRITE, AND WHOSE CALL IT WAS ───────────────────────
// /item/remove deletes an Item at Plaid's end, so it is strictly a write. I
// asked rather than decide it: offered local-forget-only, keep-it, or drop
// the button, and the owner, 2026-10-08, chose "Keep Unlink calling Plaid" —
// one write, and only this one, to remove her own connection. It is named
// here with that provenance so nobody later reads the list as "writes are
// fine if they seem harmless".
const READ_ONLY = new Set([
    '/link/token/create',               // starts Link; grants nothing by itself
    '/item/public_token/exchange',      // turns her consent into a read token
    '/accounts/get',                    // cached balance + account list, free
    '/accounts/balance/get',            // real-time balance. BILLED PER CALL
    '/transactions/sync',               // the feed
    '/institutions/get',                // which banks use OAuth
    // ── ADDED 2026-10-08, AND IT IS A READ ────────────────────────────────
    // the owner: "i dont want human intervention between jarvis and plaid."
    // Webhooks are how Plaid tells this server a connection has died
    // without her noticing a stale figure two days later. Verifying one
    // needs the public key that signed it, and this is the endpoint that
    // returns it. It takes a key id and returns a PUBLIC key: it reads, it
    // changes nothing, and it carries no account data.
    '/webhook_verification_key/get',
]);
// HER DECISION, 2026-10-08, recorded above. Separate from READ_ONLY so the
// read list stays honestly a read list.
const PERMITTED_WRITES = new Set(['/item/remove']);
// Sandbox-only, and the env check is the point: these create fake data and
// must be impossible against production even if a route is left exposed.
const SANDBOX_ONLY = new Set([
    '/sandbox/public_token/create',
    '/sandbox/item/reset_login',
    '/sandbox/item/fire_webhook',
]);

function assertReadOnly(endpoint) {
    const e = String(endpoint || '');
    if (READ_ONLY.has(e) || PERMITTED_WRITES.has(e)) return;
    if (SANDBOX_ONLY.has(e)) {
        if (env() === 'sandbox') return;
        fail(`${e} is a sandbox endpoint and PLAID_ENV is ${env()} — refused. `
            + 'Sandbox helpers must never run against her real bank.');
    }
    fail(`Jarvis is read-only at Plaid, so ${e} is refused before any request is sent. `
        + 'the owner asked for read-only access on 2026-10-08. If a new endpoint is genuinely '
        + 'needed, add it to READ_ONLY in helpers/plaid.js and say in the commit why it '
        + 'only reads — do not route around this.');
}

// ── one POST ─────────────────────────────────────────────────────────────
// fetchImpl is injectable so a test never reaches the network, and the
// default is the global fetch rather than a module-level capture — the
// mistake that let a QuickBooks token refresh escape a stubbed suite this
// morning was exactly a default that was not overridable at the call site.
async function call(endpoint, body, { fetchImpl, timeoutMs = 30000 } = {}) {
    // FIRST, before the configured() check and before any network. A refusal
    // must not depend on whether her keys happen to be set, or the guard
    // would be absent on exactly the machine where it is being developed.
    assertReadOnly(endpoint);
    if (!configured()) {
        fail('Plaid is not configured — set PLAID_CLIENT_ID and PLAID_SECRET in the server .env. '
            + 'They are on the Plaid dashboard under Developers / Keys, and they do not belong in a chat.');
    }
    const f = fetchImpl || (typeof fetch === 'function' ? fetch : null);
    if (!f) fail('no fetch available in this runtime');

    const payload = { client_id: cfg.PLAID_CLIENT_ID, secret: cfg.PLAID_SECRET, ...body };
    const ac = new AbortController();
    const timer = setTimeout(() => ac.abort(), timeoutMs);
    let res;
    try {
        res = await f(host() + endpoint, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload),
            signal: ac.signal,
        });
    } catch (e) {
        fail(`Plaid ${endpoint} did not answer: ${e && e.message}`);
    } finally { clearTimeout(timer); }

    const raw = await res.text().catch(() => '');
    let json = null;
    try { json = raw ? JSON.parse(raw) : null; } catch (e) { json = null; }
    if (!res.ok) {
        const m = json || {};
        // Plaid's own wording is the useful part — "ITEM_LOGIN_REQUIRED" means
        // she has to re-authenticate at the bank and no amount of retrying
        // helps, which is worth saying rather than hiding behind a 500.
        fail(`Plaid ${endpoint} refused (${res.status}): `
            + [m.error_code, m.error_message, m.display_message].filter(Boolean).join(' — ')
            + (m.error_code ? '' : ' ' + String(raw).slice(0, 300)));
    }
    if (!json) fail(`Plaid ${endpoint} returned something that is not JSON`);
    return json;
}

// ── the linked item ──────────────────────────────────────────────────────
// One item per institution. She has two banks, so there will be two.
function items() {
    const raw = loadJson(ITEM_FILE(), { items: [] });
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return [];
    return Array.isArray(raw.items) ? raw.items : [];
}

// What a caller outside this file is allowed to see. NEVER the token.
function itemsPublic() {
    return items().map((i) => ({
        item_id: i.item_id,
        institution: i.institution || null,
        linked_at: i.linked_at || null,
        cursor_set: !!i.cursor,
        last_sync_at: i.last_sync_at || null,
        // Set by the webhook or a failed pull; cleared by the next good pull.
        // Not a secret — it is the one thing the screen most needs to say.
        needs_login: i.needs_login || null,
        // Balances Plaid already sent WITH a transactions pull, if it did.
        // No /accounts/balance/get call is made for these: that endpoint is
        // billed per call (see bankMatchRoutes /api/bank/reconcile).
        balances: i.balances || null,
        accounts: (i.accounts || []).map((a) => ({
            account_id: a.account_id, name: a.name || null,
            mask: a.mask || null, subtype: a.subtype || null,
        })),
    }));
}

async function saveItem(item) {
    await mutateJson(ITEM_FILE(), { items: [] }, (all) => {
        const s = (all && typeof all === 'object' && !Array.isArray(all)) ? all : { items: [] };
        const rows = Array.isArray(s.items) ? s.items : [];
        s.items = rows.filter((i) => i.item_id !== item.item_id).concat([item]);
        return s;
    });
    return item;
}

// ── WHAT SHE CONSENTS TO AT THE BANK ─────────────────────────────────────
// The endpoint allowlist above governs what this server asks Plaid for. This
// governs something different and in some ways more important: what the bank
// is told Jarvis may do, on the consent screen SHE reads during Link.
//
// `transactions` is history. It is the whole feature. Of the products that
// are not here, two matter: `auth` hands over the account and routing number,
// which is what an ACH debit needs, and `transfer`/`payment_initiation` are
// money movement outright. Adding `auth` would not break a test by itself —
// it would simply widen what her bank believes she agreed to, invisibly. So
// the list is frozen, named, and asserted in tests/plaid.js.
const READ_PRODUCTS = ['transactions'];
const MONEY_PRODUCTS = ['auth', 'transfer', 'payment_initiation', 'signal', 'identity_verification'];

function assertReadProducts(products) {
    const bad = (products || []).filter((p) => MONEY_PRODUCTS.includes(String(p)));
    if (bad.length) {
        fail(`refusing to ask her bank for ${bad.join(', ')} — Jarvis reads transactions and `
            + 'nothing else. the owner asked for read-only access on 2026-10-08, and this is the '
            + 'consent screen she signs at the bank, not an internal setting.');
    }
}

// ── step 1: a link token, for the browser ────────────────────────────────
// Short-lived and not a credential for anything but starting Link. She
// completes the bank login in Plaid's own iframe; her bank password never
// touches this server, which is the entire point of Link.
//
// ── NO redirect_uri, AND THAT IS A DECISION ──────────────────────────────
// BofA and Chase are OAuth banks, so Link leaves the page and comes back.
// Plaid's OAuth guide: desktop web works WITHOUT a redirect_uri, because it
// opens the bank in a pop-up. A redirect_uri is required for webviews — and
// the Sample Yard Co Yard Android app IS a webview. So linking a bank is a DESKTOP
// WEBSITE job, once per bank, and the app is deliberately not a place it can
// be done. Adding android_package_name would make the phone a second place
// her bank credentials get entered, for a thing she does twice ever.
async function linkToken({ fetchImpl, userId = 'edge-jarvis', itemId = null } = {}) {
    assertReadProducts(READ_PRODUCTS);
    const body = {
        user: { client_user_id: String(userId) },
        client_name: 'Jarvis — Sample Yard Co Metals',
        products: READ_PRODUCTS,
        country_codes: ['US'],
        language: 'en',
    };
    // ── HOW FAR BACK, ASKED FOR ONCE AND NEVER AGAIN ─────────────────────
    // the owner, 2026-10-12: "all the transactions from plaid is from
    // 2026-07-14 to 2026-10-09.why not 2026 datas are sent?"
    //
    // 2026-07-14 is EXACTLY 90 days before that question. This body did not
    // set days_requested, so Plaid used its documented default of 90, and
    // /transactions/sync then has nothing older to hand over however often
    // it runs. It was never a sync problem.
    //
    // THE PART THAT MATTERS OPERATIONALLY: Plaid's docs say this value
    // "cannot be updated" once Transactions has been added to an Item. There
    // is no setting to widen the window later and no sync that recovers it —
    // the only way is to remove the Item and link the bank again. So this
    // has to be right BEFORE a bank is connected, which is exactly where she
    // is: the sandbox item is still linked and BofA and Chase are not.
    //
    // HOW FAR BACK IS HERS: "i need 2026 transactions from 01-01-2026" and
    // "i just need 2026 data". 365 days, not Plaid's 730 maximum and not the
    // 285 that merely reaches 1 January — because this is a ROLLING LOOKBACK
    // from the day the bank is linked, not a fixed start date, and the
    // distance to 1 January grows by a day every day. Undersizing a value
    // Plaid will not let us change afterwards is what costs a second
    // unlink/re-link. The figure itself lives in config.js, with the note on
    // why 730 was wrong — it rested on an inference of mine about her 2025
    // bills that she has since corrected.
    //
    // NEW MODE ONLY. Update mode re-authenticates an EXISTING item, where
    // this value is already fixed and `products` is deliberately omitted;
    // sending it there would be meaningless at best.
    // Clamped to Plaid's own 1..730: over the ceiling is an API error, not a
    // bigger window, so a mistyped env must not reach the request.
    const DAYS = Math.min(730, Math.max(1, Number(cfg.PLAID_DAYS_REQUESTED) || 365));
    // ── UPDATE MODE: SIGNING BACK IN TO A BANK ALREADY LINKED ────────────
    // When the bank wants her to log in again (password changed, consent
    // renewed), pressing "Connect a bank" would create a SECOND item for the
    // same accounts — two feeds, every transaction twice. Plaid's update mode
    // re-authenticates the EXISTING item instead: same access token, same
    // cursor, history kept. Plaid requires `products` to be left out here.
    // The access token goes to Plaid in this request body and nowhere else.
    let mode = 'new';
    body.transactions = { days_requested: DAYS };
    if (itemId) {
        const item = items().find((i) => i.item_id === itemId);
        if (!item) fail(`no linked item ${itemId}`);
        if (!item.access_token) fail(`item ${itemId} has no access token — unlink it and connect again`);
        body.access_token = item.access_token;
        delete body.products;
        // Already fixed on this Item — see the days_requested note above.
        delete body.transactions;
        mode = 'update';
    }
    // ── WHERE PLAID SHOULD PUSH ─────────────────────────────────────────
    // the owner, 2026-10-08: "i dont want human intervention between jarvis
    // and plaid." Set here rather than in the dashboard because the webhook
    // belongs to the Item, and an Item linked without one never sends.
    //
    // OMITTED WHEN NOT CONFIGURED, rather than guessed. A wrong URL means
    // Plaid retries into nothing for 24 hours per event and the Dashboard
    // logs fill with failures — and the fallback is not silence, it is the
    // 05:45 pull, which still works. Plaid requires a public https URL with
    // a valid certificate, so localhost cannot be used even in sandbox.
    if (cfg.PLAID_WEBHOOK_URL) body.webhook = cfg.PLAID_WEBHOOK_URL;
    const r = await call('/link/token/create', body, { fetchImpl });
    return { link_token: r.link_token, expiration: r.expiration, webhook: body.webhook || null, mode };
}

// ── step 2: the public token becomes an access token ─────────────────────
// Returns only what is safe. The access token goes to disk and no further.
async function exchange(publicToken, { fetchImpl, institution = null } = {}) {
    const pt = String(publicToken || '').trim();
    if (!pt) fail('no public_token — the browser did not finish Link');

    const r = await call('/item/public_token/exchange', { public_token: pt }, { fetchImpl });
    if (!r.access_token || !r.item_id) fail('Plaid returned no access_token/item_id');

    // Which accounts this item covers, so bank-accounts.json can be linked
    // to them — helpers/bankLedger.js needs plaid_account_id to know which
    // COMPANY a deposit belongs to, and without it nothing is matched.
    let accounts = [];
    try {
        const a = await call('/accounts/get', { access_token: r.access_token }, { fetchImpl });
        accounts = (a.accounts || []).map((x) => ({
            account_id: x.account_id, name: x.name, mask: x.mask,
            subtype: (x.subtype || null), type: (x.type || null),
        }));
    } catch (e) { accounts = []; }

    await saveItem({
        item_id: r.item_id,
        access_token: r.access_token,          // on disk, in a file excluded from the backup
        institution: institution || (r.institution_id || null),
        linked_at: new Date().toISOString(),
        cursor: null,
        accounts,
    });
    // ── JOIN HER OWN RECORD TO THE PLAID ACCOUNT, NOW ───────────────────
    // the owner, 2026-10-08: "i dont want human intervention between jarvis
    // and plaid." This was the last manual step after linking, and skipping
    // it fails SILENTLY: bankLedger.companyOf/bankOf match a row's
    // account_id against bank-accounts.json, so with no plaid_account_id
    // every transaction arrives with company:null and bank:null, the feed
    // fills, and the reconciliation reports zeroes against a full ledger.
    // That looks exactly like "Plaid sent nothing".
    //
    // Matched on the last four digits — Plaid's `mask` against the
    // accountNumber she already stores — so it is a lookup, not a guess.
    // joinPlaidAccounts refuses ambiguity rather than picking; the wrong
    // join would file Sample Yard Co Metals' deposits into Sample Yard Co Trading's books.
    //
    // A FAILURE HERE MUST NOT UNDO THE LINK. The item is already saved
    // above and the access token is the thing that cannot be recreated
    // without her going back to the bank. So this is reported, never
    // thrown: a join she can fix in a file is not worth losing a link over.
    let join = { changed: 0, joined: [], ambiguous: [], unmatched: [] };
    try {
        const ledger = require('./bankLedger');
        const file = ledger.accountsFile();   // overridable, so a test never edits the real one
        // ── AND REFUSED OUTRIGHT UNDER TEST, LIKE drive.js ──────────────
        // Overridable is not the same as safe: tests/plaid.js exercises
        // this path through sandboxLink and, until BANK_ACCOUNTS_FILE was
        // set there, every run rewrote her real qb-settings file — the one
        // holding two companies' account numbers, tracked in git. It was
        // only reformatting unicode escapes, which is exactly why nobody
        // would have noticed before it did something worse.
        //
        // So the test environment must POINT somewhere, not merely be
        // allowed to. A suite that forgets gets a clear refusal instead of
        // a silent edit to her banking file.
        if (process.env.JARVIS_TEST === '1' && !process.env.BANK_ACCOUNTS_FILE) {
            fail('refusing to write qb-settings/bank-accounts.json under JARVIS_TEST — '
                + 'set BANK_ACCOUNTS_FILE to a temp copy first');
        }
        await mutateJson(file, { accounts: [] }, (cur) => {
            const d = (cur && typeof cur === 'object' && !Array.isArray(cur)) ? cur : { accounts: [] };
            const res = ledger.joinPlaidAccounts(Array.isArray(d.accounts) ? d.accounts : [], accounts);
            join = { changed: res.changed, joined: res.joined, ambiguous: res.ambiguous, unmatched: res.unmatched };
            return { ...d, accounts: res.accounts };
        }, { strict: true });
    } catch (e) {
        join.problem = `could not write the account join: ${e.message}`;
    }

    // Deliberately not the token.
    return { item_id: r.item_id, accounts, institution: institution || null, join };
}

// ── step 3: pull, forever after ──────────────────────────────────────────
// Cursor-based. Returns what changed, and the caller decides what to do with
// it — this file does not write bank-transactions.json, because deciding
// what a bank row MEANS is bankLedger's job and mixing the two would put the
// drift rules behind a network call.
async function syncItem(itemId, { fetchImpl, pageCap = 20 } = {}) {
    const item = items().find((i) => i.item_id === itemId);
    if (!item) fail(`no linked item ${itemId}`);
    if (!item.access_token) fail(`item ${itemId} has no access token — re-link the bank`);

    let cursor = item.cursor || null;
    const added = [], modified = [], removed = [];
    let balances = null;
    let pages = 0, truncated = false;

    for (;;) {
        // added/modified/removed are the three lists; has_more means page on.
        const r = await call('/transactions/sync', {
            access_token: item.access_token,
            ...(cursor ? { cursor } : {}),
            count: 500,
            // Without this Plaid sends only its cleaned-up `name`, which for a
            // wire is the first ~half of what the bank printed (the part after
            // "PMT DET:" is what says which invoice it pays). Display only —
            // see `memo` in bankLedger.fromPlaid for why desc is NOT replaced.
            options: { include_original_description: true },
        }, { fetchImpl });

        added.push(...(r.added || []));
        modified.push(...(r.modified || []));
        removed.push(...(r.removed || []));
        if (Array.isArray(r.accounts) && r.accounts.length) {
            balances = {};
            for (const a of r.accounts) {
                if (!a || !a.account_id || !a.balances) continue;
                balances[a.account_id] = { current: a.balances.current ?? null,
                    available: a.balances.available ?? null,
                    currency: a.balances.iso_currency_code || null, as_of: new Date().toISOString() };
            }
        }
        cursor = r.next_cursor || cursor;
        pages += 1;

        if (!r.has_more) break;
        // A cap, and the fact of hitting it is REPORTED. A sync that stopped
        // early must not look like a sync that finished, which is the same
        // rule the matcher's truncated flag exists for.
        if (pages >= pageCap) { truncated = true; break; }
    }

    // A good pull proves the login works, so a "needs you to sign in" flag
    // from an earlier webhook is cleared here rather than left to nag.
    await saveItem({ ...item, cursor, last_sync_at: new Date().toISOString(), needs_login: null,
        ...(balances ? { balances } : {}) });
    return { item_id: itemId, added, modified, removed, pages, truncated, cursor_advanced: cursor !== (item.cursor || null) };
}

// ── the whole feed, into the ledger ──────────────────────────────────────
// added and modified both go through bankLedger.ingestPlaid, which upserts
// on transaction_id — so a modified row CORRECTS its existing row and is
// flagged as drift if she had already acted on it. removed rows are reported
// and NOT deleted here: a bank row vanishing after she has allocated it
// against an invoice is a question, not a tidy-up.
async function syncAll({ fetchImpl } = {}) {
    const ledger = require('./bankLedger');
    const out = { items: [], added: 0, modified: 0, removed: [], errors: [], truncated: false };
    for (const i of items()) {
        try {
            const r = await syncItem(i.item_id, { fetchImpl });
            const rep = await ledger.ingestPlaid([...r.added, ...r.modified]);
            out.items.push({ item_id: i.item_id, institution: i.institution || null, ...rep, pages: r.pages });
            out.added += r.added.length;
            out.modified += r.modified.length;
            out.removed.push(...r.removed.map((x) => x.transaction_id || x));
            if (r.truncated) out.truncated = true;
        } catch (e) {
            // One bank failing must not stop the other. ITEM_LOGIN_REQUIRED on
            // Chase should not hide BofA's deposits.
            out.errors.push({ item_id: i.item_id, institution: i.institution || null, error: redact(e.message) });
            const code = (String(e.message).match(/ITEM_LOGIN_REQUIRED|PENDING_DISCONNECT|PENDING_EXPIRATION/) || [])[0];
            if (code) { try { await markNeedsLogin(i.item_id, code); } catch (x) { /* the error above still reports it */ } }
        }
    }
    // Her standing rules ("WIRE IN FEE is a bank charge") apply to whatever
    // just arrived. Each one sets a row aside WITH the rule as the reason, so
    // it is reversible and explainable; nothing is created or deleted.
    try { out.rules = await require('./bankLearn').applyRules({ by: 'rule' }); }
    catch (e) { out.rules_error = e.message; }
    return out;
}

// ── sandbox only: a fake bank, so the whole path is exercisable ──────────
// Her choice was the live feed, and production access needs a Plaid review.
// This is how the link → sync → match path is proved end to end before that
// lands. REFUSES outside sandbox, because /sandbox/public_token/create does
// not exist in production and a caller reaching for it there is confused
// about which environment they are in.
async function sandboxLink({ fetchImpl, institutionId = 'ins_109508' } = {}) {
    if (env() !== 'sandbox') fail(`sandboxLink is sandbox-only; PLAID_ENV is ${env()}`);
    const r = await call('/sandbox/public_token/create', {
        institution_id: institutionId, initial_products: READ_PRODUCTS,
    }, { fetchImpl });
    return exchange(r.public_token, { fetchImpl, institution: institutionId });
}

async function unlink(itemId, { fetchImpl } = {}) {
    const item = items().find((i) => i.item_id === itemId);
    if (!item) fail(`no linked item ${itemId}`);
    // Told to Plaid as well as forgotten here, so the token is actually dead
    // rather than merely deleted from a file someone may have a copy of.
    try { await call('/item/remove', { access_token: item.access_token }, { fetchImpl }); }
    catch (e) { /* removing locally is still right if Plaid is unreachable */ }
    await mutateJson(ITEM_FILE(), { items: [] }, (all) => {
        const s = (all && typeof all === 'object' && !Array.isArray(all)) ? all : { items: [] };
        s.items = (Array.isArray(s.items) ? s.items : []).filter((i) => i.item_id !== itemId);
        return s;
    });
    return { item_id: itemId, removed: true };
}

// ── the public key that signed a webhook ─────────────────────────────────
// Cached by key id. Plaid rotates these, and the kid in the JWT header says
// which one to ask for, so the cache is keyed on it rather than being a
// single slot — a single slot silently refetches on every rotation and,
// worse, would hand back the wrong key if two arrived interleaved.
//
// A key that could not be fetched is NOT cached. Caching a failure would
// turn one bad minute into a permanently unverifiable webhook stream.
const KEY_CACHE = new Map();

async function verificationKey(keyId, { fetchImpl } = {}) {
    const kid = String(keyId || '').trim();
    if (!kid) fail('no key id — the webhook JWT header had no kid');
    if (KEY_CACHE.has(kid)) return KEY_CACHE.get(kid);
    const r = await call('/webhook_verification_key/get', { key_id: kid }, { fetchImpl });
    if (!r || !r.key) fail('Plaid returned no verification key');
    KEY_CACHE.set(kid, r.key);
    return r.key;
}

// ── the bank wants her to sign in again ──────────────────────────────────
// Written by the webhook (ITEM_LOGIN_REQUIRED, PENDING_DISCONNECT,
// PENDING_EXPIRATION) and by a pull that failed with one of those. Stored on
// the item so the screen can show a Reconnect button on the right account,
// instead of the alert living only in an email.
async function markNeedsLogin(itemId, code) {
    const item = items().find((i) => i.item_id === itemId);
    if (!item) return null;
    return saveItem({ ...item, needs_login: { code: String(code || 'ITEM_LOGIN_REQUIRED'), at: new Date().toISOString() } });
}
async function clearNeedsLogin(itemId) {
    const item = items().find((i) => i.item_id === itemId);
    if (!item) fail(`no linked item ${itemId}`);
    return saveItem({ ...item, needs_login: null });
}

function status() {
    return {
        configured: configured(),
        env: env(),
        host: host(),
        items: itemsPublic(),
        // Said out loud, because an unlinked account is the difference
        // between "nothing to reconcile" and "not connected yet".
        note: !configured()
            ? 'PLAID_CLIENT_ID and PLAID_SECRET are not set on this server'
            : (items().length ? null : 'configured, but no bank is linked yet'),
    };
}

module.exports = {
    env, host, configured, status, redact,
    items, itemsPublic, linkToken, exchange, syncItem, syncAll, sandboxLink, unlink,
    markNeedsLogin, clearNeedsLogin,
    ITEM_FILE, HOSTS,
    // Exported so tests/plaid.js can assert the rule rather than trust the
    // comment above it — and so a reviewer can see the whole permitted
    // surface in one place without reading the file.
    verificationKey,
    READ_ONLY, PERMITTED_WRITES, SANDBOX_ONLY, READ_PRODUCTS, MONEY_PRODUCTS,
    assertReadOnly, assertReadProducts, call,
};
