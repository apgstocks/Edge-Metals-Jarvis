// ── helpers/poSheet.js — the Purchase Order sheet, server side ────────────
// GENERATED COPY of the sheet in dashboard/documents.html (poSheetCss /
// poSheetHtml and the small helpers they use), so the phone app and the
// "Print PO" button on a load or sale print the SAME sheet the Documents →
// Purchase order tab shows. tests/po-print.js renders both and fails if they
// ever differ, so a change to the website sheet that is not carried here
// turns red instead of quietly printing two different POs.
// Not edited by hand: change documents.html, then re-run scripts/sync-po-sheet.js.

function esc(s) {
  return String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

const PO_CONTACT = { phone: '(555) 010-0100', email: 'ops@sample.example' };

const PO_LOGO = '<svg width="56" height="56" viewBox="0 0 48 48"><rect x="1.5" y="1.5" width="45" height="45" rx="13" fill="#3DA836"></rect>'
  + '<rect x="13" y="13.5" width="21" height="5" rx="2.5" fill="#fff"></rect><rect x="13" y="21.5" width="15" height="5" rx="2.5" fill="#fff"></rect>'
  + '<rect x="13" y="29.5" width="21" height="5" rx="2.5" fill="#fff"></rect>'
  + '<path d="M37 11.5c2.4 0 4.4 2 4.4 4.4 0 2.4-2 4.4-4.4 4.4-.6-2.5-1.9-3.8-4.4-4.4 2.5-.6 3.8-1.9 4.4-4.4z" fill="#ABE2A1"></path></svg>';

function poIsSampleYardCoMetals(name) {
  return String(name || '').toLowerCase().replace(/[.,]/g, ' ').replace(/\s+/g, ' ').trim()
    .replace(/\s(inc|llc)$/, '') === 'sample yard co metals';
}

function poMoney(cents) {
  const neg = cents < 0;
  const abs = Math.abs(cents);
  const whole = String(Math.floor(abs / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return (neg ? '-' : '') + '$' + whole + '.' + String(abs % 100).padStart(2, '0');
}

function poPrice(n) {
  return '$' + n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 4 });
}

function poQty(n) {
  return n.toLocaleString('en-US', { maximumFractionDigits: 3 });
}

function poVendorAddress(d) {
  const lines = String(d.supplierAddress || '').split('\n');
  if (lines.length > 1 && lines[0].trim().toLowerCase() === String(d.supplier || '').trim().toLowerCase()) lines.shift();
  return lines.join('\n').trim();
}

function poShipToHtml(shipTo, miss) {
  if (!shipTo) return '<div class="nm">' + miss('—') + '</div>';
  const parts = String(shipTo).split('\n');
  const rest = parts.slice(1).join('\n').trim();
  return '<div class="nm">' + esc(parts[0]) + '</div>' + (rest ? '<div class="v">' + esc(rest) + '</div>' : '');
}

function poSheetCss() {
  // 2026-11-17, "mimic this design for purchase order" (the owner, with the
  // signed Jemulpo proforma attached): the PO sheet now follows the proforma's
  // look — full-width green header with a rule, a big two-tone title with the
  // number box beside it, tinted party cards, a solid green table header, a
  // dark-green total box, and a dark footer. This is the PURCHASE ORDER tab
  // only: the proforma and invoice templates are untouched.
  // The proforma embeds Poppins / DM Sans / IBM Plex Mono as base64. The PO
  // stays on system fonts (2026-10-26: the print window must never wait on a
  // download), so each stack NAMES the proforma face first and falls back to
  // the closest system face. Where those fonts are not installed it will look
  // close, not identical.
  const D = '"Poppins","Helvetica Neue",Helvetica,Arial,sans-serif';
  const M = '"IBM Plex Mono",ui-monospace,Menlo,Consolas,"Courier New",monospace';
  return '.po-sheet{font-family:"DM Sans","Helvetica Neue",Helvetica,Arial,sans-serif; color:#2B3239; background:#fff; padding:0; line-height:1.45; font-size:12.5px; max-width:794px; margin:0 auto; border:1px solid #E5E9EC; box-shadow:0 1px 4px rgba(0,0,0,.18); -webkit-print-color-adjust:exact; print-color-adjust:exact; overflow:hidden;}'
    + '.po-sheet *{box-sizing:border-box;}'
    + '.po-sheet .pad{padding:24px 44px 34px;}'
    + '.po-sheet .head{padding:28px 44px 26px; background:linear-gradient(160deg,#ECF8EA 0%,#fff 55%,#ECF8EA 100%);}'
    + '.po-sheet .toprow{display:flex; justify-content:space-between; align-items:center; gap:24px;}'
    + '.po-sheet .brand{display:flex; gap:13px; align-items:center; min-width:0;} .po-sheet .brand svg{flex:none; display:block; width:46px; height:46px;}'
    + '.po-sheet .co{white-space:nowrap; font-family:' + D + '; font-size:21px; font-weight:800; letter-spacing:-.02em; color:#0C0E10; line-height:1.1;}'
    + '.po-sheet .tag{font-size:10px; font-weight:700; letter-spacing:.18em; text-transform:uppercase; color:#3DA836; margin-top:4px; line-height:1;}'
    + '.po-sheet .co-addr{font-family:' + M + '; font-size:10.5px; color:#3C454D; line-height:1.7; text-align:right; white-space:pre-line;}'
    + '.po-sheet .contact{font-family:' + M + '; font-size:10.5px; color:#2E861F; line-height:1.7; text-align:right;}'
    + '.po-sheet .rule{display:flex; align-items:center; margin:16px 0 20px;} .po-sheet .rule i{display:block; height:2px; width:56px; background:#3DA836;} .po-sheet .rule b{display:block; height:1px; flex:1; background:rgba(167,176,183,.55);}'
    + '.po-sheet .titlerow{display:flex; justify-content:space-between; align-items:flex-start; gap:24px;}'
    + '.po-sheet .eyebrow{font-family:' + M + '; font-size:10.5px; font-weight:500; letter-spacing:.16em; text-transform:uppercase; color:#2E861F;}'
    + '.po-sheet h1{margin:10px 0 0; font-family:' + D + '; font-weight:800; font-size:36px; line-height:1; letter-spacing:-.025em; color:#0C0E10; text-transform:uppercase; white-space:nowrap;} .po-sheet h1 span{color:#3DA836;}'
    + '.po-sheet .nobox{flex:0 0 250px; background:#fff; border:1px solid #ABE2A1; border-radius:8px; overflow:hidden;}'
    + '.po-sheet .nobox div{display:flex; justify-content:space-between; gap:12px; padding:8px 14px; border-bottom:1px solid #D3F0CD;} .po-sheet .nobox div:last-child{border-bottom:none;}'
    + '.po-sheet .nobox span{font-family:' + M + '; font-size:9.5px; letter-spacing:.1em; text-transform:uppercase; color:#7E8891; white-space:nowrap; align-self:center;}'
    + '.po-sheet .nobox b{font-family:' + M + '; font-size:11px; font-weight:600; color:#0C0E10; text-align:right; word-break:break-all; line-height:1.4;}'
    + '.po-sheet .k{display:block; font-family:' + M + '; font-size:9.5px; letter-spacing:.1em; text-transform:uppercase; color:#7E8891; margin-bottom:4px;}'
    + '.po-sheet .parties{display:grid; grid-template-columns:1fr 1fr; gap:16px; margin-bottom:18px;}'
    + '.po-sheet .party{border:1px solid #E5E9EC; border-radius:8px; padding:16px 18px; background:#F3F5F7; border-color:#CBD1D6;}'
    + '.po-sheet .party:first-child{background:#ECF8EA; border-color:#D3F0CD;}'
    + '.po-sheet .party .k{letter-spacing:.12em; margin-bottom:7px; color:#3C454D;} .po-sheet .party:first-child .k{color:#2E861F;} .po-sheet .party .k:before{content:"\\25CF\\00a0\\00a0";}'
    + '.po-sheet .party .v{white-space:pre-line; color:#3C454D; line-height:1.6; font-size:12.5px;} .po-sheet .party .nm{font-family:' + D + '; font-weight:700; font-size:16px; color:#0C0E10; margin-bottom:5px; line-height:1.3;}'
    + '.po-sheet .meta{display:grid; grid-template-columns:repeat(3,1fr); background:#fff; border:1px solid #CBD1D6; border-radius:8px; overflow:hidden; margin-bottom:22px;}'
    + '.po-sheet .meta div{padding:11px 14px; font-weight:700; color:#14181B; border-right:1px solid #E5E9EC;} .po-sheet .meta div:last-child{border-right:none;}'
    + '.po-sheet table{width:100%; border-collapse:collapse;}'
    + '.po-sheet th{font-size:11px; font-weight:600; letter-spacing:.03em; text-align:left; color:#fff; background:#2E861F; padding:12px 14px; white-space:nowrap; border:none;}'
    + '.po-sheet th:first-child{border-top-left-radius:8px;} .po-sheet th:last-child{border-top-right-radius:8px;}'
    + '.po-sheet th.r,.po-sheet td.r{text-align:right; font-variant-numeric:tabular-nums;}'
    + '.po-sheet td{padding:12px 14px; border-bottom:1px solid #E5E9EC; vertical-align:top; font-size:13px; color:#2B3239;}'
    + '.po-sheet tbody tr:last-child td{border-bottom:2px solid #3DA836;}'
    + '.po-sheet td.d{font-weight:600; color:#0C0E10;}'
    + '.po-sheet td.r.d{font-family:' + M + ';}'
    + '.po-sheet .pp{display:flex; justify-content:space-between; gap:12px; white-space:nowrap;} .po-sheet .pp + .pp{margin-top:3px;}'
    + '.po-sheet .pp.a{justify-content:flex-end;}'
    + '.po-sheet .pp span{font-family:' + M + '; font-size:9px; letter-spacing:.1em; text-transform:uppercase; color:#7E8891; align-self:center;}'
    + '.po-sheet .tot{margin:14px 0 0 auto; width:304px;}'
    + '.po-sheet .tot div{display:flex; justify-content:space-between; align-items:center; padding:8px 2px; border-bottom:1px solid #E5E9EC; font-variant-numeric:tabular-nums; color:#3C454D;}'
    + '.po-sheet .tot div span + span{font-family:' + M + '; font-size:13px; font-weight:500; color:#0C0E10;}'
    + '.po-sheet .tot .grand{background:#226620; color:#fff; border-radius:8px; border:none; border-top:4px solid #57BE49; margin-top:8px; padding:13px 16px 14px; align-items:flex-end; gap:12px;}'
    + '.po-sheet .tot .grand span:first-child{font-family:' + M + '; font-size:10.5px; letter-spacing:.1em; text-transform:uppercase; color:#ABE2A1; padding-bottom:4px;}'
    + '.po-sheet .tot .grand span + span{font-family:' + D + '; font-weight:800; font-size:24px; letter-spacing:-.02em; color:#fff;}'
    + '.po-sheet .notes{margin-top:22px; padding:13px 16px; background:#ECF8EA; border:1px solid #D3F0CD; border-radius:8px; white-space:pre-line; font-size:12px; color:#3C454D; line-height:1.6;}'
    + '.po-sheet .notes .k{color:#2E861F;}'
    + '.po-sheet .sign{margin-top:36px; display:flex; gap:44px;} .po-sheet .sg{flex:1;}'
    + '.po-sheet .ink{height:44px; display:flex; align-items:flex-end;} .po-sheet .ink img{max-height:42px; max-width:170px;}'
    + '.po-sheet .ln{border-top:2px solid #3DA836; padding-top:6px; font-family:' + M + '; font-size:10px; letter-spacing:.08em; text-transform:uppercase; color:#7E8891; line-height:18px;}'
    + '.po-sheet .ln b{font-family:' + D + '; font-size:13px; letter-spacing:0; text-transform:none; color:#0C0E10;}'
    + '.po-sheet .empty{color:#A7B0B7; font-style:italic; font-weight:400;}'
    + '.po-sheet .foot{display:flex; justify-content:space-between; align-items:center; gap:12px; padding:13px 44px; background:#0C0E10; font-family:' + M + '; font-size:9.5px; letter-spacing:.08em; text-transform:uppercase; color:#A7B0B7;} .po-sheet .foot span:first-child{color:#57BE49;}'
    + '@media print{.po-sheet{box-shadow:none; border:none; max-width:none; position:relative; min-height:262mm;} .po-sheet .sign{position:absolute; left:14mm; right:14mm; bottom:16mm; margin-top:0;} .po-sheet .head{padding:28px 14mm 26px;} .po-sheet .pad{padding:24px 14mm 54mm;} .po-sheet .foot{position:absolute; left:0; right:0; bottom:0; padding:13px 14mm;} .po-sheet tr,.po-sheet .party{page-break-inside:avoid;} .po-sheet .sign,.po-sheet .tot,.po-sheet .notes{page-break-inside:avoid;}}';
}

function poSheetHtml(d) {
  const miss = (t) => '<span class="empty">' + esc(t) + '</span>';
  const meta = (k, v) => '<div><span class="k">' + k + '</span>' + (v ? esc(v) : miss('—')) + '</div>';
  // A subtotal is only worth a line when it differs from the total: several
  // items to add up, or freight / other charges on top. One item and nothing
  // else would print the same figure twice.
  const showSub = d.lines.filter((l) => l.ok).length > 1 || !!d.otherCents;
  const rows = d.lines.filter((l) => l.ok).map((l) =>
    '<tr><td class="d">' + esc(l.desc) + '</td><td class="r">' + esc(poQty(l.qty)) + '</td><td>' + esc(l.unit)
    + '</td><td class="r">' + (d.two
      ? '<div class="pp"><span>' + esc(d.labelA) + '</span>' + esc(poPrice(l.price)) + '</div><div class="pp"><span>' + esc(d.labelB) + '</span>' + esc(poPrice(l.price2)) + '</div>'
      : esc(poPrice(l.price)))
    + '</td><td class="r d">' + (d.two
      ? '<div class="pp a">' + esc(poMoney(l.amountCents)) + '</div><div class="pp a">' + esc(poMoney(l.amount2Cents)) + '</div>'
      : esc(poMoney(l.amountCents))) + '</td></tr>').join('');
  const nm = d.company ? esc(d.company) : miss('Choose the issuing company');
  const row = (k, v) => '<div><span>' + k + '</span><b>' + (v ? esc(v) : '—') + '</b></div>';
  return '<div class="po-sheet">'
    + '<div class="head"><div class="toprow"><div class="brand">' + (poIsSampleYardCoMetals(d.company) ? PO_LOGO : '') + '<div>'
    + '<div class="co">' + nm + '</div>'
    + (poIsSampleYardCoMetals(d.company) ? '<div class="tag">Inc. &middot; Global Scrap</div>' : '')
    + '</div></div>'
    + '<div>' + (d.companyAddress ? '<div class="co-addr">' + esc(d.companyAddress) + '</div>' : '')
    + (d.company ? '<div class="contact">Tel ' + esc(PO_CONTACT.phone) + '</div><div class="contact">' + esc(PO_CONTACT.email) + '</div>' : '')
    + '</div></div>'
    + '<div class="rule"><i></i><b></b></div>'
    + '<div class="titlerow"><div><div class="eyebrow">// Order to supplier</div><h1>Purchase <span>Order</span></h1></div>'
    + '<div class="nobox">' + row('PO No', d.number) + row('PO Date', d.date) + '</div></div></div>'
    + '<div class="pad"><div class="meta">' + meta('Required by', d.required) + meta('Payment terms', d.terms) + meta('Currency', 'USD') + '</div>'
    + '<div class="parties"><div class="party"><span class="k">Vendor</span><div class="nm">' + (d.supplier ? esc(d.supplier) : miss('—')) + '</div>'
    + (poVendorAddress(d) ? '<div class="v">' + esc(poVendorAddress(d)) + '</div>' : '') + '</div>'
    + '<div class="party"><span class="k">Deliver to</span>' + poShipToHtml(d.shipTo, miss) + '</div></div>'
    + '<table><thead><tr><th>Description</th><th class="r">Qty</th><th>Unit</th><th class="r">Unit price</th><th class="r">Amount</th></tr></thead><tbody>'
    + (rows || '<tr><td colspan="5">' + miss('No items yet') + '</td></tr>') + '</tbody></table>'
    + '<div class="tot">' + (d.two
      // Two totals follow, so with no freight the subtotals would only say
      // the same figures a third time.
      ? (!showSub ? '' : '<div><span>Subtotal if ' + esc(d.labelA) + '</span><span>' + esc(poMoney(d.subtotalCents)) + '</span></div>'
        + '<div><span>Subtotal if ' + esc(d.labelB) + '</span><span>' + esc(poMoney(d.subtotal2Cents)) + '</span></div>')
      : (!showSub ? '' : '<div><span>Subtotal</span><span>' + esc(poMoney(d.subtotalCents)) + '</span></div>'))
    + (d.otherCents ? '<div><span>Freight / other</span><span>' + esc(poMoney(d.otherCents)) + '</span></div>' : '')
    + (d.two
      ? '<div class="grand"><span>Total if ' + esc(d.labelA) + ' (USD)</span><span>' + esc(poMoney(d.totalCents)) + '</span></div>'
        + '<div class="grand"><span>Total if ' + esc(d.labelB) + ' (USD)</span><span>' + esc(poMoney(d.total2Cents)) + '</span></div>'
      : '<div class="grand"><span>Total (USD)</span><span>' + esc(poMoney(d.totalCents)) + '</span></div>') + '</div>'
    + (d.notes ? '<div class="notes"><span class="k">Notes &amp; conditions</span>' + esc(d.notes) + '</div>' : '')
    + '<div class="sign">'
    + '<div class="sg"><div class="ink">' + (d.signatureImg ? '<img src="' + esc(d.signatureImg) + '" alt="">' : '') + '</div>'
    + '<div class="ln">Buyer &mdash; ' + (d.company ? esc(d.company) : '&hellip;') + '<br>' + (d.signer ? '<b>' + esc(d.signer) + '</b>' : '&nbsp;') + '<br>Date</div></div>'
    + '<div class="sg"><div class="ink"></div>'
    + '<div class="ln">Seller &mdash; ' + (d.supplier ? esc(d.supplier) : '&hellip;') + '<br>Name<br>Date</div></div></div>'
    + '</div>'
    + '<div class="foot"><span>&#9679; &nbsp;' + (d.company ? esc(d.company) : '&hellip;') + '</span><span>Purchase Order' + (d.number ? ' &middot; No. ' + esc(d.number) : '') + '</span></div></div>';
}

module.exports = { esc, PO_CONTACT, poSheetCss, poSheetHtml, poMoney, poPrice, poQty, poIsSampleYardCoMetals };
