const PDFDocument = require('pdfkit');
// ── Template version ────────────────────────────────────────────────────────
// Per the owner 2026-08-20 ("nothing flags 'this ticket was built by older
// code'").
//
// A load's PDF is generated ONCE and stored as a file in Drive. Changing the
// layout here therefore does NOTHING to tickets that already exist — they
// keep serving whatever was written at the time. That is exactly how the
// scale-photo links appeared to be "not working": the code was deployed, but
// every existing invoice had been written before it.
//
// Bumping this constant marks every previously-generated ticket as stale, so
// the UI can say so and offer Regenerate, instead of the operator comparing
// two tickets and wondering which is wrong.
//
// BUMP THIS whenever a change alters what appears on a generated document —
// a new section, a moved field, changed number formatting. Do NOT bump for
// internal refactors that produce a byte-identical page; a false "out of
// date" badge is as useless as no badge.
//
// History:
//   1 — baseline (everything generated before 2026-08-20 is treated as v0)
const PDF_TEMPLATE_VERSION = 1;


// ── Shared visual language for both load PDFs ─────────────────────────────
// Redesigned per the owner ("visual redesign" + "restructure layout") — was
// plain stacked Helvetica text with no branding or table borders. Now: a
// letterhead, shaded field boxes, a properly bordered/zebra-striped item
// table, and a boxed summary — built by hand with rect/line primitives since
// the installed pdfkit (0.15.2) predates its built-in .table() API.
const NAVY       = '#1a3a5c';
const NAVY_LIGHT = '#eaf0f5';
const RULE       = '#d7dce1';
const ZEBRA      = '#f6f8fa';
const MUTED      = '#6b7280';
const INK        = '#1a1a1a';
const PAGE_L = 50, PAGE_R = 562, PAGE_TOP = 50, PAGE_BOTTOM = 700; // leaves room above the footer rule at y=722

// Guards a block of a KNOWN height against straddling a page boundary — for
// anything drawn as one rect() + several explicit-position text() calls
// (field boxes, summary boxes), where a page break landing mid-block used to
// draw a rect that just visually clips off the bottom of the page while the
// text() calls inside independently trigger pdfkit's own auto-pagination
// one at a time (each thinking IT'S the one that needs a new page), scattering
// a single box across 2-3 broken pages instead of moving the whole thing
// to a clean new page as one unit. drawItemTable and the weights-PDF item
// cards already had page-break handling; this is the same idea for the
// other two block-shaped drawers.
function ensureSpace(doc, height) {
    if (doc.y + height > PAGE_BOTTOM) doc.addPage();
}

// Money formatting, per the owner 2026-08-19 ("if its 0.60 it should be 0.60
// only not 0.6" and "if its 23,768.789 it should be rounded off like
// 23,768.79").
//
// Two DIFFERENT rules, because these are two different kinds of number:
//
//   rate(n)   — a per-unit price (e.g. $0.175/lb). Padded to a MINIMUM of
//               2 decimals but never rounded: 0.6 -> "0.60", but 0.175
//               stays "0.175". Rounding a rate to 2dp would change what
//               the seller is actually paid per pound.
//
//   amount(n) — a money TOTAL (e.g. $23,768.789). Rounded to EXACTLY 2
//               decimals and grouped with thousands separators, because
//               that's what a currency figure on an invoice is:
//               23768.789 -> "23,768.79".
//
// Conflating the two was the earlier mistake — a single formatter can't
// both preserve 0.175 and round 23,768.789.
function fmtRate(n) {
    if (n == null || n === '' || !isFinite(Number(n))) return null;
    const s = String(n);
    const decimals = s.includes('.') ? s.split('.')[1].length : 0;
    return decimals >= 2 ? s : Number(n).toFixed(2);
}
function fmtAmount(n) {
    if (n == null || n === '' || !isFinite(Number(n))) return null;
    return Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
// Kept so any caller still saying money() keeps working; rates are the
// stricter of the two, so this is the safe alias.
const money = fmtRate;

// The issuing party is not a variable on these documents — every load runs
// through Sample Yard Co Trading, so it's part of the letterhead rather than a field
// that could be left blank or typo'd per load. Per the owner 2026-08-12: this
// business's name/address engraved at the top of every document.
//
// Renamed SELLER -> SAMPLE_TRADING 2026-08-15: per the owner, Sample Yard Co Trading is
// actually the BUYER in these transactions (the counterparty supplies
// material TO Sample Yard Co Trading, not the other way round) — the old name was
// backwards and only ever caused confusion in this file's own comments. This
// constant was never exported, so the rename is contained entirely to this
// file; nothing outside pdf.js references it.
const SAMPLE_TRADING = {
    name: 'SAMPLE YARD CO TRADING',
    // ONE line as of 2026-08-22 per the owner ("sample yard co trading address make it in
    // one line"). Was address1/address2 on separate rows. Kept as a single
    // string rather than joining two fields at each draw site, so there is
    // one place to edit if the address ever changes and no chance of the
    // letterhead and the POS receipt disagreeing.
    address: '2453 E 25th Street, Los Angeles, CA 90058',
    phone: '(555) 010-0100',
    email: 'ops@sample.example',
};

function drawLetterhead(doc, subtitle, load) {
    doc.font('Helvetica-Bold').fontSize(20).fillColor(NAVY).text(SAMPLE_TRADING.name, PAGE_L, 44);

    // Address block sits directly under the name, tight leading so the four
    // lines read as one unit rather than a list.
    doc.font('Helvetica').fontSize(8.5).fillColor(MUTED);
    // Two lines total, not four. Address collapsed 2026-08-22, then phone and
    // email joined onto one line the same day ("similarly phone and mail in
    // same line"). Measured before committing to it: the pair renders 159pt
    // wide and so ends at x=209, while the right-aligned "Generated ..."
    // block starts at x=409 — 200pt of clearance, so the two can't collide
    // even with a longer timestamp.
    doc.text(SAMPLE_TRADING.address, PAGE_L, 70, { lineBreak: false });
    doc.text(`${SAMPLE_TRADING.phone}  ·  ${SAMPLE_TRADING.email}`, PAGE_L, 81, { lineBreak: false });

    // Document type + load id stay right-aligned, opposite the address, so
    // neither block has to compete for the same horizontal space.
    doc.font('Helvetica-Bold').fontSize(12).fillColor(NAVY).text(load.id, PAGE_L, 44, { width: PAGE_R - PAGE_L, align: 'right' });
    // Date+time, not just date, per the owner 2026-08-15 — reuses
    // formatCreatedAt (defined below) so "Generated" on the letterhead and
    // "Created:" in the field box render in the exact same style.
    doc.font('Helvetica').fontSize(8.5).fillColor(MUTED)
        .text(subtitle.toUpperCase(), PAGE_L, 62, { width: PAGE_R - PAGE_L, align: 'right', characterSpacing: 1.2 })
        .text(`Generated ${formatCreatedAt(new Date().toISOString())}`, PAGE_L, 76, { width: PAGE_R - PAGE_L, align: 'right' });

    // 100, down from 122 across two passes on 2026-08-22 as the letterhead
    // went from four lines to two. Still clears BOTH blocks: the left column
    // now ends at 81+~9=90, and the right-hand "Generated ..." line at
    // 76+~9=85.
    doc.moveTo(PAGE_L, 100).lineTo(PAGE_R, 100).lineWidth(1.5).strokeColor(NAVY).stroke();
    doc.lineWidth(1);
    doc.y = 114; // tracks the rule: 136 -> 125 -> 114 as each line was removed
}

// twoColFields render as "Label value" pairs, 2 per row, inside a shaded box.
// fullFields (optional — a single {label,value} OR an array of them) each
// get their own full-width row below the 2-col grid, stacked top to bottom —
// used for Description/Seller Address/Buyer Address, which can run long
// enough that squeezing them into a half column would wrap awkwardly. Each
// one's height is MEASURED with doc.heightOfString() (same font/size/width
// used to actually draw it) rather than assumed to be one line — a long
// value that wraps to 2-3 lines used to overflow past the box border and
// collide with whatever heading was drawn right after it, since the old
// fixed-height guess only ever reserved room for one line.
// Two-column fields WRAP within their column as of 2026-08-22.
//
// They used to be single-line: label with `continued: true`, then the value,
// with no width constraint. That was safe only while the two-col slots held
// short things (a date, a timestamp, a company name). Per the owner the same day
// — "i want seller name and address in same line, next to seller add address"
// and "description should not go next line, side by side" — Seller Address and
// Description moved OUT of the full-width block and INTO these columns, and
// both are long. A realistic address ("456 Scrap Avenue, Suite 12, Dallas, TX
// 75201") measures 185pt at 9pt, and its label another 63pt: 248pt against a
// 238pt column. It would have run straight off the edge of the box.
//
// So each field is measured at its own column width, every row takes the
// height of its taller side, and the box grows to fit. Nothing is clipped and
// nothing overlaps regardless of how long an address gets.
const FB_COL_X = [PAGE_L + 14, PAGE_L + 262];
const FB_COL_W = [
    (PAGE_L + 262) - (PAGE_L + 14) - 12,  // col 0, less a gutter so it can't touch col 1
    PAGE_R - 14 - (PAGE_L + 262),         // col 1, to the box's inner right edge
];

function drawFieldBox(doc, twoColFields, fullFields) {
    const fields = Array.isArray(fullFields) ? fullFields : (fullFields ? [fullFields] : []);

    // ── measure the two-col rows ──────────────────────────────────────────
    // `span: 2` gives a field the whole row instead of one column. Added for
    // Description 2026-08-22 ("description should be in one straight line"):
    // it was the only field on its row, so half the width was empty while the
    // text wrapped to three lines beside it. Full width fits even a
    // 100-character description on one line (408pt of 429pt available), which
    // is what she's after — and it costs no vertical space, because the row
    // was already there.
    //
    // Column assignment walks the list rather than using i%2, since a spanning
    // field consumes a whole row and would otherwise throw off the parity of
    // everything after it.
    let cursor = 0; // running column slot
    const m2 = twoColFields.map((f) => {
        const span = f.span === 2 ? 2 : 1;
        if (span === 2 && cursor % 2 === 1) cursor += 1; // a spanning field starts a fresh row
        const col = cursor % 2;
        const row = Math.floor(cursor / 2);
        cursor += span;
        doc.font('Helvetica-Bold').fontSize(9);
        const labelW = doc.widthOfString(f.label + ' ');
        doc.font('Helvetica').fontSize(9);
        // Floor of 60pt: a pathologically long label shouldn't squeeze the
        // value into a one-character-per-line ribbon.
        const cellW = span === 2 ? (PAGE_R - 14) - FB_COL_X[0] : FB_COL_W[col];
        const valueW = Math.max(60, cellW - labelW);
        const h = doc.heightOfString(String(f.value || '—'), { width: valueW });
        return { ...f, span, col, row, labelW, valueW, h: Math.max(12, h) };
    });
    const rowCount = Math.ceil(cursor / 2);
    const rowHeights = [];
    for (let r = 0; r < rowCount; r++) {
        const inRow = m2.filter((f) => f.row === r);
        const a = inRow.length ? Math.max(...inRow.map((f) => f.h)) : 12;
        const b = 0;
        // 2pt, down from 6, per the owner 2026-08-22 ("reduce spacing between
        // date, seller, description"). These rows are label+value pairs a
        // metre from someone's eyes on a printed ticket, not body copy that
        // needs leading — 2pt is enough to keep adjacent rows from touching
        // while the three read as one block instead of a spaced-out list.
        rowHeights.push(Math.max(a, b) + 2);
    }
    const twoColH = rowHeights.reduce((s, h) => s + h, 0);

    // ── measure any remaining full-width rows ─────────────────────────────
    doc.font('Helvetica').fontSize(9.5);
    let fullBlockH = 0;
    const measured = fields.map((f) => {
        const valH = doc.heightOfString(f.value || '—', { width: 484 });
        const h = 14 + valH + 4;
        fullBlockH += h;
        return { ...f, h };
    });

    // Top/bottom padding trimmed with the row spacing (12/4 -> 9/4): the box
    // shrinking around tighter rows keeps the proportion, whereas leaving the
    // old padding would just move the empty space to the edges.
    const boxH = 9 + twoColH + fullBlockH + 4;
    // Height is fully known BEFORE anything is drawn, so the page-break check
    // runs first and doc.y is only read AFTER it — boxTop is then guaranteed
    // to be the top of wherever this box actually lands, never split across
    // two pages.
    ensureSpace(doc, boxH);
    const boxTop = doc.y;

    doc.rect(PAGE_L, boxTop, PAGE_R - PAGE_L, boxH).fillAndStroke(NAVY_LIGHT, RULE);

    m2.forEach((f) => {
        const y = boxTop + 8 + rowHeights.slice(0, f.row).reduce((s, h) => s + h, 0);
        const x = FB_COL_X[f.col];
        doc.font('Helvetica-Bold').fontSize(9).fillColor(NAVY).text(f.label, x, y, { lineBreak: false });
        // Value drawn as its own positioned block rather than `continued`,
        // so its wrap width is exactly the column remainder and wrapped
        // lines align under the value instead of under the label.
        doc.font('Helvetica').fontSize(9).fillColor(INK)
            .text(String(f.value || '—'), x + f.labelW, y, { width: f.valueW });
    });

    let fy = boxTop + 6 + twoColH;
    measured.forEach((f) => {
        doc.font('Helvetica-Bold').fontSize(8).fillColor(NAVY).text(f.label, PAGE_L + 14, fy, { characterSpacing: 0.3 });
        doc.font('Helvetica').fontSize(9.5).fillColor(INK).text(f.value || '—', PAGE_L + 14, fy + 12, { width: 484 });
        fy += f.h;
    });
    // 6pt, down from 18, per the owner 2026-08-22 ("reduce spacing between item
    // detail and box above"). Deliberately NOT changed on the summary box
    // further down (drawSummaryBox's identical line) — she named this gap
    // specifically, and that box sits against a different neighbour.
    doc.y = boxTop + boxH + 6;
}


// Sums gross/tare/net/amount per ITEM DESCRIPTION (e.g. "Sealed units",
// "Auto cast") — per the owner, the item table lists every individual weigh-in
// but nothing rolled them up by type, so a load with a dozen "Auto cast"
// pulls had no single "here's the Auto cast total" line anywhere. Order
// preserved as first-seen (Map insertion order), not alphabetized — matches
// the order items were entered in, which is usually already grouped since
// yard staff tend to weigh the same item type back-to-back.
function round2(n) {
    return typeof n === 'number' && isFinite(n) ? Math.round(n * 100) / 100 : n;
}
// Groups on a NORMALIZED key (trimmed + lowercased), not the raw description
// text — per the owner 2026-08-16 ("Battery" showing as two separate lines,
// 4075 lb and 557 lb, instead of one combined 4632 lb line in the yard
// report). Root cause: one of the two was typed with a trailing space or
// different casing (e.g. "Battery " or "battery"), and the old exact-string
// key treated that as a wholly different item type. The DISPLAYED label
// still uses whichever original spelling/casing was typed FIRST (via
// `raw`, kept alongside the normalized key) — this only affects grouping,
// never rewrites the text stored on the load itself.
function groupItemsByDescription(items) {
    const groups = new Map();
    for (const it of items) {
        const raw = it.description ? String(it.description).trim() : 'Other';
        const key = raw.toLowerCase();
        if (!groups.has(key)) groups.set(key, { description: raw, count: 0, gross: 0, tare: 0, net: 0, amount: 0 });
        const g = groups.get(key);
        g.count += 1;
        g.gross  += it.gross_weight  || 0;
        g.tare   += it.tare_weight   || 0;
        g.net    += it.net_weight    || 0;
        g.amount += it.amount        || 0;
    }
    return Array.from(groups.values()).map(g => ({
        description: g.description, count: g.count,
        gross: round2(g.gross), tare: round2(g.tare), net: round2(g.net), amount: round2(g.amount),
    }));
}

// Bordered, zebra-striped item table — `columns` lets the two PDFs show
// different fields (the priced ticket shows price/unit/amount, the
// weights-only PDF doesn't) while sharing the exact same drawing code.
// `totalsRow` (optional) renders as one extra bold row at the very bottom —
// per the owner, the item table itself had no running total, only the separate
// Summary box further down the page; this puts a TOTAL line directly under
// the last item so it reads top-to-bottom without jumping around the page.
function drawItemTable(doc, items, columns, totalsRow) {
    // $ prefix on price/amount only — per the owner 2026-08-17 ("in pdf-price
    // and amount need to have $ symbol at the front"). Scoped to these two
    // column keys specifically so weight columns (gross/tare/net/count)
    // don't pick up a stray $ — those are shared across TICKET_COLUMNS,
    // GROUP_COLUMNS, and SELLER_COLUMNS, all of which use these same key
    // names for their price/amount fields, so this one change covers the
    // priced ticket's item table, the item-type summary table, AND the
    // by-seller table in the daily inventory PDF, with nothing to touch in
    // GROUP_COLUMNS_WEIGHTS (the weights-only PDF has no price/amount
    // columns at all, so it's unaffected).
    const fmt = (n, key, row) => {
        if (n == null) return '—';
        // A PRICE SAYS WHAT IT IS PER, when the row is priced by the tonne
        // (2026-09-24). Only on a real item row — the TOTAL row has no price
        // and no single unit to claim. Everything else is untouched, so a
        // pound row and every table that is not the ticket print exactly as
        // they did.
        if (key === 'price' && row && String(row.unit || '').trim().toLowerCase() === 'mt') {
            return `$${fmtRate(n)}/MT`;
        }
        return key === 'price' ? `$${fmtRate(n)}` : (key === 'amount' ? `$${fmtAmount(n)}` : String(n));
    };
    const tableW = PAGE_R - PAGE_L;
    const headerH = 24, rowH = 22;

    const drawHeaderRow = (top) => {
        doc.rect(PAGE_L, top, tableW, headerH).fill(NAVY);
        doc.font('Helvetica-Bold').fontSize(8).fillColor('#fff');
        columns.forEach(c => {
            doc.text(c.label.toUpperCase(), c.x + 6, top + 9, { width: c.width - 12, align: c.align, characterSpacing: 0.3 });
        });
    };

    // it=null marks the totals row — bold text, shaded background (instead
    // of alternating zebra), and drawn from `totalsRow` instead of an item.
    const drawDataRow = (it, y, opts) => {
        const isTotal = !it;
        const rowData = isTotal ? totalsRow : it;
        if (isTotal) doc.rect(PAGE_L, y, tableW, rowH).fill(NAVY_LIGHT);
        else if (opts.zebra) doc.rect(PAGE_L, y, tableW, rowH).fill(ZEBRA);
        doc.font(isTotal ? 'Helvetica-Bold' : 'Helvetica').fontSize(9).fillColor(isTotal ? NAVY : INK);
        columns.forEach(c => {
            const raw = c.key === 'description' ? (rowData.description || (isTotal ? '' : '—')) : fmt(rowData[c.key], c.key, isTotal ? null : rowData);
            // ellipsis:true does nothing on its own in this pdfkit version
            // (0.15.2) — confirmed by testing directly against the installed
            // package, NOT assumed from docs. It only truncates when a HEIGHT
            // is also given (one line's worth here); without it, a long
            // description just word-wrapped onto extra lines and visually
            // overlapped the row below it, since row height was fixed.
            doc.text(raw, c.x + 6, y + 6, { width: c.width - 12, height: 10, align: c.align, ellipsis: true });
        });
        doc.moveTo(PAGE_L, y + rowH).lineTo(PAGE_R, y + rowH).lineWidth(isTotal ? 1 : 0.5).strokeColor(isTotal ? NAVY : RULE).stroke();
    };

    // Tracked PER PAGE SEGMENT, not just once at the top — a table long
    // enough to span pages used to draw its outer border as ONE rect from
    // the page-1 header down to wherever the last row landed on page 2,
    // mixing y-coordinates from two different pages (each page has its own
    // y origin) into one nonsense box. Each page's slice of the table now
    // gets its own border AND its own repeated navy header row, closed off
    // right before addPage() rather than only once at the very end.
    let segTop = doc.y;
    drawHeaderRow(segTop);
    let y = segTop + headerH;

    items.forEach((it, i) => {
        if (y + rowH > PAGE_BOTTOM) {
            doc.lineWidth(1).rect(PAGE_L, segTop, tableW, y - segTop).strokeColor(RULE).stroke();
            doc.addPage();
            segTop = PAGE_TOP;
            drawHeaderRow(segTop);
            y = segTop + headerH;
        }
        drawDataRow(it, y, { zebra: i % 2 === 1 });
        y += rowH;
    });

    if (totalsRow) {
        // Keep the TOTAL row on the same page as the header it belongs
        // under if at all possible — pushing just that one row alone is
        // more disruptive to read than moving the whole last page's worth.
        if (y + rowH > PAGE_BOTTOM) {
            doc.lineWidth(1).rect(PAGE_L, segTop, tableW, y - segTop).strokeColor(RULE).stroke();
            doc.addPage();
            segTop = PAGE_TOP;
            drawHeaderRow(segTop);
            y = segTop + headerH;
        }
        drawDataRow(null, y, {});
        y += rowH;
    }

    doc.lineWidth(1).rect(PAGE_L, segTop, tableW, y - segTop).strokeColor(RULE).stroke();
    doc.y = y + 18;
}

// Right-aligned shaded box of totals — `emphasize` rows (net/amount) render
// larger and in navy so the number that matters most doesn't get lost among
// the rest.
// Returns { top, height } so a caller can put something in the EMPTY COLUMN
// to the left of it — see the signature block, and the owner's question below.
function drawSummaryBox(doc, rows, opts) {
    const boxW = 230;
    const boxX = PAGE_R - boxW;
    const rowH = 19;
    const boxH = rows.length * rowH + 20;
    // `reserve` is the height of whatever will be drawn BESIDE this box, and
    // it is taken as a MAX rather than added: the two sit in adjacent columns,
    // so the space the pair needs is the taller of them, not their sum.
    //
    // Adding them was my first attempt and it made the bug worse — the box
    // and the signature moved to page 2 together, which is one page-break
    // earlier than before rather than none at all.
    ensureSpace(doc, Math.max(boxH, (opts && opts.reserve) || 0));
    const boxTop = doc.y;

    doc.rect(boxX, boxTop, boxW, boxH).fillAndStroke(NAVY_LIGHT, RULE);
    rows.forEach((r, i) => {
        const y = boxTop + 12 + i * rowH;
        const size = r.emphasize ? 11 : 9.5;
        const color = r.emphasize ? NAVY : INK;
        doc.font(r.emphasize ? 'Helvetica-Bold' : 'Helvetica').fontSize(size).fillColor(color).text(r.label, boxX + 14, y, { width: 110 });
        doc.font(r.emphasize ? 'Helvetica-Bold' : 'Helvetica').fontSize(size).fillColor(color).text(r.value, boxX + 14, y, { width: boxW - 28, align: 'right' });
    });
    doc.y = boxTop + boxH + 18;
    return { top: boxTop, height: boxH, left: PAGE_L, width: boxX - PAGE_L - 20 };
}

// ── Seller signature block ───────────────────────────────────────────────
// Per the owner 2026-08-17 ("post pdf generation, there should be an option
// called sign... it should open a whiteboard where it allows the user to
// sign. this should get reflected in yard invoice above Seller signature").
// So: a ruled signature line labelled "<party> signature", with the captured
// signature drawn IN THE SPACE ABOVE that line — i.e. exactly where a
// person would sign on paper.
// load.seller_signature is a data URL (image/png, transparent background)
// produced by the mobile app's signature pad. When it's absent the block
// still prints, just empty — the ticket then works as a paper form someone
// can sign by hand, which is strictly better than the block vanishing and
// the document silently changing shape depending on signed/unsigned.
// ── AND WHY IT IS NOT ON A PAGE OF ITS OWN ─────────────────────────────────
// the owner, 2026-09-16, with SAMPLE_66.pdf attached: "why sign only is in next
// page?why cant it be on left side of summary?"
//
// Because it was drawn in the flow, after the Summary box, and the Summary box
// is only 230pt wide and pinned to the RIGHT margin. So the page ended with a
// box on the right, half a page of white space to its left, and 82pt of
// signature block that no longer fitted underneath — pushing it, alone, onto
// page two. The document looked finished and then had an orphan.
//
// `at` places the block in that empty left column instead, level with the
// Summary box. Passed by the caller rather than worked out here, because this
// function is also used by documents with no summary box at all, where the
// ordinary flow position is right.
//
// SIG_BLOCK_H is exported as a constant so the caller can RESERVE the space
// before drawing the box: the box fitting is not the same question as the box
// and the signature both fitting, and conflating the two is how the orphan
// happened in the first place.
const SIG_AREA_H = 46;                      // drawing space above the rule
const SIG_BLOCK_H = SIG_AREA_H + 26 + 10;   // + label, timestamp and top gap

function drawSignatureBlock(doc, load, opts) {
    // "Buyer signature" on a sale — the person signing is whoever received
    // the material, and on a sale that is the buyer.
    const partyWord = (opts && opts.kind === 'sale') ? 'Buyer' : 'Seller';
    const BLOCK_H = SIG_AREA_H + 26;
    const at = opts && opts.at;
    if (!at) ensureSpace(doc, BLOCK_H + 10);
    const top = at ? at.top : doc.y + 10;
    const lineY = top + SIG_AREA_H;
    const lineW = 230;

    if (load.seller_signature) {
        try {
            // Data URL -> Buffer. pdfkit accepts a Buffer directly; passing
            // the data URL string would be treated as a file path and throw.
            const b64 = String(load.seller_signature).replace(/^data:image\/\w+;base64,/, '');
            const buf = Buffer.from(b64, 'base64');
            // fit (not scale) keeps the aspect ratio inside the box and
            // never overflows the rule below it, whatever the pad's
            // canvas dimensions were.
            doc.image(buf, PAGE_L, top, { fit: [lineW, SIG_AREA_H - 4], align: 'left', valign: 'bottom' });
        } catch (err) {
            // A corrupt/oversized signature must never take down the whole
            // ticket — the line still prints, just unsigned.
            console.error('[pdf] could not render seller signature:', err.message);
        }
    }

    doc.moveTo(PAGE_L, lineY).lineTo(PAGE_L + lineW, lineY).lineWidth(0.75).strokeColor(INK).stroke();
    doc.font('Helvetica').fontSize(8.5).fillColor(MUTED)
        .text(`${partyWord} signature`, PAGE_L, lineY + 5, { width: lineW, lineBreak: false });
    if (load.seller_signed_at) {
        const when = new Date(load.seller_signed_at).toLocaleString('en-US', { timeZone: 'America/Los_Angeles' });
        doc.font('Helvetica').fontSize(7.5).fillColor(MUTED)
            .text(`Signed ${when} (LA time)`, PAGE_L, lineY + 16, { width: 260, lineBreak: false });
    }
    // When placed beside the Summary box, the flow position belongs to the
    // BOX, not to this block — moving doc.y here would push whatever comes
    // next down by the height of a column that sits alongside, leaving a gap
    // the width of the page.
    if (!at) doc.y = lineY + 30;
}

function drawSectionHeading(doc, text) {
    // Small fixed guard (heading + a little breathing room) so a heading
    // never ends up as the last line on a page with its actual content
    // pushed to the next one.
    ensureSpace(doc, 30);
    doc.font('Helvetica-Bold').fontSize(11).fillColor(NAVY).text(text, PAGE_L, doc.y);
    doc.moveDown(0.4);
}

// Stamps every buffered page with a footer rule + "Load <id>" / "Page N of M"
// — requires the doc to have been created with { bufferPages: true }.
// IMPORTANT: the default 50pt margin means the page's writable area ends at
// y=742 (792 page height - 50 bottom margin) — a .text() call placed AT OR
// PAST that y triggers pdfkit's automatic "this needs a new page" logic,
// even though we're placing it with an explicit x/y (that check isn't
// skipped just because the position is explicit). That's exactly what
// happened at y=754 here: every footer stamp silently spawned a new,
// near-blank page (2 extra pages per document). Kept comfortably above 742.
function addFooters(doc, load) {
    const range = doc.bufferedPageRange();
    for (let i = range.start; i < range.start + range.count; i++) {
        doc.switchToPage(i);
        doc.moveTo(PAGE_L, 722).lineTo(PAGE_R, 722).lineWidth(0.5).strokeColor(RULE).stroke();
        doc.font('Helvetica').fontSize(7.5).fillColor(MUTED)
            .text(`${SAMPLE_TRADING.name.replace(/\b(\w)(\w*)/g, (m, a, b) => a + b.toLowerCase())} — Load ${load.id}`, PAGE_L, 729, { width: 250, lineBreak: false })
            .text(`Page ${i - range.start + 1} of ${range.count}`, PAGE_L, 729, { width: PAGE_R - PAGE_L, align: 'right', lineBreak: false });
    }
}

// load.created_at is an ISO timestamp stamped once, server-side, the moment
// the load record was first saved (helpers/loads.js's addLoad) — distinct
// from load.date, which staff enter by hand on the form and can backdate.
// Per the owner 2026-08-15: show the real creation time on the document as an
// audit fact, separate from the (possibly backdated) Date field.
function formatCreatedAt(iso) {
    if (!iso) return '—';
    const d = new Date(iso);
    if (isNaN(d.getTime())) return '—';
    // Explicit timeZone per the owner 2026-08-15 ("i want this time in...los
    // angeles local time") — without it, toLocaleString renders in whatever
    // timezone the SERVER PROCESS happens to be running in (confirmed this
    // sandbox is Asia/Calcutta; the production VM is whatever it's set to,
    // almost certainly not Pacific), not the business's own timezone. Sample
    // Trading's letterhead address is Los Angeles, so both this field
    // ("Created:") and drawLetterhead's "Generated" line (which calls this
    // same function) need to read correctly for someone in LA regardless of
    // what timezone the server itself happens to be in.
    return d.toLocaleString('en-US', {
        month: 'short', day: 'numeric', year: 'numeric',
        hour: 'numeric', minute: '2-digit',
        timeZone: 'America/Los_Angeles', timeZoneName: 'short',
    });
}

// Unit column removed per the owner (the per-item Unit field is gone from the
// dashboard entirely — see renderItemRows in dashboard/index.html). Its 40pt
// went to Gross/Tare/Net/Amount rather than Price, matching the same
// "shrink description, grow the weight/amount columns" request applied to
// the on-screen item rows.
const TICKET_COLUMNS = [
    { key: 'description',  label: 'Description', x: 50,  width: 140, align: 'left'  },
    { key: 'gross_weight', label: 'Gross',        x: 190, width: 68,  align: 'right' },
    { key: 'tare_weight',  label: 'Tare',         x: 258, width: 68,  align: 'right' },
    { key: 'net_weight',   label: 'Net',          x: 326, width: 68,  align: 'right' },
    { key: 'price',        label: 'Price',        x: 394, width: 58,  align: 'right' },
    { key: 'amount',       label: 'Amount',       x: 452, width: 110, align: 'right' },
];

// ── THE SAME TABLE, PLUS THE TONNAGE THE PRICE MULTIPLIES ─────────────────
//
// the owner, 2026-09-24: "if price is in /mt while net in lbs in pdf,it should
// should show net in pdf".
//
// A row priced per tonne prints its Net in pounds, because pounds are what
// the weighbridge said and what the seller watched. But then the Price column
// says $800.00/MT and there is no number on the page that gets him from one
// to the other. He cannot check his own ticket.
//
// ONLY USED WHEN THE LOAD ACTUALLY HAS AN MT ROW. A load priced entirely by
// the pound gets TICKET_COLUMNS above, unchanged to the point — same widths,
// same x positions, same six headings. That is deliberate and it is the rule
// in CLAUDE.md: the flag selects the NEW shape, never the old one, so a
// ticket that has always printed one way cannot start printing another way
// because someone forgot to set something.
//
// The 512pt of table is re-divided rather than widened — the page has no more
// room. Description gives up the most because it is the one column whose
// content is a name rather than a figure, and it still holds "Sealed units"
// at font 9.
const TICKET_COLUMNS_MT = [
    { key: 'description',  label: 'Description', x: 50,  width: 104, align: 'left'  },
    { key: 'gross_weight', label: 'Gross',        x: 154, width: 64,  align: 'right' },
    { key: 'tare_weight',  label: 'Tare',         x: 218, width: 64,  align: 'right' },
    { key: 'net_weight',   label: 'Net',          x: 282, width: 64,  align: 'right' },
    { key: 'net_mt',       label: 'Net MT',       x: 346, width: 68,  align: 'right' },
    { key: 'price',        label: 'Price',        x: 414, width: 66,  align: 'right' },
    { key: 'amount',       label: 'Amount',       x: 480, width: 82,  align: 'right' },
];

// True when at least one item on this load is priced by the tonne.
function loadHasMtRow(items) {
    return (Array.isArray(items) ? items : [])
        .some((it) => it && String(it.unit || '').trim().toLowerCase() === 'mt');
}

// net_mt is computed for PRINTING only and is never stored — the ledger keeps
// pounds, as it always has. Blank on a per-pound row, because a tonnage next
// to a per-pound rate is a number with nothing to do, and a column of those
// would invite exactly the mis-multiplication this is meant to prevent.
//
// 3 decimals, matching helpers/invoicePdf.js:704, which is how every tonne
// figure on her outgoing paperwork is already printed.
function withNetMt(items) {
    return (Array.isArray(items) ? items : []).map((it) => {
        const perMt = it && String(it.unit || '').trim().toLowerCase() === 'mt';
        const net = it && typeof it.net_weight === 'number' && isFinite(it.net_weight) ? it.net_weight : null;
        // A STRING, not a Number. Number('23.100') is 23.1, and String(23.1)
        // is "23.1" — so OUT_07 printed a tonnage at one decimal place while
        // 13.608 on the next ticket printed at three. Inconsistent precision
        // on a column of weights on a customer document reads as carelessness
        // at best and as a different measurement at worst. Fixed at 3, which
        // is what helpers/invoicePdf.js:704 has always done.
        return { ...it, net_mt: (perMt && net != null) ? (net / 2204.62).toFixed(3) : null };
    });
}

// "Summary by Item Type" table columns — priced version (ticket) includes
// Amount, the weights-only PDF's version below doesn't.
const GROUP_COLUMNS = [
    { key: 'description', label: 'Item Type', x: 50,  width: 180, align: 'left'  },
    { key: 'count',       label: 'Items',     x: 230, width: 50,  align: 'right' },
    { key: 'gross',       label: 'Gross',     x: 280, width: 70,  align: 'right' },
    { key: 'tare',        label: 'Tare',      x: 350, width: 70,  align: 'right' },
    { key: 'net',         label: 'Net',       x: 420, width: 70,  align: 'right' },
    { key: 'amount',      label: 'Amount',    x: 490, width: 72,  align: 'right' },
];
// Same shape as GROUP_COLUMNS, relabeled for the daily inventory report's
// "By seller" table (generateInventoryReportPdf below) — same drawItemTable
// renderer, just a different first-column header.
const SELLER_COLUMNS = [
    { key: 'description', label: 'Seller',   x: 50,  width: 180, align: 'left'  },
    { key: 'count',       label: 'Loads',    x: 230, width: 50,  align: 'right' },
    { key: 'gross',       label: 'Gross',    x: 280, width: 70,  align: 'right' },
    { key: 'tare',        label: 'Tare',     x: 350, width: 70,  align: 'right' },
    { key: 'net',         label: 'Net',      x: 420, width: 70,  align: 'right' },
    { key: 'amount',      label: 'Amount',   x: 490, width: 72,  align: 'right' },
];
const GROUP_COLUMNS_WEIGHTS = [
    { key: 'description', label: 'Item Type', x: 50,  width: 220, align: 'left'  },
    { key: 'count',       label: 'Items',     x: 270, width: 60,  align: 'right' },
    { key: 'gross',       label: 'Gross',     x: 330, width: 78,  align: 'right' },
    { key: 'tare',        label: 'Tare',      x: 408, width: 78,  align: 'right' },
    { key: 'net',         label: 'Net',       x: 486, width: 76,  align: 'right' },
];

function generateLoadPdf(load, opts = {}) {
    // Per the owner 2026-08-15: instead of the document silently deciding
    // whether to print the Summary section, the dashboard now asks before
    // generating. Default stays TRUE (old behavior) for any caller that
    // doesn't pass opts at all — e.g. scheduler.js's end-of-day yard report,
    // which runs unattended with nobody to ask.
    const includeSummary = opts.includeSummary !== false;
    return new Promise((resolve, reject) => {
        try {
            const doc = new PDFDocument({ size: 'LETTER', margin: 50, bufferPages: true });
            const chunks = [];
            doc.on('data', (c) => chunks.push(c));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);

            // Reduced to exactly what the owner asked for: date, created time,
            // seller, seller address, description. Sample Yard Co Trading's own info
            // lives in the letterhead; Created by / Status dropped — both are
            // internal workflow state, not part of the document the
            // counterparty receives.
            //
            // load.seller/load.seller_address hold the counterparty (the
            // company Sample Yard Co Trading is buying scrap FROM) — per the owner
            // 2026-08-15 ("no. buyer should be sample yard co trading"), correcting an
            // earlier backwards mapping where this data lived under
            // load.buyer and just got RELABELED "Seller:" on the printed
            // page. Field names and printed labels now agree, so no
            // relabeling trick is needed here anymore. Order matters:
            // drawFieldBox lays two-col fields out left-to-right, top-to-
            // bottom (index 0/1 = row 1, index 2 = row 2 col 1) — so [Date,
            // Created, Seller] puts Created directly beside Date on row 1,
            // and Seller directly beneath Date on row 2, per the owner
            // 2026-08-15's earlier layout request.
            // A SALE ticket names the buyer, not a seller — the owner 2026-08-24
            // ("what if i want to have ticket actions" on a sale). Sample
            // Trading is the seller on that document and already sits in the
            // letterhead, so the one variable party is whoever we traded with.
            // opts.kind is 'sale' | 'purchase'; anything else reads as a
            // purchase, which is what every existing caller passes.
            const isSale = opts && opts.kind === 'sale';
            drawLetterhead(doc, isSale ? 'Sale Ticket' : 'Load Ticket', load);
            drawFieldBox(doc, [
                { label: 'Date:',    value: load.date },
                { label: 'Created:', value: formatCreatedAt(load.created_at) },
                { label: isSale ? 'Buyer:' : 'Seller:',  value: load.seller },
                // Address beside Seller, and Description no longer alone on a
                // full-width line — per the owner 2026-08-22. Order gives:
                //   row 1  Date        | Created
                //   row 2  Seller      | Address
                //   row 3  Description |
                { label: 'Address:',     value: load.seller_address },
                // Full row: only field on its line, and full width keeps it
                // to one line instead of wrapping in a half-width column.
                // Only drawn when there IS one. The load-level description box was
                // removed from the form on 2026-08-28, and drawFieldBox does not skip
                // empty values — without this guard every new ticket would carry a bare
                // "Description:" label with nothing after it. Loads saved before that
                // change still have the field and still print it.
                ...(load.description ? [{ label: 'Description:', value: load.description, span: 2 }] : []),
            ], []);

            const unit = load.weight_unit || 'lb';
            const items = Array.isArray(load.items) ? load.items : [];
            if (items.length) {
                drawSectionHeading(doc, 'Item Detail');
                // TOTAL row uses the load-level sums already computed
                // server-side (helpers/loads.js's sumItems) rather than
                // re-adding the items here, so it's always consistent with
                // whatever the Summary box further down shows.
                // The Net MT column appears only on a load that has a
                // tonne-priced row — see TICKET_COLUMNS_MT. The TOTAL row
                // carries no net_mt on purpose: on a mixed load, summing the
                // tonnage of the MT rows and leaving out the pound rows gives
                // a figure that is not the load's weight and not what anyone
                // is paid on. A dash says that plainly; a number would not.
                const mtLoad = loadHasMtRow(items);
                drawItemTable(doc, mtLoad ? withNetMt(items) : items,
                    mtLoad ? TICKET_COLUMNS_MT : TICKET_COLUMNS, {
                        description: 'TOTAL',
                        gross_weight: load.gross_weight, tare_weight: load.tare_weight,
                        net_weight: load.net_weight, amount: load.amount,
                    });
            }

            // Rolled up by item TYPE (e.g. every "Sealed units" weigh-in
            // combined into one line) — sits between the raw item table and
            // the grand totals so a load with many pulls of the same item
            // doesn't require manually adding up scattered rows to see "how
            // much Auto cast did we actually move today."
            // Only worth printing when grouping actually COLLAPSES something.
            // Per the owner 2026-08-12: with a single item, or with every item a
            // different type, this table is a line-for-line restatement of
            // Item Detail directly above it — pure noise on the page. It
            // earns its place only when at least one item type appears more
            // than once, which is exactly when groups.length < items.length.
            // Whole Summary section (grouped table + totals box) is now
            // opt-in per document, per the owner 2026-08-15 — previously this
            // decided automatically off item count; now the dashboard asks
            // before generating and includeSummary carries that answer here.
            let summaryBox = null;
            let signaturePlaced = false;
            if (includeSummary) {
                const groups = items.length ? groupItemsByDescription(items) : [];
                if (groups.length && groups.length < items.length) {
                    drawSectionHeading(doc, 'Summary by Item Type');
                    drawItemTable(doc, groups, GROUP_COLUMNS);
                }

                drawSectionHeading(doc, 'Summary');
                // ── THE SIGNATURE GOES BESIDE THIS BOX ───────────────────
                // the owner, 2026-09-16: "why sign only is in next page?why cant
                // it be on left side of summary?" — see drawSignatureBlock.
                //
                // The space is reserved BEFORE the box is drawn, so the two
                // cannot be split across a page break. Reserving only the box
                // is what put an orphan signature on page 2 of SAMPLE_66.
                const wantsSig = !isSale && includeSummary;
                // ── THE DEDUCTION, ON THE DOCUMENT HE SIGNS ──────────────
                // the owner, 2026-09-20: when she collects the metal herself she
                // pays the seller less by the haulage. He is signing this
                // page, so the two lines that turn "Amount total" into what
                // he is actually handed have to be ON it — a ticket saying
                // $2,459 against $2,259 in his hand is an argument at the
                // gate, and she is the one standing there.
                //
                // ONLY WHEN THERE IS ONE. `trucking` is falsy on every load
                // that has no deduction, so those tickets print exactly the
                // four rows they have always printed — same height, same
                // reserved signature geometry, same one-page fit. A "Trucking
                // $0.00" line on every ticket in the book would be a change
                // to a document nobody asked to change.
                //
                // Sale tickets are excluded outright: a buyer's copy has no
                // business carrying what she paid a hauler on the way in.
                const trucking = !isSale ? Number(load.trucking_amount) || 0 : 0;
                // ── A CLAIM SHE ADJUSTED IN, ON HIS TICKET ──────────────
                // the owner, 2026-10-01, asked whether a claim should appear on
                // the seller's printed ticket: "Yes, as its own line saying
                // Claim".
                //
                // He signs this. A ticket that quietly shows $4,400 on a
                // $5,000 load is an argument in the yard next week, and the
                // one person who cannot look it up is the man holding the
                // pen. Trucking already earned its own line for the same
                // reason (2026-09-16, "Show the deduction on the ticket the
                // seller signs"); this is that decision applied to the other
                // deduction.
                //
                // Sale tickets excluded with trucking, for the same reason: a
                // buyer's copy carries nothing about what we claimed off a
                // supplier.
                const claim = !isSale ? Number(load.claim_amount) || 0 : 0;
                const deducted = trucking + claim;
                const netPayable = deducted > 0 && load.amount != null
                    ? Math.round((load.amount - deducted) * 100) / 100 : null;
                summaryBox = drawSummaryBox(doc, [
                    { label: 'Gross total',  value: load.gross_weight != null ? `${load.gross_weight} ${unit}` : '—' },
                    { label: 'Tare total',   value: load.tare_weight  != null ? `${load.tare_weight} ${unit}`  : '—' },
                    { label: 'Net total',    value: load.net_weight   != null ? `${load.net_weight} ${unit}`   : '—', emphasize: true },
                    // Still "Amount total", still the metal's figure, still
                    // emphasised when it is the last line. De-emphasised only
                    // when a Net payable follows it, so the bottom row of the
                    // box is always the number that matters most.
                    { label: 'Amount total', value: load.amount       != null ? `$${fmtAmount(load.amount)}`        : '—', emphasize: netPayable === null },
                    ...(netPayable !== null ? [
                        // LABEL STAYS SHORT, and this is not cosmetic. The
                        // label column in drawSummaryBox is 110pt wide against
                        // a FIXED 19pt row height — roughly 22 characters at
                        // 9.5pt Helvetica. "Less trucking — Bay Area Hauling"
                        // wraps to two lines inside a row that cannot grow and
                        // lands on top of the Net payable beneath it. The
                        // hauler's name is on the load record and on the
                        // trucker bill; the seller needs the deduction, not
                        // the name of the company that earned it.
                        // Each deduction only when there IS one, so a load
                        // with trucking and no claim prints exactly the three
                        // rows it printed before this existed.
                        ...(trucking > 0 ? [{ label: 'Less trucking', value: `-$${fmtAmount(trucking)}` }] : []),
                        // Label kept short for the same hard reason as
                        // 'Less trucking' above: 110pt of label column
                        // against a fixed 19pt row. "Less claim" fits; the
                        // reason for the claim does not, and lands on top of
                        // the Net payable underneath. The reason lives on the
                        // claim record, which is where she argues it from.
                        ...(claim > 0 ? [{ label: 'Less claim', value: `-$${fmtAmount(claim)}` }] : []),
                        { label: 'Net payable', value: `$${fmtAmount(netPayable)}`, emphasize: true },
                    ] : []),
                ], { reserve: wantsSig ? SIG_BLOCK_H : 0 });
                if (wantsSig) {
                    drawSignatureBlock(doc, load, { ...(opts || {}), at: summaryBox });
                    signaturePlaced = true;
                }
            }

            // The "Captured Scale Photos" list that used to be appended here
            // was removed 2026-08-12 per the owner: weight evidence belongs on
            // the separate weights PDF only, so the ticket ends on the
            // Summary rather than trailing a page of photo links. The weights
            // PDF still carries each item's gross/tare photo links inline on
            // its per-item cards, so nothing is lost — it just isn't
            // duplicated on the document the buyer receives.

            // Scale photo links — per the owner 2026-08-19 ("i want weight
            // photo link in generated invoice pdf").
            //
            // This partially reverses the 2026-08-12 decision to keep weight
            // evidence on the separate weights PDF only. The difference is
            // what's being added: that removal was of a full page of photo
            // links appended to the ticket, whereas this is a compact list
            // of clickable links, so the ticket still ends on the Summary
            // and signature rather than trailing off into evidence.
            // The weights PDF is unchanged and still carries the same links
            // inline on its per-item cards — this doesn't replace it, it
            // just means the invoice alone is enough to reach the photos.
            //
            // Skipped entirely when no photos were captured, so a load
            // weighed without photos doesn't get an empty heading.
            const photoItems = items
                .map((it, i) => ({ it, i }))
                .filter(({ it }) => it.gross_photo_link || it.tare_photo_link);
            // Diagnostic, added 2026-08-20: the owner reported photos present in
            // Drive and on the weights PDF but absent from the invoice, on
            // confirmed-latest code. This section is unconditional, so the
            // only way it can be skipped is an empty photoItems — i.e. the
            // LOAD RECORD carries no *_photo_link, whatever exists in Drive.
            // Printing the per-item link state turns that from a guess into
            // a fact visible in pm2 logs on the very next PDF generated.
            console.log(`[pdf] ${load.id} scale-photo links: ${items.length ? items.map((it, i) => `${i + 1}:${it.gross_photo_link ? 'G' : '-'}${it.tare_photo_link ? 'T' : '-'}`).join(' ') : '(no items)'} -> ${photoItems.length} item(s) with photos`);
            if (photoItems.length) {
                drawSectionHeading(doc, 'Scale Photos');
                doc.font('Helvetica').fontSize(8.5).fillColor(MUTED)
                    .text('Tap a link to open the scale photo backing each weight.', PAGE_L, doc.y);
                doc.moveDown(0.5);
                for (const { it, i } of photoItems) {
                    // Guard each row against straddling a page break — the
                    // label and its links must not end up on separate pages.
                    ensureSpace(doc, 28);
                    const y = doc.y;
                    doc.font('Helvetica-Bold').fontSize(9).fillColor(INK)
                        .text(`${i + 1}. ${it.description || 'Item ' + (i + 1)}`, PAGE_L, y, { width: 200, lineBreak: false });
                    // Links are placed at explicit x positions on the same
                    // line rather than flowed, so a long description can't
                    // push them onto the next line and split the row.
                    let lx = PAGE_L + 210;
                    if (it.gross_photo_link) {
                        doc.font('Helvetica').fontSize(9).fillColor('#1a5fb4')
                            .text('Gross photo', lx, y, { link: it.gross_photo_link, underline: true, width: 90, lineBreak: false });
                        lx += 100;
                    }
                    if (it.tare_photo_link) {
                        doc.font('Helvetica').fontSize(9).fillColor('#1a5fb4')
                            .text('Tare photo', lx, y, { link: it.tare_photo_link, underline: true, width: 90, lineBreak: false });
                    }
                    doc.y = y + 15;
                }
                doc.moveDown(0.6);
            }

            // Payment status, per the owner 2026-08-28 ("on generating invoice,
            // this should get reflected"). Drawn ABOVE the signature, because
            // the balance is one of the numbers being attested to.
            //
            // Only appears when a payment actually exists. A ticket for an
            // unpaid load is the ordinary case and does not need a row of
            // zeros announcing it; a "PAID 0.00" line on every document is
            // noise that makes the real ones easier to miss.
            //
            // The figures come from the CALLER (opts.payment), not from a
            // lookup in here: helpers/payments.js owns that arithmetic, and a
            // second implementation living in the PDF layer is how a ticket
            // ends up disagreeing with the screen it was generated from.
            const pay = opts && opts.payment;
            if (pay && Array.isArray(pay.payments) && pay.payments.length) {
                ensureSpace(doc, 90);
                drawSectionHeading(doc, 'Payment');
                const money = (n) => (n == null ? '—' : Number(n).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
                doc.font('Helvetica').fontSize(9).fillColor('#333');
                pay.payments.forEach((p) => {
                    const bits = [p.paid_on, p.mode, money(p.amount)];
                    if (p.reference) bits.push(`ref ${p.reference}`);
                    doc.text(bits.join('   ·   '), { continued: false });
                });
                doc.moveDown(0.3);
                const label = pay.status === 'paid' ? 'PAID IN FULL'
                    : pay.status === 'partial' ? 'PART PAID'
                    : pay.status === 'overpaid' ? 'OVERPAID'
                    : 'PAID';
                doc.font('Helvetica-Bold').fontSize(10).fillColor('#111')
                    .text(`${label}   Paid ${money(pay.paid)}` + (pay.total != null ? ` of ${money(pay.total)}` : ''));
                if (pay.status === 'partial') {
                    doc.font('Helvetica-Bold').fontSize(10).fillColor('#8a3b1e')
                        .text(`Balance due ${money(pay.pending)}`);
                } else if (pay.status === 'overpaid') {
                    doc.font('Helvetica-Bold').fontSize(10).fillColor('#8a3b1e')
                        .text(`Overpaid by ${money(pay.over)}`);
                }
                doc.fillColor('#000').moveDown(0.8);
            }

            // Signature block, per the owner 2026-08-17 — at the end of the
            // document, under the numbers it's attesting to.
            //
            // Already drawn BESIDE the Summary box when there is one (2026-09-16,
            // "why cant it be on left side of summary?"). This is the fallback
            // for a ticket generated WITHOUT the summary section, where there is
            // no box to sit next to and the flow position is right.
            //
            // Sales carry no signature line — the owner 2026-08-24, "no sign
            // needed". A ruled line nobody will ever sign is worse than no
            // line: it reads as an unfinished document.
            if (!isSale && !signaturePlaced) drawSignatureBlock(doc, load, opts);

            addFooters(doc, load);
            doc.end();
        } catch (err) {
            reject(err);
        }
    });
}

// ── Separate, smaller PDF: just gross/tare weights + their photo links ───────
// Generated alongside the main priced ticket (same /generate-pdf action in
// api.js) but uploaded as its own file, weights_<load id>.pdf, per the owner —
// some downstream use (handing proof-of-weight to the scale operator, a
// quick audit) doesn't need the priced item table, just the weights and the
// photos backing them up. Shares the same letterhead/field-box/summary-box
// styling as the main ticket for a consistent look across both documents.
function generateWeightsPdf(load, opts = {}) {
    const includeSummary = opts.includeSummary !== false;
    return new Promise((resolve, reject) => {
        try {
            const doc = new PDFDocument({ size: 'LETTER', margin: 50, bufferPages: true });
            const chunks = [];
            doc.on('data', (c) => chunks.push(c));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);

            // Same field reduction as the main ticket — Sample Yard Co Trading's own
            // info lives in the letterhead now, so repeating it here would be
            // redundant. Labels/Created field match generateLoadPdf — see
            // its comments for where load.seller/Created: come from.
            // Same [Date, Created, Seller] ordering as generateLoadPdf — see
            // its comment for why that puts Created beside Date and Seller
            // beneath Date.
            drawLetterhead(doc, 'Weight Record', load);
            drawFieldBox(doc, [
                { label: 'Date:',    value: load.date },
                { label: 'Created:', value: formatCreatedAt(load.created_at) },
                { label: (opts && opts.kind === 'sale') ? 'Buyer:' : 'Seller:',  value: load.seller },
                // Address beside Seller, and Description no longer alone on a
                // full-width line — per the owner 2026-08-22. Order gives:
                //   row 1  Date        | Created
                //   row 2  Seller      | Address
                //   row 3  Description |
                { label: 'Address:',     value: load.seller_address },
                // Full row: only field on its line, and full width keeps it
                // to one line instead of wrapping in a half-width column.
                // Only drawn when there IS one. The load-level description box was
                // removed from the form on 2026-08-28, and drawFieldBox does not skip
                // empty values — without this guard every new ticket would carry a bare
                // "Description:" label with nothing after it. Loads saved before that
                // change still have the field and still print it.
                ...(load.description ? [{ label: 'Description:', value: load.description, span: 2 }] : []),
            ], []);

            const unit = load.weight_unit || 'lb';
            const items = Array.isArray(load.items) ? load.items : [];
            drawSectionHeading(doc, 'Item Weights');

            if (!items.length) {
                doc.font('Helvetica').fontSize(10).fillColor(INK).text('No items on this load.');
                doc.moveDown(0.5);
            }
            items.forEach((it, i) => {
                const lines = [];
                lines.push({ text: `Gross weight: ${it.gross_weight != null ? it.gross_weight + ' ' + unit : '—'}` });
                if (it.gross_photo_link) lines.push({ text: 'View gross photo >', link: it.gross_photo_link });
                lines.push({ text: `Tare weight: ${it.tare_weight != null ? it.tare_weight + ' ' + unit : '—'}` });
                if (it.tare_photo_link) lines.push({ text: 'View tare photo >', link: it.tare_photo_link });
                lines.push({ text: `Net weight: ${it.net_weight != null ? it.net_weight + ' ' + unit : '—'}`, bold: true });

                const headerH = 22, lineH = 14;
                const cardH = headerH + lines.length * lineH + 10;
                if (doc.y + cardH > PAGE_BOTTOM) doc.addPage();
                const cardTop = doc.y;

                doc.lineWidth(1).rect(PAGE_L, cardTop, PAGE_R - PAGE_L, cardH).strokeColor(RULE).stroke();
                doc.rect(PAGE_L, cardTop, PAGE_R - PAGE_L, headerH).fill(NAVY_LIGHT);
                doc.font('Helvetica-Bold').fontSize(10).fillColor(NAVY).text(`${i + 1}. ${it.description || 'Item ' + (i + 1)}`, PAGE_L + 10, cardTop + 6);

                let ly = cardTop + headerH + 6;
                lines.forEach(l => {
                    if (l.link) {
                        doc.font('Helvetica').fontSize(9).fillColor('#1a5fb4').text('   ' + l.text, PAGE_L + 10, ly, { link: l.link, underline: true });
                    } else {
                        doc.font(l.bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(9.5).fillColor(l.bold ? NAVY : INK).text('   ' + l.text, PAGE_L + 10, ly);
                    }
                    ly += lineH;
                });
                doc.y = cardTop + cardH + 10;
            });

            doc.moveDown(0.3);
            if (includeSummary) {
                if (items.length) {
                    const groups = groupItemsByDescription(items);
                    drawSectionHeading(doc, 'Summary by Item Type');
                    drawItemTable(doc, groups, GROUP_COLUMNS_WEIGHTS);
                }

                drawSectionHeading(doc, 'Summary');
                drawSummaryBox(doc, [
                    { label: 'Gross total', value: load.gross_weight != null ? `${load.gross_weight} ${unit}` : '—' },
                    { label: 'Tare total',  value: load.tare_weight  != null ? `${load.tare_weight} ${unit}`  : '—' },
                    { label: 'Net total',   value: load.net_weight   != null ? `${load.net_weight} ${unit}`   : '—', emphasize: true },
                ]);
            }

            addFooters(doc, load);
            doc.end();
        } catch (err) {
            reject(err);
        }
    });
}

// ── Daily inventory report PDF ─────────────────────────────────────────────
// Per the owner 2026-08-15: "everyday a pdf should be created for inventory for
// that day and it should stored in drive as report folder." Same letterhead/
// table styling as the load tickets above, but the content is a report, not
// a per-load document — `dateKey` stands in for a load id in the top-right
// corner and the footer. `todayReport`/`overallReport` are both
// helpers/loads.js's getInventoryReport() output (today's date-filtered and
// unfiltered respectively) — called by scheduler.js's nightly job, which
// already has both on hand for the email/WhatsApp version of this same
// report (buildYardReportText above), so nothing here is a third source of
// truth for what "today's inventory" means.
function generateInventoryReportPdf(dateKey, todayReport, overallReport) {
    return new Promise((resolve, reject) => {
        try {
            const doc = new PDFDocument({ size: 'LETTER', margin: 50, bufferPages: true });
            const chunks = [];
            doc.on('data', (c) => chunks.push(c));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);

            const pseudoLoad = { id: dateKey };
            drawLetterhead(doc, 'Daily Inventory Report', pseudoLoad);

            const todayNet = round2(todayReport.byType.reduce((s, g) => s + (g.net || 0), 0));
            const todayAmount = round2(todayReport.byType.reduce((s, g) => s + (g.amount || 0), 0));

            drawSectionHeading(doc, `Today — ${dateKey} (${todayReport.loadCount} load${todayReport.loadCount === 1 ? '' : 's'})`);
            if (todayReport.byType.length) {
                drawItemTable(doc, todayReport.byType, GROUP_COLUMNS);
            } else {
                doc.font('Helvetica').fontSize(10).fillColor(INK).text('No loads recorded today.');
                doc.moveDown(0.6);
            }
            drawSummaryBox(doc, [
                { label: 'Loads today',  value: String(todayReport.loadCount) },
                { label: 'Net total',    value: `${todayNet} ${todayReport.unit}`, emphasize: true },
                { label: 'Amount total', value: `$${fmtAmount(todayAmount)}`, emphasize: true },
            ]);

            drawSectionHeading(doc, `By seller — today`);
            if (todayReport.bySeller.length) {
                drawItemTable(doc, todayReport.bySeller.map(s => ({ description: s.seller, count: s.loadCount, gross: '—', tare: '—', net: s.net, amount: s.amount })), SELLER_COLUMNS);
            } else {
                doc.font('Helvetica').fontSize(10).fillColor(INK).text('No loads recorded today.');
                doc.moveDown(0.6);
            }

            drawSectionHeading(doc, `All-time (${overallReport.loadCount} load${overallReport.loadCount === 1 ? '' : 's'} recorded total)`);
            if (overallReport.byType.length) {
                drawItemTable(doc, overallReport.byType, GROUP_COLUMNS);
            } else {
                doc.font('Helvetica').fontSize(10).fillColor(INK).text('No loads recorded yet.');
                doc.moveDown(0.6);
            }

            addFooters(doc, pseudoLoad);
            doc.end();
        } catch (err) {
            reject(err);
        }
    });
}

// ── On-demand inventory export PDF — Inventory tab's "⋮" export menu ──────
// Per the owner 2026-08-15 ("export as excel/pdf"). Unlike
// generateInventoryReportPdf above (a fixed "today + all-time" nightly
// report), this reflects exactly whatever date range is currently applied
// on screen — `rangeLabel` is a human-readable description of that range
// (e.g. "All time" or "2026-08-01 to 2026-08-15"), `report` is a single
// getInventoryReport() result for that range.
// ── THE SPEND REPORT, PRINTED (2026-11-07) ───────────────────────────────
// the owner: "export as xls and pdf".
//
// Handed the finished report object routes/reports.js already built from her
// query string — the SAME object the screen draws — so the sheet of paper
// cannot be a different period, company or filter from the page the button
// was pressed on. The label across the top says which, in words, because a
// printed page with no period on it cannot be checked against anything a
// month later.
//
// Built from the drawing primitives generateInventoryExportPdf already uses,
// so this is one more caller of the house letterhead rather than a second
// way of making a PDF.
function generateSpendReportPdf(label, rep) {
    return new Promise((resolve, reject) => {
        try {
            const r = rep || {};
            const n = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
            const doc = new PDFDocument({ size: 'LETTER', margin: 50, bufferPages: true });
            const chunks = [];
            doc.on('data', (c) => chunks.push(c));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);

            drawLetterhead(doc, 'Spend report', { id: label || '' });
            drawSectionHeading(doc, label || 'All time');

            // WHERE IT WENT — every part, never two of six.
            const PARTS = [
                ['Paid to sellers', r.loadTotal], ['Trucking', r.truckerTotal],
                ['Suppliers', r.supplierTotal], ['Cost of sales', r.saleCostTotal],
                ['Sample Yard Co Metals haulage', r.metalsTruckingTotal], ['Expenses', r.expenseTotal],
            ].filter(([, v]) => Math.abs(n(v)) > 0.005);

            const money = (v) => `$${fmtAmount(round2(n(v)))}`;
            const pct = (v, of) => (of ? `${((n(v) / of) * 100).toFixed(1)}%` : '—');

            // ── COLUMNS NEED AN ABSOLUTE x ─────────────────────────────
            // drawItemTable positions by `x`, not by flowing widths; without
            // it every cell lands at NaN and PDFKit throws "unsupported
            // number". Found by running it rather than by reading it.
            //
            // And the keys are `paid` / `share`, NOT `amount`: drawItemTable
            // puts a $ in front of a column called `amount` and formats it
            // as a number, which would double up on strings already
            // formatted here.
            const COLS = [
                { key: 'what',  label: '',       x: 50,  width: 250, align: 'left'  },
                { key: 'paid',  label: 'Amount', x: 300, width: 150, align: 'right' },
                { key: 'share', label: 'Share',  x: 450, width: 112, align: 'right' },
            ];
            const table = (title, rows, of) => {
                if (!rows.length) return;
                drawSectionHeading(doc, title);
                drawItemTable(doc, rows.map(([k, v]) => ({
                    what: k, paid: money(v), share: pct(v, of),
                })), COLS);
            };

            table('Where it went', PARTS, n(r.total));

            const asRows = (obj) => Object.keys(obj || {})
                .sort((a, b) => n(obj[b]) - n(obj[a])).map((k) => [k, obj[k]]);
            table('Out of each account', asRows(r.byBank), n(r.total));
            table('Whose money it was', asRows(r.byPaidVia), n(r.total));
            table('Whom we buy from', asRows(r.byBoughtFrom), n(r.total));
            if (r.received && n(r.received.total)) {
                table('Whom we sell to (of money received)', asRows(r.bySoldTo), n(r.received.total));
            }

            const summary = [
                { label: 'Entries', value: String(n(r.count)) },
                { label: 'Money out', value: money(r.total), emphasize: true },
            ];
            // Money in is shown, and labelled as NOT part of the figure
            // above — the same rule the screen follows. "Paid out X, took in
            // Y" is two facts, and adding them is the oldest mistake here.
            if (r.received && n(r.received.total)) {
                summary.push({ label: 'Received (kept apart)', value: money(r.received.total) });
            }
            drawSummaryBox(doc, summary);

            doc.end();
        } catch (e) { reject(e); }
    });
}

function generateInventoryExportPdf(rangeLabel, report) {
    return new Promise((resolve, reject) => {
        try {
            const doc = new PDFDocument({ size: 'LETTER', margin: 50, bufferPages: true });
            const chunks = [];
            doc.on('data', (c) => chunks.push(c));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);

            const pseudoLoad = { id: rangeLabel };
            drawLetterhead(doc, 'Inventory Export', pseudoLoad);

            const net = round2(report.byType.reduce((s, g) => s + (g.net || 0), 0));
            const amount = round2(report.byType.reduce((s, g) => s + (g.amount || 0), 0));

            drawSectionHeading(doc, `${rangeLabel} — ${report.loadCount} load${report.loadCount === 1 ? '' : 's'}`);
            if (report.byType.length) {
                drawItemTable(doc, report.byType, GROUP_COLUMNS);
            } else {
                doc.font('Helvetica').fontSize(10).fillColor(INK).text('No loads in this range.');
                doc.moveDown(0.6);
            }
            drawSummaryBox(doc, [
                { label: 'Loads',        value: String(report.loadCount) },
                { label: 'Net total',    value: `${net} ${report.unit}`, emphasize: true },
                { label: 'Amount total', value: `$${fmtAmount(amount)}`, emphasize: true },
            ]);

            drawSectionHeading(doc, 'By seller');
            if (report.bySeller.length) {
                drawItemTable(doc, report.bySeller.map(s => ({ description: s.seller, count: s.loadCount, gross: '—', tare: '—', net: s.net, amount: s.amount })), SELLER_COLUMNS);
            } else {
                doc.font('Helvetica').fontSize(10).fillColor(INK).text('No sellers in this range.');
                doc.moveDown(0.6);
            }

            drawSectionHeading(doc, 'Per day');
            if (report.byDay.length) {
                drawItemTable(doc, report.byDay.map(d => ({ description: d.date, count: d.loadCount, gross: '—', tare: '—', net: d.net, amount: d.amount })), SELLER_COLUMNS.map(c => c.key === 'description' ? { ...c, label: 'Date' } : (c.key === 'count' ? { ...c, label: 'Loads' } : c)));
            } else {
                doc.font('Helvetica').fontSize(10).fillColor(INK).text('No loads in this range.');
                doc.moveDown(0.6);
            }

            addFooters(doc, pseudoLoad);
            doc.end();
        } catch (err) {
            reject(err);
        }
    });
}

// ── POS/receipt-format PDF — per the owner 2026-08-17 ("I want print option
// once pdf generated... I want it to be pos dimension for printing") ────────
// A completely separate renderer from generateLoadPdf/generateWeightsPdf
// above, not a variant of them — those two are hand-built around LETTER's
// ~512pt content width (fixed-x-position multi-column tables, side-by-side
// field boxes), none of which fits an 80mm thermal receipt (~227pt total
// page width, ~207pt after margins). This draws everything as simple
// sequential single-column text instead, the way an actual POS receipt
// reads top to bottom.
//
// Page height problem: pdfkit needs the page size fixed at document
// creation, but we don't know how tall this load's receipt needs to be
// until we've laid out every item (a load can have 1 item or 20). Rather
// than guess a big height and print several inches of wasted blank paper
// past the last line (or guess too short and truncate), this runs the
// exact same draw function TWICE: once against a throwaway tall scratch
// document just to measure how far doc.y travels, then again against a
// real document sized to fit that measured height exactly — a real
// continuous-receipt page, not a multi-page LETTER-style document.
const RECEIPT_WIDTH_MM = { '58': 58, '80': 80 };
// Fixed page height, per the owner 2026-08-19 ("make the pos receipt standard
// size for printing"). The first version sized every page to its own
// content, which meant no two receipts had the same page size. That's fine
// for a raw continuous roll but bad for everything that expects a real
// page: Android's print dialog and most print drivers map the PDF page onto
// a selected paper size, and a page whose dimensions change per load gets
// scaled inconsistently — the same receipt coming out a different size each
// time. 80x150mm is a conventional receipt page and comfortably fits a
// typical load; content that genuinely exceeds it flows onto a SECOND PAGE
// OF THE SAME SIZE rather than stretching the page (see generateLoadReceiptPdf).
const RECEIPT_HEIGHT_MM = 150;
function mmToPt(mm) { return (mm / 25.4) * 72; }

function drawReceiptContent(doc, load, contentWidth, opts) {
    // Own copy: partyWord lives in drawSignatureBlock's scope, and referencing
    // it here threw a ReferenceError on every POS receipt until this was added.
    const partyWord = (opts && opts.kind === 'sale') ? 'Buyer' : 'Seller';
    // Page-break guard for the primitives that DON'T paginate themselves.
    // doc.text() checks the bottom margin and adds a page on its own, but
    // moveTo/lineTo/image draw at raw coordinates — past the page bottom
    // they'd render off the page and silently vanish. Now that the page
    // height is fixed (2026-08-19) that's a reachable case on a long load,
    // where before the page simply grew to fit.
    const room = (needed) => {
        const bottom = doc.page.height - doc.page.margins.bottom;
        if (doc.y + needed > bottom) doc.addPage();
    };
    const line = (text, { size = 9, bold = false, align = 'left', gap = 2, color = '#000' } = {}) => {
        doc.font(bold ? 'Helvetica-Bold' : 'Helvetica').fontSize(size).fillColor(color)
            .text(text, doc.page.margins.left, doc.y, { width: contentWidth, align });
        doc.moveDown(gap / size);
    };
    const divider = () => {
        room(4);
        doc.moveTo(doc.page.margins.left, doc.y).lineTo(doc.page.margins.left + contentWidth, doc.y)
            .lineWidth(0.75).strokeColor('#000').dash(2, { space: 2 }).stroke().undash();
        doc.moveDown(0.6);
    };

    line(SAMPLE_TRADING.name, { size: 13, bold: true, align: 'center', gap: 1 });
    line(SAMPLE_TRADING.address, { size: 7.5, align: 'center', color: MUTED, gap: 0.5 });
    line(SAMPLE_TRADING.phone, { size: 7.5, align: 'center', color: MUTED, gap: 2 });
    divider();

    line(`Load: ${load.id || '—'}`, { size: 9, bold: true, gap: 1 });
    line(`Date: ${load.date || '—'}`, { size: 8.5, gap: 1 });
    line(`${partyWord}: ${load.seller || '—'}`, { size: 8.5, gap: load.seller_address ? 0.5 : 1 });
    if (load.seller_address) line(load.seller_address, { size: 7.5, color: MUTED, gap: 1 });
    divider();

    const unit = load.weight_unit || 'lb';
    const items = Array.isArray(load.items) ? load.items : [];
    items.forEach((it, i) => {
        line(it.description || `Item ${i + 1}`, { size: 8.5, bold: true, gap: 0.5 });
        line(`Gross ${it.gross_weight ?? '—'} ${unit}  ·  Tare ${it.tare_weight ?? '—'} ${unit}`, { size: 7.5, color: MUTED, gap: 0.5 });
        // ── THE PRICE SAYS WHAT IT IS PER ───────────────────────────────
        // Rows can be priced per MT since 2026-09-24 while the weights stay
        // in pounds. Without this the line would read "Net 30,000 lb ·
        // Price $800 · Amount $10,886.23" — three true figures arranged
        // into a lie, on the one piece of paper the seller signs and takes
        // away. If he ever multiplies it out he gets $24,000,000 and an
        // argument nobody in the office can win, because the document is
        // what he has.
        // `unit` (the LOAD's weight unit) still governs the weights; this
        // only qualifies the rate, and only when it differs.
        //
        // ── AND THE TONNES, WHEN THAT IS WHAT HE IS BEING PAID BY ───────
        // the owner, 2026-09-24: "if price is in /mt while net in lbs in pdf,it
        // should should show net in pdf".
        //
        // Qualifying the rate was only half of it. "Net 30,000 lb · Price
        // $800.00/MT · Amount $10,886.23" is now honest but still not
        // CHECKABLE — the seller cannot get from the weight he watched go
        // over the scale to the money he is being handed without a
        // calculator and the conversion factor. The figure the price
        // actually multiplies has to be on the page.
        //
        // The pounds stay first and unconverted, because that is what the
        // weighbridge printed and what he came to see. The tonnes are shown
        // as a restatement of it — "= 13.608 MT" — not as a second weight.
        //
        // 3 decimals, matching helpers/invoicePdf.js:704, which is how every
        // tonne figure on her outgoing paperwork is already printed. See the
        // note to her about the cent-level gap this leaves: the AMOUNT is
        // computed from the full-precision division, so multiplying the
        // rounded tonnage by the rate can land a few cents off.
        const perMt = String(it.unit || '').trim().toLowerCase() === 'mt';
        // A POUND ROW PRINTS EXACTLY WHAT IT ALWAYS PRINTED — "$0.36", with
        // nothing appended. It was not ambiguous before and she did not ask
        // for it to change; only the tonne row is new, and only the tonne row
        // says so. Qualifying every rate was tidier and it was also a change
        // to a document that has been going out for months.
        const priceText = `$${fmtRate(it.price) ?? '—'}${perMt ? '/MT' : ''}`;
        line(`Net ${it.net_weight ?? '—'} ${unit}  ·  Price ${priceText}  ·  Amount $${fmtAmount(it.amount) ?? '—'}`, { size: 7.5, gap: perMt ? 0.5 : 1.5 });
        // ── AND THE WORKING, ON ITS OWN LINE ────────────────────────────
        // It has to be its own line: this receipt is narrow, and putting the
        // conversion inline pushed "Amount $10,886.23" off the right edge —
        // caught by rendering the PDF and reading the text back, not by
        // looking at the code, which is the only way that kind of fault ever
        // shows up. A signed ticket with no amount on it is worse than one
        // that makes him reach for a calculator.
        if (perMt && typeof it.net_weight === 'number' && isFinite(it.net_weight)) {
            line(`${it.net_weight} ${unit} = ${(it.net_weight / 2204.62).toFixed(3)} MT`, { size: 7, color: MUTED, gap: 1.5 });
        }
    });
    divider();

    line(`Net total: ${load.net_weight != null ? `${load.net_weight} ${unit}` : '—'}`, { size: 9.5, bold: true, gap: 1 });
    // ── THE DEDUCTION, ON THE COPY HE WALKS AWAY WITH ────────────────────
    // Same rule as the full ticket's summary box, and it matters more here:
    // this is the slip that physically leaves with the seller, so it is the
    // one he will hold up when the cash does not match. Prints only when
    // there IS a deduction, so every other receipt in the book is byte-for-byte
    // the receipt it was. Purchases only — `partyWord` above is already the
    // kind test this file uses.
    const rcpTrucking = (opts && opts.kind === 'sale') ? 0 : Number(load.trucking_amount) || 0;
    // A claim she adjusted in — the owner 2026-10-01, "Yes, as its own line
    // saying Claim". This slip matters MORE than the full ticket for it: it
    // is the paper in his hand when the cash does not match, and a deduction
    // he cannot read is the argument this line prevents. Unlike the summary
    // box above there is no fixed row height here, so the reason could fit —
    // it is still left off, because the slip is the receipt and not the
    // correspondence, and a one-line reason invites being argued with as if
    // it were the whole case.
    const rcpClaim = (opts && opts.kind === 'sale') ? 0 : Number(load.claim_amount) || 0;
    const rcpDeducted = rcpTrucking + rcpClaim;
    const rcpNet = rcpDeducted > 0 && load.amount != null
        ? Math.round((load.amount - rcpDeducted) * 100) / 100 : null;
    if (rcpNet !== null) {
        line(`Amount total: $${fmtAmount(load.amount)}`, { size: 9.5, gap: 0.5 });
        if (rcpTrucking > 0) {
            line(`Less trucking${load.trucking_company ? ` (${load.trucking_company})` : ''}: -$${fmtAmount(rcpTrucking)}`,
                 { size: 8.5, color: MUTED, gap: 1 });
        }
        if (rcpClaim > 0) {
            line(`Less claim: -$${fmtAmount(rcpClaim)}`, { size: 8.5, color: MUTED, gap: 1 });
        }
        line(`Net payable: $${fmtAmount(rcpNet)}`, { size: 11, bold: true, gap: 3 });
    } else {
        line(`Amount total: ${load.amount != null ? `$${fmtAmount(load.amount)}` : '—'}`, { size: 11, bold: true, gap: 3 });
    }
    divider();

    // Signature — same idea as the full ticket's block (see
    // drawSignatureBlock), scaled to receipt width. This is the copy the
    // seller physically takes away, so it's arguably the one that most
    // needs their signature on it. Prints the ruled line either way so an
    // unsigned receipt can still be signed by hand on paper.
    room(52); // keep the signature image, its rule and its label together
    if (load.seller_signature) {
        try {
            const b64 = String(load.seller_signature).replace(/^data:image\/\w+;base64,/, '');
            doc.image(Buffer.from(b64, 'base64'), doc.page.margins.left, doc.y, { fit: [contentWidth, 34], align: 'left', valign: 'bottom' });
            doc.y += 36;
        } catch (err) {
            console.error('[pdf] could not render seller signature on receipt:', err.message);
        }
    } else {
        doc.y += 30; // blank space to sign by hand
    }
    doc.moveTo(doc.page.margins.left, doc.y).lineTo(doc.page.margins.left + contentWidth, doc.y).lineWidth(0.75).strokeColor('#000').stroke();
    doc.moveDown(0.35);
    line(`${partyWord} signature`, { size: 7.5, color: MUTED, gap: 2 });

    line(`Generated ${new Date().toLocaleString('en-US', { timeZone: 'America/Los_Angeles' })} (LA time)`, { size: 6.5, align: 'center', color: MUTED });
}

// widthMm: '58' or '80' (the two standard thermal roll widths) — defaults
// to 80mm, the more common size for a business receipt printer.
// heightMm: defaults to RECEIPT_HEIGHT_MM (150mm). Every page is this exact
// size, per the owner 2026-08-19 ("make the pos receipt standard size for
// printing") — a receipt longer than one page continues onto another page
// of identical dimensions rather than the page itself growing, so a printer
// or print dialog always sees one consistent paper size.
function generateLoadReceiptPdf(load, opts = {}) {
    const widthMm = RECEIPT_WIDTH_MM[String(opts.widthMm)] || 80;
    const heightMm = Number(opts.heightMm) > 0 ? Number(opts.heightMm) : RECEIPT_HEIGHT_MM;
    const pageWidth = mmToPt(widthMm);
    const pageHeight = mmToPt(heightMm);
    const margin = 10;
    const contentWidth = pageWidth - margin * 2;

    return new Promise((resolve, reject) => {
        try {
            const doc = new PDFDocument({ size: [pageWidth, pageHeight], margin });
            const chunks = [];
            doc.on('data', (c) => chunks.push(c));
            doc.on('end', () => resolve(Buffer.concat(chunks)));
            doc.on('error', reject);
            drawReceiptContent(doc, load, contentWidth, opts);
            doc.end();
        } catch (err) {
            reject(err);
        }
    });
}

// Exported 2026-08-15 so scheduler.js's eodYardReport can reuse the exact
// same item-type grouping logic for its new inventory sections instead of
// duplicating this reduce elsewhere — one definition of "how items roll up
// by type" for both the PDF and the report.
module.exports = {
    PDF_TEMPLATE_VERSION,
    generateLoadPdf, generateWeightsPdf, generateLoadReceiptPdf, groupItemsByDescription, generateInventoryReportPdf, generateInventoryExportPdf, generateSpendReportPdf,
    // Additive exports — added 2026-08-19 for the Documents (Invoice/Proforma/
    // Verification) build-out. These drawing primitives already existed as
    // private module-level functions used internally by generateLoadPdf and
    // friends; nothing about their implementation changed, they're just now
    // reachable from other files (helpers/proformaPdf.js, helpers/invoicePdf.js)
    // instead of being reimplemented from scratch. Zero risk to existing
    // Load/Weights/Receipt/Inventory PDF generation above.
    ensureSpace, drawLetterhead, drawFieldBox, drawItemTable, drawSummaryBox, drawSignatureBlock, drawSectionHeading,
    NAVY, NAVY_LIGHT, RULE, MUTED, INK, PAGE_L, PAGE_R, PAGE_TOP, PAGE_BOTTOM,
};
