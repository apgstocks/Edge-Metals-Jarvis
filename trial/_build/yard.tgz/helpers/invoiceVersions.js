// ── helpers/invoiceVersions.js — Review & Generate edit-state history ──────
// Added per the owner's "Load previous edits" mockup: every real (non-preview)
// Generate & Download on the Commercial Invoice screen saves the full form
// payload that produced it, keyed by container #. Reopening the review
// screen for that same container later can then show "You last generated
// this on [date] — N versions saved" and offer to reload those exact edits
// instead of starting from the raw sheet data again.
//
// Deliberately separate from helpers/documentsSaved.js, which archives the
// finished PDF FILE — this stores the FORM STATE (every editable field) so
// it can be poured back into the review screen's inputs, which a PDF
// obviously can't be.
//
// Storage shape: { [containerNo]: [{ ...payload, saved_at }, ...] }, newest
// last. Capped at the last 10 versions per container — this is a UI
// convenience for catching a recent re-edit, not a full audit trail (see
// documentsSaved.js's dated PDF archive for that).

const cfg = require('../config');
const { mutateJson, loadJson } = require('./json');

const MAX_VERSIONS_PER_CONTAINER = 10;

function keyFor(containerNo) {
    return String(containerNo || '').trim().toUpperCase();
}

async function saveInvoiceVersion(containerNo, payload) {
    const key = keyFor(containerNo);
    if (!key) return; // no container assigned yet — nothing to key this history off of
    await mutateJson(cfg.INVOICE_VERSIONS_FILE, {}, (all) => {
        if (!Array.isArray(all[key])) all[key] = [];
        all[key].push({ ...payload, saved_at: new Date().toISOString() });
        if (all[key].length > MAX_VERSIONS_PER_CONTAINER) {
            all[key] = all[key].slice(-MAX_VERSIONS_PER_CONTAINER);
        }
        return all;
    });
}

// Returns { count, latest, saved_at } — latest is the full payload of the
// most recent version (or null if this container has never been generated
// before), saved_at is that version's own timestamp separated out for easy
// display without the caller needing to reach into the payload.
function getInvoiceVersionSummary(containerNo) {
    const key = keyFor(containerNo);
    if (!key) return { count: 0, latest: null, saved_at: null };
    const all = loadJson(cfg.INVOICE_VERSIONS_FILE, {});
    const versions = Array.isArray(all[key]) ? all[key] : [];
    if (!versions.length) return { count: 0, latest: null, saved_at: null };
    const last = versions[versions.length - 1];
    const { saved_at, ...latest } = last;
    return { count: versions.length, latest, saved_at };
}

// The most recent full payload for a container — the whole Review & Generate
// form state, header and line items. Exported 2026-09-16 so the packing list
// can borrow the invoice HEADER rather than asking her to retype an exporter
// block, a vessel and four ports she has already entered once.
//
// Returns null rather than a partial: a packing list built on half a header
// is a document that looks fine and is useless to a broker, which is the same
// reasoning as extractInvoiceHeader's loud failure in helpers/invoicePdf.js.
function getLatestInvoicePayload(containerNo) {
    const key = keyFor(containerNo);
    if (!key) return null;
    const all = loadJson(cfg.INVOICE_VERSIONS_FILE, {});
    const list = (all && Array.isArray(all[key])) ? all[key] : [];
    return list.length ? list[list.length - 1] : null;
}

// ── EVERY INVOICE SHE HAS GENERATED, NEWEST FIRST ─────────────────────────
// the owner, 2026-09-29: "Generated invoice should be editable.It should display
// below the invoice things.with edit option."
//
// Until now the only way back to a generated invoice was the banner on the
// review screen, which appears ONLY once she has already loaded that exact
// container — so to re-edit an invoice she had to remember which container it
// was and go and fetch it first. The list is the missing half: it shows what
// there is, and Edit pours the saved payload back into the form.
//
// A SUMMARY, NOT THE PAYLOADS. Each entry is a handful of fields for the row;
// the full form state (header, every line item) stays behind
// getLatestInvoicePayload and is fetched only when she presses Edit. Sending
// ten complete invoice payloads to render a ten-row table would make this
// screen slower the longer she uses it.
//
// Reads what is there and nothing more — no backfill. An invoice generated
// before this store existed is a PDF in documents_saved and has no form state
// to edit, and inventing one would produce a document that looks right and is
// not what was sent.
function listGeneratedInvoices() {
    const all = loadJson(cfg.INVOICE_VERSIONS_FILE, {}) || {};
    const out = [];
    for (const [container, versions] of Object.entries(all)) {
        const list = Array.isArray(versions) ? versions : [];
        if (!list.length) continue;
        const last = list[list.length - 1];
        if (!last) continue;
        out.push({
            container,
            versions: list.length,
            saved_at: last.saved_at || null,
            // Whatever the row needs to be recognised. Named from the invoice
            // form's own keys — this payload is the form, not a booking, so
            // it is inv_no and buyer rather than invoice_no and customer.
            inv_no: last.inv_no || last.invoice_no || '',
            buyer: last.buyer || '',
            port_discharge: last.port_discharge || '',
        });
    }
    // Newest first: the one she wants to correct is almost always the last one
    // she made, and scrolling a list to find it is how the wrong row gets
    // opened.
    return out.sort((a, b) => String(b.saved_at || '').localeCompare(String(a.saved_at || '')));
}

module.exports = { saveInvoiceVersion, getInvoiceVersionSummary, getLatestInvoicePayload,
                   listGeneratedInvoices };
