// ── helpers/invoicePdf.js — Commercial Invoice + Packing List PDF ──────────
// Added per the owner: "build invoice now.similar to proforma ask me who is the
// buyer.then follow python anywhere invoice flow". Data/calculations are
// ported from her old PythonAnywhere Flask tool (invoice_gen.py — see
// helpers/invoiceSheet.js for the sourcing/mapping notes and the important
// caveat about that tool's stale column indices).
//
// VISUAL DESIGN — first version reused Jarvis's modern "leaf/steel" Proforma
// look; the owner rejected it outright ("this design is not what i wanted.")
// and, asked explicitly via AskUserQuestion, chose "Match the old blue
// layout exactly". This now renders assets/invoice-classic/template.html,
// a close replica of invoice_gen.py's draw_mk_trading_invoice() reportlab
// layout (blue header bars, light-blue label cells, boxed grid) — NOT the
// Proforma style. Still rendered via puppeteer; no custom fonts needed here
// (the classic template uses plain Helvetica/Arial), so FONTS_DIR/font
// substitution from the old template is not used by this one.

const fs = require('fs');
const path = require('path');
const { round2 } = require('./money');

const TEMPLATE_DIR = path.join(__dirname, '..', 'assets', 'invoice-classic');

let _templateCache = null;
function loadTemplate() {
    if (_templateCache) return _templateCache;
    _templateCache = fs.readFileSync(path.join(TEMPLATE_DIR, 'template.html'), 'utf8');
    return _templateCache;
}

// ── Standalone packing-list header ────────────────────────────────────────
// the owner, 2026-09-09: "What if i want to have separate invoice and packing
// list" -> "Use seprate flag.." -> then sent her own separately-created
// packing list as the reference. Hers carries the FULL invoice header block:
// Exporter (with FAX), Invoice No & Items, DATE, Other Reference(s), the full
// Buyer address, Terms, Vessel / Flight No, Payment Terms, and all four port
// cells including Place of Receipt by Carrier.
//
// My first cut hand-wrote a trimmed-down second header in the template. That
// was wrong twice over: it dropped fields her document has, and it created a
// second copy of the header that would silently drift the first time anyone
// edited the real one (this template gets edited often — see the border and
// wrapping history in it). So instead the region between INV_HEAD_START and
// INV_HEAD_END is LIFTED from the invoice header and dropped into
// {{pl_header_rows}}. One source of truth.
//
// The lifted markup still contains {{...}} placeholders; it is injected
// BEFORE the substitution loop runs, so both copies get filled from the same
// values and cannot disagree about the buyer, the vessel or the ports.
const INV_HEAD_START = '<!--INV_HEAD_START-->';
const INV_HEAD_END = '<!--INV_HEAD_END-->';

function extractInvoiceHeader(tpl) {
    const a = tpl.indexOf(INV_HEAD_START);
    const b = tpl.indexOf(INV_HEAD_END);
    if (a === -1 || b === -1 || b < a) {
        // Fail loudly. Silently rendering a packing list with a blank header
        // would produce a document that looks fine and is useless to a broker.
        throw new Error(
            'invoicePdf: INV_HEAD markers missing from assets/invoice-classic/template.html — '
            + 'the standalone packing list cannot be built without them.'
        );
    }
    return tpl.slice(a + INV_HEAD_START.length, b);
}

function escapeHtml(s) {
    return String(s == null ? '' : s)
        .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// ── Formatting — reuses the exact same date/rate/qty helpers already proven
// correct in helpers/proformaPdf.js, required directly rather than
// re-implemented, so a fix made there doesn't silently drift out of sync
// between the two document types. amountInWords is not used by this classic
// layout (the old reportlab tool didn't print it either), so it's not
// imported here.
const { formatDate, formatRate } = require('./proformaPdf');
const { ITEM_CODE_MAP, deriveItemCodeFromDesc } = require('./invoiceSheet');

function formatMoney2(value) {
    return Number(value || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}
function formatInt(value) {
    return Math.round(Number(value) || 0).toLocaleString('en-US');
}
// invoice_gen.py's qty_display used f"{weight:.3f}" for MT quantities (3
// decimals — confirmed against the real reference PDF: "22.680", not
// "22.68"). Proforma's own formatQty() is fixed at 2 decimals for its own
// document, so it's not reused here — a local 3-decimal formatter matches
// this specific document's real historical output instead.
function formatQtyMt(value) {
    return Number(value || 0).toFixed(3);
}

// ── AND POUNDS ARE WHOLE NUMBERS WITH COMMAS ──────────────────────────────
// 22.571 MT is three decimals; 49,760 lb is not "49760.000". The unit decides
// the format as well as the heading, because a quantity printed in the wrong
// shape is the first thing that makes a buyer doubt the rest of the page.
function formatQty(value, data) {
    if (unitHeads(data).qty !== 'lbs') return formatQtyMt(value);
    const n = Number(value) || 0;
    // A pound figure is normally whole. Kept to at most 2 decimals rather
    // than forced to an integer, so a genuinely fractional weight is not
    // silently rounded into the money.
    return n.toLocaleString('en-US',
        { minimumFractionDigits: 0, maximumFractionDigits: Number.isInteger(n) ? 0 : 2 });
}

// ── WHAT THE TWO MONEY COLUMNS ARE HEADED ─────────────────────────────────
// 'lb' gives "Quantity lb" and "Rate US$/lb"; anything else gives the MT
// pair the document has always printed. Read from ONE place so the two
// headings cannot be set independently and end up describing different units.
function unitHeads(data) {
    const u = String((data && data.units) || '').trim().toLowerCase();
    return (u === 'lb' || u === 'lbs' || u === 'pound' || u === 'pounds')
        ? { qty: 'lbs', rate: 'lb' }
        : { qty: 'MT', rate: 'MT' };
}

// ── "12 × 110 lb", OR NOTHING AT ALL ──────────────────────────────────────
// The working behind a boxes tare, for a container that came on pallets.
// the owner, 2026-09-22: "if its pallets-i need to have that boxes in attached
// in our packing list."
//
// Returns null unless BOTH figures are there and both make sense, because
// the alternative — printing half of it, or printing "12 × " with a blank —
// is worse than printing the total alone, which is what every packing list
// does today. A loosely loaded container has neither field and gets exactly
// the document it gets now.
//
// Deliberately does NOT check the working against boxes_weight_lbs. They are
// set together by the one answer she gives, so they cannot drift here; and
// if they ever did, the packing list is the wrong place to discover it —
// helpers/scaleTicketBoxes.js reports a disagreement to her face, before the
// PDF exists.
function boxWorking(p) {
    if (!p) return null;
    const n = Number(p.boxes_count);
    const u = Number(p.boxes_unit_lb);
    // One guard, not two. There was a !Number.isFinite() line above this and
    // it could not be killed by any test, because Number.isInteger(NaN) is
    // already false and u > 0 is already false for NaN — a missing field and
    // a nonsense field take the same exit. Redundant code that no test can
    // reach is code the next reader has to decide about for nothing.
    if (!Number.isInteger(n) || n <= 0 || !(u > 0)) return null;
    // 110 and 110.5 both read correctly; a trailing ".00" does not.
    const unit = Number.isInteger(u) ? String(u) : String(Math.round(u * 100) / 100);
    return `${formatInt(n)} × ${unit} lb`;
}

// "AC-AUTO CAST" style label — mirrors invoice_gen.py's get_item_label().
// Tries to find the code by matching the resolved description back against
// ITEM_CODE_MAP first (cheap, no ambiguity when the description is exactly
// one of the known material names); falls back to pulling the 2-letter code
// out of the Inv No. token, same fallback helpers/invoiceSheet.js's own
// resolveItemDesc() already uses for the description itself.
function getItemCode(itemDesc, invNo) {
    const descUpper = String(itemDesc || '').toUpperCase().trim();
    for (const [code, desc] of Object.entries(ITEM_CODE_MAP)) {
        if (desc === descUpper) return code;
    }
    // KEYWORD match, second pass. Exact equality above only catches a
    // description already written exactly like the canonical name. Her real
    // line items say "Al combo", which is not "ALUMINIUM COMBO", so a
    // two-material invoice resolved only the regular combo and printed one
    // material in the header. Same rules the dashboard and mobile app use.
    const byKeyword = deriveItemCodeFromDesc(itemDesc);
    if (byKeyword && ITEM_CODE_MAP[byKeyword]) return byKeyword;

    const tokens = String(invNo || '').split(/[\s_]+/);
    for (const t of tokens) {
        const code = t.toUpperCase();
        if (ITEM_CODE_MAP[code]) return code;
    }
    return '';
}
// Matches invoice_gen.py's get_item_label() exactly: the label is
// CODE-CANONICAL_NAME (e.g. "AL-ALUMINIUM COMBO"), always from
// ITEM_CODE_MAP's own value — NOT the sheet row's raw item_desc text (which
// can be lowercase/abbreviated, like "Al combo" in a real sample invoice).
function itemLabel(itemDesc, invNo) {
    const code = getItemCode(itemDesc, invNo);
    if (code && ITEM_CODE_MAP[code]) return `${code}-${ITEM_CODE_MAP[code]}`;
    return '';
}

// EVERY material on the invoice, not just the first one.
//
// the owner, 2026-09-09: "Invoice description should be Aluminium combo, regular
// combo as both are there."
//
// The header label was built from lineItems[0] alone, so an invoice covering
// two containers of different materials announced itself as whichever one
// happened to be first — "AL-ALUMINIUM COMBO" on a document that is half
// regular combo. On a customs document that is not a cosmetic problem.
//
// TWO SOURCES, in order of how much they can be trusted:
//
//   1. Each line item's own description, matched against ITEM_CODE_MAP.
//      De-duplicated and kept in the order they appear, so a five-container
//      invoice of one material still reads as one label.
//
//   2. Only if NOT ONE description matched: the codes carried in the Inv No.
//      itself. getItemCode already does this per item, but it returns the
//      FIRST code it finds in the number — so on "260901_AL_26JY96_260901_RC_
//      26JY97" every unmatched item resolved to AL, quietly relabelling the
//      regular combo as aluminium. Reading ALL of them instead is both more
//      honest and exactly what she asked for.
function itemLabels(lineItems, invNo) {
    const out = [];
    const seen = new Set();
    const push = (label) => {
        if (!label || seen.has(label)) return;
        seen.add(label);
        out.push(label);
    };

    // ── WHEN THE LINE ITEMS ARE SUB-ITEMS, THE NUMBER LEADS ──────────────
    // the owner, 2026-09-19, about 260918_AP_26ARIS02: "WHY ITS COMING AS SU?"
    // and then, plainly, "it is scrap auto parts. yeah it will include more
    // than one item in the container."
    //
    // That is the shape this got wrong. A container of SCRAP AUTO PARTS holds
    // sealed units, alternators, starters and electric motors — things INSIDE
    // the grade, not four grades. The per-item pass matched "Sealed units" to
    // SU, found nothing for the other three, and announced a container of auto
    // parts as SU-SEALED UNITS. The number two lines above it said AP.
    //
    // ── BUT NOT ALWAYS, WHICH IS WHERE THE FIRST ATTEMPT WENT WRONG ──────
    // Reading the number first, full stop, broke two checks in
    // tests/invoice-header.js and deserved to. The number carries a segment
    // per CONTAINER, and an invoice can cover fewer containers than the number
    // names — so on an invoice of one regular-combo container it would have
    // announced aluminium as well, materials that are not on the document.
    // Wrong in the opposite direction, and worse: the first bug UNDER-named
    // what was in the container, this one would INVENT what was in it.
    //
    // So the number leads only where the rows are demonstrably finer-grained
    // than the grades:
    //
    //   SEVERAL ROWS IN ONE CONTAINER — her sentence, literally. Rows in a
    //     single container cannot each be a different grade of that container.
    //
    //   MORE ROWS THAN THE NUMBER HAS CODES — the same conclusion when
    //     container_no is not filled in. The number names one container per
    //     segment, so extra rows have to be sub-items.
    //
    // Anything else is one row per container, and each row's own description
    // is the better answer — which is what the 2026-09-09 requirement
    // ("Aluminium combo, regular combo as both are there") depends on, down to
    // the two materials appearing in the invoice's own row order.
    const numberCodes = [];
    for (const t of String(invNo || '').split(/[\s_,]+/)) {
        const code = t.toUpperCase();
        if (ITEM_CODE_MAP[code] && !numberCodes.includes(code)) numberCodes.push(code);
    }
    const rows = lineItems || [];
    const containers = [...new Set(rows.map((it) => String((it && it.container_no) || '').trim()))]
        .filter(Boolean);
    const subItems = numberCodes.length > 0 && rows.length > 1
        && ((containers.length === 1) || (numberCodes.length < rows.length));

    if (subItems) {
        for (const code of numberCodes) push(`${code}-${ITEM_CODE_MAP[code]}`);
        if (out.length) return out.join(', ');
    }

    for (const it of rows) {
        // Deliberately NOT passing invNo here. The per-item pass must answer
        // "what did THIS line say"; letting it fall back to the number is what
        // produced the mislabel described above.
        push(itemLabel(it && it.item_desc, null));
    }
    if (out.length) return out.join(', ');

    // Not one description matched. Then the number is all there is — and ALL
    // its codes, not the first, which is the trap this function was written
    // for in the first place.
    for (const code of numberCodes) push(`${code}-${ITEM_CODE_MAP[code]}`);
    return out.join(', ');
}

// ── EVERY MATERIAL ON THE DOCUMENT, WITH THIS ROW'S IN RED ────────────────
//
// the owner, 2026-09-24, with a mock of "Al combo, Regular Combo" rendered three
// ways — the first word red, then neither, then the second word red: "just
// replicate the colour exactly in invoice and packing lsit". Asked where it
// belonged she chose the per-row Description column over the header label,
// having been told it means each row starts listing ALL the materials rather
// than only its own.
//
// So a row on a mixed invoice reads "Al combo, Regular Combo" with the one
// that is actually IN that container in red. The point is that a customer
// reading line three can see at a glance which of the two materials that
// container holds, without cross-referencing the container number against
// anything.
//
// ── THE COLOUR ────────────────────────────────────────────────────────────
// #EA3323, sampled from her mock: it was the solid glyph fill (1,284 px of
// it, everything else in that family being anti-aliasing). Not a named CSS
// red and not the app's --status-danger, both of which are visibly different.
const ROW_ITEM_RED = '#EA3323';

// ── HOW THIS WORKS, AND HOW I GOT IT WRONG FIRST ──────────────────────────
//
// The first version of this read every ROW on the document, listed the
// distinct materials across them, and reddened the one matching that row's
// container. It never fired on a single one of her documents, because that is
// not the shape her data has. 260901_AL_26JY99 is ONE container, ONE row, and
// the description she typed into it is a single string:
//
//     "Al combo,Regular Combo"
//
// Both materials are in the one box, in the one field. Her mock was not two
// containers — it was the AL invoice and the RC invoice of the SAME shipment,
// which is why "Al combo" is red in one and "Regular Combo" in the other, and
// why the middle line (neither red) is what the document prints today.
//
// So the split is on the COMMA inside one description, and what decides the
// red is the item code in the invoice number: 260901_**AL**_26JY99 is the
// aluminium invoice, and the header already says AL-ALUMINIUM COMBO. Nothing
// here needs to look at other rows at all.
//
// ── AND THE WRAPPING, WHICH IS WHY SHE SENT THE PDFs ──────────────────────
// the owner, 2026-09-25, on the real output: "Description looks ugly". It read
//
//     Al
//     combo,Regular
//     Combo
//
// — three ragged lines. Two causes, both fixed here: she typed no space after
// the comma, so "combo,Regular" was one unbreakable token that forced the
// break back onto "Al"; and the cell had no say in where it broke. Each
// material now gets its own line, which is what the column is for and reads
// as a list rather than as text that ran out of room.
//
// ── THE GUARD, WHICH IS MINE ──────────────────────────────────────────────
// One material, no red and no reflow: the cell prints exactly what it prints
// today. That covers every single-material invoice she has ever sent, and it
// covers the packing list of 2026-09-16 ("3 different items in a container..
// alternator,starter,ac compressor") — there each ROW is its own material and
// the description is a single name, so this leaves it alone.
//
// `row` is the line being drawn; `invNo` is the document's invoice number.
// Returns escaped HTML, so callers must NOT escape it again.
function rowItemsHtml(row, invNo) {
    const raw = String((row && (row.item || row.item_desc)) || '').trim();
    // Split on commas only — "Alternator / Starter" and other separators are
    // left alone, because the comma is the one she actually types and
    // guessing at others would reflow descriptions nobody asked about.
    const parts = raw.split(',').map((p) => p.trim()).filter(Boolean);
    if (parts.length < 2) return escapeHtml(raw);

    // The code in the invoice number says which material THIS document is
    // for. getItemCode already resolves a description to a code; passing the
    // number alone resolves the document's own.
    const docCode = getItemCode('', invNo);
    return parts.map((p) => {
        const mine = docCode && getItemCode(p, null) === docCode;
        return mine
            ? `<span style="color:${ROW_ITEM_RED};">${escapeHtml(p)}</span>`
            : escapeHtml(p);
    }).join(',<br>');
}

// Normalizes whatever the client sent into a flat [{label, amount}, ...]
// list. the owner's redesign ("Invoice Notes" — replaces the old dedicated
// Freight Deduction field) lets her add arbitrary labeled adjustment rows,
// each signed: negative deducts from the total, positive adds to it (her
// own words on the mockup). Freight and EFS are no longer special-cased
// fields — they're just the first couple of notes, still shown as friendly
// labeled inputs in the UI, but structurally identical to any other note.
//
// Backward compatible with the OLD single-freight payload shape
// (data.freight, a positive number meaning "deduct this much") for any
// already-saved version-history entries or in-flight requests from a
// not-yet-updated client — synthesized into one negative-amount note so old
// and new payloads render identically.
function normalizeNotes(data) {
    if (Array.isArray(data.notes)) {
        return data.notes
            .map((n) => ({ label: String((n && n.label) || '').trim(), amount: Number(n && n.amount) || 0 }))
            .filter((n) => n.label && n.amount !== 0);
    }
    const legacyFreight = Number(data.freight) || 0;
    return legacyFreight > 0 ? [{ label: 'Less: Freight Charges', amount: -legacyFreight }] : [];
}

function buildInvoiceClassicHtml(data) {
    const lineItems = data.line_items || [];
    const subtotal = data.subtotal != null ? Number(data.subtotal) : lineItems.reduce((s, it) => s + (Number(it.amount) || 0), 0);
    const notes = normalizeNotes(data);
    const notesTotal = notes.reduce((s, n) => s + n.amount, 0);
    const finalAmount = data.final_amount != null ? Number(data.final_amount) : subtotal + notesTotal;

    // Item table — S.No / Booking# / Container# / Seal# / Description /
    // Quantity MT / Rate US$/MT / Amount US$. Booking/Container/Seal are the
    // same for every row on a container's invoice (one shipment can carry
    // several line items), so they're repeated per row rather than merged —
    // simpler and safer than a rowspan that could misrender in some PDF
    // engines.
    const itemRowsHtml = lineItems.map((item, i) => {
        const qty = Number(item.weight) || 0;
        const rate = Number(item.rate) || 0;
        // ── ROUNDED, LIKE ITS TWO SISTER FILES ───────────────────────
        // helpers/invoiceSheet.js and helpers/proformaPdf.js both wrap this
        // in round2; this one lost it in 7f16c64 "invoice change". 29,000 lb
        // at $0.41 is 11889.999999999998 in floating point, and this figure
        // goes on a document a customer pays against. Her own figure, when
        // she has typed one, still wins untouched.
        const amount = item.amount != null
            ? Number(item.amount)
            : round2(qty * rate);
        // Booking#/Container#/Seal# use a smaller 8.5pt (was 8pt, bumped
        // one step less than the other columns' +1pt) + tighter padding
        // and nowrap+hidden-overflow — real Helvetica (reportlab) renders
        // these ID strings narrower than Chromium's Helvetica-substitute
        // font does, so pushing this column all the way to 9pt like the
        // rest reintroduced the overflow into the neighboring cell that
        // was fixed earlier this session (re-tested against the real
        // "DALA27808800"/"KOCU4877967" values before settling here).
        const idCell = (val) => `<td style="padding:0.5mm;font-size:8.5pt;text-align:center;vertical-align:middle;white-space:nowrap;overflow:hidden;">${escapeHtml(val)}</td>`;
        // Description always wraps (word-wrap/overflow-wrap:break-word,
        // white-space:normal) regardless of length — a long unbroken item
        // description no longer overflows into the Quantity column now
        // that table-layout:fixed enforces the column width, it just wraps
        // and the row grows taller instead. Every cell is both
        // horizontally (text-align:center) AND vertically
        // (vertical-align:middle) centered — global td{vertical-align:top}
        // in the template's CSS would otherwise pin short cells (S.No,
        // Quantity) to the top of a row that a wrapped Description has
        // made much taller. the owner: "make the text in center aligned. also
        // wrap description always." / "mid center alignment."
        // item.container_no/item.seal_no exist when several containers are
        // merged into one invoice (buildMultiContainerInvoiceData — each
        // container keeps its own seal); falls back to the shared
        // top-level value for the ordinary single-container case, so this
        // one code path renders both shapes correctly.
        return `        <tr style="height:8mm;">
          ${idCell(i + 1)}
          ${idCell(data.booking_no)}
          ${idCell(item.container_no || data.container_no)}
          ${idCell(item.seal_no || data.seal_no)}
          <td style="padding:1mm;font-size:10pt;text-align:center;vertical-align:middle;word-wrap:break-word;overflow-wrap:break-word;white-space:normal;">${rowItemsHtml(item, data.inv_no)}</td>
          <td style="padding:1mm;font-size:10pt;text-align:center;vertical-align:middle;">${formatQty(qty, data)}</td>
          <td style="padding:1mm;font-size:10pt;text-align:center;vertical-align:middle;">${formatRate(rate)}</td>
          <td style="padding:1mm;font-size:10pt;text-align:center;vertical-align:middle;">${formatMoney2(amount)}</td>
        </tr>`;
    });

    // One merged-through-Rate italic row per note (same visual pattern the
    // old single hardcoded freight row used — label cell's own colspan
    // extends through Rate, 7 columns: S.No/Booking/Container/Seal/
    // Description/Quantity/Rate, only Amount stays a separate column.
    // the owner: "no till rate only merge" — merge through Rate only, not a
    // second blank cell after the label). A negative amount prints with its
    // sign and reads as a deduction; a positive amount prints with a "+"
    // so it's visually obvious it's adding to the total, not a stray
    // positive line item.
    const notesRowsHtml = notes.map((n) => {
        const sign = n.amount < 0 ? '-' : '+';
        return `        <tr style="height:8mm;">
          <td colspan="7" style="padding:1mm;font-size:10pt;text-align:center;vertical-align:middle;font-style:italic;">${escapeHtml(n.label)}</td>
          <td style="padding:1mm;font-size:10pt;text-align:center;vertical-align:middle;">${sign}${formatMoney2(Math.abs(n.amount))}</td>
        </tr>`;
    }).join('\n');

    const addr = data.consignee_address || [];
    const buyerName = addr.length ? addr[0] : (data.consignee || '');
    const rest = addr.length > 1 ? addr.slice(1) : [];
    const buyerAddressLines = rest.map(escapeHtml).join('<br>');

    // (firstItemDesc removed 2026-09-09 — the header label now reads EVERY
    //  line item via itemLabels(), not just the first one.)
    const otherRefParts = [];
    if (data.reference) otherRefParts.push(escapeHtml(data.reference));
    if (data.proforma_date) otherRefParts.push(`Proforma Date: ${escapeHtml(formatDate(data.proforma_date))}`);
    const otherRef = otherRefParts.join(' &nbsp;|&nbsp; ');

    // Packing List rows — one per line item, using whatever weights were
    // resolved server-side (real packing-sheet data where matched, else a
    // calculated fallback — see helpers/invoiceSheet.js).
    // ── THE PACKING TABLE'S COLUMNS, DECLARED ONCE ───────────────────────
    // the owner, 2026-09-16: "sometimes i will have 3 different items in a
    // container..for eg:alternator,starter,ac compressor.each with separate
    // gross,net,tare overall total gross,net,tare and adding those
    // gross,net,tare --->overall for the container", and on whether the
    // customer's copy shows the breakdown: "Item column on the PDF too".
    //
    // The table is therefore FIVE columns or SIX, and the heading, the rows
    // and the TOTAL row must all agree about which. Three hand-written copies
    // of a changing count is how that row SHEARS: no error, the net figures
    // slide one column left and print under the wrong headings on the paper a
    // customer is checking with a calculator. tests/packing-list.js counts
    // cells for exactly this reason.
    //
    // So: one list, three renderers. The count cannot disagree with itself.
    //
    // ── OFF BY DEFAULT ───────────────────────────────────────────────────
    // showItem is false unless a packing list says otherwise, so an INVOICE
    // generated through the "Separate invoice & packing list" flag prints the
    // same five columns it has printed since 2026-09-09. Nothing on file
    // changes shape because a different screen grew a checkbox.
    // ── WHY AN INVOICE'S PACKING LIST SHOWS IT TOO ───────────────────────
    // the owner, 2026-09-16: "why item description missing in packing list of
    // invoice tab in docs?"
    //
    // Because the column was built for the packing-list screen and switched on
    // by ITS checkbox, and the invoice path never sets that flag. Her invoice
    // line items have carried item_desc all along — "Aluminium combo",
    // "Regular combo" — and the packing list beside them printed a container
    // number and four weights with no word about what was in the box. On a
    // customs document that is the column that matters most.
    //
    // So the column also appears when the DATA has descriptions, which for an
    // invoice is always. This DOES change a document her customers already
    // receive, from five columns to six. Deliberate, and the smaller change of
    // the two available: the alternative is a packing list that names nothing.
    const lineItemsNameSomething = lineItems.some((it) =>
        String((it && (it.item || it.item_desc)) || '').trim());
    const showItem = data.packing_show_item === true || data.packing_show_item === 'true'
        || lineItemsNameSomething;

    // ── TWO PACKING LISTS, NOT ONE ───────────────────────────────────────
    // the owner, 2026-09-17: "Why my invoice packing list ave only gross,tare,
    // net? i told that my separate packing list tab needs to have only that
    // while my invoice tab's packing list need to have gross,tare,container,
    // boxes like last time".
    //
    // She is right and this was my mistake, made on 2026-09-16 and written
    // down as though it were hers. When she said "in packing list i juxt want
    // gross,tare,net" she meant the packing-list SCREEN she was looking at. I
    // applied it to the shared template and left a comment claiming both
    // documents "change together, deliberately" — a decision of mine, filed
    // under her name, which is the worst way to record one.
    //
    // They are two documents with two jobs:
    //
    //   THE INVOICE TAB'S — one row per container, and the tare BROKEN OUT
    //   into truck, container tare, chassis and boxes. That is the shape her
    //   broker has received since before this project existed, and the four
    //   components are the working that justifies the net.
    //
    //   THE PACKING LIST TAB'S — one row per bundle off a weigh sheet, which
    //   has a gross and one tare and nothing to break out.
    //
    // helpers/packingList.js sets packing_compact; NOTHING ELSE DOES, so the
    // invoice path keeps the fuller shape by default. Defaulting the other
    // way round is what caused this: a flag that has to be set to keep an
    // existing document the way it was will eventually not be set.
    const compact = data.packing_compact === true || data.packing_compact === 'true';
    const num = (v) => {
        const n = parseFloat(String(v == null ? '' : v).replace(/,/g, '').trim());
        return isFinite(n) ? n : null;
    };

    let totalNetLbs = 0, totalNetMt = 0, totalGrossLbs = null, totalTareLbs = null;
    // The four components, totalled in their own right so the fuller table's
    // TOTAL row adds up column by column rather than leaving them blank.
    let totalTruck = null, totalCtare = null, totalChassis = null, totalBoxes = null;
    const addUp = (acc, v) => (v == null ? acc : (acc == null ? v : acc + v));

    // ── DOES THE CONTAINER COLUMN SAY ANYTHING? ──────────────────────────
    // the owner, 2026-09-16, looking at a forty-row sample: "Why would i need to
    // repeat container number?"
    //
    // She does not. A bundle tally is forty weighings of ONE container, and a
    // column printing HMMU7060866 forty times is the same column she had me
    // remove from the entry grid a few hours earlier ("remove container in
    // item grid") — I took it out of the form she types into and left it on
    // the paper her customer reads.
    //
    // So the column earns its place only when the rows actually DIFFER. When
    // they are all one container it is dropped and the number is stated ONCE,
    // above the table, where it reads as a fact about the shipment rather than
    // as data.
    //
    // ── ONLY WHEN THERE IS REPETITION TO REMOVE ──────────────────────────
    // A single-row table is not repetition, so a one-container invoice's
    // packing list keeps the exact shape it has had since 2026-09-09. The only
    // documents that change are the ones that were saying the same thing
    // several times over.
    const containersOn = [...new Set(lineItems
        .map((it) => String((it && it.container_no) || data.container_no || '').trim())
        .filter(Boolean))];
    const oneContainer = compact && lineItems.length > 1 && containersOn.length === 1;
    const containerWidth = showItem ? '18%' : '22%';

    // ── A SUBTOTAL PER ITEM ──────────────────────────────────────────────
    // the owner, 2026-09-19, having had to ask me what the per-item totals were
    // on MSDU2726332: "ADD PER ITEM SUBTOTAL IN PACKING LIST IF DIFFERENT
    // ITEMS FOUND".
    //
    // Sixteen bundles of four different things, and the only totals on the
    // page were for the container. Working out what the Alternators weighed
    // meant adding four numbers by hand off a document her buyer also has to
    // add by hand.
    //
    // ── `compact`, WHICH MEANS THE PACKING LIST TAB AND NOTHING ELSE ─────
    // Gated the same way the single Tare column is, and for the same reason
    // as the note above it. The INVOICE tab's packing list is one row per
    // CONTAINER — a subtotal there would group containers by whatever their
    // item happens to be called and insert rows into the document her broker
    // has received for years. She named the packing list; the packing list is
    // what changes. If she wants it on the invoice's too, that is one flag and
    // her yes.
    //
    // ── "IF DIFFERENT ITEMS FOUND" ───────────────────────────────────────
    // Her condition, and it is the right one: on a list of one item the
    // subtotal and the TOTAL are the same figures twice, which invites the
    // reader to look for the difference between them.
    const itemKeyOf = (it) => String((it && (it.item || it.item_desc)) || '').trim().toLowerCase();
    const distinctItems = [...new Set(lineItems.map(itemKeyOf).filter(Boolean))];
    // showItem is implied — an item can only differ if it is named, and a
    // named item turns the column on — but it is asserted rather than assumed,
    // because a subtotal row labelled in a column that is not being printed
    // would put the label nowhere.
    //
    // No "and there are more rows than items" clause here, though the first
    // version had one: a mutation deleted it and nothing went red, because
    // the `run.rows > 1` guard further down already refuses to print a
    // subtotal for a run of one. Dead code with a confident comment in front
    // of it is worse than no code — the next person reads it as load-bearing.
    const showSubtotals = compact && showItem && distinctItems.length > 1;

    // ── EVERY WEIGHT PRINTED THE SAME WAY ────────────────────────────────
    // A packing list went out with "1111" in the Gross column beside "1,046"
    // in Net, because gross is copied through as the STRING she typed while
    // net is derived and formatted. One column with separators and one
    // without, on the same four-figure numbers, reads as carelessness on a
    // document a customs broker checks.
    //
    // Formatted only when the value is a clean number. Anything else — a
    // range, a note, a figure with a unit stuck to it — is printed exactly as
    // it arrived, because mangling what she wrote is worse than an odd-looking
    // cell.
    const weightText = (v) => {
        const raw = String(v == null ? '' : v).trim();
        if (!raw) return '';
        const n = Number(raw.replace(/,/g, ''));
        if (!isFinite(n) || !/^[\d,]+(\.\d+)?$/.test(raw)) return raw;
        return n.toLocaleString('en-US', { maximumFractionDigits: 3 });
    };

    // ── THE LINE NUMBER ──────────────────────────────────────────────────
    // the owner's weigh sheet numbers every bundle — "#1 - 3599", "#2 - 3475" —
    // and she types those into the form's leading column. They were not on the
    // printed document at all, so a buyer querying "the fourth bundle" and she
    // querying it were counting rows by eye on different sheets.
    //
    // Only when the Container column is gone, which is exactly the
    // bundle-by-bundle case. On an invoice's packing list, one row per
    // container, a row number is noise. It also gives the TOTAL row back a
    // label cell of its own — "TOTAL 9,851" crammed into the Gross column was
    // the other half of what she called bad.
    //
    // Her own numbering wins; a row she left blank is numbered by position,
    // which is a presentation index and not a claim about anything.
    // The line number replaces the repeated container on the BUNDLE list. An
    // invoice's packing list is one row per container and numbering it says
    // nothing, so it stays off there even when every row happens to be one
    // container.
    const numberCol = oneContainer && compact;
    const numberWidth = 9;

    // ── HER NUMBERING ONLY WHEN IT IDENTIFIES A PIECE ────────────────────
    // the owner, 2026-10-01, on the packing list Jarvis generated from her weigh
    // sheet for TCLU 6619618: "Did you notice he s.no".
    //
    // 42 of the 53 serial numbers on it were duplicates. Her sheet is written
    // in SIX COLUMNS side by side — Junk Car, Al Cast, Container, and three
    // more — and each column is numbered from 1 again. The scan carries each
    // bundle's written number into `note`, and the rule above was "her own
    // numbering wins". So the document printed five rows called #1, six called
    // #2, and so on.
    //
    // That rule was right for what it was written for: ONE tally column, where
    // her #4 and the buyer's #4 are the same bundle. It is wrong the moment
    // the page has more than one column, and nothing about the output looks
    // wrong — the numbers are all plausible and the weights are all correct.
    //
    // So the test is no longer "did she number it" but "does her numbering
    // IDENTIFY a row". Unique across the printed rows → hers wins, exactly as
    // before. Repeated → fall back to position, which is what a serial number
    // on a packing list means: piece 34 of 53, resolvable by a buyer counting
    // or by anyone raising a claim against one bundle.
    //
    // Decided from the data rather than from a setting, so the single-tally
    // case she asked for keeps working with nothing to switch on, and the
    // multi-column case fixes itself.
    const printedNotes = lineItems.map((it) => String((it && it.note) || '').trim());
    const filledNotes = printedNotes.filter(Boolean);
    const notesIdentifyRows = filledNotes.length === printedNotes.length
        && new Set(filledNotes).size === filledNotes.length;

    // What the dropped Container column gives back, minus what the line number
    // takes, shared among the weight columns so the table still fills the page.
    const weightCols = showItem ? 5 : 4;
    const spare = oneContainer
        ? (Number(containerWidth.replace('%', '')) - (numberCol ? numberWidth : 0)) / weightCols
        : 0;
    const w = (pct) => `${(Number(pct.replace('%', '')) + spare).toFixed(1)}%`;

    const PACKING_COLUMNS = [
        ...(numberCol ? [{ head: '#', width: `${numberWidth}%`,
          // Position unless her own numbers are unique — see notesIdentifyRows.
          cell: (item, p, netLbs, netMt, i) => escapeHtml(
              notesIdentifyRows ? (String(item.note || '').trim() || String(i + 1)) : String(i + 1)),
          sub: () => 'Subtotal',
          total: 'TOTAL' }] : []),
        ...(oneContainer ? [] : [{ head: 'Container', width: containerWidth,
          cell: (item) => escapeHtml(item.container_no || data.container_no),
          sub: () => (numberCol ? '' : 'Subtotal'),
          total: 'TOTAL' }]),
        // `item` is what the packing-list screen sends; `item_desc` is what an
        // invoice line item has always been called. One column, either source
        // — reading only one of them is how this went missing in the first
        // place.
        ...(showItem ? [{ head: 'Item', width: w('16%'),
          // ── AND HOW IT WAS PACKED, WHEN IT CAME ON PALLETS ─────────────
          // the owner, 2026-09-23: "Still that 12*120 boxes looks ugly..find a
          // way to make it better."
          //
          // It was stacked under the figure in the Boxes column, which is 10%
          // of the page — two lines crammed into the narrowest cell on the
          // document, and the second one clipped. The number belongs in that
          // column; the DESCRIPTION of the packing does not.
          //
          // Here it has room and it reads as a sentence about the goods,
          // which is what a packing list's Item column is for: "Sealed Units
          // / 12 boxes x 120 lb". The Boxes column goes back to one clean
          // figure.
          cell: (item, p) => {
              // Same helper as the invoice's Description column, so the two
              // documents cannot say different things about the same
              // container — see rowItemsHtml. Already escaped.
              const name = rowItemsHtml(item, data.inv_no);
              const w2 = boxWorking(p);
              return w2
                  ? `${name}<div style="font-size:7.5pt;font-weight:400;">${escapeHtml(w2)}</div>`
                  : name;
          },
          // The item's own name, so the row cannot be read as "everything
          // above this line" — it says exactly what it is the total of.
          sub: (acc) => escapeHtml(acc.label),
          // Something has to carry the word TOTAL or the last row is a line of
          // figures with no label on it — but only ONE something. When the
          // line-number column is there it takes the label and this one stays
          // blank; the first version of that printed "TOTAL | TOTAL" across
          // two cells.
          total: (oneContainer && !numberCol) ? 'TOTAL' : '' }] : []),
        { head: 'Gross Weight<br>(lbs)', width: w(showItem ? '17%' : '20%'),
          cell: (item, p) => escapeHtml(weightText(p.gross_weight_lbs) || '-'),
          sub: (acc) => (acc.gross == null ? '' : formatInt(acc.gross)),
          total: () => (totalGrossLbs == null ? '' : formatInt(totalGrossLbs)) },
        // ── ONE TARE, OR THE FOUR IT IS MADE OF ──────────────────────────
        // The invoice's packing list prints the working: truck, container
        // tare, chassis and boxes, each in its own column, which is what her
        // broker has always received. The packing list tab prints the single
        // figure, because a bundle on a scale has one tare and nothing to
        // break out.
        ...(compact
            ? [{ head: 'Tare<br>(lbs)', width: w(showItem ? '16%' : '20%'),
                 cell: (item, p) => { const t = require('./packingList').tareOf(p);
                                      return escapeHtml(t == null ? '-' : t.toLocaleString('en-US')); },
                 sub: (acc) => (acc.tare == null ? '' : formatInt(acc.tare)),
                 total: () => (totalTareLbs == null ? '' : formatInt(totalTareLbs)) }]
            : [
                { head: 'Truck<br>(lbs)', width: '10%',
                  cell: (item, p) => escapeHtml(weightText(p.truck_lbs) || '-'),
                  total: () => (totalTruck == null ? '' : formatInt(totalTruck)) },
                { head: 'Container Tare<br>(lbs)', width: '12%',
                  cell: (item, p) => escapeHtml(weightText(p.container_tare_lbs) || '-'),
                  total: () => (totalCtare == null ? '' : formatInt(totalCtare)) },
                { head: 'Chassis<br>(lbs)', width: '10%',
                  cell: (item, p) => escapeHtml(weightText(p.chassis_lbs) || '-'),
                  total: () => (totalChassis == null ? '' : formatInt(totalChassis)) },
                // ── AND THE WORKING, WHEN IT CAME ON PALLETS ───────────────
                // the owner, 2026-09-22: "if its pallets-i need to have that
                // boxes in attached in our packing list." Her supplier's
                // scale ticket states it as working, not as a total —
                // "12 Boxes x 110Lb  Tare. - 1320Lb" — and that is what the
                // buyer checks against.
                //
                // ADDED BENEATH THE FIGURE, never instead of it. The column
                // still prints 1,320 exactly as it does today, so a loosely
                // loaded container's packing list is unchanged to the byte
                // and her broker's document does not move. The second line
                // appears only when the count and the unit weight are both
                // present, which only the pallets answer sets.
                // One figure, nothing stacked — the "12 x 120 lb" working now
                // sits in the Item cell, which has the width for it. See the
                // note there, and the owner on 2026-09-23.
                //
                // UNLESS THERE IS NO ITEM COLUMN. showItem is false when no
                // line names anything, and then the working has nowhere else
                // to go — so it falls back here rather than disappearing off
                // the document she asked to have it on. Cramped beats absent.
                { head: 'Boxes<br>(lbs)', width: '10%',
                  cell: (item, p) => {
                      const shown = escapeHtml(weightText(p.boxes_weight_lbs) || '-');
                      if (showItem) return shown;
                      const w2 = boxWorking(p);
                      return w2
                          ? `${shown}<div style="font-size:7pt;font-weight:400;">${escapeHtml(w2)}</div>`
                          : shown;
                  },
                  total: () => (totalBoxes == null ? '' : formatInt(totalBoxes)) },
              ]),
        { head: 'Net Weight<br>(lbs)', width: w(showItem ? '17%' : '20%'),
          // A dash, never a zero, when there is genuinely nothing to state.
          cell: (item, p, netLbs) => escapeHtml(weightText(p.net_weight_lbs) || (netLbs ? formatInt(netLbs) : '-')),
          sub: (acc) => (acc.netLbs ? formatInt(acc.netLbs) : ''),
          total: () => (totalNetLbs ? formatInt(totalNetLbs) : '-') },
        { head: 'Net Weight<br>(MT)', width: w(showItem ? '16%' : '18%'),
          // A dash, not 0.000, when there is genuinely nothing: a printed zero
          // is a CLAIM that the container weighed nothing, and a blank is an
          // absence. The same rule tareOf follows, on the same document.
          cell: (item, p, netLbs, netMt) => (netMt ? netMt.toFixed(3) : '-'),
          sub: (acc) => (acc.netMt ? acc.netMt.toFixed(3) : ''),
          total: () => (totalNetMt ? totalNetMt.toFixed(3) : '-') },
    ];

    const packingHeadCellsHtml = PACKING_COLUMNS.map((c) =>
        `          <th style="width:${c.width};padding:1mm;font-size:9.5pt;text-align:center;vertical-align:middle;border:1pt solid black;">${c.head}</th>`
    ).join('\n');

    // Packing List rows — one per line item, using whatever weights were
    // resolved server-side (real packing-sheet data where matched, else a
    // calculated fallback — see helpers/invoiceSheet.js).
    //
    // ── ONE TARE COLUMN ──────────────────────────────────────────────────
    // the owner, 2026-09-16: "in packing list,i juxt want gross,tare ,net" — and,
    // on whether the printed document follows, "Yes".
    //
    // helpers/packingList.js's tareOf is the ONE place that decides what a
    // tare is: her own figure when she typed one, otherwise the four
    // components added up. Reused rather than re-implemented here, because two
    // answers to "what is the tare" would eventually differ, and they would
    // differ on a document a customer is holding.
    //
    // An INVOICE SAVED BEFORE TODAY still carries truck/container/chassis/
    // boxes broken out. It regenerates with the same total it always had, in
    // one column instead of four — nothing on file needs migrating.
    // A `for` rather than a `map` because a subtotal row is emitted BETWEEN
    // rows, and because the accumulators below are per-run as well as per-page.
    const packingRowsHtml = [];
    let run = null;
    lineItems.forEach((item, rowIndex) => {
        const p = item.packing || {};
        // ── MT IS A CONVERSION, NOT A FIELD THAT MAY BE BLANK ────────────
        // A packing list built from a weigh sheet has pounds and nothing else,
        // and this printed 0.000 down the whole column and on the TOTAL — on a
        // customs document, a stated net weight of zero tonnes.
        //
        // An invoice states its own MT (that is what it prices on) and is
        // untouched. Only a row that has pounds and no tonnes gets the
        // conversion, which is arithmetic anyone receiving the document can
        // repeat, not a figure being invented.
        let netMt = parseFloat(String(p.net_weight_mt || '').replace(/,/g, '')) || Number(item.weight) || 0;
        // ── NET FROM THE WEIGHTS, NOT FROM NOTHING ───────────────────────
        // A row carrying a gross and a tare but no stored net printed "0" —
        // and a 0 on a packing list is a CLAIM that the bundle weighed
        // nothing, printed beside a gross of 6,000 on the same line. Gross
        // minus tare is the rule the rest of the system runs on
        // (helpers/packingList.js's netOf); it simply was not reaching this
        // table, which is fed by invoice line items as well as by the
        // packing-list screen.
        let netLbs = parseFloat(String(p.net_weight_lbs || '').replace(/,/g, ''));
        if (!isFinite(netLbs) || netLbs === 0) {
            const grossN = parseFloat(String(p.gross_weight_lbs || '').replace(/,/g, ''));
            const tareN = require('./packingList').tareOf(p);
            netLbs = isFinite(grossN)
                ? grossN - (tareN == null ? 0 : tareN)
                : Math.round(netMt * 2204.62);
        }
        if (!isFinite(netLbs)) netLbs = 0;
        if (!netMt && netLbs) netMt = netLbs / 2204.62;
        totalNetMt += netMt;
        totalNetLbs += netLbs;
        // The overall gross and tare for the container — her words, "overall
        // total gross,net,tare". Null rather than 0 when no row carried one:
        // a printed 0 claims a container that weighed nothing, and a blank is
        // an absence. Same rule tareOf follows.
        totalGrossLbs = addUp(totalGrossLbs, num(p.gross_weight_lbs));
        totalTareLbs = addUp(totalTareLbs, require('./packingList').tareOf(p));
        totalTruck = addUp(totalTruck, num(p.truck_lbs));
        totalCtare = addUp(totalCtare, num(p.container_tare_lbs));
        totalChassis = addUp(totalChassis, num(p.chassis_lbs));
        totalBoxes = addUp(totalBoxes, num(p.boxes_weight_lbs));
        const cells = PACKING_COLUMNS.map((c) =>
            `          <td style="padding:1mm;font-size:9.5pt;text-align:center;vertical-align:middle;">${c.cell(item, p, netLbs, netMt, rowIndex)}</td>`
        ).join('\n');
        packingRowsHtml.push(`        <tr style="height:10mm;">\n${cells}\n        </tr>`);

        // ── AND THE SUBTOTAL, WHEN THIS ITEM'S RUN ENDS ──────────────────
        // Totalled over a CONTIGUOUS RUN of one item, not over every row
        // carrying that name wherever it sits. The figure a subtotal states
        // has to be the sum of the rows directly above it, because that is
        // the only thing the person holding the document can check — and
        // this document gets checked with a calculator. Her weigh sheets are
        // grouped, so in practice a run IS the item; if one ever is not, she
        // gets two labelled subtotals that each add up rather than one that
        // does not.
        if (!showSubtotals) return;
        const key = itemKeyOf(item);
        if (!run || run.key !== key) {
            run = { key, label: item.item || item.item_desc || '',
                    gross: null, tare: null, netLbs: 0, netMt: 0, rows: 0 };
        }
        run.gross = addUp(run.gross, num(p.gross_weight_lbs));
        run.tare = addUp(run.tare, require('./packingList').tareOf(p));
        run.netLbs += netLbs;
        run.netMt += netMt;
        run.rows += 1;

        const next = lineItems[rowIndex + 1];
        if (next && itemKeyOf(next) === key) return;
        // A run of one is not a subtotal, it is the row again. Skipped, so a
        // single Alternator among fifteen sealed units does not get a line
        // underneath restating itself.
        if (run.rows > 1) {
            const subCells = PACKING_COLUMNS.map((c) => {
                const v = typeof c.sub === 'function' ? c.sub(run) : '';
                return `          <td style="padding:1.4mm 1mm;font-size:9.5pt;font-weight:700;`
                     + `text-align:center;vertical-align:middle;background:var(--light-orange);`
                     + `border-top:0.8pt solid var(--black);">${v}</td>`;
            }).join('\n');
            packingRowsHtml.push(`        <tr style="height:8mm;">\n${subCells}\n        </tr>`);
        }
        run = null;
    });

    // Built AFTER the rows, because the totals are accumulated while they
    // render. Hence the thunks in `total` above — reading the variables at
    // declaration time would print zeroes.
    const packingTotalCellsHtml = PACKING_COLUMNS.map((c, i) => {
        const v = typeof c.total === 'function' ? c.total() : c.total;
        const style = v
            ? 'padding:2mm 1mm;font-weight:700;font-size:10pt;text-align:center;vertical-align:middle;border:1pt solid black;'
            : 'padding:2mm 1mm;border:1pt solid black;';
        return `          <td style="${style}">${v}</td>`;
    }).join('\n');

    // One line naming what is in the container when it is all one thing.
    // the owner, 2026-09-16, on where the header description goes: "Printed above
    // the packing table". Empty when she has not named one — a stray "Item:"
    // with nothing after it looks like a field that failed to fill.
    const itemDesc = String(data.packing_item_description || '').trim();
    // Stated ONCE when every row is the same container — see the note on
    // PACKING_COLUMNS. It is not anywhere else on this document: the standalone
    // packing list's header carries the exporter, the invoice number and the
    // ports, but no container, so dropping the column without saying it here
    // would lose it from the page entirely.
    const aboveTable = [
        oneContainer ? `Container: ${escapeHtml(containersOn[0])}` : '',
        itemDesc ? `Item: ${escapeHtml(itemDesc)}` : '',
    ].filter(Boolean).join(' &nbsp;|&nbsp; ');
    // Tinted like the label strips above it and the table head below, so the
    // line naming the container reads as part of the coloured document rather
    // than as a white gap between two orange bands. the owner, 2026-09-16: "Fill
    // the packing list colour."
    const packingItemLineHtml = aboveTable
        ? `    <div class="seam" style="background:var(--light-orange);padding:1.2mm 2.5mm;font-size:9.5pt;font-weight:700;border-left:0.8pt solid var(--black);border-right:0.8pt solid var(--black);">${aboveTable}</div>`
        : '';

    // ── THE STANDALONE PACKING LIST'S REFERENCE LINE ─────────────────────
    // the owner, 2026-09-16: "I dont want this much big packing list", "I dont
    // want terms,vessel,payment terms..", "Build B".
    //
    // The tall cloned invoice header is gone; what a packing list needs from
    // it fits on one line. Every part is omitted when it is empty rather than
    // printed as a label with nothing after it — two of the three boxes she
    // asked me to remove were printing blank on her own documents, which is
    // how a header grows without anyone deciding it should.
    //
    // The ITEM and CONTAINER already print immediately above the table (see
    // packing_item_line) and are deliberately not repeated here.
    const plRefs = [
        data.booking_no ? `Booking ${escapeHtml(data.booking_no)}` : '',
        data.seal_no ? `Seal ${escapeHtml(data.seal_no)}` : '',
        (data.port_loading || data.port_discharge)
            ? `${escapeHtml(data.port_loading || '—')} &rarr; ${escapeHtml(data.port_discharge || '—')}`
            : '',
        data.country_of_origin ? `Origin ${escapeHtml(data.country_of_origin)}` : '',
        data.reference ? escapeHtml(data.reference) : '',
    ].filter(Boolean).join(' &nbsp;&middot;&nbsp; ');

    // ── WHICH HEADER THIS PACKING LIST GETS ──────────────────────────────
    // The invoice tab's gets the clone it has always had — exporter, buyer,
    // Terms, Vessel, Payment Terms, four ports — so a list split off its
    // invoice still says everything the invoice said. The packing list tab's
    // gets the compact block: no Terms, no Vessel, no Payment Terms, and the
    // shipment's references on one line.
    const COMPACT_PL_HEADER = `
      <div style="background:var(--orange);color:var(--light-orange);padding:1.8mm 2.5mm;display:flex;justify-content:space-between;align-items:center;">
        <div style="font-weight:700;font-size:13.5pt;letter-spacing:.03em;">PACKING LIST</div>
        <div style="font-size:9.5pt;font-weight:700;">{{inv_no}} &nbsp;&middot;&nbsp; {{inv_date}}</div>
      </div>
      <table class="seam" style="width:100%;border-collapse:collapse;">
        <tr>
          <td style="width:50%;padding:0;vertical-align:top;border-right:1pt solid var(--black);">
            <div style="background:var(--light-orange);padding:0.8mm 2.5mm;font-size:7.5pt;font-weight:700;letter-spacing:.06em;">EXPORTER</div>
            <div style="padding:1.2mm 2.5mm;">
              <div style="font-weight:700;font-size:10pt;">SAMPLE YARD CO METALS INC</div>
              <div style="font-size:8.5pt;line-height:1.45;">100 Main Street, Anytown, TX 75000<br>TAX-ID: 26-3269514 &nbsp;&middot;&nbsp; TEL:(555) 010-0100</div>
            </div>
          </td>
          <td style="width:50%;padding:0;vertical-align:top;">
            <div style="background:var(--light-orange);padding:0.8mm 2.5mm;font-size:7.5pt;font-weight:700;letter-spacing:.06em;">BUYER</div>
            <div style="padding:1.2mm 2.5mm;">
              <div style="font-weight:700;font-size:10pt;">{{buyer_name}}</div>
              <div style="font-size:8.5pt;line-height:1.45;">{{buyer_address_lines}}</div>
            </div>
          </td>
        </tr>
      </table>
      <div class="seam" style="border-top:1pt solid var(--black);padding:1.2mm 2.5mm;font-size:8.5pt;line-height:1.5;">{{pl_refs_line}}</div>`;

    // The banner the cloned header needs: the compact block carries its own,
    // the clone never did. The same bar the document has opened with since
    // 2026-09-09.
    const CLONE_PL_BANNER = '\n      <div style="background:var(--orange);color:var(--light-orange);text-align:center;'
        + 'font-weight:700;font-size:15.5pt;height:12mm;box-sizing:border-box;display:flex;align-items:center;'
        + 'justify-content:center;">PACKING LIST</div>\n';

    let html = loadTemplate();
    // Injected BEFORE substitution, exactly as the clone always was, so
    // whichever block lands has its placeholders filled by the same pass. A
    // header assembled afterwards would print {{buyer_name}} on a customer's
    // document — and this very edit left {{pl_header_block}} unfilled for one
    // run, which is how that gets discovered if you look.
    html = html.split('{{pl_header_block}}')
               .join(compact ? COMPACT_PL_HEADER : (CLONE_PL_BANNER + extractInvoiceHeader(html)));
    const subs = {
        // <wbr> after each underscore: a real break OPPORTUNITY that
        // contributes no character, so the wrapped number still copies out of
        // the PDF as plain text. Without it, overflow-wrap breaks at the box
        // edge wherever that lands — splitting "26JY96" into "26JY9" and "6"
        // on a financial document. With it, a combined number breaks between
        // whole invoice numbers. Escape FIRST, then insert the tag, or the
        // angle brackets get escaped too.
        // Also after a COMMA (2026-09-10): the mixed-material number separates
        // whole numbers with one — "260901_AL_26JY96,260901_RC_26JY97" — and
        // a comma is no more a break opportunity in CSS than an underscore is.
        // Without this the preferred break is mid-number at an underscore
        // instead of at the boundary between the two numbers.
        inv_no: escapeHtml(data.inv_no || '').replace(/([_,])/g, '$1<wbr>'),
        // ── HERS IF SHE TYPED ONE, DERIVED OTHERWISE ─────────────────────
        // the owner, 2026-09-29: "HAVE AN OPTION TO EDIT THE DESCRIPTION BELOW
        // THE INVOICE NUMBER LIKE AL-AL COMBO".
        //
        // itemLabels() reads the line items and the invoice number and is
        // right most of the time; this is the correction for when it is not.
        //
        // BLANK FALLS THROUGH TO THE DERIVATION, which is the whole of the
        // safety here: every invoice generated before today, and every one
        // where she leaves the box alone, prints exactly what it printed
        // before. The override names the new shape, never the old one — a
        // flag that had to be SET to keep the existing label would
        // eventually not be set, and the header would quietly change on a
        // document a customs broker reads.
        item_label: escapeHtml(
            String(data.item_label_override == null ? '' : data.item_label_override).trim()
            || itemLabels(lineItems, data.inv_no)),
        inv_date: escapeHtml(formatDate(data.inv_date)),
        other_ref: otherRef,
        pl_refs_line: plRefs,
        buyer_name: escapeHtml(buyerName),
        buyer_address_lines: buyerAddressLines,
        terms: escapeHtml(data.terms || ''),
        vessel: escapeHtml(data.vessel || ''),
        country_of_origin: escapeHtml(data.country_of_origin || 'USA'),
        place_of_receipt: escapeHtml(data.place_of_receipt || ''),
        port_loading: escapeHtml(data.port_loading || ''),
        port_discharge: escapeHtml(data.port_discharge || ''),
        item_rows: itemRowsHtml.join('\n'),
        notes_rows: notesRowsHtml,
        final_amount_fmt: formatMoney2(finalAmount),
        // ── ONE SIGNATURE FILE, TWO PRESENTATIONS ────────────────────────
        // 7f16c64 replaced the shared {{signature_block}} with the image
        // pasted inline as base64. Understandable: the shared block is
        // left-aligned at 34px and her new layout needs it centred at 8mm in
        // a table cell, so the block did not fit and the image did.
        //
        // Her MARKUP is kept exactly — the wrapper, the sizing, the centring
        // are hers. Only the src comes from helpers/signature.js now, so the
        // invoice and the proforma cannot end up showing different
        // signatures the day the file is replaced. That drift is the whole
        // reason ab3cf26 unified them in the first place.
        signature_src: require('./signature').signatureDataUrl() || '',
        signature_block: require('./signature').signatureBlockHtml(),
        // ── THE UNIT THE MONEY COLUMNS ARE IN ─────────────────────────────
        // the owner, 2026-09-23, on 260831_SU_26EM05 — an invoice that billed
        // $13.09 for a container worth $28,860.80: "If i want to generate inv
        // in lbs?"
        //
        // She buys in pounds at cents per pound. Those are the only figures
        // she has, and every one of them was correct on that document —
        // 49,760 lb net, $0.58 a pound. The loss came entirely from the
        // Quantity column being headed MT while the Rate column still held
        // her per-pound price, a mismatch documents.html created silently
        // when she edited a weight box (see wireInvItemRow).
        //
        // So the unit is now a property of the invoice and BOTH headings come
        // from it. A heading and its figure cannot disagree when one decides
        // the other.
        //
        // ── ABSENT MEANS MT, AND THAT IS NOT A DEFAULT, IT IS HISTORY ─────
        // Every invoice ever generated before today is in MT and carries no
        // `units` field. If this fell back to pounds, reopening a March
        // invoice would re-head its tonnes as pounds — restating a document
        // a customer already has. The FORM defaults new invoices to lb; this
        // renderer defaults to what the file was made in.
        qty_unit_head: unitHeads(data).qty,
        rate_unit_head: unitHeads(data).rate,
        packing_rows: packingRowsHtml.join('\n'),
        packing_head_cells: packingHeadCellsHtml,
        packing_total_cells: packingTotalCellsHtml,
        packing_item_line: packingItemLineHtml,
        // Kept as substitutions even though the TOTAL row now builds its own
        // cells: an older saved template or another caller may still reference
        // them, and leaving a live {{placeholder}} on a customer's document is
        // the worst possible failure mode for a rename.
        total_net_lbs_fmt: formatInt(totalNetLbs),
        total_net_mt_fmt: totalNetMt.toFixed(3),
    };
    for (const [key, val] of Object.entries(subs)) {
        html = html.split(`{{${key}}}`).join(val);
    }
    return { html, subtotal, notes, finalAmount };
}

// ONE browser, N renders. Chromium launch is by far the most expensive part
// of this (~1s), so producing two documents must not pay it twice.
// Queued — one Chromium at a time. This is the launch point for BOTH the
// invoice and the packing list (helpers/packingList.js calls renderModes),
// so queueing here covers both. Tests that inject their own renderer never
// reach this function and are unaffected. See helpers/pdfQueue.js.
// The invoice's page, stated once. Its @page is 210mm x 297mm — real A4 —
// and the fitter measures against that, not against the 816px width, which
// is the box every one of these documents has always been laid out in.
// Saying only the width let the height default to 297 by luck rather than by
// statement, which is a different thing to rely on.
const PAGE = { width: '816px', printBackground: true, preferCSSPageSize: true };
const FIT = { pageHeightMm: 297, pageWidthMm: 210 };

async function renderModes(html, modes, opts) {
    // ── THE RENDER PROCESS, IF IT IS THERE ───────────────────────────────
    // the owner, 2026-10-10: "think like a production system."
    //
    // One pm2 process was carrying 275 routes, 34 crons, WhatsApp's Chromium
    // and every render under a 1500M cap — so a single large document could
    // restart the API for every customer and silently drop the whole queue.
    // render-server.js owns Chromium now; this asks it.
    //
    // THE FALLBACK IS NOT OPTIONAL. No socket, a stale one, a timeout, a bad
    // answer — helpers/renderClient.js ends every one of them by calling the
    // function below, which is exactly the code that ran before today. So a
    // renderer that is not installed, not started, or mid-restart behaves
    // precisely as this did yesterday.
    //
    // The queue moved WITH the work: when the render process takes the job it
    // queues there, beside the memory the job actually costs. Only the
    // in-process path still queues here, which is what it has always done.
    const job = {
        html, modes,
        // ── ONE DEFINITION, OR THE DOCUMENT DEPENDS ON WHICH PATH RAN ────
        // These were about to exist twice: once here for the render process
        // and once inside renderModesUnqueued for the in-process path. Two
        // copies of a page setup means an invoice that is 816px wide down
        // one path and something else down the other, and the only way to
        // notice is a broker querying a document. PAGE and FIT are the
        // single source; the wire carries them rather than the renderer
        // knowing them.
        pdfOptions: PAGE, fitOpts: FIT,
        label: `invoice ${(modes || []).join('+')}`,
    };
    return require('./renderClient').render(job, () => require('./pdfQueue').run(
        () => renderModesUnqueued(html, modes, opts),
        `invoice ${(modes || []).join('+')}`));
}

async function renderModesUnqueued(html, modes, opts) {
    // ── WHERE THE SECONDS GO ─────────────────────────────────────────────
    // the owner, 2026-09-16: "why invoice and bol takes more time to generate?"
    // Measured, not reasoned about — see helpers/pdfTiming.js. The phases are
    // named for the four things this function does, in order, so the log line
    // answers the question directly rather than needing arithmetic.
    const timer = require('./pdfTiming').start(`invoice ${(modes || []).join('+')}`);
    // A tab in WhatsApp's Chromium, not a Chromium of its own — see
    // helpers/pdfBrowser.js. 'launch-chromium' now times getting the tab.
    try {
      return await require('./pdfBrowser').withPage(async (page) => {
        timer.mark('launch-chromium');
        // ── 'load', NOT 'networkidle0' (2026-10-10) ──────────────────
        // the owner, on a 14.2s invoice: "Fix it.why its taking more time
        // to generate". Her own [PDF-TIME] line said load-page was 1641ms
        // of it, and about 500ms of that was this one word.
        //
        // networkidle0 means "wait for load, THEN for 500ms during which
        // no request starts". These documents have no network to go
        // quiet: every one was checked — no <link>, no <script>, no
        // @font-face, no url(), no http(s) anywhere. The only subresource
        // is the signature, an <img> with a data: URL.
        //
        // 'load' waits for exactly the same subresources — the signature
        // included — and skips only the arbitrary half-second afterwards.
        // So this is not "wait for less"; it is "stop waiting for a
        // network that does not exist". domcontentloaded WOULD be wait-
        // for-less, and would be wrong: it can fire before that image is
        // decoded, and her broker's document carries her signature.
        await page.setContent(html, { waitUntil: 'load' });
        timer.mark('load-page');
        const out = {};
        for (const mode of modes) {
            // The mode is a BODY CLASS, and the CSS in the template hides the
            // other document. One DOM, re-labelled — no second setContent, and
            // no possibility of the two PDFs disagreeing about the data.
            await page.evaluate((m) => {
                document.body.classList.remove('only-invoice', 'only-packing');
                if (m) document.body.classList.add(m);
            }, mode === 'both' ? null : `only-${mode}`);
            // ── ONE PAGE, PER MODE ───────────────────────────────────
            // Restored 2026-09-10. e20d8a1 "separate inv and packing list"
            // rewrote this into a loop over modes and the fitter did not come
            // with it — the invoice went back to spilling a near-empty second
            // page, which is what pdfFittedToOnePage was written for on
            // 2026-08-29. Read as an accidental drop rather than a decision:
            // that commit is about SEPARATING two documents, and the proforma
            // path a few files away still fits to one page.
            //
            // Inside the loop deliberately. Each mode is a different amount of
            // content — the invoice alone, the packing list alone, or both —
            // so each needs measuring on its own. Fitting once outside would
            // scale all three by whatever the longest one needed.
            const { pdfFittedToOnePage } = require('./pdfFit');
            // PAGE and FIT, not a second copy of the same numbers — see the
            // note in renderModes. The render process gets these over the
            // wire from the very same constants.
            const pdf = await pdfFittedToOnePage(page, PAGE,
                { ...FIT, timer, label: `invoice ${mode}` });
            // Same Uint8Array -> Buffer gotcha documented in proformaPdf.js —
            // res.send() needs a real Buffer or it JSON-stringifies byte-by-byte.
            out[mode] = Buffer.from(pdf);
        }
        return out;
      }, { launchArgs: opts.launchArgs });
    } finally {
        timer.mark('close-chromium');
        timer.done({ html_kb: Math.round(String(html || '').length / 1024), modes: (modes || []).length });
    }
}

// ── separate ──────────────────────────────────────────────────────────────
// the owner, 2026-09-09: "What if i want to have separate invoice and packing
// list" -> "Use seprate flag."
//
// opts.separate falsy (DEFAULT, unchanged)  -> Buffer, both documents in one
//                                              PDF, exactly as before.
// opts.separate true                        -> { invoice: Buffer, packing: Buffer }
//
// The return type changes with the flag rather than always being an object,
// so every existing caller keeps working untouched. api.js opts in explicitly.
// ── invoice only ──────────────────────────────────────────────────────────
// the owner, 2026-09-16: "add a checkbox called invoice only in invoice of
// documents".
//
// opts.invoiceOnly true -> Buffer, the invoice ALONE. No packing list, not in
//                          the same PDF and not as a second file.
//
// The machinery was already there: the template has hidden the packing half
// under body.only-invoice since 2026-09-09, and separate mode has been
// rendering exactly this document as its first output ever since. What was
// missing was a way to ask for it and keep only that half.
//
// It BEATS separate, and deliberately so: "invoice only" and "and also give me
// the packing list" are a contradiction, and the safe reading of a
// contradiction on a document going to a customer is the narrower one — she
// gets fewer papers than she expected, not a packing list she asked not to
// send. The screen keeps the two boxes from being ticked together; this is
// what happens if anything else ever posts both.
//
// `opts.render` is injectable for the same reason helpers/packingList.js's
// generatePdf takes a renderer: Chromium cannot launch in the test sandbox, and
// WHICH MODES are asked for is the whole of this decision. A test that cannot
// see the mode list can only re-read the source.
async function generateInvoiceClassicPdf(data, opts = {}) {
    const { html } = buildInvoiceClassicHtml(data);
    const render = opts.render || renderModes;
    if (opts.invoiceOnly) {
        const { invoice } = await render(html, ['invoice'], opts);
        return invoice;
    }
    if (!opts.separate) {
        const { both } = await render(html, ['both'], opts);
        return both;
    }
    // opts.ticketPacking (2026-11-10, her tick-box on Documents -> Invoice): the packing
    // list half is the scale-ticket document INSTEAD of the standard one. Only reachable
    // in separate mode, and only when the caller passes it, so every existing caller
    // gets the two PDFs it always got.
    if (opts.ticketPacking) {
        // Validated BEFORE any render, so figures that do not add up fail fast and never
        // cost a Chromium pass on the invoice first.
        const tpl = require('./ticketPackingList');
        const chk = tpl.buildTicketPackingHtml(opts.ticketPacking);
        if (chk.problems.length) { const e = new Error(`Scale-ticket packing list: ${chk.problems.join('; ')}`); e.code = 'TICKET_PACKING_INVALID'; e.problems = chk.problems; throw e; }
        const { invoice } = await render(html, ['invoice'], opts);
        const packing = await require('./ticketPackingList').generateTicketPackingPdf(opts.ticketPacking, opts);
        return { invoice, packing };
    }
    const { invoice, packing } = await render(html, ['invoice', 'packing'], opts);
    return { invoice, packing };
}

module.exports = { buildInvoiceClassicHtml, generateInvoiceClassicPdf, renderModes,
                   extractInvoiceHeader, PAGE, FIT };
