// ── helpers/emailContacts.js — saved name→email directory ────────────────────
// Built 2026-08-03 per the owner: "if i say send mail to <person>, instead of
// asking for email, can't it store all the email addresses and just ask, are
// you mentioning this?" — mirrors helpers/pricelist.js's contacts pattern
// (loadContacts/addContact/removeContact/resolveTarget) almost exactly,
// deliberately its own file/JSON (not truckers.json/suppliers.json/pricelist
// contacts) — an email recipient list is its own concern, even where names
// overlap with operational contacts.
//
// Grows two ways: (1) manually, via the dashboard Contacts UI (POST/DELETE
// /api/email-contacts), and (2) automatically — workflow/actions.js saves a
// name→address pairing here the first time it's successfully resolved via
// mail search or forward-extraction, so the SECOND time someone says "email
// carrier about X" it's an instant contacts hit instead of a fresh Gmail
// search. Never overwrites silently in a way that loses data: addContact
// upserts by case-insensitive name, so re-resolving the same name just
// refreshes/confirms the same entry.
//
// DOMAIN GROUPS (added 2026-08-03) — per the owner: "we are hardcoding, we
// should not... instead of one contact, I need a tree-like structure, all
// nodes like helen, brian, docs attached to domain sample." Real incident
// that forced this: "sample" as a single flat name→address pairing kept
// getting overwritten with whichever address a bug happened to resolve most
// recently (the shared docs mailbox, a hallucination, etc.) — there was no
// way to represent "this company has three real addresses that mean
// different things" at all. Storage is STILL a flat array (dashboard/
// api.js's existing list-based UI and the by-address Cc lookups in
// actions.js both keep working completely unchanged) — each record just
// optionally carries `domain` and `role` now. `role: 'primary'` is who a
// bare company-name mention ("mail sample") resolves to by default;
// other roles (e.g. 'secondary', 'shared') must be addressed by their own
// name ("mail helen"). Every member of a domain group is wired to auto-cc
// every OTHER member (cc scope widened 2026-08-04 per the owner's explicit
// choice — "everyone else at that company," not just shared/docs-style
// addresses) by literally setting those addresses on each member's own
// `cc` field — draftEmailWithAddress/ccForAddress already look up cc by the
// resolved email address, so this needed zero changes there. `role` itself
// still matters for a different reason: it decides who a bare domain
// mention ("mail eccomelt") resolves to by default (primary) and who
// should never be that default (shared).

const cfg = require('../config');
const { loadJson, mutateJson } = require('./json');

function isValidEmail(addr) {
    return typeof addr === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(addr.trim());
}

function loadContacts() {
    return loadJson(cfg.EMAIL_CONTACTS_FILE, []);
}

// extra: optional { domain, role, cc, displayName } — domain groups pass
// these; ordinary single-name contacts (e.g. "jeyshree") never need to.
// Passing role: 'primary' for a domain demotes any OTHER existing primary
// on that same domain to 'secondary' first, so a domain can never silently
// end up with two primaries (resolveContact would then have to guess
// between them). displayName (built 2026-08-04, see proposeDomainRoles'
// own comment) is the real human/company name for use IN an email's
// greeting — separate from `name`, which is only ever the short typed
// lookup key ("mail export") and should never itself appear in a draft.
async function addContact(name, email, extra = {}) {
    if (!name || !email) throw new Error('name and email required');
    if (!isValidEmail(email)) throw new Error('email address looks invalid');
    const { domain, role, cc, displayName } = extra;
    await mutateJson(cfg.EMAIL_CONTACTS_FILE, [], (list) => {
        // GUARD (2026-08-03): actions.js has three separate call sites that
        // auto-save name→address pairings it just resolved (reply_email's
        // direct-sender and forward-extraction paths, draftEmailForConfirm's
        // mail-search fallback). None of them know about domain groups. If
        // any of them ever auto-saved a bare, non-domain-tagged entry whose
        // name happens to equal an EXISTING domain (e.g. "sample", once
        // sample.example is a known domain), that flat entry would win
        // resolveContact's exact-name tier forever and permanently shadow
        // the domain_default resolution — silently reintroducing the exact
        // "stale flat contact never updates" bug the domain-tree redesign
        // exists to kill. Refuse that specific save instead; every other
        // addContact call (explicit domain/role entries, ordinary
        // single-person names) is unaffected.
        if (!domain) {
            const shadowsDomain = list.some((x) => x.domain && (
                x.domain.toLowerCase() === name.toLowerCase() ||
                x.domain.toLowerCase() === `${name.toLowerCase()}.com`
            ));
            if (shadowsDomain) {
                console.warn(`[EMAIL_CONTACTS] Refusing to save bare contact "${name}" — it matches a known domain group and would shadow domain resolution. Use a specific person's name instead.`);
                return list;
            }
        }
        if (domain && role === 'primary') {
            list = list.map((x) => (x.domain && x.domain.toLowerCase() === domain.toLowerCase() && x.role === 'primary')
                ? { ...x, role: 'secondary' }
                : x);
        }
        const i = list.findIndex((x) => x.name.toLowerCase() === name.toLowerCase());
        const entry = { name: String(name).trim(), email: String(email).trim().toLowerCase() };
        if (domain) entry.domain = String(domain).trim().toLowerCase();
        if (role) entry.role = role;
        if (cc) entry.cc = Array.isArray(cc) ? cc : [cc];
        if (displayName) entry.displayName = displayName;
        if (i >= 0) list[i] = { ...list[i], ...entry };
        else list.push(entry);
        return list;
    });
    return true;
}

// Edits an EXISTING contact. the owner, 2026-08-22: "EMAIL CONTACTS doesnt have
// edit option."
//
// Deliberately separate from addContact rather than reusing it. addContact is
// an upsert-by-name, so it cannot express a RENAME — a new name simply
// creates a second record and leaves the original behind, which is how a
// directory quietly fills with duplicates. It also carries a guard that
// silently REFUSES (returns the list untouched) when a bare name collides
// with a known domain group; correct for auto-saves, but an edit that
// silently does nothing while the UI says "saved" is worse than an error.
//
// Everything not being edited is preserved: `domain`, `role`, and any
// standing `cc` survive an address correction, so fixing a typo cannot drop
// someone out of their company group.
async function updateContact(originalName, patch = {}) {
    const from = String(originalName || '').trim();
    if (!from) throw new Error('original contact name is required');

    const nextName = patch.name != null ? String(patch.name).trim() : from;
    if (!nextName) throw new Error('name cannot be empty');
    if (patch.email != null) {
        const e = String(patch.email).trim();
        if (!e) throw new Error('email cannot be empty');
        if (!isValidEmail(e)) throw new Error('email address looks invalid');
    }

    let failure = null;
    await mutateJson(cfg.EMAIL_CONTACTS_FILE, [], (list) => {
        const i = list.findIndex((x) => x.name.toLowerCase() === from.toLowerCase());
        if (i === -1) { failure = `No email contact named "${from}".`; return list; }

        // Renaming onto a name that already belongs to someone else would
        // either clobber them or leave two records competing in
        // resolveContact's exact-name tier. Refuse loudly instead.
        if (nextName.toLowerCase() !== from.toLowerCase()) {
            const clash = list.some((x, j) => j !== i && x.name.toLowerCase() === nextName.toLowerCase());
            if (clash) { failure = `Another contact is already named "${nextName}".`; return list; }
        }

        const entry = { ...list[i], name: nextName };
        if (patch.email != null) entry.email = String(patch.email).trim().toLowerCase();
        // Blanking a display name is a legitimate edit — it falls back to the
        // contact's name — so an empty string DELETES the field rather than
        // being ignored the way addContact's truthy checks would.
        if (patch.displayName != null) {
            const dn = String(patch.displayName).trim();
            if (dn) entry.displayName = dn; else delete entry.displayName;
        }
        // Same for cc: an empty list means "no standing cc any more".
        if (patch.cc != null) {
            const list_ = Array.isArray(patch.cc) ? patch.cc : String(patch.cc).split(',');
            const clean = list_.map((c) => String(c).trim().toLowerCase()).filter(Boolean);
            const bad = clean.find((c) => !isValidEmail(c));
            if (bad) { failure = `Cc address "${bad}" looks invalid.`; return list; }
            if (clean.length) entry.cc = clean; else delete entry.cc;
        }

        // ── THE DOMAIN GROUP IS EDITABLE, 2026-09-20 ────────────────────
        // the owner, looking at a contact the harvest had filed under a
        // HOTMAIL.COM group: "if i want to change the domain-??"
        //
        // She could not. This function copied domain and role straight off
        // the old record and the edit panel said "that stays as it is" — so
        // a wrong grouping was permanent unless she deleted the contact and
        // retyped it, losing the standing Cc with it. That is the same
        // "delete and retype" hole the Edit button was added to close on
        // 2026-08-22, still open for the two fields hardest to get right.
        //
        // An EMPTY domain means "not in a group": the field is deleted along
        // with the role, because a role without a group is a label that
        // resolveContact can never act on.
        if (patch.domain != null) {
            const d = String(patch.domain).trim().toLowerCase();
            if (d) {
                if (!/^[a-z0-9][a-z0-9.\-]*\.[a-z]{2,}$/.test(d)) {
                    failure = `"${patch.domain}" does not look like a domain.`; return list;
                }
                entry.domain = d;
            } else {
                delete entry.domain;
                delete entry.role;
            }
        }
        if (patch.role != null && entry.domain) {
            const r = String(patch.role).trim().toLowerCase();
            if (r && !['primary', 'secondary', 'shared'].includes(r)) {
                failure = `"${patch.role}" is not a role — use primary, secondary or shared.`; return list;
            }
            if (r) entry.role = r; else delete entry.role;
        }

        // ── ONE PRIMARY PER DOMAIN, SAME AS addContact ──────────────────
        // Promoting someone here without demoting the incumbent leaves two
        // primaries, and resolveContact would then pick by list order —
        // which is to say, by accident.
        if (entry.domain && entry.role === 'primary') {
            list = list.map((x, j) => (j !== i && x.domain
                && x.domain.toLowerCase() === entry.domain && x.role === 'primary')
                ? { ...x, role: 'secondary' } : x);
        }

        list[i] = entry;
        return list;
    });

    if (failure) throw new Error(failure);
    return true;
}

async function removeContact(name) {
    await mutateJson(cfg.EMAIL_CONTACTS_FILE, [], (list) =>
        list.filter((x) => x.name.toLowerCase() !== String(name).toLowerCase()));
}

// ── Per-contact standing Cc ("when I mail T, same people every time") ──────
// Built 2026-08-03. Set only after helpers/gmail.js's detectCcPattern finds
// a real recurring pattern AND the owner confirms it (see workflow/actions.js's
// 'await_cc_pattern_confirm' pending) — never written silently. Requires the
// contact to already exist (addContact must have run first); a no-op merge
// (`{ ...list[i], cc: ... }`) preserves every other field on the record.
async function setContactCc(name, ccList) {
    await mutateJson(cfg.EMAIL_CONTACTS_FILE, [], (list) => {
        const i = list.findIndex((x) => x.name.toLowerCase() === String(name).toLowerCase());
        if (i < 0) return list; // nothing to attach the cc to — caller should have saved the contact first
        list[i] = { ...list[i], cc: Array.isArray(ccList) ? ccList : [] };
        return list;
    });
}

// Recorded when the owner says "no" to a detected pattern — stops Jarvis asking
// again on every future email to the same contact. Doesn't block her from
// setting a cc some OTHER way later (dashboard edit, re-detection after
// manually clearing this flag) — it just stops the automatic re-ask.
async function declineCcSuggestion(name) {
    await mutateJson(cfg.EMAIL_CONTACTS_FILE, [], (list) => {
        const i = list.findIndex((x) => x.name.toLowerCase() === String(name).toLowerCase());
        if (i < 0) return list;
        list[i] = { ...list[i], cc_declined: true };
        return list;
    });
}

// Resolve a loosely-typed name (or an already-typed raw address) to a saved
// contact. Five distinct outcomes, so the caller can decide what "just ask,
// are you mentioning this" should actually look like per case:
//   { type: 'exact',          contact }  — typed a raw address, a name matched a saved contact exactly, OR an
//                                           explicit "person from/at company" pinned it to one saved person. Use directly.
//   { type: 'domain_default', contact }  — bare company/domain mention (e.g. "sample"), resolved to that
//                                           domain's marked primary. Use directly — this is a real, deliberate
//                                           default per the owner, not a guess.
//   { type: 'single_partial', contact }  — exactly one saved contact's name contains the typed text. Use directly
//                                           (still shown in the draft preview for a visible confirm before send).
//   { type: 'ambiguous',      matches }  — more than one saved contact matches, OR a domain has multiple
//                                           members and none is marked primary. Caller must ask which one —
//                                           this IS the "are you mentioning this?" case.
//   null                                  — nothing saved matches. Caller falls back to mail search.
function resolveContact(nameOrEmail) {
    const raw = String(nameOrEmail || '').trim();
    if (!raw) return null;
    if (isValidEmail(raw)) return { type: 'exact', contact: { name: raw, email: raw } };

    const contacts = loadContacts();
    const rawLower = raw.toLowerCase();

    // 0. Qualified "person from/at company" — explicit disambiguation.
    // Built 2026-08-04 per the owner: "can I give like send mail to mike from
    // eccomelt?" — lets her name someone specifically within a domain group
    // rather than relying on a bare name being unambiguous on its own (two
    // people with the same first name under different domains), or on the
    // domain's default primary being who she actually means. Only resolves
    // an ALREADY-SAVED person under an ALREADY-KNOWN domain — for a domain
    // that's never been learned yet, this falls through to the normal tiers
    // below (which will end up as a plain mail search on the full phrase,
    // unlikely to resolve well until that domain's been set up via "learn X
    // contacts" or the automatic multi-member check in draftEmailForConfirm).
    const qualified = raw.match(/^(.+?)\s+(?:from|at)\s+(.+)$/i);
    if (qualified) {
        const [, personPart, domainPart] = qualified;
        const qDomain = normalizeDomain(domainPart.trim());
        const qPersonLower = personPart.trim().toLowerCase();
        const siblings = contacts.filter((c) => c.domain && c.domain.toLowerCase() === qDomain);
        if (siblings.length) {
            const match = siblings.find((c) => c.name.toLowerCase() === qPersonLower);
            if (match) return { type: 'exact', contact: match };
            // Domain's known, but not this specific person — genuinely
            // ambiguous (or just wrong), not a mail-search phrase that could
            // ever resolve ("mike from eccomelt" isn't a real search term) —
            // show her who's actually saved there instead of a dead end.
            return { type: 'ambiguous', matches: siblings };
        }
        // Domain not known at all — fall through to the normal tiers.
    }

    // 1. Exact name match — a specific person, e.g. "helen", always wins
    // over any domain-level default. Unchanged from before domain groups.
    const exact = contacts.find((c) => c.name.toLowerCase() === rawLower);
    if (exact) return { type: 'exact', contact: exact };

    // 2. Domain match — only reached when no specific person was named.
    // "sample" matches a record with domain "sample.example" (with or
    // without the typed term including the TLD). Resolves to whichever
    // member is marked role:'primary'; with 2+ members and no primary
    // marked, that's genuinely ambiguous — don't guess which one the owner
    // means, ask (same posture as the name-based ambiguous case below).
    const domainMembers = contacts.filter((c) => {
        if (!c.domain) return false;
        const d = c.domain.toLowerCase();
        return d === rawLower || d === `${rawLower}.com` || d.startsWith(`${rawLower}.`);
    });
    if (domainMembers.length) {
        const primary = domainMembers.find((c) => c.role === 'primary');
        if (primary) return { type: 'domain_default', contact: primary };
        if (domainMembers.length === 1) return { type: 'domain_default', contact: domainMembers[0] };
        return { type: 'ambiguous', matches: domainMembers };
    }

    // 3. Partial name match — unchanged fallback.
    const partials = contacts.filter((c) => c.name.toLowerCase().includes(rawLower));
    if (partials.length === 1) return { type: 'single_partial', contact: partials[0] };
    if (partials.length > 1) return { type: 'ambiguous', matches: partials };

    return null;
}

// "sample" -> "sample.example"; "sample.example" -> unchanged. Shared by
// the WhatsApp domain-learn flow (workflow/actions.js) and the CLI diagnostic
// (scripts/learnDomain.js) so both mean the same thing by "the domain".
function normalizeDomain(term) {
    const t = String(term || '').trim().toLowerCase();
    return t.includes('.') ? t : `${t}.com`;
}

// Given a tally Map (address -> { from, to, cc }) — as returned by
// helpers/gmail.js's tallyAddressesForTerm — propose primary/secondary/
// shared roles for a domain-tree contact group. Pure function, no I/O, so
// both the WhatsApp flow (workflow/actions.js's learnDomainForConfirm) and
// the CLI tool (scripts/learnDomain.js) call this ONE implementation rather
// than keeping their own copies that could quietly drift apart.
//
// Built 2026-08-03 after the owner pointed out that hand-writing per-domain
// seed scripts just relocates the "hardcoding" problem instead of fixing
// it — this proposes from real From/Cc/To frequency instead of a guess:
//   from === 0                                  -> shared (never originates mail)
//   from > 0 but cc >= from*3 (and cc >= 10)     -> shared, UNLESS the display name looks like a real
//                                                   person (see looksLikePersonName below)
//   otherwise                                    -> primary (highest From count) / secondary (everyone else)
//
// REAL BUG (found 2026-08-04, live): eccomelt.com's "Michael Horowitz" got
// classified 'shared' purely from his From/Cc ratio — he sends occasionally
// but gets copied on almost everything, the same numeric pattern as a
// generic mailbox. But a shared/departmental box (docs, purchasing,
// accounts) and a busy person who's cc'd on everything are NOT the same
// thing, and the consequence is real: shared members never get a cc list of
// their own (they're what gets auto-cc'd onto OTHERS' mail, not the other
// way round) — so addressing Michael directly silently dropped everyone
// else who should have been looped in. The display name is the signal the
// pure ratio was missing: "Michael Horowitz" reads as a person; "Eccomelt
// Purchasing" or a bare "Docs" doesn't. Only the ratio-based shared
// classification is gated on this — the from===0 branch is untouched,
// since the owner explicitly confirmed elsewhere (helen@sample, who has
// never sent anything at all) that a real person with zero sent mail should
// still default to shared/auto-cc.
// A name is inferred from the address's local-part UNLESS it's identical to
// the domain term itself (e.g. sample@sample.example when learning
// "sample") — that collision is left unnamed (name: null) rather than
// guessing a label like "docs"; the caller must supply one explicitly. This
// is deliberate: auto-picking that name would just be a different flavor of
// the exact guessing this whole feature exists to avoid.
//
// `name` is ONLY ever a short lookup key (so "mail export" works) — it is
// NOT meant to appear inside an actual email. REAL BUG (found 2026-08-04,
// live): mkmetaltrading's drafted emails greeted "Dear export" because
// nothing distinguished the lookup key from a real name. `displayName`
// (from tallyAddressesForTerm's real From-header capture, e.g. "Marc Kang")
// is carried through separately here so callers can use it for the actual
// email body/greeting while `name` stays the short typed key — null when
// no display name was ever seen in the scanned mail (e.g. the domain's
// been mentioned but this address has never actually sent anything).
// Heuristic, not a verdict — "Michael Horowitz" or "Tiffany Furleigh" reads
// as a real person; a bare "Docs", "Support Team", or "Eccomelt Purchasing"
// doesn't. Two-plus words with none of them a generic/departmental keyword
// is treated as a person's name. False positives/negatives are possible
// (an unusually-named shared inbox, a person who only gave one name) — this
// only gates ONE specific heuristic branch in proposeDomainRoles and every
// proposal is still shown to the owner for review/override before anything
// saves, same as always.
const GENERIC_NAME_WORDS = new Set([
    'team', 'dept', 'department', 'support', 'sales', 'purchasing', 'accounts', 'accounting',
    'info', 'admin', 'administration', 'docs', 'documents', 'documentation', 'service', 'services',
    'office', 'group', 'desk', 'helpdesk', 'notifications', 'billing', 'invoices', 'orders',
    'shipping', 'logistics', 'operations', 'company', 'inc', 'llc', 'ltd', 'corp',
]);
function looksLikePersonName(name) {
    if (!name) return false;
    const words = name.trim().split(/\s+/).filter(Boolean);
    if (words.length < 2) return false; // a single word ("Support", "Docs") reads as generic, not a person
    return !words.some((w) => GENERIC_NAME_WORDS.has(w.toLowerCase().replace(/[^a-z]/g, '')));
}

function proposeDomainRoles(tally, term, domain) {
    const bareTerm = String(term).replace(/\.com$/i, '').toLowerCase();
    const domainAddrs = [...tally.entries()].filter(([addr]) => addr.endsWith(`@${domain}`));

    const proposals = domainAddrs.map(([addr, counts]) => {
        const localPart = addr.split('@')[0];
        const displayName = counts.displayName || null;
        let role;
        if (counts.from === 0) role = 'shared';
        else if (counts.cc >= counts.from * 3 && counts.cc >= 10 && !looksLikePersonName(displayName)) role = 'shared';
        else role = 'candidate'; // resolved to primary/secondary below
        const name = localPart.toLowerCase() === bareTerm ? null : localPart;
        return { addr, counts, role, name, displayName };
    });

    // REAL CASE (found 2026-08-04, live): mkmetaltrading.com has THREE real
    // addresses, and the top two (marckang, export) are tied at From=11
    // each. Picking one as primary here would just be a different flavor of
    // guessing — Array.sort's tie-break (stable, so effectively "whichever
    // was seen in a more recent message") isn't a real signal of who's
    // actually primary, it's an accident of scan order. On an exact tie for
    // the top spot, deliberately leave NOBODY marked primary — resolveContact
    // already asks which person is meant whenever a domain has 2+ members
    // and none is primary, so this just lets that existing "don't guess, ask"
    // path do its job instead of a false-confidence auto-pick.
    const candidates = proposals.filter((p) => p.role === 'candidate');
    if (candidates.length) {
        candidates.sort((a, b) => b.counts.from - a.counts.from);
        const topCount = candidates[0].counts.from;
        const tiedForTop = candidates.filter((c) => c.counts.from === topCount);
        if (tiedForTop.length > 1) {
            for (const c of candidates) c.role = 'secondary';
        } else {
            candidates[0].role = 'primary';
            for (const c of candidates.slice(1)) c.role = 'secondary';
        }
    }
    return proposals;
}

module.exports = {
    updateContact,
    loadContacts, addContact, removeContact, resolveContact, isValidEmail,
    setContactCc, declineCcSuggestion, normalizeDomain, proposeDomainRoles,
};