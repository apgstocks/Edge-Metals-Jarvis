// ── helpers/sheetSyncJob.js — the 11pm run, and the email it sends ────────
//
// the owner, 2026-09-24: "at everyday night,a bot should run which need to update
// my bills and invoices in website from live sheet..if anything is missing,
// enter that as well", with "1 with discrepancy should be notified via email
// report" and "Dry run first — report only, write nothing".
//
// helpers/sheetSync.js decides WHAT would happen and cannot write. This file
// is the part with side effects: it fetches, it emails, and one day it will
// commit. Split that way on purpose — the decision stays testable without a
// network, a mailbox or a live ledger, and the risky half is small enough to
// read in one sitting.
//
// ── WRITING TAKES TWO KEYS, AND NEITHER IS THE DEFAULT ─────────────────────
// A live run needs opts.write === true AND SHEET_SYNC_WRITE=1 in the
// environment. She asked to see a report first; a flag that defaults to
// "write" is one typo away from a night nobody asked for, and this job runs
// while she is asleep.
//
// Until she turns it on, every night is a dry run: read, compare, email, stop.

const sync = require('./metalsSheetSync');

const enabled = () => String(process.env.SHEET_SYNC_WRITE || '').trim() === '1';
const DEFAULT_SINCE = '2026-01-01';
const sinceDate = () => (process.env.SHEET_SYNC_SINCE === undefined
    ? DEFAULT_SINCE : (String(process.env.SHEET_SYNC_SINCE).trim() || null));

// ── THE REPORT ─────────────────────────────────────────────────────────────
// Plain text, because she reads it on a phone at 6am. The summary line first
// so the common case — nothing happened — is answered without scrolling.
function reportText(report, { dryRun, committed }) {
    const L = [];
    L.push(sync.summarise(report));
    L.push('');
    L.push(dryRun
        ? 'DRY RUN — nothing was written. This is what it would have added.'
        : `Written as batch ${committed && committed.batchId ? committed.batchId : '(none)'} — undo it from the Import screen if it looks wrong.`);

    if (report.newBills.length) {
        L.push('', `NEW BILLS (${report.newBills.length})`);
        for (const b of report.newBills.slice(0, 40)) {
            L.push(`  ${b.date || '—'}  ${b.container_no || '—'}  ${b.supplier || '—'}  ${b.description || ''}`);
        }
        if (report.newBills.length > 40) L.push(`  … ${report.newBills.length - 40} more`);
    }
    if (report.newSales.length) {
        L.push('', `NEW INVOICES (${report.newSales.length})`);
        for (const s of report.newSales.slice(0, 40)) {
            L.push(`  ${s.date || '—'}  ${s.invoice_no || '—'}  ${s.container_no || '—'}  ${s.customer || ''}`);
        }
        if (report.newSales.length > 40) L.push(`  … ${report.newSales.length - 40} more`);
    }

    // ── THE DISAGREEMENTS, WHICH ARE THE POINT ─────────────────────────────
    // Nothing here was changed. Both sides are printed so she can see which
    // is right without opening either system.
    const changed = [...report.changedBills, ...report.changedSales];
    if (changed.length) {
        L.push('', `DISAGREEMENTS (${changed.length}) — NOT changed, for you to settle`);
        for (const c of changed.slice(0, 30)) {
            const who = c.invoice_no ? `${c.invoice_no} / ${c.container_no || '—'}` : (c.container_no || c.key);
            L.push(`  ${who}`);
            for (const d of c.differences) {
                L.push(`      ${d.field}: sheet "${d.sheet}"  vs  Jarvis "${d.jarvis}"`);
            }
        }
        if (changed.length > 30) L.push(`  … ${changed.length - 30} more`);
    }

    if ((report.beforeCutoff || []).length) {
        L.push('', `LEFT OUT — dated before ${report.since} (${report.beforeCutoff.length})`);
        L.push('  Not added to Jarvis. Rows already in Jarvis are still compared as usual.');
    }

    if (report.unkeyed.length) {
        L.push('', `UNREADABLE (${report.unkeyed.length}) — no booking and no container, so they cannot be matched`);
        L.push('  These are skipped every night rather than added every night.');
    }
    return L.join('\n');
}

// ── THE RUN ────────────────────────────────────────────────────────────────
// Returns the report and what it did, and never throws at the caller: a cron
// job that throws at 11pm is a silent failure until someone reads the logs.
async function runNightly(opts = {}) {
    const dryRun = !(opts.write === true && enabled());
    const out = { ok: false, dryRun, report: null, committed: null, error: null };
    try {
        const buffer = opts.buffer || await sync.fetchWorkbook(opts.sheetId);
        const parsed = await require('./sheetImport').readWorkbook(buffer);

        const bills = require('./bills').list();
        const sales = require('./sales').list();
        const report = sync.diff({
            sheetBills: parsed.bills || [], sheetSales: parsed.sales || [], bills, sales,
            // the owner, 2026-10-12: nothing from 2025 or earlier is added by the
            // nightly sweep. Only THIS caller opts in; see diff() for why.
            // SHEET_SYNC_SINCE overrides it (set to an empty string to turn the
            // cut-off off again).
            since: opts.since !== undefined ? opts.since : sinceDate(),
        });
        out.report = report;

        if (!dryRun && (report.newBills.length || report.newSales.length)) {
            // Through the SAME commit the Upload screen uses, so the night's
            // work is a batch with an id and an undo — not a scatter of rows
            // that have to be found again one by one.
            //
            // ── PLAN FIRST. commit() TAKES A PLAN, NOT ROWS ────────────────
            // This handed commit() a bare { bills, sales } object, which has
            // no .batch — so commit() threw "nothing planned to commit" on
            // EVERY live night, the job caught it into out.error, and the
            // scheduler logged that sentence as if it were a summary
            // (2026-09-25: "bills from the nightly sync: 0 | sales: 0" after
            // days of running live). plan() is what stamps the batch id,
            // prepares each row through bills.prepareBill/sales.prepareSale
            // and separates the rows that cannot be saved at all.
            const siw = require('./sheetImportWrite');
            const source = `nightly-sheet-sync ${new Date().toISOString().slice(0, 10)}`;
            const planned = siw.plan({ bills: report.newBills, sales: report.newSales }, { source, actor: 'nightly sheet sync' });
            out.refused = planned.refused || [];
            out.committed = await siw.commit(planned, { source, force: true });
        }
        out.ok = true;
    } catch (e) {
        out.error = e.message;
    }
    return out;
}

// Sent to her, once, whatever happened — including the failures. A night the
// job could not run is a night her ledgers did not get the new rows, and
// silence would read as "nothing to add".
async function emailReport(result, opts = {}) {
    const to = opts.to || process.env.SHEET_SYNC_TO || 'owner@sample.example';
    const when = new Date().toLocaleDateString('en-US', { timeZone: 'America/Los_Angeles' });
    const subject = result.error
        ? `Sheet sync FAILED — ${when}`
        : `Sheet sync ${result.dryRun ? '(dry run)' : ''} — ${sync.summarise(result.report)} ${when}`;
    const body = result.error
        ? `The nightly sheet sync could not run.\n\n${result.error}\n\nNothing was written.`
        : reportText(result.report, result);
    const gmail = require('./gmail');
    return gmail.sendEmail({ to, subject, body });
}

module.exports = { runNightly, emailReport, reportText, enabled };
