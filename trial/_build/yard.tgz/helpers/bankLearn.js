// ── helpers/bankLearn.js — what the matcher learns, and from where ────────
//
// the owner, 2026-10-05: "it should able to self learn, self find… figure out why
// there is an issue and it should able to fix that".
//
// ── TWO KINDS OF LEARNING, AND ONLY ONE OF THEM NEEDS A STORE ────────────
// It is worth being precise about this, because a stored "learned fact" that
// drifts from the ledger is worse than no learning at all — it is a
// confident wrong answer.
//
//   1. HOW A CUSTOMER PAYS — do they combine invoices, do they pay in parts,
//      how many days do they take, how much does their bank take in transit.
//      This is NOT stored. It is COMPUTED from sales_receipts.json, which is
//      the record of every receipt she has ever confirmed. So it cannot go
//      stale, cannot disagree with the ledger, needs no migration, and
//      corrects itself the moment she deletes a receipt that was wrong.
//      Deriving it is also the only honest way to call it learned: it is her
//      behaviour, measured, not a setting someone typed.
//
//   2. WHAT A BANK DESCRIPTOR MEANS — that "WIRE IN CUSTOM ALLOYS LLC REF
//      88213" is Custom Alloys. This information exists NOWHERE else in the
//      business, so it is the one thing that genuinely has to be remembered.
//      One answer from her, then every future deposit from that payer
//      resolves itself.
//
// ── IT STILL DOES NOT GUESS ──────────────────────────────────────────────
// helpers/nameMatch.js argues the case against fuzzy matching: a near-miss
// resolves to the wrong company. Here the cost is higher than a misdirected
// email — it allocates real money against the wrong customer's invoice, and
// both ledgers look right until the year end.
//
// So resolution is EXACT (after normalising punctuation), against the
// aliases she has confirmed and against the customer names themselves.
// Anything else is a SUGGESTION — returned separately, shown on the screen,
// and only ever turned into an alias by her pressing something. The engine
// proposes; it never decides who paid.

const path = require('path');
const cfg = require('../config');
const { loadJson, mutateJson } = require('./json');
const { normalizeName } = require('./nameMatch');

// Env-overridable so a test can never write her real file — the same rule
// QB_DECISIONS_FILE follows, and for the same reason.
function FILE() {
    return process.env.BANK_LEARN_FILE
        || path.join(cfg.DATA_DIR, 'bank-learn.json');
}

const round2 = (n) => (typeof n === 'number' && isFinite(n) ? Math.round(n * 100) / 100 : null);
const num0 = (v) => { const n = Number(v); return isFinite(n) ? n : 0; };
const day = (d) => String(d || '').slice(0, 10);

const DEFAULT = { aliases: [] };

function store() {
    const raw = loadJson(FILE(), DEFAULT);
    // loadJson never throws and does not merge defaults, so a file that
    // somebody hand-edited into an array or a string must not take the
    // matcher down with it. A broken learning file means "nothing learned
    // yet", which degrades to asking — the safe direction.
    if (!raw || typeof raw !== 'object' || Array.isArray(raw)) return { aliases: [] };
    return { aliases: Array.isArray(raw.aliases) ? raw.aliases : [] };
}

function listAliases() { return store().aliases.slice(); }

// ── remember ─────────────────────────────────────────────────────────────
// Keyed on the NORMALISED descriptor, so "WIRE IN  CUSTOM-ALLOYS" and "Wire
// In Custom Alloys" are one alias rather than two.
async function learnAlias(descriptor, customer, { by = null, why = null } = {}) {
    const key = normalizeName(descriptor);
    if (!key) throw new Error('nothing to learn from an empty description');
    const name = String(customer || '').trim();
    if (!name) throw new Error('learn it as whose?');
    const row = {
        key, descriptor: String(descriptor).trim(), customer: name,
        at: new Date().toISOString(), by: by || null, why: why || null,
    };
    await mutateJson(FILE(), DEFAULT, (all) => {
        const s = (all && typeof all === 'object' && !Array.isArray(all)) ? all : { aliases: [] };
        s.aliases = (Array.isArray(s.aliases) ? s.aliases : []).filter((a) => a.key !== key);
        s.aliases.push(row);
        return s;
    });
    return row;
}

// Un-learning has to be as easy as learning. A wrong alias silently
// misallocates every future deposit from that payer, so there must be a way
// back that does not involve editing JSON on a server.
async function forgetAlias(descriptor) {
    const key = normalizeName(descriptor);
    let gone = null;
    await mutateJson(FILE(), DEFAULT, (all) => {
        const s = (all && typeof all === 'object' && !Array.isArray(all)) ? all : { aliases: [] };
        const rows = Array.isArray(s.aliases) ? s.aliases : [];
        gone = rows.find((a) => a.key === key) || null;
        s.aliases = rows.filter((a) => a.key !== key);
        return s;
    });
    return gone;
}

// ── resolve: exact only ──────────────────────────────────────────────────
// `customers` is the list of names in her ledger. Returns a name or null.
// Never a best effort.
function resolverFrom(aliases, customers) {
    const byKey = new Map((aliases || []).map((a) => [a.key, a.customer]));
    const byName = new Map();
    for (const c of (customers || [])) {
        const k = normalizeName(c);
        if (!k) continue;
        // A duplicate normalised customer name means two records that are the
        // same company spelled differently. Resolving to either would be a
        // coin flip, so it resolves to NEITHER and she gets asked — which is
        // also how she finds out she has a duplicate.
        if (byName.has(k) && byName.get(k) !== c) byName.set(k, null);
        else if (!byName.has(k)) byName.set(k, c);
    }
    // ── THE NAME, NOT THE WHOLE LINE (2026-11-05) ────────────────────────
    // the owner: "why my jarvis was not able to identify that?" — a deposit
    // whose line began "ARIS ENTERPRISES DES:ACH Pmt ID:XXXXX620487 ...".
    //
    // This normalised the WHOLE descriptor and looked for a ledger name
    // equal to it. Nothing is called
    // "arisenterprisesdesachpmtidxxxxx620487indnsampleyardcometalsinc..." so it found
    // nothing and asked her. The company name was the first two words.
    //
    // Worse, the alias she would then create was keyed on that same full
    // line — payment id and PO number included — so the NEXT ARIS payment,
    // carrying a different payment id, missed again. The screen promised
    // "name it once and every future deposit from them matches itself" and
    // that promise was false. Proven by changing only the reference on a
    // second line: with the alias in place it still resolved to null.
    //
    // helpers/bankPayee.js reads the counterparty out of the bank's own
    // field markers. That is PARSING, not the near-miss guessing
    // nameMatch.js refuses to do — what comes out is still matched exactly,
    // and an unparseable line still returns null and still asks her.
    //
    // The full-line key is tried FIRST so every alias she has already
    // created keeps working untouched.
    const { payeeOf } = require('./bankPayee');
    return (descriptor) => {
        const whole = normalizeName(descriptor);
        if (whole) {
            if (byKey.has(whole)) return byKey.get(whole);
            if (byName.has(whole)) return byName.get(whole) || null;
        }
        const name = payeeOf(descriptor);
        if (!name) return null;
        const k = normalizeName(name);
        if (!k) return null;
        if (k !== whole) {
            if (byKey.has(k)) return byKey.get(k);
            if (byName.has(k)) return byName.get(k) || null;
        }

        // ── THE BANK TRUNCATES THE NAME, AND THAT IS NOT A NEAR MISS ─────
        // the owner, shown a line she still had to confirm: "still bad".
        //
        //   ALEE METAL TRADI   <- what the bank printed
        //   A.LEE METAL TRADING <- what she calls them
        //
        // Banks cut the payee at a fixed width. The read name is then a
        // PREFIX of the real one, which is a different thing from the
        // near-miss helpers/nameMatch.js refuses — that refusal is about
        // two companies looking alike, and it still stands below.
        //
        // THREE CONDITIONS, ALL REQUIRED, because this decides where her
        // money is allocated:
        //   1. EXACTLY ONE ledger name starts with what was read. Two and
        //      it is ambiguous, which is the danger nameMatch names, and
        //      she is asked.
        //   2. At least 8 characters were read. "AJ" must never select
        //      "AJAX TRADING" — the same instinct bankLearn's own comment
        //      records, with a mechanism that cannot wave a long generic
        //      name through.
        //   3. It is a prefix, not a fuzzy distance. A cut name shares its
        //      whole beginning; nothing else qualifies.
        //
        // Reversible in one block if she wants only exact matching back.
        if (k.length >= 8) {
            const starts = [];
            for (const [nk, who] of byName) {
                if (who && nk.startsWith(k)) starts.push(who);
            }
            const uniq = [...new Set(starts)];
            if (uniq.length === 1) return uniq[0];
        }
        return null;
    };
}

// ── suggest: this is where name matching lives, and it decides nothing ────
// A bank descriptor is a customer name buried in noise, so some kind of
// containment is the only thing that could ever match one. It is also
// exactly what nameMatch.js refuses to do automatically, and it is right to
// refuse: a near-miss resolves to the wrong company.
//
// ── THE GUARD I HAD HERE WAS A GUESS, AND IT IS GONE ─────────────────────
// This used to require a minimum normalised name length (MIN_SUGGEST = 6) so
// that "AJ" could not match "AJAX TRADING LLC". That is the right instinct
// and the wrong mechanism: "Sample Scrap" is ten characters and both its words
// are near-generic, so a length threshold waves it through anything.
//
// helpers/partyName.js answers the same question properly — a name counts
// only when a word that is THEIRS ALONE appears, and when nothing
// distinctive is left ("5 Core Trading Inc") only an outright containment of
// the whole name counts. That logic was extracted from
// scripts/qb-bank-match.js, where it has been running against her real bank
// exports since September and where it was written because a similarity
// match put a $60,000 wire against the wrong supplier.
//
// It is still only a SUGGESTION. Ambiguous hits are all returned rather than
// the first shown as certain, and nothing here resolves anything: the engine
// proposes, she decides, and her decision becomes an alias.
const partyName = require('./partyName');

function suggestParty(descriptor, customers) {
    // ── SEARCH THE NAME, NOT THE WHOLE LINE (2026-11-05) ─────────────────
    // the owner, shown "could be Sample Yard Co Metals Recycling or A.LEE METAL TRADING":
    // "How can it assume its edge recycling?"
    //
    // It did not assume. It matched substrings over the WHOLE descriptor,
    // and an ACH line carries INDN: — the RECEIVER, which is Sample itself:
    //
    //   ALEE METAL TRADI DES:ACH Pmt ID:XXXXX81012 INDN:Sample Yard Co Metals Inc. ...
    //
    // So her own company was in the haystack on EVERY incoming payment, and
    // a clear answer became "too close to call". Searching the name
    // helpers/bankPayee.js reads instead leaves exactly one candidate.
    //
    // Falls back to the raw text when no name can be read, so a descriptor
    // this cannot parse still gets the old, wider search rather than none.
    // ONE thing is removed: the value of INDN:, which on a deposit is the
    // RECEIVER — Sample itself. Searching the whole line put her own company
    // in the haystack on every incoming payment. Prose and every other
    // field stay, because two companies in one description must BOTH be
    // offered and some banks print the name after the first marker.
    const { withoutSelfFields } = require('./bankPayee');
    const d = withoutSelfFields(descriptor);
    if (!d.trim()) return [];
    const hits = [];
    for (const c of (customers || [])) {
        if (!String(c || '').trim()) continue;
        if (!partyName.nameHit(d, c)) continue;
        // How much of the name is actually distinctive. Used only to order
        // the suggestions — a company identified by two words of its own is
        // a better guess than one identified by a single short word.
        const own = partyName.words(c);
        hits.push({ customer: c, distinctive: own.length, len: partyName.squash(c).length });
    }
    hits.sort((a, b) => b.distinctive - a.distinctive || b.len - a.len
        || String(a.customer).localeCompare(String(b.customer)));
    return hits.map((h) => ({ customer: h.customer, basis: 'name found in the bank description' }));
}

// ── measure: how each customer actually pays ──────────────────────────────
// Pure. `receipts` is salesReceipts.list(), `salesById` a Map of sale id to
// { date, amount }. Returns a plain object keyed by customer.
//
// EVERY FIELD CARRIES ITS SAMPLE COUNT. A pattern derived from one receipt is
// not a pattern, and the scorer must be able to tell the difference between
// "this customer always combines" and "they did it once in March".
function patternsFromHistory(receipts = [], salesById = new Map()) {
    const out = {};
    const at = (c) => {
        if (!out[c]) {
            out[c] = {
                receipts: 0, combines: false, combinedCount: 0,
                partPays: false, partCount: 0,
                typicalDays: null, daySamples: [],
                feeAllowance: 0, feeSamples: 0,
            };
        }
        return out[c];
    };

    for (const r of (receipts || [])) {
        const c = String((r && r.customer) || '').trim();
        if (!c) continue;
        const p = at(c);
        p.receipts += 1;
        const allocs = Array.isArray(r.allocations) ? r.allocations : [];

        if (allocs.length > 1) { p.combinedCount += 1; p.combines = true; }

        for (const a of allocs) {
            const sale = salesById.get ? salesById.get(a.sale_id) : (salesById || {})[a.sale_id];
            if (sale && isFinite(Number(sale.amount))) {
                // A part payment is an allocation smaller than the invoice it
                // is against, allowing for whatever was written off on it.
                const covered = num0(a.amount) + num0(a.deduction_amount);
                if (covered + 0.005 < num0(sale.amount)) { p.partCount += 1; p.partPays = true; }
            }
            if (sale && sale.date && r.date) {
                const g = Math.round((Date.parse(day(r.date) + 'T00:00:00Z')
                    - Date.parse(day(sale.date) + 'T00:00:00Z')) / 86400000);
                if (isFinite(g) && g >= 0 && g < 1000) p.daySamples.push(g);
            }
            // ── ONLY bank_charge BECOMES AN ALLOWANCE ────────────────────
            // A 'discount' is money she AGREED to give up — a negotiation,
            // not a predictable transit fee. Rolling discounts into the
            // allowance would teach the matcher to silently close any invoice
            // this customer underpays, which is the opposite of useful: a
            // short payment she did not agree to is exactly the thing she
            // needs to see.
            if (a.deduction_reason === 'bank_charge') {
                const d = num0(a.deduction_amount);
                if (d > 0) { p.feeSamples += 1; p.feeAllowance = Math.max(p.feeAllowance, round2(d)); }
            }
        }
    }

    for (const c of Object.keys(out)) {
        const p = out[c];
        if (p.daySamples.length) {
            const s = p.daySamples.slice().sort((a, b) => a - b);
            // MEDIAN, not mean. One invoice paid nine months late drags a mean
            // far enough to make every normal payment look early.
            p.typicalDays = s.length % 2
                ? s[(s.length - 1) / 2]
                : Math.round((s[s.length / 2 - 1] + s[s.length / 2]) / 2);
        }
        delete p.daySamples;
    }
    return out;
}

// ── RULES: "a line like this is always X" ────────────────────────────────
// the owner approved, on the Bank mock-up, remembering that a line such as
// "WIRE IN FEE" is a bank charge so she is never asked again.
//
// What a rule DOES is deliberately small: it SETS ASIDE matching rows, with
// the rule written into the reason, exactly as if she had pressed "Set aside"
// and typed it. That is reversible (Put back), explainable at tax time, and
// creates nothing in her books. A rule that CREATED expense records from a
// description would be the bulk-create-from-a-guess this screen refuses
// everywhere else.
//
// Guard rails, each because the opposite has a cost:
//   · a rule has a direction (in or out). "WIRE IN" as a money-in rule would
//     set aside every customer's wire, so a rule can only be made from a row
//     she is looking at, and it takes that row's direction;
//   · the text must be 4+ characters and not only digits;
//   · rows already matched or already set aside are never touched.
const RULE_LABELS = ['Bank charge', 'Transfer fee', 'Card fee', 'Tax payment', 'Loan repayment', 'Owner', 'Not business'];
const ruleKey = (t) => String(t || '').toUpperCase().replace(/\s+/g, ' ').trim();

function listRules() {
    const raw = loadJson(FILE(), DEFAULT);
    return raw && Array.isArray(raw.rules) ? raw.rules.slice() : [];
}

function cleanRule(input) {
    const b = input || {};
    const text = ruleKey(b.text);
    if (text.length < 4 || /^[\d\s.,-]+$/.test(text)) throw new Error('a rule needs at least four letters of the bank description');
    const direction = String(b.direction || '');
    if (!['in', 'out'].includes(direction)) throw new Error('a rule is for money in or money out — make it from a row');
    const label = String(b.label || '').trim();
    if (!label) throw new Error('say what these lines are — for example "Bank charge"');
    return { text, direction, label };
}

function ruleHits(rule, rows) {
    return (rows || []).filter((r) => r && !r.excluded && !r.matched && r.direction === rule.direction
        && ruleKey(`${r.desc || ''} ${r.party || ''}`).includes(rule.text));
}

async function addRule(input, { by = null } = {}) {
    const r = cleanRule(input);
    const row = { ...r, at: new Date().toISOString(), by: by || null };
    await mutateJson(FILE(), DEFAULT, (all) => {
        const s = (all && typeof all === 'object' && !Array.isArray(all)) ? all : { aliases: [] };
        s.rules = (Array.isArray(s.rules) ? s.rules : []).filter((x) => !(x.text === r.text && x.direction === r.direction));
        s.rules.push(row);
        return s;
    });
    return row;
}

async function deleteRule(text, direction) {
    const t = ruleKey(text);
    let gone = null;
    await mutateJson(FILE(), DEFAULT, (all) => {
        const s = (all && typeof all === 'object' && !Array.isArray(all)) ? all : { aliases: [] };
        const rows = Array.isArray(s.rules) ? s.rules : [];
        gone = rows.find((x) => x.text === t && x.direction === direction) || null;
        s.rules = rows.filter((x) => !(x.text === t && x.direction === direction));
        return s;
    });
    return gone;
}

// Sets aside every live row a rule covers. Returns what it did, per rule.
async function applyRules({ by = 'rule', only = null } = {}) {
    const ledger = require('./bankLedger');
    const rules = only ? [only] : listRules();
    const done = [];
    for (const rule of rules) {
        for (const row of ruleHits(rule, ledger.list())) {
            await ledger.exclude(row.id, `${rule.label} — rule "${rule.text}"`, by);
            done.push({ id: row.id, rule: rule.text, label: rule.label });
        }
    }
    return { applied: done.length, rows: done };
}

module.exports = {
    FILE, listAliases, learnAlias, forgetAlias,
    RULE_LABELS, listRules, cleanRule, ruleHits, addRule, deleteRule, applyRules,
    resolverFrom, suggestParty, patternsFromHistory,
    // Re-exported so a caller has one place to look, and so a test can prove
    // this file uses the shared logic rather than a copy of it.
    partyName,
};
