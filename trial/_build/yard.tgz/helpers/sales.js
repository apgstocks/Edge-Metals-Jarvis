// ── helpers/sales.js — what a container sold for ─────────────────────────
// the owner, 2026-09-09: "In sales tab-i want customer name,date,invoice number,
// HBL number,Proforma date,Reference,weight,invoice price,invoice amount,
// Freight charges to be there"
//
// SAMPLE YARD CO METALS, NOT SAMPLE YARD CO YARD. Her first sentence in that message was "This is
// for sample yard co metals not for sample yard co yard", and it decides where this file lives.
//
// ── WHY THIS IS NOT THE SALES THAT ALREADY EXIST ─────────────────────────
// The app already has "sales": loads with kind:'sale' (helpers/loadDrafts.js,
// helpers/pdf.js, helpers/spendReport.js all branch on it). Those are scrap
// sold OUT OF THE YARD — a buyer, a weighbridge ticket, a load sheet.
//
// Her columns are not those columns. An HBL number is a House Bill of Lading;
// a proforma date and freight charges belong to an export shipment. This is
// the freight side selling a container that went on a vessel, and bolting
// these fields onto the yard's load record would have put ocean paperwork on
// a scrap ticket and quietly changed what a yard "sale" means.
//
// So: a register of its own, and the pair to helpers/bills.js. A bill is what
// a container COST her; a sale is what it SOLD for. Same shape, same
// discipline, same arithmetic rules — deliberately, so the two tabs cannot
// disagree about what a ton is.
//
// ── THE PRICE UNIT IS bills.js's DECISION, NOT A SECOND COPY ─────────────
// Her rule, given for the bill side: "if price is in cents or less than 10
// dollars,go with net lbs*price else net mt*price". Scrap is quoted the same
// way whichever direction it is moving, so the same rule applies here — and
// it is IMPORTED rather than restated. Two implementations of one $10
// threshold is two chances to drift, and the drift would be a factor of 2204
// on an invoice. helpers/payments.js's PAYMENT_MODES comment makes the same
// argument about money constants.

const cfg = require('../config');
const { loadJson, mutateJson } = require('./json');
const bills = require('./bills');

const round2 = (n) => (typeof n === 'number' && isFinite(n) ? Math.round(n * 100) / 100 : null);
const round3 = (n) => (typeof n === 'number' && isFinite(n) ? Math.round(n * 1000) / 1000 : null);

// Null, not zero — same reasoning as bills.js. A missing weight is a sale
// nobody has finished, and treating it as 0 shows a confident $0 invoice.
function num(v) {
    if (v === null || v === undefined || v === '') return null;
    const n = typeof v === 'number' ? v : parseFloat(String(v).replace(/[$,\s]/g, ''));
    return isFinite(n) ? n : null;
}

// ── THE ARITHMETIC ───────────────────────────────────────────────────────
// Pure and exported on its own, like bills.compute.
//
// ONE WEIGHT, NOT SIX. The bill side derives its net from gross minus four
// tares because that is what a weighbridge gives her. By the time a container
// is sold the weight is settled and she gives it directly — so this takes the
// number she typed and does not invent a tare structure she did not ask for.
// `weight_unit` says which scale that number is on.
function compute(input) {
    const s = input || {};
    const weight = num(s.weight);

    // Which scale her weight is on. Explicit wins; otherwise pounds, because
    // that is what the yard scale and the bill side both produce and a
    // five-figure number is not metric tons.
    const wUnit = s.weight_unit === 'mt' || s.weight_unit === 'lb'
        ? s.weight_unit
        : (weight === null ? null : (weight >= 1000 ? 'lb' : 'mt'));

    const lb = weight === null ? null : (wUnit === 'mt' ? round3(weight * bills.LB_PER_MT) : round3(weight));
    const mt = weight === null ? null : (wUnit === 'mt' ? round3(weight) : round3(weight / bills.LB_PER_MT));

    const price = num(s.invoice_price);
    // bills.js's threshold, imported. See the header for why this is not
    // written out again.
    const unit = s.price_unit === 'lb' || s.price_unit === 'mt'
        ? s.price_unit
        : (price === null ? null : (price < bills.PER_LB_CEILING ? 'lb' : 'mt'));

    let amount = null;
    if (price !== null && unit) {
        amount = unit === 'lb'
            ? (lb === null ? null : round2(lb * price))
            : (mt === null ? null : round2(mt * price));
    }

    // ── SEVERAL GRADES ON ONE INVOICE ────────────────────────────────────
    // the owner, 2026-09-10: "Once bill thing are fixed,i want outgoing sales to
    // be fixed to support multi item in a container."
    //
    // The SAME cleanItems as the purchase side, imported rather than written
    // again. Two implementations of "a container holding several grades"
    // would drift, and the two sides are joined on booking + container for
    // margin — the moment they disagree about how a line is priced, that
    // margin is comparing two different things.
    //
    // So a sale line takes the same shapes a bill line does: a plain weight,
    // or a full weighbridge ticket with its own gross and tares.
    let items = [];
    try { items = bills.cleanItems(s.items); } catch (e) { items = []; }
    const itemsWeightLb = items.length
        ? round3(items.reduce((t, i) => t + (i.weight || 0), 0)) : null;
    const itemsAmount = items.length && items.every((i) => i.amount !== null)
        ? round2(items.reduce((t, i) => t + i.amount, 0)) : null;

    // The lines decide the weight and the money when there are lines. Her own
    // typed figures are KEPT and reported as a conflict — same rule as the
    // invoice amount, because a number she entered is a statement.
    const typedLb = lb;
    const lbUsed = items.length && itemsWeightLb !== null ? itemsWeightLb : lb;
    const mtUsed = lbUsed === null ? null : round3(lbUsed / bills.LB_PER_MT);
    const weightConflict = (items.length && typedLb !== null && lbUsed !== null
        && Math.abs(typedLb - lbUsed) >= 0.001) ? round3(typedLb - lbUsed) : null;
    if (itemsAmount !== null) amount = itemsAmount;

    // An invoice amount she typed WINS. The invoice is the document of
    // record; if our arithmetic disagrees that is a conversation to have, not
    // a number to overwrite. Identical rule to bills.js, and the difference is
    // reported rather than hidden.
    const stated = num(s.invoice_amount);
    const amountUsed = stated !== null ? stated : amount;

    const freight = num(s.freight_charges);

    // ── NET IS AFTER FREIGHT, AND IT IS NOT A GUESS ──────────────────────
    // Not one of her ten columns, so it is returned but NOT added to COLUMNS
    // below — the table shows what she asked for. It is here because the
    // totals row needs it: an invoice total that ignores freight overstates
    // what the shipment actually earned, and she asked for freight to be on
    // the row precisely because it comes off the top.
    const net = amountUsed === null ? null : round2(amountUsed - (freight || 0));

    // ── CHARGES ──────────────────────────────────────────────────────────
    // freight_charges predates the charge list and is still written by rows
    // entered before 2026-09-10. Rather than leave that money uncounted, a
    // legacy value with no charge list becomes one — so nothing disappears
    // and nothing is counted twice. net_of_freight keeps its old meaning
    // exactly, because three tests and the totals strip read it.
    let charges = [];
    try { charges = cleanCharges(s.charges); } catch (e) { charges = []; }
    if (!charges.length && freight) {
        charges = [{ id: 'CHG_LEGACY_FREIGHT', what: 'Freight', amount: round2(freight),
                     direction: 'out',
                     why: 'Entered as the Freight charges column before charges had notes.' }];
    }
    const sumWhere = (d) => round2(charges.filter((c) => c.direction === d)
        .reduce((t, c) => t + c.amount, 0)) || 0;
    const chargesIn = sumWhere('in');    // the customer pays these on top
    const chargesOut = sumWhere('out');  // Sample Yard Co Metals pays these

    // ── COMMISSION ───────────────────────────────────────────────────────
    // the owner, 2026-09-10, asked which weight it runs on: "The invoiced weight
    // (sale)". So it follows the document the customer holds and moves if the
    // invoice is revised — deliberately NOT the bill's net weight, which can
    // differ after reweighing at destination.
    const perMt = num(s.commission_per_mt);
    // Off the INVOICED weight, which is the lines' total once there are
    // lines — otherwise an agent would be paid on a figure the invoice does
    // not show.
    const commissionComputed = (perMt === null || mtUsed === null) ? null : round2(mtUsed * perMt);
    const commissionStated = num(s.commission_amount);
    const commission = commissionStated !== null ? round2(commissionStated) : commissionComputed;

    // What the customer owes: the invoice plus anything rebilled to them.
    const receivable = amountUsed === null ? null : round2(amountUsed + chargesIn);

    return {
        weight_unit: wUnit,
        weight_lb: lbUsed,
        weight_mt: mtUsed,
        items,
        items_weight: itemsWeightLb,
        items_amount: itemsAmount,
        weights_from_items: items.length > 0,
        weight_conflict: weightConflict,
        price_unit: unit,
        computed_amount: amount,
        amount: amountUsed,
        amount_is_stated: stated !== null,
        amount_differs: (stated !== null && amount !== null && Math.abs(stated - amount) >= 0.01)
            ? round2(stated - amount) : null,
        net_of_freight: net,

        charges,
        charges_in_total: chargesIn,
        charges_out_total: chargesOut,
        receivable,
        commission_computed: commissionComputed,
        commission_amount: commission,
        commission_is_stated: commissionStated !== null,
        // Everything this container costs Sample Yard Co Metals on the sale side. The
        // purchase side (supplier + trucking) lives on the matching Bill, and
        // the two join on booking + container.
        sale_side_cost: round2(chargesOut + (commission || 0)),
    };
}

// ── OTHER CHARGES, EACH WITH A REASON ────────────────────────────────────
// the owner, 2026-09-10, asked which direction freight money flows: "i want to
// have other charges,with a note symbol,so that it will have detailed
// description of what charged and sample why?"
//
// A better answer than the question. A fixed Freight column can state that
// $450 exists and can never state that it is three days' detention at Busan
// caused by the customer's late clearance — which is the only form in which
// that number can be defended when they query the invoice three months on.
// So: a list, and the note is REQUIRED. A charge nobody can explain is a
// charge that gets written off.
//
// DIRECTION IS PER CHARGE, NOT PER COMPANY. Ocean freight paid to the carrier
// and detention rebilled to the customer sit on the same container and move
// opposite ways. One flag on the store could not have said that, and the
// money would have been added where it should have been subtracted.
const CHARGE_DIRECTIONS = ['in', 'out'];   // in = customer pays me, out = I pay

function cleanCharges(input) {
    const out = [];
    for (const c of (Array.isArray(input) ? input : [])) {
        if (!c) continue;
        const what = String(c.what || '').trim();
        const amount = round2(num(c.amount));
        const why = String(c.why || c.note || '').trim();
        // A blank line in the form is not an error, it is a blank line.
        if (!what && amount === null && !why) continue;
        if (!what) throw new Error('a charge needs a name — what is it for?');
        if (amount === null || amount <= 0) throw new Error(`"${what}" needs an amount greater than zero`);
        if (!why) throw new Error(`"${what}" needs a note saying why — that is the whole point of it being a charge and not a column`);
        const direction = CHARGE_DIRECTIONS.includes(String(c.direction || '').trim())
            ? String(c.direction).trim()
            : null;
        if (!direction) {
            throw new Error(`"${what}" needs to say whether you pay it or the customer does`);
        }
        // ── A STABLE ID PER CHARGE ───────────────────────────────────────
        // helpers/salesSettlements.js pays these off one at a time, so an
        // allocation has to name WHICH charge. By array index it would follow
        // the wrong charge the first time one is deleted from the middle —
        // and it would follow it silently, moving a settled freight payment
        // onto an unrelated detention line. An id she never sees, minted once
        // and preserved on every later save.
        const id = String((c && c.id) || '').trim()
            || `CHG_${Date.now().toString(36)}${Math.random().toString(36).slice(2, 7)}`;
        out.push({ id, what, amount, direction, why });
    }
    return out;
}

// Her ten columns, in her order. `derived: true` marks the two this file
// computes, so the client renders them read-only and cannot post a total that
// does not follow from its own weight and price.
// How she gets paid. A closed list: LC and TT are the two, and anything else
// in this box is a typo rather than a third arrangement.
const TERMS = ['LC', 'TT'];

// ── AND HOW IT SHIPS, WHICH IS A DIFFERENT QUESTION ──────────────────────
// the owner, 2026-09-10: "rename terms with payment terms and next to it should
// be shipment terms."
//
// Two things were living under one word. LC/TT says when the money moves;
// FOB/CIF says where her responsibility for the container ends — and that
// second one decides whether ocean freight is her cost or the customer's,
// which is exactly the charge-direction question the charge list asks per
// line. Suggested rather than enforced: Incoterms have editions and she
// trades on terms this file has no business refusing.
const SHIPMENT_TERMS = ['FOB', 'CFR', 'CIF', 'EXW', 'FAS', 'DAP', 'DDP'];

const COLUMNS = [
    // ── BOOKING FIRST, THEN CONTAINER ────────────────────────────────────
    // the owner, 2026-09-10: "bookng first then container no", correcting the
    // mockup. It is also the correct order for a reason worth writing down:
    // a container number is NOT unique — MSKU1111111 sails again next year
    // with different metal in it — so the booking has to come with it.
    // Reading booking-first groups the containers under their shipment, which
    // is how the business thinks about them, and it matches helpers/bills.js
    // so the two tables join on the same pair.
    //
    // ── AND THE PAIR IS NOT UNIQUE EITHER ────────────────────────────────
    // This said "the booking is what makes it unique" until 2026-09-19, when
    // the owner corrected it: "booking never makes it unique.sometimes diff
    // container under same booking.sometimes diff items in same container."
    //
    // The correction matters because code was written on the old sentence.
    // helpers/margin.js kept ONE row per booking+container and threw the rest
    // away — $15,955 of revenue missing from a single four-grade container —
    // and duplicates() called every multi-grade container a duplicate. Both
    // are fixed; the wording is fixed here so the next reader does not rebuild
    // the same assumption.
    //
    // booking + container identifies a CONTAINER. Booking + container + grade
    // identifies a ROW.
    { key: 'booking_no',     label: 'Booking no',     group: 'shipment' },
    { key: 'container_no',   label: 'Container no',   group: 'shipment' },
    { key: 'terms',           label: 'Payment terms',  group: 'shipment', choices: TERMS,
      hint: 'LC or TT — when the money moves' },
    { key: 'shipment_terms',  label: 'Shipment terms', group: 'shipment', choices: SHIPMENT_TERMS,
      suggest: true, hint: 'FOB, CFR, CIF … — where your responsibility ends' },
    // In its own group so the FORM renders the line editor beside it — the
    // same group id bills uses, which is what dashboard/index.html keys the
    // item table on. Without it the backend took multi-grade sales and the
    // form had nowhere to type them, which is where this sat for a day.
    { key: 'item',            label: 'Item',           group: 'items', suggest: true },

    { key: 'customer',       label: 'Customer name',  group: 'customer', suggest: true },
    { key: 'date',           label: 'Date',           group: 'customer', date: true },
    { key: 'reference',      label: 'Reference',      group: 'customer' },

    { key: 'invoice_no',     label: 'Invoice number', group: 'documents' },
    { key: 'hbl_no',         label: 'HBL number',     group: 'documents', placeholder: 'House B/L' },
    { key: 'proforma_date',  label: 'Proforma date',  group: 'documents', date: true },

    { key: 'weight',         label: 'Weight',         group: 'money', num: true, unit: 'lbs',
      hint: 'pounds unless you say otherwise' },
    { key: 'invoice_price',  label: 'Invoice price',  group: 'money', num: true, unit: '$',
      hint: 'under $10 is read as per lb, $10+ as per MT' },
    // Same split as bills: stored under `amount`, typed as `invoice_amount`,
    // and hers wins over the computed figure.
    { key: 'amount',         label: 'Invoice amount', group: 'money', derived: true, unit: '$',
      writeKey: 'invoice_amount', num: true, hint: 'leave blank to use the computed figure' },
    // Commission runs off the INVOICED weight — her answer when asked, over
    // the purchased weight on the bill. commission_amount is derived and also
    // writable, same rule as the invoice amount: an agent's own figure wins.
    { key: 'commission_per_mt', label: 'Commission / MT', group: 'money', num: true, unit: '$',
      hint: 'per metric ton of the invoiced weight' },
    { key: 'commission_amount', label: 'Commission amount', group: 'money', derived: true,
      unit: '$', writeKey: 'commission_amount', num: true,
      hint: 'leave blank to use weight x rate' },

    // Filled from helpers/salesReceipts.js in listWithTotals, never typed.
    // "Payment received amount" from her list — as a figure that follows from
    // the receipts, so it cannot say settled while the bank says otherwise.
    { key: 'received',       label: 'Received',       group: 'money', derived: true, unit: '$' },
    { key: 'balance',        label: 'Balance',        group: 'money', derived: true, unit: '$' },
];

// `freight_charges` is GONE from the columns and deliberately still writable:
// rows entered before 2026-09-10 carry it, compute() folds it into the charge
// list so the money is not lost, and the totals strip still reads
// net_of_freight. New charges go in `charges`, where they can carry a note.
const LEGACY_WRITABLE = ['freight_charges'];

// Her ten, in the order she listed them, for the table. The form uses GROUPS.
// Her order, 2026-09-10: "i wnt proforma date on right of item .next to it
// should be reference .rename terms with payment terms and next to it should
// be shipment terms."
const TABLE_ORDER = ['booking_no', 'container_no', 'date', 'hbl_no', 'invoice_no',
    'customer', 'terms', 'shipment_terms', 'item', 'proforma_date', 'reference',
    'weight', 'invoice_price', 'amount', 'received', 'balance'];

const GROUPS = [
    { id: 'shipment',  label: 'Shipment' },
    { id: 'customer',  label: 'Customer' },
    { id: 'documents', label: 'Documents' },
    // the owner, 2026-09-10: "boss what if i have multiple items in sales under
    // the same container". compute() has taken them since this morning; this
    // is the group the form hangs the line editor off, exactly as bills does.
    { id: 'items',     label: 'Items and weights', full: true, keys: ['item'] },
    { id: 'money',     label: 'Weight & money' },
];

// ── WHICH COLUMNS THE INVOICE REGISTER SHOWS (2026-11-07) ────────────────
// the owner: "bill and invoice tab data are unevenly spaced .mny blank in
// between" — and then, exactly: "inv register i want date first,bkg no,cont
// no,hbl no it can be removed,i want inv no,customer name,then payment
// terms,shioment terms removed,rest can be there".
//
// The blanks were the cause, not the symptom. Bills has marked its core
// columns since 2026-10 and shows nine, with the rest one click away under
// the row. SALES NEVER DID — so the Invoice register rendered all sixteen,
// including the ones that are empty on most rows, and the eye has to cross
// a field of gaps to get from the date to the amount.
//
// Her list, by key — CORRECTED 2026-11-07 by "no booking no,container no
// should be there in core". My first cut read "bkg no,cont no,hbl no it can
// be removed" as all three going. Only HBL does.
//
//   date          FIRST
//   booking_no    stays — her correction
//   container_no  stays — her correction
//   invoice_no, customer
//   rest          item, proforma_date, reference, weight, invoice_price,
//                 amount, received, balance — "rest can be there"
//
// Off the table, into the row's panel:
//   hbl_no                   "it can be removed"
//   terms, shipment_terms    "removed"
//
// ── AND NOW THE ORDER HAS TO BE STATED, NOT INHERITED ───────────────────
// TABLE_ORDER opens booking_no, container_no, date — correct, and deliberate
// (see COLUMNS: "bookng first then container no"). With booking and
// container back in core, filtering alone leaves Date third, and she asked
// for it first.
//
// So CORE_KEYS is the ORDER as well as the set, and each core column carries
// a `coreIndex`. TABLE_ORDER IS NOT TOUCHED: the export, the API and every
// other reader still get all sixteen in the order they have always been in.
// Only a client that narrows sorts on the new field — additive, like `core`
// itself. Changing TABLE_ORDER to move one column would have reordered her
// spreadsheet columns too, which nobody asked for.
//
// NOTHING IS DELETED. `core` is ADDITIVE, the same way helpers/bills.js
// added it: every existing reader — the export, the API, the margin
// calculation — still sees all sixteen columns in the same order, and only a
// client that looks for the flag narrows. A column she wants back is one
// line here, which is what "add/remove columns on request" asks for.
const CORE_KEYS = ['date', 'booking_no', 'container_no', 'invoice_no', 'customer',
    'item', 'proforma_date', 'reference', 'weight', 'invoice_price', 'amount',
    'received', 'balance'];

// ── THE THREE SHE TOOK OFF ARE OPTIONAL, NOT GONE (2026-11-07) ──────────
// the owner, after seeing the narrowed table: "I want them in earlier positions
// only but these are like option column just like reports show in qb".
//
// So hbl_no, terms and shipment_terms become columns she can switch back on,
// the way a QuickBooks report lets you pick your columns — and when she does,
// each one returns to the slot it used to hold, not to the end of the row.
//
// THE ORDER RULE, stated once here so no client has to invent it:
//   core columns keep CORE_KEYS order (Date first, as she asked);
//   an optional column goes after whichever of its TABLE_ORDER predecessors
//   now sits FURTHEST RIGHT.
//
// "Furthest right", not "nearest in TABLE_ORDER". The nearest rule puts HBL
// second, because TABLE_ORDER reads booking, container, date, hbl and date
// has moved to the front — so HBL follows it there, ahead of booking and
// container it used to sit behind. Anchoring on the furthest-right
// predecessor keeps it behind all three, which is where she has always seen
// it, and still lands shipment_terms after terms rather than after customer.
//
// Run against her own words that produces exactly what she described on
// 2026-09-10 and again today:
//   hbl_no          follows container_no   (TABLE_ORDER: ...container_no, hbl_no...)
//   terms           follows customer       — "customer name,then payment terms"
//   shipment_terms  follows terms          — "shioment terms" next to it
//
// `displayIndex` is the new shape, and it is a FLAG IN THAT DIRECTION:
// helpers/bills.js marks `core` with no index at all, so the Bills tab sends
// no displayIndex, shows no picker, and is untouched. A client narrows only
// when the server hands it one. TABLE_ORDER is still not touched — the
// export, the API and every other reader see all sixteen as they always have.
const OPTIONAL_KEYS = TABLE_ORDER.filter((k) => !CORE_KEYS.includes(k));

const displayOrder = () => {
    const out = CORE_KEYS.slice();
    for (const k of OPTIONAL_KEYS) {
        const before = TABLE_ORDER.slice(0, TABLE_ORDER.indexOf(k));
        // The anchor may itself be an optional column already placed (that is
        // how shipment_terms lands after terms rather than after customer).
        const at = before.reduce((m, p) => Math.max(m, out.indexOf(p) + 1), 0);
        out.splice(at, 0, k);
    }
    return out;
};

const tableColumns = () => {
    const order = displayOrder();
    return TABLE_ORDER.map((k) => COLUMNS.find((c) => c.key === k))
        .filter(Boolean)
        .map((c) => {
            const i = CORE_KEYS.indexOf(c.key);
            const d = order.indexOf(c.key);
            return i < 0
                ? { ...c, optional: true, displayIndex: d }
                : { ...c, core: true, coreIndex: i, displayIndex: d };
        });
};

// Same helper bills has, so the form can walk a group in the order the group
// states rather than in COLUMNS order.
function groupColumns(groupId) {
    const g = GROUPS.find((x) => x.id === groupId);
    if (g && Array.isArray(g.keys)) {
        return g.keys.map((k) => COLUMNS.find((c) => c.key === k)).filter(Boolean);
    }
    return COLUMNS.filter((c) => c.group === groupId);
}

// A sale's own filterable columns. NOT bills' — a sale has a customer and an
// HBL number where a bill has a supplier and a container number, and reusing
// the wrong list would leave the search box quietly matching nothing.
const FILTERABLE = ['customer', 'invoice_no', 'hbl_no', 'reference',
    'booking_no', 'container_no', 'item', 'terms', 'shipment_terms'];
const filterRows = (rows, q) => bills.filterRows(rows, q, FILTERABLE);
// Same self-learning list as bills — the customers she has invoiced are the
// customers offered. See helpers/bills.js:facets.
function facets(rows) {
    const of = (f) => [...new Set((rows || []).map((r) => String(r[f] || '').trim()).filter(Boolean))].sort();
    return { customer: of('customer'), reference: of('reference'),
             item: of('item'), terms: of('terms'),
             // Her own past values first, then the standard ones, so a term
             // she actually uses is at the top and an unused Incoterm is
             // still one keystroke away.
             shipment_terms: [...new Set([...of('shipment_terms'), ...SHIPMENT_TERMS])],
             booking_no: of('booking_no'), container_no: of('container_no') };
}

// `amount` is derived but ALSO writable — she can type the figure off the
// customer's invoice, and compute() prefers it when she does. That is why it
// is listed here explicitly instead of being taken from !derived.
const WRITABLE = COLUMNS.filter((c) => !c.derived).map((c) => c.key)
    .concat(['invoice_amount', 'commission_amount', 'price_unit', 'weight_unit',
             'charges', 'items', 'note'])
    .concat(LEGACY_WRITABLE);

const list = () => {
    const raw = loadJson(cfg.SALES_FILE, []);
    return Array.isArray(raw) ? raw : [];
};

function newId() {
    return `SALE_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
}

function clean(input) {
    const out = {};
    for (const k of WRITABLE) {
        if (!Object.prototype.hasOwnProperty.call(input || {}, k)) continue;
        const v = input[k];
        out[k] = typeof v === 'string' ? v.trim() : v;
    }
    for (const k of ['weight', 'invoice_price', 'invoice_amount', 'freight_charges',
                     'commission_per_mt', 'commission_amount']) {
        if (k in out) out[k] = num(out[k]);
    }
    // Charges are validated on the way IN, not on the way out: a charge with
    // no note must fail at the point she saves it, where she still remembers
    // why she typed it, rather than being quietly dropped from a total later.
    if ('charges' in out) out.charges = cleanCharges(out.charges);
    // Validated on the way in, by the purchase side's own function.
    if ('items' in out) out.items = bills.cleanItems(out.items);
    // Uppercased, not refused: "cfr" and "CFR" are the same term, and a list
    // this file only suggests is not a list it may reject.
    if ('shipment_terms' in out && out.shipment_terms) {
        out.shipment_terms = String(out.shipment_terms).trim().toUpperCase();
    }
    if ('terms' in out && out.terms) {
        const t = TERMS.find((x) => x.toLowerCase() === String(out.terms).toLowerCase());
        if (!t) throw new Error(`terms must be ${TERMS.join(' or ')}`);
        out.terms = t;
    }
    return out;
}

// A stored row plus its arithmetic. One function, so no caller can render a
// sale without it.
function withTotals(s) { return { ...s, ...compute(s) }; }

// ── NEWEST INVOICE FIRST, THEN BOOKING, THEN CONTAINER ───────────────────
//
// the owner, 2026-09-19, holding an exported PDF headed "Invoice register" whose
// first five rows ran 2026-04, 2026-05, 2025-11, 2025-12, 2026-01:
//
//     "why its not sorted by invoice date?"
//
// It was not sorted by date at all. It was sorted by BOOKING, which was the
// right answer to a different question and is recorded below as the thing it
// replaced. Asked which should change — the screen, the export, or both — she
// chose all of it, newest first.
//
// ── WHAT THE OLD ORDER WAS FOR, SO IT IS NOT LOST ────────────────────────
// Booking-then-container grouped every container of one shipment together,
// because a container number is not unique over time: MSKU1111111 sails again
// next year with different metal in it, so the booking has to come with it.
// That grouping is what has been given up here. Rows sharing a booking still
// sit together WHEN THEY SHARE AN INVOICE DATE, which on her data is most of
// them — the four TEMU7944250 rows on 2026-03-02 stay a block — but a booking
// invoiced across two days now appears in two places, and that is the trade
// she made knowingly.
//
// ── DATES ARRIVE IN TWO FORMATS AND MUST NOT BE SORTED AS TEXT ───────────
// The 569 imported rows carry '2026-04-24'; anything typed on the Sales form
// carries '09/10/2026'. Compared as plain strings, EVERY typed row sorts
// after EVERY imported one regardless of when it happened — a table that
// looks sorted and is not, which is worse than one that visibly is not.
//
// bills.sortableDate normalises both to YYYY-MM-DD and is imported rather
// than rewritten: two answers to "which of these two dates is earlier" would
// eventually disagree, and the two ledgers are joined on booking + container
// for margin.
//
// A date that parses as NEITHER sorts last, after every dated row. There is
// no honest place to put a row in time when its date cannot be read, and the
// bottom is where she will find it. Those rows keep booking order among
// themselves so the list stays stable rather than shuffling on every load.
function sortRows(rows) {
    const key = (r) => [bills.sortableDate(r.date),
                        String(r.booking_no || '').trim().toUpperCase(),
                        String(r.container_no || '').trim().toUpperCase()];
    return [...(rows || [])].sort((a, b) => {
        const [ad, ab, ac] = key(a); const [bd, bb, bc] = key(b);
        // Undated last, whichever direction the dated ones run.
        if (!ad !== !bd) return ad ? -1 : 1;
        if (ad && bd && ad !== bd) return ad < bd ? 1 : -1;   // DESC: newest first
        // Everything below is the tie-break, and it is the old order exactly.
        // Deterministic on purpose: a list that reshuffles between two loads
        // because two rows compared equal is a list she cannot trust.
        if (!ab !== !bb) return ab ? -1 : 1;
        if (ab !== bb) return ab < bb ? -1 : 1;
        if (ac !== bc) return ac < bc ? -1 : 1;
        return 0;
    });
}

// ── THE SAME GRADE TWICE ON ONE CONTAINER ────────────────────────────────
// Reported, never refused. A duplicate is usually a typo and occasionally
// real, and this file is not in a position to tell the difference — but
// silence would let the margin join against helpers/bills.js double-count,
// which is the failure nobody finds until a month is closed.
//
// ── IT USED TO KEY ON booking|container, AND THAT WAS WRONG ──────────────
// the owner, 2026-09-19: "booking never makes it unique.sometimes diff container
// under same booking.sometimes diff items in same container."
//
// Her imported ledger has one ROW PER GRADE — booking 266116225, container
// TEMU7944250, four rows: Alu Breakage, Alternator, Starter/ops load, Wheel
// Weight/ops load. Keyed on booking|container, all four were reported as a
// duplicated container. So the warning fired on most of her ledger, which is
// the same as never firing: a list of false alarms is where a real duplicate
// goes to hide.
//
// The grade is part of the key now. Two rows naming DIFFERENT grades are that
// container's two grades; two rows naming the SAME grade are the double-count
// worth interrupting her for. A blank grade is still a grade — two rows on
// one container with nothing named is the classic duplicated row.
const gradeKey = (r) => String((r && (r.item || r.description)) || '').trim().toUpperCase();
function duplicates(rows) {
    const seen = new Map();
    for (const r of (rows || [])) {
        const bk = String(r.booking_no || '').trim().toUpperCase();
        const cn = String(r.container_no || '').trim().toUpperCase();
        if (!bk || !cn) continue;
        const k = `${bk}|${cn}|${gradeKey(r)}`;
        if (!seen.has(k)) seen.set(k, { booking_no: r.booking_no, container_no: r.container_no,
                                        item: (r.item || r.description) || null, ids: [] });
        seen.get(k).ids.push(r.id);
    }
    return [...seen.values()].filter((d) => d.ids.length > 1);
}

// ── WHAT IS STILL OWED ───────────────────────────────────────────────────
// Read from helpers/salesReceipts.js in ONE pass, the same way bills reads
// its payments. A container is settled when what arrived plus what was
// deducted (bank charge or discount) covers the receivable — so a $12,340
// invoice closed by $12,315 landing and $25 of wire charge shows a zero
// balance AND still says where the $25 went.
//
// Non-fatal if the receipts file cannot be read: a sales table that refuses
// to render because the money store is unavailable is worse than one that
// renders without balances and says so in the log.
function listWithTotals() {
    let received = {}; let deducted = {};
    try {
        const r = require('./salesReceipts');
        received = r.receivedBySale();
        deducted = r.deductedBySale();
    } catch (e) { console.warn('[SALES] could not read receipts:', e.message); }

    return sortRows(list()).map((row) => {
        const t = withTotals(row);
        const got = received[row.id] || 0;
        const ded = deducted[row.id] || { total: 0, bank_charge: 0, discount: 0 };
        return {
            ...t,
            received: got,
            deducted: ded.total || 0,
            bank_charge: ded.bank_charge || 0,
            discount: ded.discount || 0,
            // Null, not zero, when there is nothing to measure against: an
            // invoice with no amount yet is not a paid one.
            balance: t.receivable === null ? null
                : round2(t.receivable - got - (ded.total || 0)),
        };
    });
}

function getSale(id) { return list().find((s) => s.id === id) || null; }

// ── ONE IMPLEMENTATION OF "WHAT IS A VALID SALE" ────────────────────────────
// Extracted from addSale 2026-09-19 so the spreadsheet importer can check 647
// rows BEFORE writing any of them, without a second copy of these rules that
// would drift the first time one changed. addSale calls it too.
function prepareSale(input = {}) {
    const rec = clean(input);
    if (!rec.date) throw new Error('a sale needs a date');
    if (!rec.customer) throw new Error('a sale needs a customer');
    return {
        id: newId(),
        ...rec,
        created_at: new Date().toISOString(),
        created_by: input.created_by || null,
    };
}

async function addSale(input = {}) {
    const rec = clean(input);
    if (!rec.date) throw new Error('a sale needs a date');
    if (!rec.customer) throw new Error('a sale needs a customer');
    const row = {
        id: newId(),
        ...rec,
        created_at: new Date().toISOString(),
        created_by: input.created_by || null,
    };
    // ── STRICT: THIS WRITE EITHER HAPPENS OR SAYS SO ─────────────────────
    // mutateJson is forgiving by default — on failure it logs, returns
    // loadJson() and NEVER RUNS THE MUTATOR, handing back plausible-looking
    // data with no way to tell the write never landed. Its own note says the
    // paths where a lost write means lost DATA should opt in; this is one of
    // them, and 131 of 146 writes in this codebase had not.
    //
    // The catch covers mutator errors too, not just lock contention, so the
    // forgiving path also swallows bugs in the function above.
    //
    // No retry loop on top: LOCK_OPTS already backs off eight times (40ms to
    // 400ms), so a failure here is genuinely exceptional and a second layer
    // would be defensive code with nothing to defend against.
    await mutateJson(cfg.SALES_FILE, [], (all) => {
        const rows = Array.isArray(all) ? all : [];
        rows.push(row);
        return rows;
    }, { strict: true });
    return withTotals(row);
}

async function editSale(id, input = {}) {
    const patch = clean(input);
    let found = null;
    let problem = null;
    await mutateJson(cfg.SALES_FILE, [], (all) => {
        const rows = Array.isArray(all) ? all : [];
        const i = rows.findIndex((r) => r.id === id);
        if (i === -1) return rows;
        // PATCH, not replace — the editLoad lesson, recorded in helpers/
        // loads.js: rebuilding a record wholesale dropped pdf_link. Ten
        // columns here and the same mistake would silently erase an HBL
        // number nobody was editing.
        const merged = { ...rows[i], ...patch, updated_at: new Date().toISOString() };
        // ── AN EDIT MUST NOT BLANK WHAT AN ADD INSISTS ON ────────────────
        // addBill/addSale refuse a row with no date or no customer, and an edit
        // that could clear either would leave a record the create path would
        // never have allowed. The client sends empty strings on edit (that is
        // how a field gets CLEARED), so this is reachable by simply deleting
        // the text and pressing Save.
        if (!merged.date) { problem = 'a sale needs a date'; return rows; }
        if (!merged.customer) { problem = 'a sale needs a customer'; return rows; }
        rows[i] = merged;
        found = rows[i];
        return rows;
    }, { strict: true });
    if (problem) throw new Error(problem);
    if (!found) throw new Error(`no sale ${id}`);
    return withTotals(found);
}

async function deleteSale(id) {
    let gone = false;
    await mutateJson(cfg.SALES_FILE, [], (all) => {
        const rows = Array.isArray(all) ? all : [];
        const i = rows.findIndex((r) => r.id === id);
        if (i === -1) return rows;
        rows.splice(i, 1);
        gone = true;
        return rows;
    }, { strict: true });
    if (!gone) throw new Error(`no sale ${id}`);
    return true;
}

// Column totals for the foot of the table. Only the ones that mean anything
// added up — a price per pound summed across shipments is a number with no
// meaning, and putting it under a column invites someone to read it.
function summary(rows) {
    const r = (rows || []).map(withTotals);
    const sum = (k) => round2(r.reduce((s, x) => s + (num(x[k]) || 0), 0));
    return {
        count: r.length,
        weight_lb: round3(r.reduce((s, x) => s + (x.weight_lb || 0), 0)),
        weight_mt: round3(r.reduce((s, x) => s + (x.weight_mt || 0), 0)),
        amount: sum('amount'),
        freight_charges: sum('freight_charges'),
        net_of_freight: sum('net_of_freight'),
        // The four figures the four tabs are about. Kept here rather than
        // computed per tab in the client, so Outgoing and Freight cannot
        // disagree about the same containers.
        charges_in_total: sum('charges_in_total'),
        charges_out_total: sum('charges_out_total'),
        commission_amount: sum('commission_amount'),
        receivable: sum('receivable'),
        sale_side_cost: sum('sale_side_cost'),
    };
}

module.exports = {
    COLUMNS, GROUPS, TABLE_ORDER, tableColumns, WRITABLE, FILTERABLE, filterRows, facets,
    compute, withTotals, list, listWithTotals, getSale,
    addSale, editSale, deleteSale, summary, prepareSale,
    sortRows, duplicates, cleanCharges, CHARGE_DIRECTIONS, TERMS, SHIPMENT_TERMS,
    groupColumns,
};
