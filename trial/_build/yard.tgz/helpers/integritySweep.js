// ── helpers/integritySweep.js — what disagrees with itself ────────────────
//
// the owner, 2026-09-26: "Is it possible to run an agent everyday in website to
// find out any issue or discrepancy?" Email, and everything it notices.
//
// ── THIS INVENTS NO CHECKS ────────────────────────────────────────────────
// Every finding below comes from a function that already existed and was on
// no schedule. bills.duplicates() and sales.duplicates() were computed once
// per page load and shown only if she happened to be looking at that tab.
// weight_gap was on the row and read by nobody. helpers/reconcile.js was
// written and never called by anything that runs on its own. The gap was
// never "we cannot tell" — it was that nothing ever looked.
//
// So this file is a caller, not a rule-maker. That matters: a sweep that
// invents its own idea of what is wrong will disagree with the screens, and
// then she has two answers and no way to choose.
//
// ── PURE. IT FINDS, IT DOES NOT SEND ──────────────────────────────────────
// run() returns findings. helpers/integritySweepJob.js is what emails them.
// Split because a check is worth testing and an email is not — and because a
// function that both computes and sends cannot be run to see what it would
// say.
//
// ── AND IT IS READ ONLY ───────────────────────────────────────────────────
// Nothing here writes. A nightly job that quietly "tidies" a ledger is how
// you lose a figure you cannot get back; every finding names the rows and
// stops. She decides.

const round2 = (n) => (typeof n === 'number' && isFinite(n) ? Math.round(n * 100) / 100 : null);
const money = (n) => `$${(Number(n) || 0).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

// A weight gap of a few pounds is the weighbridge and the packing list
// disagreeing, which is normal and constant. Worth reporting only when it is
// big enough to be an error rather than a rounding — her own bills.js comment
// says the two "disagree by a few pounds as a matter of course".
const WEIGHT_GAP_LB = 50;

// Below this, an unreconciled payment is a timing difference, not a problem.
const STALE_DAYS = 21;

const daysSince = (d) => {
    const t = Date.parse(String(d || ''));
    return Number.isFinite(t) ? Math.floor((Date.now() - t) / 86400000) : null;
};

// ── EACH CHECK RETURNS A FINDING OR NOTHING ───────────────────────────────
// Every one is wrapped by run() so a single broken check reports itself and
// the other seven still run. A sweep that dies on its first problem tells her
// nothing about the other six ledgers, which is the opposite of the point.
// ── ROWS IDENTIFIED BY A RECORD ID, NOT A CONTAINER ──────────────────────
// the owner, twice: "BILL_1789990307231_2eiz5 — DRM ignore all these things likle
// BILL_,SALE_", and again on 2026-10-01 after they were still in her list:
// "I told you explicitly dont combine BILL_ and SALE_ in this checking."
//
// The first time, I applied this inside unjoined-containers — the check I
// happened to be looking at — and nowhere else. unfinished-bills prints
// `container_no || id`, so every row without a container came out as
// "BILL_1789990307231_rar5g — DRM: needs container no" and her list was full
// of them again. Fixing one call site of a rule she stated generally is the
// same mistake CLAUDE.md's rule 1 is about, pointing the other way.
//
// So it lives HERE now, at module scope, and every check that reports rows by
// container uses it. A new check written next month gets it by reaching for
// the same helper rather than by remembering.
const RECORD_ID = /^(BILL|SALE)_/i;

// A row this sweep should not name by container, because it has none to name:
// either the field is empty, or it holds the synthetic id the ledger gave it.
//
// WHAT THIS COSTS, said plainly rather than buried: a bill that genuinely
// SHOULD have a container number and lost it is no longer reported either.
// That is the trade she asked for twice, and the reason it is right is that
// the rows carrying these ids are not containers at all — they are local
// deliveries and one-off bills that will never have one, so the finding could
// never be closed and a finding that cannot be closed is what makes a daily
// report stop being read.
const noRealContainer = (row) => {
    const c = String((row && row.container_no) || '').trim();
    return !c || RECORD_ID.test(c.toUpperCase());
};

const CHECKS = [

    // ── WHAT THE BOOKS SILENTLY LEFT OUT (2026-10-26) ─────────────────────
    // the owner, after four turns of "run this on the VM and paste the output":
    // make the product need "very less human intervention". The three
    // diagnostics written this week — scripts/entity-audit.js,
    // scripts/books-readiness.js, scripts/yard-sales-trace.js — all answer
    // questions she should never have had to ask, and none of them had run,
    // because running them was her job.
    //
    // They are checks, not scripts. This sweep already goes out at 06:30 and
    // is SILENT WHEN CLEAN, so adding them costs her nothing on a good day
    // and tells her on a bad one. The scripts stay for when she wants the
    // detail; this is the part that notices.
    //
    // READ ONLY, like every check here: booksBuild derives a journal and
    // writes nothing.
    {
        id: 'rows-on-no-company',
        title: 'Rows that belong to no company, so they are on no statement',
        why: 'a row entities.js cannot place is missing from the P&L entirely, '
           + 'and the total still balances without it',
        run() {
            const built = require('./booksBuild').build({});
            const byStore = new Map();
            for (const u of (built.unplaced || [])) {
                const k = `${u.store}|${u.why || 'no reason given'}`;
                byStore.set(k, (byStore.get(k) || 0) + 1);
            }
            // Grouped, not one line per row: 40 rows with the same cause is
            // one job, and a wall of 40 is how a report stops being read.
            return [...byStore.entries()].map(([k, n]) => {
                const [store, why] = k.split('|');
                return { what: `${n} row${n === 1 ? '' : 's'} in ${store}`, detail: why };
            });
        },
    },

    // ── A SALE THAT NEVER BECAME REVENUE ──────────────────────────────────
    // Found 2026-10-26: Sample Yard Co Yard showed $50,160 of sales against $1.25m of
    // purchases. outboundLoads.sumItems() returns null for `amount` when no
    // item on the row carries a price, postings refuses anything under a
    // cent, and the sale leaves the books without a word. The money is on her
    // Loads tab and absent from her P&L.
    {
        id: 'unpriced-outbound-loads',
        title: 'Outbound loads with no price, so they are not in Yard sales',
        why: 'the load is on the Loads tab but contributes nothing to revenue',
        run() {
            const rows = require('./outboundLoads').loadOutboundLoads() || [];
            const out = [];
            for (const l of rows) {
                if (!l || !l.date) continue;
                const amt = Number(l.amount);
                if (l.amount !== null && l.amount !== undefined && Math.abs(amt) >= 0.005) continue;
                const items = Array.isArray(l.items) ? l.items : [];
                const net = items.reduce((t, it) => t + (Number(it && it.net_weight) || 0), 0);
                // A row with WEIGHT but no price is a real sale missing a
                // figure. One with neither is probably a draft, and saying so
                // is the difference between a job and a distraction.
                out.push({
                    what: `${l.id || '(no id)'} ${l.date} ${l.buyer || '(no buyer)'}`,
                    detail: net > 0
                        ? `${net.toLocaleString()} lb weighed, no price — price it and it appears in revenue`
                        : 'no weight and no price — probably a draft',
                });
            }
            return out;
        },
    },

    // ── POSTED, BUT JARVIS HAD TO GUESS ───────────────────────────────────
    // The other half of the 2026-10-26 expense change. An expense with an
    // unknown category or no named payment source now POSTS — into 6900 or
    // against 2090 — instead of vanishing. That was her instruction, and the
    // bargain was that it would never be silent. This is the half that keeps
    // the bargain: 2090 not trending to zero means nobody is answering.
    {
        id: 'posted-but-not-settled',
        title: 'Entries that posted but are waiting on an answer',
        why: 'these ARE in the figures — they are in Other expenses or against '
           + 'Unallocated payments until someone says where they belong',
        run() {
            const built = require('./booksBuild').build({});
            const byKind = new Map();
            const examples = new Map(), totals = new Map();
            for (const raw of (built.needs || [])) {
                // postings.js ends each note with "[date $amount who]" (2026-11-07) so this can say WHICH ones.
                const who = (/\[([^\]]*)\]\s*$/.exec(raw) || [])[1] || null;
                const n = String(raw).replace(/\s*\[[^\]]*\]\s*$/, '');
                const key = /is not in the chart/.test(n)
                    ? 'an expense category the chart does not have'
                    : /no bank or drawer identified/.test(n)
                        ? 'a payment whose source was never named'
                        : String(n).slice(0, 70);
                // For "no bank identified" the quoted text is only the fallback label ("this payment"), which says nothing; the entries do.
                const quoted = (/"([^"]*)"/.exec(n) || [])[1];
                const detail = /no bank or drawer identified/.test(n) ? '' : quoted;
                const k = `${key}|${detail || ''}`;
                byKind.set(k, (byKind.get(k) || 0) + 1);
                if (who) {
                    if (!examples.has(k)) examples.set(k, []);
                    if (examples.get(k).length < 3) examples.get(k).push(who);
                    const m = /\$(-?[\d,]+(?:\.\d+)?)/.exec(who);
                    const amt = m ? Number(m[1].replace(/,/g, '')) : NaN;
                    if (Number.isFinite(amt)) totals.set(k, (totals.get(k) || 0) + amt);
                }
            }
            return [...byKind.entries()].map(([k, n]) => {
                const [key, detail] = k.split('|');
                const ex = examples.get(k);
                const tot = totals.get(k);
                const which = ex && ex.length
                    ? `e.g. ${ex.join('; ')}${n > ex.length ? '; \u2026' : ''}${tot ? ` (total $${tot.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })})` : ''} \u2014 set the payment method on each in Expenses`
                    : null;
                return {
                    what: `${n} \u00d7 ${key}`,
                    detail: which || (detail ? `"${detail}"` : 'see the Books page'),
                };
            });
        },
    },


    // ── TWO BILLS ON ONE CONTAINER ────────────────────────────────────────
    // The one that costs money, and it is already documented in api.js:
    // margin.js keeps only the LAST bill for a container, so a duplicate
    // makes that container read cheaper than it was, and the margin on it is
    // wrong in her favour — which is the direction nobody questions.
    {
        id: 'duplicate-bills',
        title: 'Two bills for the same container',
        why: 'margin keeps only the last one, so the container reads cheaper than it was',
        run() {
            const bills = require('./bills');
            const dups = bills.duplicates(bills.listWithTotals());
            return dups.map((d) => ({
                what: `${d.container_no || '(no container)'} on ${d.booking_no || '(no booking)'}`
                    + (d.item ? ` — ${d.item}` : ''),
                detail: `${d.ids.length} bills: ${d.ids.join(', ')}`,
            }));
        },
    },

    {
        id: 'duplicate-sales',
        title: 'Two invoices for the same container',
        why: 'the container is billed to the customer twice',
        run() {
            const sales = require('./sales');
            const dups = sales.duplicates(sales.listWithTotals());
            return dups.map((d) => ({
                what: `${d.container_no || '(no container)'} on ${d.booking_no || '(no booking)'}`
                    + (d.item ? ` — ${d.item}` : ''),
                detail: `${d.ids.length} invoices: ${d.ids.join(', ')}`,
            }));
        },
    },

    // ── THE ITEMS DO NOT ADD UP TO THE CONTAINER ──────────────────────────
    // Her own rule, from bills.js: reported, never refused, because the
    // weighbridge and the packing list disagree by a few pounds as a matter
    // of course. So the threshold is what turns a fact into a finding.
    {
        id: 'weight-gap',
        title: `Line items miss the container net by more than ${WEIGHT_GAP_LB} lb`,
        why: 'the grades were typed from one sheet and the container weighed on another',
        run() {
            const bills = require('./bills');
            return bills.listWithTotals()
                .filter((b) => Number.isFinite(b.weight_gap) && Math.abs(b.weight_gap) > WEIGHT_GAP_LB)
                .map((b) => ({
                    what: `${b.container_no || b.id} — ${b.supplier || 'no supplier'}`,
                    detail: `${b.weight_gap > 0 ? '+' : ''}${round2(b.weight_gap)} lb between the items and the net`,
                }));
        },
    },

    // ── BOUGHT AND NEVER SOLD, SOLD AND NEVER BOUGHT ──────────────────────
    // margin.rows() already joins the two sides and labels the state. A
    // container stuck on 'bought' for months is either stock nobody counted
    // or an invoice nobody raised; one on 'sold' with no bill behind it is
    // revenue with no cost, which flatters every margin it touches.
    {
        id: 'unjoined-containers',
        title: 'A container with only one side of the trade',
        why: 'sold with no bill flatters the margin; bought with no sale may be an invoice nobody raised',
        run() {
            const margin = require('./margin');
            const rows = margin.rows() || [];
            const out = [];
            // ── THE SAME CONTAINER, TWICE, IS ONE PROBLEM NOT TWO ────────
            // Her first live run, 2026-09-26:
            //
            //   CAIU9824029 — Calderon:     bought 277 days ago and not sold
            //   CAIU9824029 — SOLINE METAL: sold 277 days ago with no bill
            //
            // A bill AND a sale, same container, same day, reported as two
            // separate gaps. They are not. margin.js:58 keys a row on
            // BOOKING + CONTAINER, so two halves that agree on the container
            // and disagree on the booking never meet — and the container is
            // counted twice with its real margin computed nowhere.
            //
            // Reporting that as two missing halves sends her looking for two
            // documents that both already exist, which is worse than saying
            // nothing. Grouped by container first, so the pair is named as
            // what it is.
            // ── A LEAKED RECORD ID IS NOT A CONTAINER ────────────────────
            // the owner, 2026-09-29, reading this very report:
            //
            //   BILL_1789990307231_2eiz5 — DRM
            //   "ignore all these things likle BILL_,SALE_"
            //
            // A Jarvis row id sitting in the container column. It can never
            // join to anything and the sheet will never supply a matching
            // half, so every night it reports a gap that cannot be closed —
            // and a nightly report carrying items nobody can act on is a
            // report that stops being read. Dropped here rather than in the
            // email, so every consumer of this check agrees.
            //
            // Only the id shape is dropped, not everything odd: a genuinely
            // unfamiliar container number is still worth her seeing.
            // RECORD_ID is now module-scope — see the comment there for why
            // having a second private copy here was the bug.

            const byContainer = new Map();
            for (const r of rows) {
                if (r.state === 'closed') continue;
                const c = String(r.container_no || '').trim().toUpperCase();
                if (!c) continue;
                // The SAME helper the other two checks use. This check had its
                // own private copy of the rule, which is precisely why fixing
                // it here left the other two reporting BILL_ ids for weeks.
                if (noRealContainer(r)) continue;
                if (!byContainer.has(c)) byContainer.set(c, []);
                byContainer.get(c).push(r);
            }
            for (const [container, group] of byContainer) {
                const age = Math.max(...group.map((r) => daysSince(r.bill_date || r.sale_date) || 0));
                if (age < STALE_DAYS) continue;                 // still in flight
                const bought = group.find((r) => r.state === 'bought');
                const sold = group.find((r) => r.state === 'sold');
                if (bought && sold) {
                    out.push({
                        what: `${container} — ${bought.supplier || '?'} to ${sold.customer || '?'}`,
                        detail: `both halves exist but the booking numbers differ, so the margin is computed nowhere`
                            + ` (bill ${bought.booking_no || 'blank'}, sale ${sold.booking_no || 'blank'})`,
                    });
                    continue;
                }
                const r = group[0];
                out.push({
                    what: `${container} — ${r.supplier || r.customer || 'unnamed'}`,
                    detail: r.state === 'bought'
                        ? `bought ${age} days ago and not sold`
                        : `sold ${age} days ago with no bill behind it`,
                });
            }
            return out;
        },
    },

    // ── A BILL NOBODY FINISHED ────────────────────────────────────────────
    // bills.missingFor() is the one implementation of "what is this bill
    // still waiting for" — date, supplier, container, weights, and either a
    // price or a typed amount.
    //
    // The first version of this read `b.is_finished`, which does not exist on
    // a bill: it is DERIVED in helpers/data/dataMirror.js for the SQL mirror,
    // out of this very function. The filter was therefore always false and
    // the check could never fire — it read correctly, it ran every night, and
    // it found nothing forever. Caught by seeding a fixture and noticing two
    // of seven checks stayed silent, not by reading the code.
    {
        id: 'unfinished-bills',
        title: 'Bills that are still missing something',
        why: 'an unfinished bill has a figure nobody can rely on',
        run() {
            const bills = require('./bills');
            return bills.listWithTotals()
                // Her instruction, applied at the SOURCE of this check rather
                // than to the email: every consumer agrees, and a screen that
                // calls run() sees the same list she does.
                .filter((b) => !noRealContainer(b))
                .map((b) => ({ b, needs: bills.missingFor(b) || [] }))
                .filter((x) => x.needs.length)
                // A bill typed this morning is not a problem; one from three
                // weeks ago that still has gaps is.
                //
                // `=== null` rather than `||`. daysSince() returns 0 for
                // today, and `0 || STALE_DAYS` takes the undated fallback —
                // so every bill typed this morning was reported as overdue.
                // Caught by the test, and it is the same falsy-zero trap that
                // made an invoice note of "0" vanish: a legitimate zero is
                // not a missing value.
                .filter((x) => { const d = daysSince(x.b.date); return d === null || d >= STALE_DAYS; })
                .map((x) => ({
                    what: `${x.b.container_no || x.b.id} — ${x.b.supplier || 'no supplier'}`,
                    detail: `needs ${x.needs.join(', ')}`,
                }));
        },
    },

    // ── WHAT IS DELIBERATELY NOT HERE: THE YARD'S OPEN CLAIMS ─────────────
    // They were here, for one afternoon, and the owner took them out on
    // 2026-10-01: "SAMPLE_9 — Sam never involve yard with this."
    //
    // She is right and it is rule 5. Every other check in this file reads
    // bills, sales or margin — Sample Yard Co Metals' paperwork. A claim against a load
    // the YARD bought is Sample Yard Co Yard's, and the separation between the two
    // companies is most of what this app is for. Putting them in one email
    // because both happen to be "things that need attention" is the kind of
    // tidying that quietly teaches her the two books are one book.
    //
    // They now ride the 8PM end-of-day yard report, which has its own
    // toggle, its own recipients and its own WhatsApp group under
    // Settings > Yard. Her daily reminder, on the yard's channel.

    // ── A BOOKING WITH NO ERD OR NO CUTOFF ────────────────────────────────
    // the owner, 2026-11-09: "ERD and cutoff is must for a booking in jarvis. If
    // its not there, sweep email wherever that booking is mentioned."
    // Active bookings only (archived ones live in history). Read-only: the
    // line names the booking and who it is with so she can chase the dates.
    // This does NOT refuse a booking without them — that would be a change to
    // booking intake, which she has not asked for.
    {
        id: 'booking-missing-dates',
        title: 'Bookings missing ERD or cutoff',
        why: 'both dates decide whether a booking can still move, and a booking without them cannot be chased',
        run() {
            return require('./bookingDates').missing().map((x) => ({ what: x.booking, detail: x.detail }));
        },
    },

    // ── A ROW WITH NO DATE OR NO PARTY ────────────────────────────────────
    // compute() already marks these `incomplete` rather than refusing them,
    // deliberately — a form that refuses a real bill is a form she works
    // around. But nothing ever came back to them afterwards.
    {
        id: 'incomplete-rows',
        title: 'Rows missing a date or a party',
        why: 'they were allowed in on purpose, and then nobody came back to them',
        run() {
            const bills = require('./bills');
            return bills.listWithTotals()
                // Same rule, same reason — this check prints `container_no ||
                // id` too, so without it her list fills with BILL_ ids from a
                // third direction. THREE checks had the same shape and only
                // one had the filter; that is what made "I told you
                // explicitly" the right thing for her to say.
                .filter((b) => !noRealContainer(b))
                .filter((b) => Array.isArray(b.incomplete) && b.incomplete.length)
                .map((b) => ({
                    what: `${b.container_no || b.id}`,
                    detail: `no ${b.incomplete.join(', no ')}`,
                }));
        },
    },

    // ── WHAT IS DELIBERATELY NOT HERE: THE BANK RECONCILIATION ────────────
    // helpers/reconcile.js computes exactly the finding this sweep wants —
    // money recorded in Jarvis that the statement has never seen. It is NOT
    // wired in, and that is a decision rather than an oversight.
    //
    // Two reasons. It has no caller anywhere in the app, so nothing has ever
    // exercised it against real rows. And it takes its inputs explicitly —
    // reconcile({ payments, expenses, bills, transactions }) — where
    // bookedOutflows() keys on p.load_id, which is a YARD payment; the metals
    // side pays through helpers/billPayments.js and its allocations. Feeding
    // it the wrong store would produce a confident list of discrepancies that
    // are not discrepancies, in an email whose whole value is that she can
    // trust it.
    //
    // data/bank-transactions.json is empty on this machine, so I cannot see
    // the shape to wire it correctly. It goes in once I can — the same rule
    // that kept the metals catalog from being written from fixtures.
];

// ── RUN THEM ALL, AND SURVIVE ANY OF THEM ─────────────────────────────────
// A check that throws becomes a finding of its own rather than taking the
// sweep down. She should hear "the reconcile check is broken" from the same
// email, not discover a week later that it silently stopped running.
function run({ limitPerCheck = 25 } = {}) {
    const findings = [];
    const broken = [];
    for (const c of CHECKS) {
        let hits = [];
        try { hits = c.run() || []; }
        catch (e) { broken.push({ id: c.id, title: c.title, error: String(e.message || e).slice(0, 200) }); continue; }
        if (!hits.length) continue;
        findings.push({
            id: c.id, title: c.title, why: c.why,
            count: hits.length,
            // Capped for the email, and the count above says how many there
            // really were — a truncated list that hides its own truncation is
            // how a hundred problems look like twenty-five.
            items: hits.slice(0, limitPerCheck),
            truncated: Math.max(0, hits.length - limitPerCheck),
        });
    }
    const total = findings.reduce((a, f) => a + f.count, 0);
    return { at: new Date().toISOString(), clean: total === 0 && !broken.length, total, findings, broken, checks: CHECKS.length };
}

// Plain text, because it goes in an email she reads on a phone.
function reportText(res) {
    if (res.clean) return `Nothing to report. ${res.checks} checks, no discrepancies.`;
    const out = [];
    out.push(`${res.total} thing${res.total === 1 ? '' : 's'} worth a look, across ${res.findings.length} of ${res.checks} checks.`);
    for (const f of res.findings) {
        out.push('');
        out.push(`${f.title} — ${f.count}`);
        out.push(`  (${f.why})`);
        for (const i of f.items) out.push(`  · ${i.what}: ${i.detail}`);
        if (f.truncated) out.push(`  … and ${f.truncated} more`);
    }
    if (res.broken.length) {
        out.push('');
        out.push('CHECKS THAT DID NOT RUN');
        for (const b of res.broken) out.push(`  · ${b.title}: ${b.error}`);
    }
    return out.join('\n');
}

module.exports = { run, reportText, CHECKS, WEIGHT_GAP_LB, STALE_DAYS };
