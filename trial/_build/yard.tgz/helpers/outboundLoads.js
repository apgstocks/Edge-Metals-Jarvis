// ── helpers/outboundLoads.js — outbound loads sold/shipped TO a buyer ───────
// Built 2026-08-16 per the owner: "loads sent to Eccomelt, what load at which
// date, at what price" — then confirmed general-purpose ("multiple regular
// buyers"), not Eccomelt-specific, capturing material/weight, price/amount,
// date sent + trucker used, and an optional link back to the Quote Requests/
// Contacts flow that led to the sale.
//
// Deliberately the MIRROR IMAGE of helpers/loads.js, and deliberately its
// OWN store (data/outbound_loads.json, config.OUTBOUND_LOADS_FILE) rather
// than a `direction` flag bolted onto loads.json — see config.js's comment
// on OUTBOUND_LOADS_FILE for why. Reuses the same gross/tare/net/amount
// item math as loads.js (computeItem/sumItems) by design — that's proven,
// tested logic, just not exported from loads.js today, so it's duplicated
// here in a small, self-contained form rather than either (a) exporting
// internals out of a live, production, already-complex file for one new
// caller, or (b) importing loads.js wholesale and risking coupling to
// internals that may change for inbound-specific reasons later.

const cfg = require('../config');
const { loadJson, mutateJson: mutateJsonRaw } = require('./json');

// ── EVERY WRITE HERE IS STRICT ────────────────────────────────────────────
// Added 2026-09-21, alongside the same fix in helpers/loads.js and for the
// same reason. the owner entered a load on the 21st; it showed in the app, was
// absent from the website, and was gone from the app after a restart. It had
// never been written.
//
// helpers/json.js's mutateJson defaults to strict:false: a failed write is
// LOGGED and the file's PREVIOUS CONTENTS are returned. The caller cannot
// tell that from success, so the record comes back, the route answers 200,
// the screen shows the row, and the next read has never heard of it.
//
// The money stores opted in months ago. outbound loads did not did not, and a SALE can vanish exactly the way that purchase did — after the buyer
// has signed for the metal and driven away with it.
//
// Wrapped once rather than passed at each call site, so a new write cannot
// be added without it.
const mutateJson = (file, dflt, fn) => mutateJsonRaw(file, dflt, fn, { strict: true });

const loadOutboundLoads = () => loadJson(cfg.OUTBOUND_LOADS_FILE, []);

function round2(n) {
    return typeof n === 'number' && isFinite(n) ? Math.round(n * 100) / 100 : null;
}
function toNum(v) {
    const n = typeof v === 'number' ? v : parseFloat(v);
    return isFinite(n) ? n : null;
}

// draws: [{ load_id, weight }] — which inbound lots this line drew from, and
// how much from each. Added 2026-08-24; see helpers/stock.js for the model and
// for why whole-load linking wasn't enough. Optional: a sale with no draws
// still counts as shipped, it just carries no cost.
function normaliseDraws(raw) {
    return (Array.isArray(raw) ? raw : [])
        .map((d) => ({ load_id: String(d && d.load_id || '').trim(), weight: toNum(d && d.weight) }))
        .filter((d) => d.load_id && d.weight != null && d.weight > 0);
}

// The divisors live in helpers/priceUnits.js since 2026-10-10 — see the note
// in computeItem below on why importing that table is not the coupling this
// file's header warns against.

function computeItem(it) {
    const gross = toNum(it.gross_weight);
    const tare  = toNum(it.tare_weight);
    const net   = (gross != null && tare != null) ? round2(gross - tare) : null;
    const price = toNum(it.price);
    // ── PRICED PER POUND OR PER TONNE, ROW BY ROW (2026-09-24) ─────────────
    // the owner, asked how far the yard's new per-row lb/MT pricing should go:
    // "Full per-row lb/MT on sales too".
    //
    // This is urgent rather than merely consistent, and the reason is worth
    // recording. The SALE uses the SAME modal as a purchase —
    // dashboard/index.html's loadModalMode === 'sale' posts the very same
    // `items` array that syncItemsFromDom() builds. So the moment the unit
    // select went onto that form, the sale screen started OFFERING /MT while
    // this function, which recomputes over whatever the client sends rather
    // than trusting it, kept answering in pounds. A sale priced at $800/MT
    // would have been booked at $800 per pound — 2,204 times over — with
    // nothing on screen to say so.
    //
    // THE NET IS NOT CONVERTED, exactly as on the purchase side: it is what
    // the scale said, and only the quantity the price multiplies changes.
    // 'lb' and a missing unit take the same branch, so every outbound load
    // already on file is arithmetically untouched.
    // ── AND SINCE 2026-10-10, FIVE UNITS — HER CALL, BOTH SIDES ────────────
    // Asked whether net ton, gross ton and /piece should reach sales as well
    // as purchases, she said both. Which is the same answer she gave in
    // September and for the same reason: this screen SHARES the purchase
    // modal, so a unit the form can offer and this function cannot compute
    // gets booked at the pound figure, 2,204 times over on an /MT row.
    //
    // The divisors are in helpers/priceUnits.js now rather than a fourth
    // private copy of the table. That is a change this file's header argues
    // against — it says the item math is duplicated deliberately rather than
    // reaching into loads.js internals — and the argument still holds: this
    // does NOT import loads.js. priceUnits.js is a pure table with no store,
    // no state and nothing inbound-specific in it, which is the thing that
    // made the duplication worth avoiding.
    const PU = require('./priceUnits');
    const pieces = toNum(it.pieces);
    const unit = PU.normalise(it.unit);
    if (unit === null) {
        throw new Error(`"${it.unit}" is not a unit Jarvis prices in — a sale item takes `
            + PU.ORDER.map((k) => PU.LABEL[k]).join(', '));
    }
    const amount = PU.amountFor({ unit, net, pieces, price });
    return {
        draws: normaliseDraws(it && it.draws),
        description: it.description || '',
        // Ferrous / non-ferrous (2026-11-17); null = Unsorted. See helpers/itemMetal.js.
        metal_type: require('./itemMetal').normType(it.metal_type),
        gross_weight: gross, tare_weight: tare, net_weight: net,
        // '' stays '' when it is pounds — see loads.js on why this is not
        // quietly migrated to 'lb' one row at a time.
        price, unit: unit === 'lb' ? (it.unit || '') : unit,
        pieces: PU.isCounted(unit) ? pieces : null,
        amount,
    };
}
function sumItems(items) {
    const sum = (key) => {
        const vals = items.map((it) => it[key]).filter((v) => v != null);
        return vals.length ? round2(vals.reduce((a, b) => a + b, 0)) : null;
    };
    return { gross_weight: sum('gross_weight'), tare_weight: sum('tare_weight'), net_weight: sum('net_weight'), amount: sum('amount') };
}

// ── TRUCKING ON A SALE (2026-11-04) ──────────────────────────────────────
// the owner: "Similar to loads trucking in sample yard co yard,sales trucking should be
// there na", and asked who bears it: "You haul, buyer is charged".
//
// So this is the MIRROR of helpers/loads.js's deduction, not a copy of it.
// There Sample arranges the haul and takes the cost OFF what the seller is
// paid; here Sample arranges the haul and puts it ON what the buyer owes. In
// both cases the counterparty bears the freight — the sign is the only
// difference, and it is the whole of the difference.
//
// THREE FIELDS, the same three, for the same reason loads.js gives: who
// hauled it, what it cost, and a note. Splitting it into line haul / fuel /
// accessorials is helpers/bills.js's job when a real hauler invoice arrives.
function cleanTrucking(entry) {
    const company = String(entry.trucking_company || '').trim();
    const note    = String(entry.trucking_note || '').trim();
    return {
        trucking_company: company || null,
        trucking_amount : toNum(entry.trucking_amount),
        trucking_note   : note || null,
    };
}

// PLUS, where loads.js has minus. A sale with no amount yet has no
// receivable, and 0 + trucking would invent a debt the buyer does not owe
// for metal he has not been priced for — the same guard, mirrored.
function receivableFrom(amount, trucking) {
    const amt = toNum(amount);
    if (amt === null) return null;
    return round2(amt + (toNum(trucking) || 0));
}

// THE SINGLE READER, exactly as payableOf is on the purchase side. Falls
// back to `amount` for every sale recorded before this existed — those have
// no net_receivable key and must read as "nothing added".
function receivableOf(load) {
    if (!load) return null;
    return load.net_receivable !== undefined && load.net_receivable !== null
        ? load.net_receivable : (load.amount ?? null);
}

// Sequential OUT_N ids — own namespace, deliberately never colliding with
// loads.js's SAMPLE_N ids (two different stores, two different sequences;
// sharing a namespace would falsely imply they're the same series of
// records when they represent opposite transactions).
function nextOutboundId(loads) {
    let max = 0;
    for (const l of loads) {
        const m = /^OUT_(\d+)$/.exec(l.id || '');
        if (m) max = Math.max(max, parseInt(m[1], 10));
    }
    return `OUT_${String(max + 1).padStart(2, '0')}`;
}

// Same "no partial saves" bar as loads.js's validateLoadForSave — a real
// buyer name is mandatory (this is the whole point of the record); an item
// row only has to be complete once it has ANY data in it at all, so an
// untouched spare row never blocks saving.
function validateForSave(entry) {
    if (!entry.buyer || !String(entry.buyer).trim()) {
        throw new Error('Validation: buyer is required.');
    }
    const items = Array.isArray(entry.items) ? entry.items : [];
    items.forEach((it, i) => {
        const hasAnyData = it.description || it.gross_weight || it.price;
        if (!hasAnyData) return;
        const label = it.description ? `"${it.description}"` : `#${i + 1}`;
        if (!it.description || !String(it.description).trim()) {
            throw new Error(`Validation: item ${label} is missing a description.`);
        }
        if (it.gross_weight === null || it.gross_weight === undefined || it.gross_weight === '' || !isFinite(parseFloat(it.gross_weight))) {
            throw new Error(`Validation: item ${label} is missing a gross weight.`);
        }
    });
}

function buildRecord(entry) {
    validateForSave(entry);
    // ── ONE METAL, ONE SPELLING ──────────────────────────────────────
    // the owner, 2026-09-16: "if i saved description say HMS and when i type
    // ike hms in small,it i considering that as a new item." Case only —
    // see helpers/itemSpelling.js for why this is not the alias feature and
    // must never grow into it.
    const _known = require('./itemSpelling').knownSpellings();
    const items = Array.isArray(entry.items)
        ? require('./itemMetal').fill(require('./itemSpelling').canonicaliseItems(entry.items, _known)).map(computeItem) : [];
    const totals = sumItems(items);
    return {
        date          : entry.date || null,
        buyer         : String(entry.buyer).trim(),
        buyer_address : entry.buyer_address || null,
        // Which of her companies is SELLING (2026-11-17). A label only — null means
        // Sample Yard Co Trading, as every sale before today. See helpers/loadCompany.js.
        seller_company: require('./loadCompany').canon(entry.seller_company),
        trucker_name  : entry.trucker_name || null,
        // ── THE TRUCKER'S PROMISED DELIVERY (2026-09-10) ──────────────────
        // the owner: "trucker will give estimated delivery date and time. I want
        // to send a enquiry at that date and time reg the load delivery
        // status". A DATE plus a TIME, held as the wall clock the driver
        // actually said, with the zone beside them — turning it into an
        // instant here would bake in whatever zone the server is in.
        //
        // DELIBERATELY NOT CALLED `eta`. In this codebase `eta` already means
        // the VESSEL's arrival on an Sample Yard Co Metals booking
        // (helpers/cutoffBackfill.js, helpers/gemini.js's extraction schema),
        // and a field that reuses a taken name is a field that eventually
        // gets read by the code that owns the other meaning.
        delivery_eta_date : entry.delivery_eta_date || null,
        delivery_eta_time : entry.delivery_eta_time || null,
        delivery_eta_tz   : entry.delivery_eta_tz || null,
        // Optional link back to whichever quote-request pipeline actually
        // led to this sale — 'lane' (workflow/quoteRequests.js, trucker
        // lane quotes) or 'contact' (workflow/contactQuoteRequests.js).
        // Purely informational (no FK enforcement — the source request may
        // later be archived/deleted independently), used only to show a
        // "from this quote" reference on the record, never dereferenced for
        // anything load-critical.
        quote_request_id   : entry.quote_request_id || null,
        quote_request_kind : entry.quote_request_kind || null,
        // Margin tracking (2026-08-16, per the owner: "Sample Yard Co Metals acts as an
        // intermediary — buy from one supplier and sent to another
        // customer" — confirmed she wants this linked, not tracked as two
        // independent lists). References helpers/loads.js's INBOUND
        // load ids (SAMPLE_N) this outbound sale's material was sourced from.
        // SIMPLIFICATION, worth knowing: this links whole inbound loads,
        // not a weight-prorated split — margin here is
        // (this outbound load's amount) minus (the FULL amount of every
        // linked inbound load), computed in getOutboundReport/getMargin
        // below. That's accurate when an inbound load's material goes to
        // ONE outbound sale, but overstates cost if the same inbound load
        // is linked from more than one outbound sale (its full cost would
        // get counted against each). Flagged rather than silently assumed
        // correct — ask if partial/weight-based allocation is needed later.
        linked_inbound_load_ids: Array.isArray(entry.linked_inbound_load_ids) ? entry.linked_inbound_load_ids.filter(Boolean) : [],
        description   : entry.description || '',
        items,
        gross_weight  : totals.gross_weight,
        tare_weight   : totals.tare_weight,
        net_weight    : totals.net_weight,
        amount        : totals.amount,
        ...cleanTrucking(entry),
        // Derived at WRITE time, never at read time — the same decision
        // loads.js records for net_payable, for the same reason:
        // receivableOf has many callers, several in loops, and must stay a
        // pure read of the record.
        net_receivable: receivableFrom(totals.amount, entry.trucking_amount),
        weight_unit   : entry.weight_unit || 'lb',
        status        : 'sent',
    };
}

async function addOutboundLoad(entry) {
    const rec = buildRecord(entry);
    await require('./itemMetal').learnFromItems(rec.items);
    rec.id = null;
    rec.created_at = new Date().toISOString();
    rec.created_by = entry.created_by || 'unknown';
    // Set here and not in buildRecord, because buildRecord also runs on every
    // edit and would reset a delivered load to in_transit each time.
    rec.delivery_status = 'in_transit';
    rec.delivered_at = null;
    // Set outside buildRecord for the same reason as the three lines above:
    // buildRecord also runs on every edit, and an edit must not mint a new
    // ticket or wipe the one this record was created with.
    rec.client_request_id = require('./oncePerSave').normTicket(entry.client_request_id);
    // ── ONE DRAFT, ONE LOAD ──────────────────────────────────────────────
    // the owner, 2026-09-29: "ALWAYS ONE LOAD SHOULD BE CREATED". Per draft,
    // never expires — see helpers/oncePerSave.js. Set outside buildRecord
    // for the same reason as the ticket: an edit must not mint or wipe it.
    rec.draft_id = require('./oncePerSave').normDraftId(entry.draft_id);

    // ── ONE SAVE, ONE RECORD ─────────────────────────────────────────────
    // the owner, 2026-09-15: "I just added one.But two ones are created" — two
    // identical Darwin sales, OUT_02 and OUT_03. See helpers/oncePerSave.js
    // for what was ruled out and why this is a ticket rather than a
    // duplicate warning. The lookup is INSIDE the mutator so it runs under
    // the file lock; checking before mutateJson would let two simultaneous
    // requests both find nothing and both write.
    let already = null;
    await mutateJson(cfg.OUTBOUND_LOADS_FILE, [], (loads) => {
        const once = require('./oncePerSave');
        already = once.findSpent(loads, rec.client_request_id)
            || once.findByDraft(loads, rec.draft_id);
        if (already) return loads;   // returned unchanged — nothing is written
        // One buyer, one spelling — see the twin comment in helpers/loads.js.
        rec.buyer = require('./canonicalName').canonicalName(loads.map((l) => l.buyer), rec.buyer);
        rec.id = nextOutboundId(loads);
        loads.unshift(rec);
        if (loads.length > 5000) loads.length = 5000;
        return loads;
    });
    // The caller gets the record that exists, so a re-sent save looks to the
    // client exactly like the save that succeeded — same id, same everything.
    return already || rec;
}

async function editOutboundLoad(id, entry) {
    const patch = buildRecord(entry);
    await require('./itemMetal').learnFromItems(patch.items);
    // ── AN EDIT MUST NOT UN-DELIVER A LOAD ───────────────────────────────
    // buildRecord rebuilds from a fixed field list, so anything it does not
    // name is wiped by the Object.assign below — the trap this file's own
    // patchOutboundLoad comment records having already sprung once, on
    // pdf_link. delivery_status and delivered_at are recorded by arriving,
    // not by this form, so they are carried across rather than rebuilt.
    // Without this, correcting a typo on a delivered load would silently put
    // it back in transit and let a new enquiry be scheduled against it.
    const prior = getOutboundLoad(id);
    if (prior) {
        // A caller that never mentions the picker (the APK already on her phone,
        // the voice path) must not blank a company she chose.
        if (entry.seller_company === undefined) patch.seller_company = prior.seller_company || null;
        patch.delivery_status = prior.delivery_status || 'in_transit';
        patch.delivered_at = prior.delivered_at || null;
        // ── AND MUST NOT FREE THE DRAFT TO BECOME A SECOND LOAD ──────────
        // buildRecord does not name draft_id, so without this line an edit
        // wipes it — and the duplicate the owner reported on 2026-09-29 came
        // from a flow with an edit in the middle of it ("He just saved it
        // first.then edit,continue or cancel.he clicked continue"). A load
        // that forgets which draft it came from lets that draft create
        // another one, which is the rule this is here to hold.
        patch.draft_id = prior.draft_id || null;
        // ── AND MUST NOT WIPE TRUCKING IT NEVER MENTIONED (2026-11-04) ──
        // buildRecord rebuilds from a fixed field list, so a caller that
        // does not send the three trucking fields blanks them AND resets
        // net_receivable to the bare amount — quietly dropping money the
        // buyer owes. The two screens send them; the voice path and any
        // future caller may not, and CLAUDE.md records that the caller
        // without a form is the one that breaks. loads.js guards the same
        // thing with its truckingGiven flag; this is that guard, mirrored.
        const mentions = ('trucking_amount' in entry) || ('trucking_company' in entry)
            || ('trucking_note' in entry);
        if (!mentions) {
            patch.trucking_company = prior.trucking_company || null;
            patch.trucking_amount  = prior.trucking_amount ?? null;
            patch.trucking_note    = prior.trucking_note || null;
        }
        // Recomputed either way: the ITEMS may have changed, which moves
        // `amount`, and a net_receivable left over from the old amount is
        // the stale-derived-figure bug loads.js records having had.
        patch.net_receivable = receivableFrom(patch.amount, patch.trucking_amount);
        // NOTE (mine, not hers): client_request_id is wiped by the same
        // mechanism and is NOT restored here, because that is a separate
        // pre-existing weakness and fixing it was not asked for. Flagged to
        // the owner 2026-09-30; a one-line change if she wants it.
    }
    // An edit invalidates the ticket. Same rule helpers/loads.js applies to a
    // purchase: the stored PDF shows the OLD figures, so leaving the link in
    // place would keep serving a document that disagrees with the record it
    // came from. Cleared here so the card offers "Generate PDF" again.
    patch.pdf_link = null; patch.pdf_drive_id = null;
    patch.receipt_pdf_link = null; patch.receipt_pdf_drive_id = null;
    let updated = null;
    await mutateJson(cfg.OUTBOUND_LOADS_FILE, [], (loads) => {
        const l = loads.find((x) => x.id === id);
        if (l) { Object.assign(l, patch, { updated_at: new Date().toISOString() }); updated = l; }
        return loads;
    });
    return updated;
}

// Writes arbitrary fields straight onto a record, bypassing buildRecord.
// Added 2026-08-24 for the sale-ticket PDF: editOutboundLoad() rebuilds the
// record from a known field list, so pdf_link/pdf_drive_id passed through it
// were silently dropped and the ticket appeared to generate while the card
// never gained a link. Caught before shipping by reading buildRecord rather
// than assuming a patch object survives it.
async function patchOutboundLoad(id, patch) {
    let updated = null;
    await mutateJson(cfg.OUTBOUND_LOADS_FILE, [], (loads) => {
        const l = loads.find((x) => x.id === id);
        if (l) { Object.assign(l, patch, { updated_at: new Date().toISOString() }); updated = l; }
        return loads;
    });
    return updated;
}

// ── ARRIVED ─────────────────────────────────────────────────────────────
// The other half of the delivery enquiry: once she knows it landed, the
// pending "has it been delivered?" has to stop. Cancelling here rather than
// leaving it to the condition gate means the task is gone from her queue
// immediately, not merely inert until its ETA comes round.
//
// `on` is when it was DELIVERED, which is not always when she recorded it —
// a driver phones at six and she enters it next morning.
async function markDelivered(id, { on = null, by = null } = {}) {
    const updated = await patchOutboundLoad(id, {
        delivery_status: 'delivered',
        delivered_at: on || new Date().toISOString(),
        delivered_by: by || null,
    });
    if (!updated) return null;
    try {
        await require('./deliveryEnquiry').cancelForLoad(id, 'delivered');
    } catch (e) {
        // The load IS delivered; that fact must survive a queue problem. Loud
        // in the log rather than thrown, or she would be told the delivery did
        // not record when it did.
        console.error('[DELIVERY] marked delivered but could not cancel the enquiry:', e.message);
    }
    return updated;
}

async function deleteOutboundLoad(id) {
    let existed = false;
    await mutateJson(cfg.OUTBOUND_LOADS_FILE, [], (loads) => {
        const before = loads.length;
        const next = loads.filter((l) => l.id !== id);
        existed = next.length < before;
        return next;
    });
    return existed;
}

function getOutboundLoad(id) {
    return loadOutboundLoads().find((l) => l.id === id) || null;
}

// Margin for ONE outbound load — sold amount minus the full cost of every
// linked inbound load. Reads helpers/loads.js directly rather than being
// passed inbound records, so every caller (API route, report) gets this for
// free without having to separately fetch/pass loads.json themselves.
// Returns null (not 0) for cost/margin when nothing is linked yet — an
// unlinked load has UNKNOWN margin, not zero margin; the dashboard should
// show that distinction, not a misleading "$0 profit".
function getLoadMargin(outboundLoad) {
    const ids = outboundLoad.linked_inbound_load_ids || [];
    if (!ids.length) return { cost: null, margin: null, linkedCount: 0 };
    const { loadLoads } = require('./loads');
    const inbound = loadLoads();
    let cost = 0;
    let foundCount = 0;
    for (const id of ids) {
        const l = inbound.find((x) => x.id === id);
        if (l && l.amount != null) { cost += l.amount; foundCount++; }
    }
    if (!foundCount) return { cost: null, margin: null, linkedCount: ids.length };
    cost = round2(cost);
    // ── amount, NOT receivableOf, AND THAT IS THE POINT (2026-11-04) ─────
    // Trucking on a sale is charged straight through to the buyer, so the
    // money arrives and leaves again: using net_receivable here would show
    // the haulage as profit on the metal, and every sale with a truck on it
    // would look better than it was. The haulage shows up as a trucker bill
    // where it belongs. Anyone tempted to "fix" this to receivableOf for
    // consistency should read helpers/yardProfit.js's double-count comment
    // first — this is the same trap with the sign flipped.
    const margin = outboundLoad.amount != null ? round2(outboundLoad.amount - cost) : null;
    return { cost, margin, linkedCount: ids.length, missingCount: ids.length - foundCount };
}

// Item-wise + per-buyer rollup, same shape/spirit as helpers/loads.js's
// getInventoryReport (bySeller there -> byBuyer here) so the dashboard's
// existing per-seller UI pattern can be reused directly for this, not
// reinvented. from/to are optional 'YYYY-MM-DD' strings (inclusive).
function getOutboundReport(allLoads, { from, to } = {}) {
    const { groupItemsByDescription } = require('./pdf');
    const filtered = (from || to)
        ? allLoads.filter((l) => l.date && (!from || l.date >= from) && (!to || l.date <= to))
        : allLoads;

    const items = filtered.flatMap((l) => (Array.isArray(l.items) ? l.items : []));
    let byType = items.length ? groupItemsByDescription(items) : [];

    // ── HOW MANY LOADS CARRIED THIS ITEM ────────────────────────────────
    // the owner, 2026-10-17: "Build it properly so as sales". The mirror of the
    // same addition in helpers/loads.js's getInventoryReport — these two are
    // the same report with "bought" and "sold" swapped, and adding the
    // column to only the side she happened to name is how half a feature
    // ships (the per-seller/per-buyer case-insensitivity fix above says the
    // same thing about the same pair of functions).
    //
    // `count` is item LINES; this is distinct LOADS. Keyed exactly as
    // groupItemsByDescription keys its rows — trimmed, lower-cased — so the
    // two always line up. NOT alias-merged, because byType here is not
    // either; making only the count alias-aware would have the column
    // disagree with the row it sits on.
    const soldLoadIdsByKey = new Map();
    for (const l of filtered) {
        for (const it of (Array.isArray(l.items) ? l.items : [])) {
            const key = (it && it.description ? String(it.description).trim() : 'Other').toLowerCase();
            if (!soldLoadIdsByKey.has(key)) soldLoadIdsByKey.set(key, new Set());
            soldLoadIdsByKey.get(key).add(l.id);
        }
    }
    byType = byType.map((g) => {
        const set = soldLoadIdsByKey.get(String(g.description || 'Other').trim().toLowerCase());
        return { ...g, loadCount: set ? set.size : 0 };
    });

    // ── ONE BUYER, ONE ROW ───────────────────────────────────────────────
    // the owner, 2026-09-16: "Sellers name/bUyers name-make it case
    // insensitive". Mirror of the per-seller fix in helpers/loads.js and
    // changed in the same breath: these two were the same code with one word
    // different, and fixing only the one she happened to name is how half a
    // bug survives. helpers/canonicalName.js exists so there is now one
    // implementation rather than two that drift.
    const { groupByName, normalizeName } = require('./canonicalName');
    const buyerMap = new Map();
    for (const [key, grp] of groupByName(filtered, (l) => l.buyer, 'Unknown buyer')) {
        buyerMap.set(key, { buyer: grp.label, loadCount: 0, net: 0, amount: 0,
            invoiced: 0, collected: 0, byMode: new Map(),
            cost: 0, costKnown: false, items: [] });
    }
    let overallCost = 0, overallCostKnown = false;

    // ── WHAT WAS INVOICED, AND WHAT CAME BACK (2026-11-07) ───────────────
    // the owner, 2026-11-06: "What if paid by cash,paid by various payment
    // type,invoice amount in report of ege yard/think of all permuattion adn
    // combination", then "not in nightky yard report.in webiste/app".
    //
    // This report answered one question — what did we SELL — and she was
    // asking a different one: of that, what has actually been collected, and
    // how. A sales figure with no collection beside it reads as money in the
    // bank when half of it may still be owed.
    //
    // THREE FIGURES, NOT ONE, because they are genuinely different:
    //   amount    the METAL. Untouched, because `margin` is measured against
    //             it and the haulage she recharges is a pass-through, not
    //             profit. Changing this would quietly move every margin.
    //   invoiced  what the buyer was actually billed — receivableOf, so the
    //             trucking charged to him is in it. The old report summed
    //             `amount` and therefore UNDER-REPORTED the invoice by
    //             exactly the haulage, the same mistake api.js made on the
    //             payment path (fixed yesterday).
    //   collected what has been received against it.
    //
    // Lazy require: helpers/payments.js already requires THIS file, so a
    // top-level require back would be a cycle.
    const pay = (() => { try { return require('./payments'); } catch (e) { return null; } })();

    for (const l of filtered) {
        const key = normalizeName(String(l.buyer || '').trim()) || '~blank';
        const b = buyerMap.get(key);
        if (!b) continue;
        b.loadCount += 1;
        b.net += l.net_weight || 0;
        b.amount += l.amount || 0;
        // The whole invoice, haulage included.
        b.invoiced += receivableOf(l) || 0;
        if (pay) {
            // Payments are read per load rather than totalled off the load,
            // because a load carries no paid figure — the payments store is
            // the only truth, and it is what every screen already reads.
            const sum = pay.paymentSummary(l.id, receivableOf(l));
            b.collected += sum.paid || 0;
            for (const row of (sum.payments || [])) {
                const mode = String((row && row.mode) || 'Not recorded');
                b.byMode.set(mode, round2((b.byMode.get(mode) || 0) + (Number(row.amount) || 0)));
            }
        }
        if (Array.isArray(l.items)) b.items.push(...l.items);
        // Margin only accumulates for loads that actually have a linked
        // inbound cost — an unlinked load contributes to net/amount (real,
        // known numbers) but is left OUT of the margin sum rather than
        // silently treated as $0 cost, which would overstate margin.
        const m = getLoadMargin(l);
        if (m.cost != null) { b.cost += m.cost; b.costKnown = true; overallCost += m.cost; overallCostKnown = true; }
    }
    const byBuyer = Array.from(buyerMap.values())
        .map((b) => ({
            buyer: b.buyer,
            loadCount: b.loadCount,
            net: round2(b.net),
            amount: round2(b.amount),
            invoiced: round2(b.invoiced),
            collected: round2(b.collected),
            // Never negative: an overpayment is not "minus owed". Same rule
            // helpers/payments.js's paymentSummary follows for `pending`.
            outstanding: Math.max(0, round2(b.invoiced - b.collected)),
            byMode: [...b.byMode.entries()]
                .map(([mode, amount]) => ({ mode, amount }))
                .sort((x, y) => y.amount - x.amount),
            cost: b.costKnown ? round2(b.cost) : null,
            margin: b.costKnown ? round2(b.amount - b.cost) : null,
            byType: b.items.length ? groupItemsByDescription(b.items) : [],
        }))
        .sort((a, b) => (b.net || 0) - (a.net || 0));

    const totalAmount = filtered.reduce((sum, l) => sum + (l.amount || 0), 0);
    const totalInvoiced = byBuyer.reduce((s, b) => s + (b.invoiced || 0), 0);
    const totalCollected = byBuyer.reduce((s, b) => s + (b.collected || 0), 0);
    // One list for the whole report, so "how much came in as cash" is
    // answerable without adding up the buyers by hand.
    const modeTotals = new Map();
    for (const b of byBuyer) {
        for (const m of (b.byMode || [])) {
            modeTotals.set(m.mode, round2((modeTotals.get(m.mode) || 0) + m.amount));
        }
    }
    return {
        loadCount: filtered.length,
        unit: filtered.find((l) => l.weight_unit)?.weight_unit || 'lb',
        byType,
        byBuyer,
        totalAmount: round2(totalAmount),
        totalInvoiced: round2(totalInvoiced),
        totalCollected: round2(totalCollected),
        totalOutstanding: Math.max(0, round2(totalInvoiced - totalCollected)),
        byMode: [...modeTotals.entries()]
            .map(([mode, amount]) => ({ mode, amount }))
            .sort((a, b) => b.amount - a.amount),
        totalCost: overallCostKnown ? round2(overallCost) : null,
        totalMargin: overallCostKnown ? round2(totalAmount - overallCost) : null,
    };
}

module.exports = {
    receivableOf, receivableFrom,
    normaliseDraws, patchOutboundLoad,
    loadOutboundLoads, addOutboundLoad, editOutboundLoad, deleteOutboundLoad, getOutboundLoad, getOutboundReport, getLoadMargin,
    markDelivered,
};
