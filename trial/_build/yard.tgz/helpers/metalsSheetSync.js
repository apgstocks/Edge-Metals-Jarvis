// ── helpers/metalsSheetSync.js — her live workbook, read into Sample Yard Co Metals ──
//
// the owner, 2026-09-24: "at everyday night,a bot should run which need to update
// my bills and invoices in website from live sheet..if anything is missing,
// enter that as well".
//
// Asked what to do when the sheet and Jarvis disagree about a row that already
// exists, she chose: "1 with discrepancy should be notified via email report"
// — option 1 being ADD WHAT IS MISSING, TOUCH NOTHING THAT EXISTS. And for the
// first run: "Dry run first — report only, write nothing".
//
// ── NOT helpers/sheetSync.js ───────────────────────────────────────────────
// That name was already taken, by the SAMPLE YARD CO YARD sync that pushes loads and
// expenses OUT to Drive every night (scheduler.js calls its syncNow). This
// reads her Sample Yard Co Metals workbook IN. Opposite direction, opposite company.
// I overwrote that file once while building this; the nightly yard sync would
// have thrown on a missing export at 11pm. Hence the longer name.
//
// ── SO THIS NEVER EDITS A ROW ──────────────────────────────────────────────
// It inserts rows Jarvis does not have, and for rows it DOES have it compares
// and reports. That asymmetry is the whole safety story:
//
//   - 260831_SU_26EM05 was billed $13.09 and corrected on 2026-09-23. An
//     overwriting sync would have put the wrong figure back that night, from
//     a sheet that still holds it.
//   - Rows 59–61 of her Packing tab have an HS code containing a comma, which
//     shifts every column after it. Those are unreadable, not authoritative.
//   - One price column carries both $/lb and $/MT with nothing marking which.
//
// A person can look at a discrepancy and know which side is right. A cron job
// at 11pm cannot, and there is nobody awake to ask.
//
// ── AND IT RUNS THE SAME CODE HER UPLOAD RUNS ──────────────────────────────
// The live workbook is fetched as XLSX and handed to helpers/sheetImport.js's
// readWorkbook — the identical function behind the Upload screen, not a second
// parser reading the same columns slightly differently.

const cfg = require('../config');

// ── ROW IDENTITY ───────────────────────────────────────────────────────────
// Her rule, 2026-09-16: A CONTAINER IS booking_no + container_no TOGETHER,
// NEVER BOOKING ALONE — "UMXU637049 is a trailer that goes out again next
// week", so keying on the booking would call the second trip the first and
// skip a real bill.
const norm = (v) => String(v == null ? '' : v).trim().toUpperCase().replace(/\s+/g, '');

function billKey(row) {
    const b = norm(row && row.booking_no), c = norm(row && row.container_no);
    if (!b && !c) return null;             // nothing to match on — never "new"
    return `${b}|${c}`;
}
// ── AND A SALE IS KEYED BY ITS GRADE TOO ───────────────────────────────────
// One invoice covers several grades and sheetImport's toSales does NOT group
// them — one row per grade, deliberately (toBills groups by container; toSales
// does not). Keying on invoice + container alone collapsed them, and the first
// dry run showed exactly what that costs:
//
//   260923_MC_26MK80 / KOCU4930737 appeared TWICE in the insert list — it
//   would have been added twice that night and twice again the next;
//
//   and 251203 25DHATU01 compared Alternators, Starters AND Compressors
//   against one stored row, then reported the other two as disagreements.
//   Most of that run's 94 conflicts were this artefact, not real ones.
//
// The grade is what makes the row, so the grade is in the key.
function saleKey(row) {
    const i = norm(row && row.invoice_no), c = norm(row && row.container_no);
    const g = norm(row && (row.item || row.description));
    if (!i && !c) return null;
    return `${i}|${c}|${g}`;
}

// ── IS THIS A SHIPMENT AT ALL? ─────────────────────────────────────────────
// sheetImport keeps any row that says ANYTHING — its own comment: "Only a row
// that says NOTHING is dropped". That is right for the upload screen, where
// she reviews the list before it is written. It is wrong at 11pm with nobody
// watching, and the first dry run proved it: these three were queued as new
// invoices —
//
//   AL-ALUMINIUM COMBO,AP-Scrap Auto Parts,RC-Regular Combo,…   (her legend)
//   QB DONE TILL 5/8                                            (a note)
//   260630_BAT_26NT08 … "Order confirmed on Text with ops"     (a note in the
//                                                                container cell)
//
// So a row must LOOK like a shipment before anything is inserted from it: a
// date, and something that identifies the container it travelled in. Rows that
// fail are reported, never written — she can see them and decide.
const CONTAINER_RE = /^[A-Z]{4}\d{6,7}$/;

function looksLikeShipment(row) {
    if (!row) return false;
    const c = norm(row.container_no), b = norm(row.booking_no);
    // Prose in the invoice cell: her legend row is one long comma-separated
    // line, and a note is a sentence. Neither is an invoice number.
    const inv = String((row.invoice_no == null ? '' : row.invoice_no)).trim();
    if (inv.length > 40 || /,\s/.test(inv)) return false;
    // A container number has a shape. A sentence in that cell does not.
    if (c && !CONTAINER_RE.test(c) && !b) return false;
    if (!c && !b) return false;                 // nothing to identify it by
    if (!String(row.date || '').trim()) return false;
    return true;
}

// ── WHAT COUNTS AS A DISAGREEMENT ──────────────────────────────────────────
// Only the fields that are hers to type. Derived figures are deliberately not
// compared: sheetImport does not import Total, NET, MT or INVOICE AMT because
// Jarvis recomputes them, so a difference there is arithmetic, not a conflict,
// and reporting it nightly would bury the real ones.
const BILL_WATCH = ['date', 'supplier', 'supplier_price', 'supplier_invoice_amount',
    'trucking_amount', 'seal_no', 'description', 'gross'];
const SALE_WATCH = ['date', 'customer', 'consignee', 'invoice_price', 'freight_charges',
    'commission_per_mt', 'seal_no', 'item'];

const same = (a, b) => {
    // Whitespace collapsed, not just trimmed. The first dry run reported
    // supplier: sheet "Sample Yard Co Yard" vs Jarvis "SampleYardCoYard" as a disagreement —
    // one spacing difference is not a change of supplier.
    const flat = (v) => String(v == null ? '' : v).trim().replace(/\s+/g, ' ');
    const x = flat(a);
    const y = flat(b);
    // A blank on EITHER side is not a disagreement — a field she has not
    // filled in yet on one side is the normal state of a live sheet.
    if (!x || !y) return true;
    if (x === y) return true;
    // ── BOTH SIDES MUST ACTUALLY BE NUMBERS ────────────────────────────────
    // Stripping non-numerics from "Gomez" leaves an empty string, and
    // Number('') is 0 — so without this guard "Gomez" and "Freddy" both became
    // 0 and compared EQUAL. A supplier changing on a bill would have gone
    // unreported, which is exactly what this job exists to catch. Found by
    // tests/metals-sheet-sync.js section E.
    const digits = (s) => /[0-9]/.test(String(s));
    const nx = digits(x) ? Number(String(x).replace(/[^0-9.-]/g, '')) : NaN;
    const ny = digits(y) ? Number(String(y).replace(/[^0-9.-]/g, '')) : NaN;
    // Money and weights: equal to the cent. "1,250.00" and "1250" are the same
    // number typed two ways, and flagging that is noise.
    if (Number.isFinite(nx) && Number.isFinite(ny)) return Math.abs(nx - ny) < 0.005;
    return x.replace(/\s/g, '').toLowerCase() === y.replace(/\s/g, '').toLowerCase();
};

// ── FREIGHT IS NOT A FIELD ANY MORE ───────────────────────────────────────
// the owner, 2026-09-28, on a live dry run: "freight_charges: sheet 553 vs
// Jarvis 170 — why?"
//
// Because this was comparing a dead column. helpers/sales.js:333 says it
// plainly: freight_charges is "GONE from the columns" since 2026-09-10 and
// kept writable only so rows entered before then do not lose their money.
// Freight now lives in `charges[]`, where it can carry the note she asked
// for. compute() folds a legacy value into that list ONLY when there is no
// list — so on any row entered since, freight_charges holds whatever was
// there before and the real figure is in the charges.
//
// So the sheet's single freight column was being compared against a
// superseded field, and every row entered since 10 September reported a
// disagreement that does not exist.
//
// ── WHAT IT COMPARES NOW, AND WHAT IT REFUSES TO ──────────────────────────
// Her sheet has ONE freight number. Jarvis has a LIST with notes. Those are
// not the same shape, and pretending otherwise is how the last wrong answer
// happened. So:
//
//   · charges named freight  ->  compared against the sheet's column.
//   · a legacy row (no list) ->  compared, exactly as before.
//   · outgoing charges that are NOT freight -> NOT silently added in. An
//     inspection fee is not freight, and quietly summing it would invent a
//     disagreement in the other direction.
//
// When Jarvis holds outgoing charges but none of them is named freight, the
// two sides cannot be compared field-to-field at all, and the difference SAYS
// so rather than printing a number that means something else.
const FREIGHT_RE = /freight|ocean|drayage/i;

// This file had no number helpers — it compared strings. freightOf needs to
// ADD charges up, so it needs real ones. Written here rather than imported
// from sales.js, because this module is deliberately pure: the whole point of
// diff() is that it can be handed two plain arrays and tested with no ledger,
// no network and no clock.
const num = (v) => {
    if (v === null || v === undefined || v === '') return null;
    const n = typeof v === 'number' ? v : parseFloat(String(v).replace(/[$,\s]/g, ''));
    return isFinite(n) ? n : null;
};
const round2 = (n) => (typeof n === 'number' && isFinite(n) ? Math.round(n * 100) / 100 : null);

function freightOf(row) {
    const charges = Array.isArray(row && row.charges) ? row.charges : [];
    const out = charges.filter((c) => c && c.direction === 'out');
    if (!out.length) {
        // Nothing in the list: the legacy column is all there is, and
        // compute() would have folded it in anyway.
        return { amount: num(row && row.freight_charges), basis: 'legacy field' };
    }
    const freight = out.filter((c) => FREIGHT_RE.test(String(c.what || '')));
    if (freight.length) {
        return { amount: round2(freight.reduce((t, c) => t + (num(c.amount) || 0), 0)), basis: 'charges' };
    }
    // Charges, but none of them freight. Comparable to nothing.
    return { amount: null, basis: 'no freight charge', others: out.length };
}

function differences(sheetRow, jarvisRow, watch) {
    const out = [];
    for (const f of watch) {
        if (f === 'freight_charges') {
            const mine = freightOf(jarvisRow);
            if (mine.amount === null) {
                // Only worth saying when the sheet actually claims freight.
                if (num(sheetRow[f])) {
                    out.push({ field: 'freight_charges', sheet: sheetRow[f],
                        jarvis: `no freight charge (${mine.others} other charge${mine.others === 1 ? '' : 's'})`,
                        note: 'the sheet has one freight column; Jarvis has a charge list with none named freight' });
                }
                continue;
            }
            if (!same(sheetRow[f], mine.amount)) {
                out.push({ field: 'freight_charges', sheet: sheetRow[f], jarvis: mine.amount, from: mine.basis });
            }
            continue;
        }
        if (!same(sheetRow[f], jarvisRow[f])) {
            out.push({ field: f, sheet: sheetRow[f], jarvis: jarvisRow[f] });
        }
    }
    return out;
}

// ── WHAT THE SHEET HAS AND JARVIS DOES NOT ─────────────────────────────────
// the owner, 2026-10-01: "check sheet properly,whatever is missed in jarvis fill
// it. Every day,ensure that there is no discrepancy."
//
// This is NOT differences(). same() deliberately returns true when either
// side is blank — "a field she has not filled in yet on one side is the
// normal state of a live sheet" — and that is right for the disagreements
// email, which exists to show her two conflicting numbers. A blank is not a
// conflict.
//
// But it meant a blank was invisible to every consumer, and the 07:30 ledger
// agent is built entirely around filling blanks. Its sheet source could only
// ever propose and never fill, which is the half she asked for.
//
// So blanks get their own list rather than being folded into changedBills.
// Folding them in would have put every empty seal_no into her nightly
// DISAGREEMENTS section, which is the opposite of what that section is for.
// Additive: metalsSheetSyncJob's report reads changedBills/changedSales by
// name and ignores this.
function blanksOnly(sheetRow, jarvisRow, watch) {
    const out = [];
    const flat = (v) => String(v == null ? '' : v).trim();
    for (const f of watch) {
        // freight is a shape mismatch, not a blank — see freightOf. The
        // sheet has one number, Jarvis has a list with notes, and "filling"
        // across that gap is exactly the wrong answer this file already
        // learned once.
        if (f === 'freight_charges') continue;
        const theirs = flat(sheetRow[f]);
        const mine = flat(jarvisRow[f]);
        if (theirs && !mine) out.push({ field: f, sheet: sheetRow[f], jarvis: '' });
    }
    return out;
}

// ── THE DIFF ───────────────────────────────────────────────────────────────
// Pure: hand it what the sheet says and what Jarvis holds, get back what would
// happen. No fetching, no writing, no clock — which is what makes the night
// job's decision testable without a network or a live ledger.
//
// ── `since`: NOTHING OLDER THAN THIS IS ADDED (2026-10-12) ─────────────────
// the owner: "i dont want 2025 row bills and shipments in sweep into jarvis from
// sheet on every day". OPT-IN: pass { since: 'YYYY-MM-DD' } and a sheet row
// dated before it is not queued as new — it is listed in report.beforeCutoff
// so she can see what was left out. Without `since` this behaves exactly as
// before, because scripts/fill-money-blanks.js and scripts/why-one-sided.js
// call diff() too and were not asked to change.
//
// ONLY THE INSERT PATH. A row already in Jarvis is still compared (changed /
// fillable) whatever its date; deciding whether old rows should also stop
// being compared is a separate question for her. A date that is not
// YYYY-MM-DD is not blocked: better one extra row she can see than a real
// shipment dropped because its date was written oddly.
const ISO_DAY = /^\d{4}-\d{2}-\d{2}$/;
const olderThan = (row, since) => {
    const d = String((row && row.date) || '').trim().slice(0, 10);
    return !!since && ISO_DAY.test(d) && ISO_DAY.test(since) && d < since;
};
function diff({ sheetBills = [], sheetSales = [], bills = [], sales = [], since = null }) {
    const haveBills = new Map();
    for (const b of bills) { const k = billKey(b); if (k) haveBills.set(k, b); }
    const haveSales = new Map();
    for (const s of sales) { const k = saleKey(s); if (k) haveSales.set(k, s); }
    // ── A BLANK INVOICE NO. ON EITHER SIDE IS NOT A DIFFERENT INVOICE ─────
    // the owner, 2026-10-12: where the sheet's invoice cell is empty but
    // QuickBooks made a number and it was put into Jarvis, "keep it as per
    // quickbook. I don't want to make them back to empty on daily sweep".
    // saleKey includes the invoice number, so `|CONT|ITEM` (sheet, blank) and
    // `1043|CONT|ITEM` (Jarvis, filled) never met, and the sweep queued the
    // sheet row as NEW — a duplicate invoice, every time the sweep ran.
    // So when the full key finds nothing, a stored row on the SAME container
    // and item is the same row if either side's number is blank. Two rows
    // with DIFFERENT non-blank numbers stay separate (split billing).
    const looseKey = (r) => {
        const c = norm(r && r.container_no), g = norm(r && (r.item || r.description));
        return c ? `${c}|${g}` : null;
    };
    const haveSalesLoose = new Map();
    for (const s of sales) {
        const lk = looseKey(s);
        if (!lk) continue;
        if (!haveSalesLoose.has(lk)) haveSalesLoose.set(lk, []);
        haveSalesLoose.get(lk).push(s);
    }

    const report = { newBills: [], newSales: [], changedBills: [], changedSales: [],
                     // Blanks, kept OUT of changedBills on purpose — see
                     // blanksOnly. These are what the 07:30 agent fills.
                     fillableBills: [], fillableSales: [],
                     unkeyed: [], notShipments: [], beforeCutoff: [], since: since || null };

    for (const row of sheetBills) {
        // A legend line or a note to herself is not a bill. Reported, never
        // written — see looksLikeShipment.
        if (!looksLikeShipment(row)) { report.notShipments.push({ kind: 'bill', row }); continue; }
        const k = billKey(row);
        // No booking AND no container: it cannot be matched next time, so it
        // must not be inserted either — an unkeyable row added tonight is a
        // duplicate added every night after.
        if (!k) { report.unkeyed.push({ kind: 'bill', row }); continue; }
        const mine = haveBills.get(k);
        if (!mine) {
            if (olderThan(row, since)) report.beforeCutoff.push({ kind: 'bill', row });
            else report.newBills.push(row);
            continue;
        }
        const blank = blanksOnly(row, mine, BILL_WATCH);
        if (blank.length) report.fillableBills.push({ key: k, row_id: mine && mine.id,
            container_no: row.container_no, supplier: row.supplier, blanks: blank });
        const d = differences(row, mine, BILL_WATCH);
        // row_id so a consumer can ACT on a difference rather than only
        // print it. helpers/ledgerAgent.apply needs the row to patch, and
        // without this it had nothing to write to — the sheet half produced
        // findings nobody could apply. Additive: every existing reader
        // ignores it.
        if (d.length) report.changedBills.push({ key: k, row_id: mine && mine.id,
            container_no: row.container_no, supplier: row.supplier, differences: d });
    }
    for (const row of sheetSales) {
        if (!looksLikeShipment(row)) { report.notShipments.push({ kind: 'sale', row }); continue; }
        const k = saleKey(row);
        if (!k) { report.unkeyed.push({ kind: 'sale', row }); continue; }
        let mine = haveSales.get(k);
        if (!mine) {
            const cands = haveSalesLoose.get(looseKey(row)) || [];
            const sheetBlank = !norm(row.invoice_no);
            mine = cands.find((c) => sheetBlank || !norm(c.invoice_no));
        }
        if (!mine) {
            if (olderThan(row, since)) report.beforeCutoff.push({ kind: 'sale', row });
            else report.newSales.push(row);
            continue;
        }
        const blank = blanksOnly(row, mine, SALE_WATCH);
        if (blank.length) report.fillableSales.push({ key: k, row_id: mine && mine.id,
            invoice_no: row.invoice_no, container_no: row.container_no,
            customer: row.customer, blanks: blank });
        const d = differences(row, mine, SALE_WATCH);
        if (d.length) report.changedSales.push({ key: k, row_id: mine && mine.id,
            invoice_no: row.invoice_no, container_no: row.container_no,
            customer: row.customer, differences: d });
    }
    return report;
}

// ── THE LIVE WORKBOOK ──────────────────────────────────────────────────────
// Exported as XLSX so readWorkbook gets exactly what an upload gives it. Kept
// separate from diff() on purpose: the decision is testable offline, and this
// is the only part that can fail for reasons that have nothing to do with her
// data — a redirect, an expired share, a network down at 11pm.
function fetchWorkbook(sheetId) {
    const id = sheetId || cfg.INVOICE_SHEET_ID;
    const url = `https://docs.google.com/spreadsheets/d/${id}/export?format=xlsx`;
    return new Promise((resolve, reject) => {
        const get = (u, hops) => {
            if (hops > 5) return reject(new Error('too many redirects fetching the workbook'));
            require('https').get(u, { headers: { 'User-Agent': 'jarvis-metals-sheet-sync' } }, (res) => {
                if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                    res.resume();
                    return get(res.headers.location, hops + 1);
                }
                if (res.statusCode !== 200) {
                    res.resume();
                    return reject(new Error(`the workbook came back HTTP ${res.statusCode}`));
                }
                const chunks = [];
                res.on('data', (c) => chunks.push(c));
                res.on('end', () => resolve(Buffer.concat(chunks)));
            }).on('error', reject);
        };
        get(url, 0);
    });
}

// One line she can read at a glance. Written here rather than in the mailer so
// the same words go to email, to the log and to WhatsApp.
function summarise(report) {
    const n = report.newBills.length + report.newSales.length;
    const c = report.changedBills.length + report.changedSales.length;
    const head = n
        ? `${n} row${n === 1 ? '' : 's'} to add (${report.newBills.length} bills, ${report.newSales.length} invoices)`
        : 'Nothing new';
    const tail = c ? `, ${c} disagree with the sheet` : '';
    const bad = report.unkeyed.length ? `, ${report.unkeyed.length} unreadable` : '';
    const nots = (report.notShipments || []).length
        ? `, ${report.notShipments.length} not shipment rows` : '';
    const old = (report.beforeCutoff || []).length
        ? `, ${report.beforeCutoff.length} older than ${report.since} left out` : '';
    return head + tail + bad + nots + old + '.';
}

module.exports = { diff, differences, blanksOnly, billKey, saleKey, same, fetchWorkbook, summarise,
    looksLikeShipment, BILL_WATCH, SALE_WATCH };
