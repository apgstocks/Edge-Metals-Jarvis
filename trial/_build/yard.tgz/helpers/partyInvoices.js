// ── helpers/partyInvoices.js — what carrier, Jio, Sher, Pan Metal, AJ Transport and Garduno's invoiced ──
// the owner, 2026-10-07: "similar for carrier, jio, sher, pan metal, AJ, Gardunos" — an invoice
// LIST per party, read from email, in Jarvis ("Jarvis is the ultimate record"). Chosen over
// copying the sheet tabs into bills (that is scripts/trucker-tabs-to-bills.js).
//
// A REGISTER, NOT A LEDGER. Own store (party_invoices.json). Nothing reads it except the
// register tab: it is not a bill, a sale or a book entry, so it changes no supplier balance
// and no statement. It records WHAT EACH PARTY BILLED and whether the line was found on the
// Invoice sheet.
//
// ── PAYING (added 2026-10-07: "edit, delete, pay ... a single payment against multiple") ──
// Payments live in their OWN store (party_invoice_payments.json), one payment allocated
// across one or more invoice lines of ONE party. Paid / balance / status of a line are
// DERIVED from those allocations — never typed onto the row, so there is no second figure
// to disagree with. This is a register-only record of what was paid; it posts nothing to
// bills, the books, bank matching or QuickBooks.
//
// Rules that protect the figures: allocations must add up to the payment exactly; a line
// can never be paid more than it is owed; a payment never spans two parties; an edit may
// not take a line's amount below what has been paid against it; a line with money paid
// against it cannot be deleted until that payment is.
//
// One row per invoice LINE (a container, a booking or an HBL), keyed
// party + invoice_no + line key, so a re-import updates in place. A row with `locked`
// (hand-edited) is never overwritten. Writes are strict: a lost write must throw.
const cfg = require('../config');
const { loadJson, mutateJson } = require('./json');

// ── COMMISSION AGENTS ARE PARTIES TOO ───────────────────────────────────
// the owner, 2026-10-14: "WHy joey commission not built in jarvis?" — and, on
// how it should work: "We have already told about pan metal commission.
// Mimic that."
//
// Pan Metal was already the precedent, and it is exact: amountOf() below
// reads `commission` for panmetal where every other party uses an invoice
// total. So an agent is a party whose line amount IS the commission.
//
// WHY THIS, RATHER THAN A FIELD ON THE SALE. helpers/sales.js has
// commission_per_mt and commission_amount — ONE rate, ONE amount, and NO
// PAYEE. Her own mails routinely name two or three agents on one sale;
// proformaFromEmail.js records her example verbatim: "$2,520 CIF Busan (10c
// for Mr.Kim and 10c for Hynos included)". Two of those three commissions
// have nowhere to live on a sale row, and none of them has a name.
//
// AND IT CANNOT DOUBLE-COUNT. This file is a REGISTER: its header says it
// "posts nothing to bills, the books, bank matching or QuickBooks". The
// sale's commission_amount still posts 5300/2100 exactly as it did, so the
// books are untouched and the register answers the question the books
// cannot — WHO, and HAVE I PAID THEM.
//
// JOEY ONLY, AND THAT IS DELIBERATE. Her Verification tab already reads
// "Under commission-Joey,Pan metal" (documents.html:939) — a Joey sub-tab
// and a verifyPanelJoey have existed since that tab was built, as an
// honest placeholder with no store behind them. So this connects a screen
// she already has rather than inventing one.
//
// Mr. Kim appears in her mails too ("10c for Mr.Kim and 10c for Hynos
// included") but she has never asked for him as a tab, and a name read out
// of an email is not a decision. One entry here plus one sub-tab button
// when she says so.
//
// 'joey' is labelled "Joey (Hynos)" because the two names are a person and
// his company, and both are needed. the owner, 2026-10-15: "Hynos is a company
// joey is its owner" — and her sample commission invoice is issued by HYNOS
// (beneficiary Hynos, signed Hynos SooAn Choi, paid to Industrial Bank of
// Korea), while "Joey" in her address book is a broker alias shared across
// Yeon Seong, Shinyoung, CM Trading, CM Global, Taewon and Buyerco. So the
// tab stays the person she deals with; the register row names the entity the
// wire actually goes to. Her choice, asked 2026-10-15.
const PARTIES = { carrier: 'carrier', eagle: 'Eagle Trans', jio: 'Jio', sher: 'Sher Trucking', ajtransport: 'AJ Transport', panmetal: 'Pan Metal', gardunos: "Garduno's",
    joey: 'Joey (Hynos)' };
// A party whose line amount is a COMMISSION on a sale, not something they
// invoiced. Pan Metal has always been one — it is named here so the rule is
// a list rather than a special case buried in amountOf().
const COMMISSION_PARTIES = new Set(['panmetal', 'joey']);
// The sweep calls Eagle Trans 'eaglebrit'.
const ALIAS = { eaglebrit: 'eagle' };
// Same ceiling the sweep uses for its trucker tab logging: a drayage line is hundreds of
// dollars; above this on a trucker is almost certainly Sample's own outbound invoice.
const TRUCKING_CAP = 3000;
const TRUCKERS = ['jio', 'sher', 'ajtransport', 'gardunos'];

const num = (v) => { if (v === null || v === undefined || v === '') return null; const n = parseFloat(String(v).replace(/[$,\s]/g, '')); return Number.isFinite(n) ? Math.round(n * 100) / 100 : null; };
const txt = (v) => String(v == null ? '' : v).trim();
const up = (v) => txt(v).toUpperCase().replace(/\s+/g, '');

// "166 REVISED" replaces "166". The line's identity is the BASE number, so a revised
// invoice and the original it replaces are the same line, not two (the owner, 2026-10-07,
// pasting Garduno's 166 listed twice: "166 revised" and "166", six containers each at $930).
const REVISED_RE = /\s*\b(REV(ISED|ISION)?|CORRECTED|AMENDED)\b.*$/i;
const baseInvoice = (no) => txt(no).replace(REVISED_RE, '').trim();
const isRevised = (no) => REVISED_RE.test(txt(no)) && baseInvoice(no) !== '';

// ── TWO COMMISSION LINES ON ONE CONTAINER ────────────────────────────────
// Hynos's invoice EM-261014-01 bills eight contracts TWICE on the same
// container — one container, two weights, two commission figures (26JY51 /
// KOCU5148281 at $32.16 and again at $87.14). The line key is
// party:invoice:container, so both lines produce the identical key and
// upsertMany treats the second as an UPDATE of the first. On one import of
// that one invoice $237.32 vanishes with no error and no skip reason.
//
// the owner chose (2026-10-15) to widen the key for COMMISSION PARTIES ONLY,
// so the seven other parties are untouched. This is narrower still, and
// deliberately so: the suffix is added only when a batch ACTUALLY collides,
// and only to the second and later rows of the collision. A commission line
// that does not collide keeps a byte-identical key, which matters because
// her register lives on the VM and I cannot see how many Pan Metal rows are
// already in it — a key that changed under them would re-insert every one as
// a duplicate rather than update it.
//
// The ordinal comes from the data (sorted by amount, then weight), not from
// the position in the batch, so a re-import of the same invoice reproduces
// the same keys whatever order the extractor emits lines in.
//
// KNOWN HOLE, not closed: this sees collisions WITHIN one import. If the two
// halves of a split container arrive in separate imports, the second still
// overwrites the first, because "a different line with the same key" and "a
// correction to the line already here" are the same thing from here and
// guessing between them would be worse. An invoice is imported whole, so her
// actual flow is covered; upsertMany reports dup_lines so a split that did
// happen is visible rather than silent.
const DUP_SUFFIX_RE = /#dup=\d+$/;
const dupSuffixOf = (key) => { const m = DUP_SUFFIX_RE.exec(txt(key)); return m ? m[0] : ''; };

function disambiguateDups(rows) {
    const groups = new Map();
    for (const r of rows) {
        if (!COMMISSION_PARTIES.has(r.party)) continue;
        if (!groups.has(r.key)) groups.set(r.key, []);
        groups.get(r.key).push(r);
    }
    let marked = 0;
    for (const g of groups.values()) {
        if (g.length < 2) continue;
        const ordered = g.slice().sort((a, b) => (num(a.amount) - num(b.amount)) || ((num(a.quantity) || 0) - (num(b.quantity) || 0)));
        // The first keeps the key it has always had; only the extras are marked.
        for (let i = 1; i < ordered.length; i++) { ordered[i].key += `#dup=${i + 1}`; marked++; }
    }
    return marked;
}

// What this line is worth, by party — the same field order the sweep itself reads.
function amountOf(party, r) {
    // A commission party's line IS the commission. Was `party === 'panmetal'`
    // until 2026-10-14; the set is the same rule with the agents added, so
    // Joey's line reads his commission the way Pan Metal's always has.
    if (COMMISSION_PARTIES.has(party)) return num(r.commission != null ? r.commission : r.amount);
    return num(r.net_amount != null ? r.net_amount : (r.total_amount != null ? r.total_amount : r.amount));
}

// One export record -> a register row, or { skip: reason }.
function normalize(rec) {
    const rawParty = txt(rec && rec.party).toLowerCase();
    const party = ALIAS[rawParty] || rawParty;
    if (!PARTIES[party]) return { skip: 'unknown party' };
    if (rec.extraction_failed) return { skip: 'extraction failed' };
    const amount = amountOf(party, rec);
    if (amount === null || amount === 0) return { skip: 'no amount (booking confirmation / certificate, not an invoice)' };
    // A negative line is a credit (carrier has 133 of them in 2026) and is kept, as it always was — an earlier
    // revision of this file skipped negatives for every party but Eagle, which silently dropped them from
    // the import. It is marked credit_note so it cannot be paid or edited to a positive.
    // Per load, for sher: the invoice amount covers `quantity` loads.
    const perLoad = TRUCKERS.includes(party) ? amount / (Number(rec.quantity) > 0 ? Number(rec.quantity) : 1) : 0;
    if (TRUCKERS.includes(party) && perLoad > TRUCKING_CAP) return { skip: `over $${TRUCKING_CAP} per load — probably not a ${PARTIES[party]} invoice` };
    // Eagle bills a BOOKING in one total with several containers: one register line per INVOICE,
    // containers kept as a list (the figure is never divided across them).
    const containers = party === 'eagle' ? (Array.isArray(rec.containers) ? rec.containers.map(up).filter(Boolean) : []) : [];
    const line = containers.join(',') || up(rec.container_no) || up(rec.booking_no) || up(rec.hbl_no) || up(rec.order_no);
    const invoiceNo = txt(rec.invoice_no);
    if (!line && !invoiceNo) return { skip: 'no invoice number and no container/booking/HBL to key it on' };
    return {
        row: {
            party, key: `${party}:${baseInvoice(invoiceNo) || '(none)'}:${(party === 'eagle' && up(rec.booking_no)) || line || '(none)'}`,
            invoice_no: invoiceNo || null, revised: isRevised(invoiceNo), invoice_date: txt(rec.invoice_date) || null,
            container_no: containers.join(',') || up(rec.container_no) || null, booking_no: up(rec.booking_no) || null, hbl_no: up(rec.hbl_no) || null,
            ...(amount < 0 || rec.kind === 'credit_note' ? { kind: 'credit_note' } : {}),
            ...(party === 'eagle' ? { containers } : {}),
            amount, quantity: num(rec.quantity),
            check_status: txt(rec.status) || null,            // verified / match / not_in_sheet / booking_mismatch / …
            source_file: txt(rec.source_file) || null, source_subject: txt(rec.source_subject) || null,
            source_date: txt(rec.source_date) || null, source_mailbox: txt(rec.source_mailbox) || null,
        },
    };
}

const list = () => { const r = loadJson(cfg.PARTY_INVOICES_FILE, []); return Array.isArray(r) ? r : []; };

// rows: normalize().row[]. Returns { added, updated, kept_locked, dup_lines }.
async function upsertMany(rows) {
    let added = 0, updated = 0, keptLocked = 0;
    // Copied before disambiguateDups rewrites keys, so a caller that reuses
    // its own rows afterwards sees them exactly as it built them.
    rows = (Array.isArray(rows) ? rows : []).map((r) => ({ ...r }));
    const dupLines = disambiguateDups(rows);
    const paidNow = paidByRow();
    await mutateJson(cfg.PARTY_INVOICES_FILE, [], (cur) => {
        const arr = Array.isArray(cur) ? cur : [];
        const at = new Map(arr.map((r, i) => [r.key, i]));
        for (const row of rows) {
            const now = new Date().toISOString();
            if (!at.has(row.key)) { arr.push({ id: `PI_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, ...row, createdAt: now, updatedAt: now }); at.set(row.key, arr.length - 1); added++; }
            else if (arr[at.get(row.key)].locked) keptLocked++;
            // The ORIGINAL never overwrites a REVISED line that is already here, whatever order they arrive in.
            else if (isRevised(arr[at.get(row.key)].invoice_no) && !row.revised) keptLocked++;
            // A re-import must not lower a line below what has already been paid against it.
            else if ((paidNow[arr[at.get(row.key)].id] || 0) > 0 && row.amount + 0.005 < paidNow[arr[at.get(row.key)].id]) keptLocked++;
            else { const i = at.get(row.key); arr[i] = { ...arr[i], ...row, updatedAt: now }; updated++; }
        }
        return arr;
    }, { strict: true });
    return { added, updated, kept_locked: keptLocked, dup_lines: dupLines };
}


// ── DERIVED PAYMENT FIGURES ───────────────────────────────────────────────
const MODES = ['Wire', 'Zelle', 'Cash', 'Cheque'];
const round2 = (n) => Math.round(n * 100) / 100;
const payments = () => { const r = loadJson(cfg.PARTY_INVOICE_PAYMENTS_FILE, []); return Array.isArray(r) ? r : []; };
function paidByRow(pays = payments(), { excluding = null } = {}) {
    const out = {};
    for (const p of pays) { if (excluding && p.id === excluding) continue; for (const a of p.allocations || []) out[a.row_id] = round2((out[a.row_id] || 0) + a.amount); }
    return out;
}
// ── ONE OVERALL LOCK (the owner, 2026-10-07) ─────────────────────────────────────────────
// First built per row; she corrected it: "No. Overall one lock. If unlocked, row-level copy and
// delete. Rows should be editable on unlocking the overall lock by default."
//
// So: ONE lock over the whole register and the Transport / Freight / Commission lists, LOCKED by
// default. Unlocking it makes EVERY line editable and gives each row Copy and Delete. It closes
// by itself LOCK_MS after the last change (every edit / copy / delete renews it), or at once on
// Lock — the stamp simply expires, so nothing has to remember to re-lock. Paying is not an edit
// to an invoice, so it works while locked.
//
// NOT the same as `locked` on a row, which predates this: that flag means "edited by hand — an
// import or sheet sync must not overwrite it". Untouched; shown as ✎, not a padlock.
//
// The helpers default to the OLD behaviour (no lock check) so existing callers — the importer, the
// supersede script, the suites — are unchanged; the HTTP routes pass { enforceLock: true }. A
// lock enforced only by the screen is not a lock.
const LOCK_MS = 30 * 60 * 1000;
function lockState(now = Date.now()) {
    const s = loadJson(cfg.PARTY_INVOICES_LOCK_FILE, {});
    const t = Date.parse((s && s.unlocked_at) || '');
    const on = Number.isFinite(t) && now - t >= 0 && now - t < LOCK_MS;
    return { unlocked: on, until: on ? new Date(t + LOCK_MS).toISOString() : null, lock_minutes: LOCK_MS / 60000 };
}
const isUnlocked = () => lockState().unlocked;
function assertUnlocked(what) { if (!isUnlocked()) throw new Error(`the register is locked — unlock it before you ${what}`); }
async function setLock(unlock, { actor = null } = {}) {
    await mutateJson(cfg.PARTY_INVOICES_LOCK_FILE, {}, () => ({ unlocked_at: unlock ? new Date().toISOString() : null, by: actor }), { strict: true });
    return lockState();
}
// A change made while unlocked keeps it open; a lock that expired mid-session is not revived.
async function touchLock() { if (isUnlocked()) await setLock(true); }

// ── A CREDIT NOTE CANCELS THE INVOICE(S) IT REVERSES ───────────────────────
// Eagle Trans cancels an invoice by issuing a credit note for the same booking: XSINV/171581 +2,180
// then XSCRN/015704 −2,180; and XSCRN/015595 −412.48 reversed two July add-ons (267.56 + 144.92).
// Left as two rows they look like duplicates AND the invoice still shows as owed — one click from
// being paid. A credit is matched to a single invoice of the same party + booking with exactly the
// opposite amount, or else to a small set of them (up to 3) that add up to it. Never matched to an
// invoice that has already been paid (that is a refund due, not a cancellation), and never guessed:
// no exact fit means no match, and both rows stay as they are.
function cancellations(rows, paid) {
    const byInvoice = new Map(), matchedCredits = new Map();
    const credits = rows.filter((r) => r.amount < 0 && r.booking_no);
    for (const c of credits) {
        const pool = rows.filter((r) => r.party === c.party && r.booking_no === c.booking_no && r.amount > 0 && !byInvoice.has(r.id) && !(paid[r.id] > 0));
        const want = round2(-c.amount);
        let hit = pool.filter((r) => Math.abs(r.amount - want) < 0.005).slice(0, 1);
        if (!hit.length) {
            outer: for (let a = 0; a < pool.length; a++) for (let b = a + 1; b < pool.length; b++) {
                if (Math.abs(pool[a].amount + pool[b].amount - want) < 0.005) { hit = [pool[a], pool[b]]; break outer; }
                for (let d = b + 1; d < pool.length; d++) if (Math.abs(pool[a].amount + pool[b].amount + pool[d].amount - want) < 0.005) { hit = [pool[a], pool[b], pool[d]]; break outer; }
            }
        }
        if (hit.length) { hit.forEach((r) => byInvoice.set(r.id, c.invoice_no)); matchedCredits.set(c.id, hit.map((r) => r.invoice_no)); }
    }
    return { byInvoice, matchedCredits };
}

function withPaid(rows = list(), pays = payments()) {
    const paid = paidByRow(pays);
    const canc = cancellations(rows, paid);
    return rows.map((r) => {
        if (canc.byInvoice.has(r.id)) return { ...r, paid: 0, balance: 0, pay_status: 'cancelled', cancelled_by: canc.byInvoice.get(r.id) };
        if (canc.matchedCredits.has(r.id)) return { ...r, paid: 0, balance: 0, pay_status: 'cancelled', cancels: canc.matchedCredits.get(r.id) };
        const p = paid[r.id] || 0, balance = round2(r.amount - p);
        return { ...r, paid: p, balance, pay_status: p <= 0 ? 'unpaid' : (balance > 0.005 ? 'part' : 'paid') };
    });
}

const EDITABLE = ['invoice_no', 'invoice_date', 'container_no', 'booking_no', 'hbl_no', 'amount', 'note'];
const UPPER = ['container_no', 'booking_no', 'hbl_no'];

// Edit one line. Marks it `locked` so a later import/sync never overwrites a hand edit, and keeps
// what it was before. The row's key never changes, so a re-import cannot re-add the original.
async function editRow(id, patch = {}, { actor = null, enforceLock = false } = {}) {
    if (enforceLock) assertUnlocked('edit a line');
    const clean = {};
    for (const k of EDITABLE) if (k in patch) {
        if (k === 'amount') {
            const n = num(patch.amount);
            const isCredit = (list().find((r) => r.id === id) || {}).kind === 'credit_note';   // a credit note stays negative
            if (n === null || (isCredit ? n >= 0 : n <= 0)) throw new Error(isCredit ? 'a credit note amount must be less than 0' : 'amount must be greater than 0');
            clean.amount = n;
        }
        else clean[k] = UPPER.includes(k) ? (up(patch[k]) || null) : (txt(patch[k]) || null);
    }
    if (!Object.keys(clean).length) throw new Error('nothing to change');
    let saved = null, problem = null;
    const paid = paidByRow();
    await mutateJson(cfg.PARTY_INVOICES_FILE, [], (cur) => {
        const arr = Array.isArray(cur) ? cur : [];
        const i = arr.findIndex((r) => r.id === id);
        if (i === -1) { problem = `no invoice line ${id}`; return arr; }
        if ('amount' in clean && (paid[id] || 0) > 0 && clean.amount + 0.005 < paid[id]) { problem = `${(paid[id] || 0).toFixed(2)} has already been paid against this line — the amount cannot go below that`; return arr; }
        const before = {}; for (const k of Object.keys(clean)) before[k] = arr[i][k] === undefined ? null : arr[i][k];
        arr[i] = { ...arr[i], ...clean, locked: true, updatedAt: new Date().toISOString(),
            edit_history: [...(arr[i].edit_history || []), { at: new Date().toISOString(), by: actor, before }] };
        saved = arr[i];
        return arr;
    }, { strict: true });
    if (problem) throw new Error(problem);
    if (enforceLock) await touchLock();
    return withPaid([saved])[0];
}


// Copy one line into a NEW line of its own (new id, new key, no payments carried over). It is marked
// edited so an import never touches it, and it remembers where it came from.
async function copyRow(id, { actor = null, enforceLock = false } = {}) {
    const src = list().find((r) => r.id === id);
    if (!src) throw new Error(`no invoice line ${id}`);
    if (enforceLock) assertUnlocked('copy a line');
    const now = new Date().toISOString();
    const copy = { ...src, id: `PI_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        key: `${src.key}#copy-${Date.now().toString(36)}`, source: 'copy', copied_from: src.id, locked: true,
        edit_history: [], createdAt: now, updatedAt: now, created_by: actor };
    await mutateJson(cfg.PARTY_INVOICES_FILE, [], (cur) => [...(Array.isArray(cur) ? cur : []), copy], { strict: true });
    if (enforceLock) await touchLock();
    return withPaid([copy])[0];
}

async function deleteRow(id, { enforceLock = false } = {}) {
    if (enforceLock) assertUnlocked('delete a line');
    if ((paidByRow()[id] || 0) > 0) throw new Error('money has been paid against this line — delete that payment first');
    let found = false;
    await mutateJson(cfg.PARTY_INVOICES_FILE, [], (cur) => { const arr = Array.isArray(cur) ? cur : []; const n = arr.filter((r) => r.id !== id); found = n.length !== arr.length; return n; }, { strict: true });
    if (!found) throw new Error(`no invoice line ${id}`);
    if (enforceLock) await touchLock();
    return { ok: true };
}

// ONE payment, MANY invoice lines (of one party). allocations: [{ row_id, amount }].
function validatePayment(input = {}) {
    const rows = new Map(list().map((r) => [r.id, r]));
    const amount = num(input.amount);
    if (amount === null || amount <= 0) throw new Error('payment amount must be greater than 0');
    const mode = MODES.find((m) => m.toLowerCase() === txt(input.mode).toLowerCase());
    if (!mode) throw new Error(`payment mode must be one of: ${MODES.join(', ')}`);
    const paidOn = txt(input.paid_on);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(paidOn) || Number.isNaN(Date.parse(paidOn))) throw new Error('paid_on must be a date, YYYY-MM-DD');
    const allocs = Array.isArray(input.allocations) ? input.allocations : [];
    if (!allocs.length) throw new Error('pick at least one invoice line to pay');
    const seen = new Set(), clean = [];
    const already = paidByRow();
    const canc = cancellations([...rows.values()], already);
    for (const a of allocs) {
        const row = rows.get(a && a.row_id);
        if (!row) throw new Error(`no invoice line ${a && a.row_id}`);
        if (seen.has(row.id)) throw new Error('the same invoice line is listed twice');
        seen.add(row.id);
        const amt = num(a.amount);
        if (amt === null || amt <= 0) throw new Error(`allocation for ${row.invoice_no || row.container_no || row.id} must be greater than 0`);
        if (canc.byInvoice.has(row.id)) throw new Error(`${row.invoice_no || row.id} was cancelled by credit note ${canc.byInvoice.get(row.id)} — nothing to pay`);
        const owed = round2(row.amount - (already[row.id] || 0));
        if (amt > owed + 0.005) throw new Error(`${row.invoice_no || row.container_no || row.id} owes only ${owed.toFixed(2)}, cannot allocate ${amt.toFixed(2)}`);
        clean.push({ row_id: row.id, amount: amt });
    }
    const parties = new Set(clean.map((a) => rows.get(a.row_id).party));
    if (parties.size > 1) throw new Error('one payment goes to one party — these lines belong to different parties');
    const sum = round2(clean.reduce((t, a) => t + a.amount, 0));
    if (Math.abs(sum - amount) > 0.005) throw new Error(`allocations come to ${sum.toFixed(2)} but the payment is ${amount.toFixed(2)}`);
    return { party: [...parties][0], amount, mode, paid_on: paidOn, ref: txt(input.ref) || null, note: txt(input.note) || null, allocations: clean };
}

async function addPayment(input = {}, { actor = null } = {}) {
    const rec = { id: `PIP_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`, ...validatePayment(input), created_by: actor, createdAt: new Date().toISOString() };
    await mutateJson(cfg.PARTY_INVOICE_PAYMENTS_FILE, [], (cur) => [...(Array.isArray(cur) ? cur : []), rec], { strict: true });
    return rec;
}
async function deletePayment(id) {
    let found = false;
    await mutateJson(cfg.PARTY_INVOICE_PAYMENTS_FILE, [], (cur) => { const arr = Array.isArray(cur) ? cur : []; const n = arr.filter((p) => p.id !== id); found = n.length !== arr.length; return n; }, { strict: true });
    if (!found) throw new Error(`no payment ${id}`);
    return { ok: true };
}


// ── REVISED INVOICES SUPERSEDE THEIR ORIGINAL ──────────────────────────────
// Report first. supersedePlan() is pure; supersedeApply() writes. It removes the ORIGINAL
// line only when a REVISED line for the same party + base invoice + container/booking/HBL
// exists, and it never removes one that has money paid against it or that she edited by
// hand — those are reported for her to decide. A line that is on the original but NOT on
// the revision is kept and flagged: the revision may have dropped it, or the read may have
// missed it, and only she knows which.
function supersedePlan(rows = list(), pays = payments()) {
    const paid = paidByRow(pays);
    const lineOf = (r) => r.container_no || r.booking_no || r.hbl_no || '';
    const groups = new Map();
    for (const r of rows) { const k = `${r.party}|${baseInvoice(r.invoice_no)}`; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(r); }
    const out = { remove: [], blocked: [], only_on_original: [], ambiguous: [], keep: [] };
    for (const g of groups.values()) {
        // Derived from the printed invoice number, NOT the stored `revised` flag: rows imported
        // before that flag existed have none, and those are exactly the duplicates to clean up.
        const rev = g.filter((r) => isRevised(r.invoice_no)), orig = g.filter((r) => !isRevised(r.invoice_no));
        if (!rev.length || !orig.length) continue;
        const revNos = [...new Set(rev.map((r) => r.invoice_no))];
        if (revNos.length > 1) { out.ambiguous.push({ base: baseInvoice(rev[0].invoice_no), revisions: revNos }); continue; }
        const revLines = new Set(rev.map(lineOf));
        for (const o of orig) {
            if (!revLines.has(lineOf(o))) { out.only_on_original.push(o); continue; }
            if ((paid[o.id] || 0) > 0) out.blocked.push({ row: o, why: `${paid[o.id]} already paid against the original` });
            else if (o.locked) out.blocked.push({ row: o, why: 'edited by hand' });
            else out.remove.push(o);
        }
        out.keep.push(...rev);
    }
    return out;
}

async function supersedeApply() {
    const plan = supersedePlan();
    const doomed = new Set(plan.remove.map((r) => r.id));
    if (doomed.size) {
        await mutateJson(cfg.PARTY_INVOICES_FILE, [], (cur) => {
            const arr = (Array.isArray(cur) ? cur : []).filter((r) => !doomed.has(r.id));
            // A revised line keeps one key (the base), so a later re-import of the original cannot re-add it.
            // The #dup=N suffix is CARRIED, not rebuilt. This is a second copy of the
            // key formula and it is deliberately not merged with normalize()'s — the two
            // differ for Eagle (normalize prefers booking_no, this prefers container_no)
            // and unifying them would re-key Eagle's revised lines, which nobody asked
            // for. Carrying the suffix is what keeps two commission lines on one
            // container from collapsing back into one the moment a revision lands.
            for (const r of arr) if (isRevised(r.invoice_no)) { r.revised = true; r.key = `${r.party}:${baseInvoice(r.invoice_no)}:${r.container_no || r.booking_no || r.hbl_no || '(none)'}${dupSuffixOf(r.key)}`; }
            return arr;
        }, { strict: true });
    }
    return { removed: doomed.size, plan };
}

function summary(rows = list()) {
    const out = {};
    for (const p of Object.keys(PARTIES)) {
        const r = rows.filter((x) => x.party === p);
        const paidMap = paidByRow();
        const canc = cancellations(rows, paidMap);   // a cancelled invoice and its credit note both count as nothing owed
        out[p] = { label: PARTIES[p], count: r.length, total: Math.round(r.reduce((a, x) => a + x.amount, 0) * 100) / 100,
            // Credit notes (negative) net against the invoices they cancel; a positive line is never below 0.
            outstanding: round2(r.reduce((a, x) => a + (canc.byInvoice.has(x.id) || canc.matchedCredits.has(x.id) ? 0 : (x.amount < 0 ? x.amount : Math.max(0, x.amount - (paidMap[x.id] || 0)))), 0)),
            not_on_sheet: r.filter((x) => x.check_status === 'not_in_sheet').length,
            verified: r.filter((x) => x.check_status === 'verified' || x.check_status === 'match').length };
    }
    return out;
}

module.exports = { PARTIES, COMMISSION_PARTIES, TRUCKING_CAP, MODES, normalize, amountOf, list, upsertMany, summary,
    payments, paidByRow, withPaid, cancellations, editRow, deleteRow, addPayment, deletePayment, validatePayment, EDITABLE,
    baseInvoice, isRevised, supersedePlan, supersedeApply, disambiguateDups, dupSuffixOf,
    LOCK_MS, lockState, isUnlocked, setLock, copyRow };
