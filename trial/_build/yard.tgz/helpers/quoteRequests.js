// ── helpers/quoteRequests.js — multi-trucker quote-request data + logic ─────
// Built 2026-08-05 per the owner: "get quote from LA to Richmond" should fan a
// quote ask out to one or more truckers — over whichever channel each one
// actually uses (WhatsApp group, WhatsApp DM, or email) — track each
// trucker's reply independently, and follow up on a fixed reminder schedule
// until a price comes back. This file holds the pure data/logic pieces
// (store, lane resolution, channel resolution, price detection, message
// building) — actually SENDING anything and scheduling reminder tasks is
// orchestration, deliberately kept in workflow/quoteRequests.js instead (same
// helpers/ vs workflow/ split as truckers.js/suppliers.js vs actions.js
// throughout this codebase).
//
// Storage: one row per quote request, each holding an array of per-trucker
// "legs" (one row per (request, trucker) pair — neither brain.json's
// pending_actions, which is one-slot-per-chat, nor tasks.json, which is
// fire-and-forget, models "N parallel outstanding asks belonging to one
// logical request", so this is its own flat-array store, same pattern as
// data/address_book.json).
//
// request shape:
//   { id, origin_query, destination_query, origin_entry_id, destination_entry_id,
//     created_at, asked_by_chat, status: 'active'|'closed',
//     legs: [ legShape, ... ] }
// leg shape:
//   { trucker_name, channel: 'whatsapp_group'|'whatsapp_individual'|'email',
//     target,                          // chatId or email address actually used
//     status: 'awaiting_reply'|'price_received'|'no_response_escalated',
//     sent_at, last_reply_at, last_reply_text,
//     reminders_sent: [ { stage, at } ],
//     price: { amount, raw_text, received_at } | null }

const crypto = require('crypto');
const cfg = require('../config');
const { loadJson, mutateJson } = require('./json');
const { resolveAddress, loadAddressBook } = require('./addressBook');

// ── Storage ─────────────────────────────────────────────────────────────────
const loadQuoteRequests = () => loadJson(cfg.QUOTE_REQUESTS_FILE, []);

// ── Lane resolution — "LA" / "Richmond" → an address-book entry ────────────
// A small, hand-picked set of common freight-lane shorthand → the fuller
// name that's actually likely to appear inside a saved address's raw text.
// Deliberately tiny and easy to extend — NOT a general geocoder. Mirrors
// dashboard/index.html's normalizePol() in spirit (known abbreviation →
// canonical form) but for a different purpose (search expansion here, not
// group-key merging there).
const LANE_ABBREVIATIONS = {
    la: 'los angeles',
    lb: 'long beach',
    nyc: 'new york',
    ny: 'new york',
    sf: 'san francisco',
    sa: 'san antonio',
};

function expandLaneQuery(query) {
    const q = String(query || '').trim().toLowerCase();
    return LANE_ABBREVIATIONS[q] || q;
}

// Resolves a free-text lane query ("LA", "Rad Metal", "Richmond") against
// the address book. Alias matching (resolveAddress's exact/partial/ambiguous
// tiers) is tried FIRST since a real saved name should always win over a
// coincidental text match; only when NO alias matches at all does this fall
// back to searching every entry's raw address text for the (possibly
// abbreviation-expanded) query — this is what lets "Richmond" find "DRM Iron
// & Metal LLC" (whose raw address contains "Long Beach, CA 90815"... no —
// contains "Richmond" itself, e.g. Mazariegos/Advanced Atlantic Corp) even
// though nobody saved an alias literally called "Richmond".
// Returns the SAME shape as resolveAddress(): { type: 'exact'|'partial'|'ambiguous', entry|matches } | null
function resolveLaneEntry(query) {
    const raw = String(query || '').trim();
    if (!raw) return null;

    const aliasMatch = resolveAddress(raw);
    if (aliasMatch) return aliasMatch;

    const expanded = expandLaneQuery(raw);
    const book = loadAddressBook();
    const textMatches = book.filter((e) => String(e.raw || '').toLowerCase().includes(expanded));
    if (textMatches.length === 1) return { type: 'partial', entry: textMatches[0] };
    if (textMatches.length > 1) return { type: 'ambiguous', matches: textMatches };
    return null;
}

// ── Trucker channel resolution ──────────────────────────────────────────────
// REAL BUG (found 2026-08-06, live — the owner: "fix supplier/trucker mode of
// communication is email"): `preferred_mode` is a real, first-class field —
// set per contact via the dashboard's "Preferred" dropdown (dashboard/
// index.html's ct_mode), saved to Supabase, shown right there in the
// contacts table — but this function never once looked at it. It always
// picked group_id, then whatsapp, then email, no matter what the contact's
// own saved preference said. A trucker explicitly marked "Preferred: Email"
// who also happens to have a WhatsApp number or group on file (common — a
// trucker can be in a WhatsApp group for booking updates but still want
// quote asks by email) was getting WhatsApp every time regardless.
// Fixed: preferred_mode === 'email' (with a real email on file) now wins
// outright. Anything else — 'whatsapp', unset, or email preferred but no
// email actually saved — keeps the original group_id → whatsapp → email
// fallback chain exactly as before, so this changes behavior ONLY for
// contacts that are both (a) explicitly set to email and (b) have an email
// address saved; every other contact resolves identically to before.
function resolveTruckerChannel(trucker) {
    if (!trucker) return null;
    if (trucker.preferred_mode === 'email' && trucker.email) return { channel: 'email', target: trucker.email };
    if (trucker.group_id) return { channel: 'whatsapp_group', target: trucker.group_id };
    if (trucker.whatsapp) {
        const digits = String(trucker.whatsapp).replace(/\D/g, '');
        if (digits) return { channel: 'whatsapp_individual', target: `${digits}@c.us` };
    }
    if (trucker.email) return { channel: 'email', target: trucker.email };
    return null;
}

// ── Price detection ──────────────────────────────────────────────────────────
// Freight quote replies are almost always just a dollar figure ("$450",
// "450", "500 flat", "1,200/load") — v1 is regex-only, no LLM call, since
// that covers the overwhelming majority of real replies at zero cost/latency
// and the owner can correct/extend this from real examples as they come in
// (same "ship the simple version, fix from real data" discipline used
// throughout this session — see mergeEntries', resolveAddress's own history).
// Returns { isPrice, amount, matchedText } — amount is a number when
// parseable, null if a price-like phrase matched but the number itself
// couldn't be cleanly parsed (still isPrice: true — better to flag it for a
// human glance than silently drop a real quote).
const PRICE_PATTERNS = [
    /\$\s?([\d,]+(?:\.\d{1,2})?)/,                              // "$450", "$1,200.50"
    // REAL BUG (found 2026-08-05, live): a real trucker (Jey) replied
    // "1250$" — dollar sign AFTER the number, a very common casual way to
    // text a price — and it went completely undetected, so the reminder
    // chain kept firing "any price yet?" at him twice after he'd already
    // answered. The pattern above only matches "$" BEFORE the digits; this
    // one covers "$" (or "usd"/"dollars") trailing the number instead.
    /([\d,]+(?:\.\d{1,2})?)\s?\$/,                                // "1250$", "1,250 $"
    /\b([\d,]{2,}(?:\.\d{1,2})?)\s*(?:dollars|usd|flat|per\s?load|each|\/load)\b/i, // "500 dollars", "1200 flat", "900/load"
];
function classifyQuoteReply(text) {
    const clean = String(text || '').trim();
    if (!clean) return { isPrice: false, amount: null, matchedText: null };

    for (const pattern of PRICE_PATTERNS) {
        const m = clean.match(pattern);
        if (m) {
            const amount = parseFloat(m[1].replace(/,/g, ''));
            return { isPrice: true, amount: Number.isFinite(amount) ? amount : null, matchedText: m[0] };
        }
    }
    // Bare-number reply — a terse trucker just typing "450" (or "450$") with
    // nothing else. Only treat the WHOLE message as a price this way (not a
    // number buried in a longer sentence — that's much more likely to be a
    // phone number, a booking number, or something else entirely). Allows an
    // optional "$" on EITHER side, same leading-or-trailing reasoning as above.
    const bareNumber = clean.match(/^\$?\s?([\d,]{2,}(?:\.\d{1,2})?)\s?\$?$/);
    if (bareNumber) {
        const amount = parseFloat(bareNumber[1].replace(/,/g, ''));
        return { isPrice: true, amount: Number.isFinite(amount) ? amount : null, matchedText: clean };
    }
    return { isPrice: false, amount: null, matchedText: null };
}

// ── Message building ─────────────────────────────────────────────────────────
// Mirrors the owner's own real WhatsApp pattern (short ask line + full pickup/
// delivery address blocks pasted separately) rather than inventing a new
// format. cargo_details (2026-08-06, per the owner: "I want jarvis to ask about
// cargo description, cargo value") is optional — omitted entirely when she
// skipped it, rather than printing an empty "Cargo:" line.
function buildQuoteMessage(request) {
    const lines = [`Hi — can you quote a haul from ${request.origin_query} to ${request.destination_query}?`];
    if (request.cargo_details) {
        lines.push('', `Cargo: ${request.cargo_details}`);
    }
    // origin_raw/destination_raw can be null now that an address-book
    // entry's address is optional (2026-08-17) — guarded so a name-only
    // contact never sends a trucker the literal word "null" as an address.
    lines.push('', 'Pickup:', request.origin_raw || '(no address on file — confirm with dispatcher)', '', 'Delivery:', request.destination_raw || '(no address on file — confirm with dispatcher)');
    return lines.join('\n');
}
function buildReminderMessage(request, stage) {
    const ordinal = { 1: 'Just following up', 2: 'Following up again', 3: 'One more follow-up' }[stage] || 'Following up';
    return `${ordinal} on the quote request for ${request.origin_query} → ${request.destination_query} — any price yet?`;
}

// ── Creating a request (data only — no sending, no scheduling) ─────────────
// Throws AmbiguousLaneError / AmbiguousLaneError-like plain errors with a
// `.matches`/`.query` payload so the caller (workflow/quoteRequests.js,
// eventually brain.js) can turn that into a disambiguation question instead
// of failing silently or guessing.
class LaneResolutionError extends Error {
    constructor(query, result) {
        super(result ? `"${query}" matches more than one saved address` : `"${query}" doesn't match anything in the address book`);
        this.query = query;
        this.matches = result && result.type === 'ambiguous' ? result.matches : [];
    }
}

function resolveOrThrow(query) {
    const result = resolveLaneEntry(query);
    if (!result) throw new LaneResolutionError(query, null);
    if (result.type === 'ambiguous') throw new LaneResolutionError(query, result);
    return result.entry;
}

// truckerLegs: [{ name, channel, target }] — already-resolved by the caller
// (workflow/quoteRequests.js resolves trucker names via workflow/truckers.js
// before calling this; keeping Supabase truckers lookups out of this
// helpers-layer file, consistent with truckers.js/suppliers.js owning that).
async function createQuoteRequest({ originQuery, destinationQuery, truckerLegs, askedByChat, cargoDetails }) {
    const originEntry = resolveOrThrow(originQuery);
    const destinationEntry = resolveOrThrow(destinationQuery);
    if (!Array.isArray(truckerLegs) || !truckerLegs.length) {
        throw new Error('at least one trucker with a resolvable contact channel is required');
    }

    const request = {
        id: crypto.randomUUID(),
        origin_query: String(originQuery).trim(),
        destination_query: String(destinationQuery).trim(),
        origin_entry_id: originEntry.id,
        destination_entry_id: destinationEntry.id,
        origin_raw: originEntry.raw,
        destination_raw: destinationEntry.raw,
        cargo_details: cargoDetails ? String(cargoDetails).trim() : null,
        created_at: new Date().toISOString(),
        asked_by_chat: askedByChat || null,
        status: 'active',
        legs: truckerLegs.map((t) => ({
            trucker_name: t.name,
            channel: t.channel,
            target: t.target,
            status: 'awaiting_reply',
            sent_at: null,
            last_reply_at: null,
            last_reply_text: null,
            reminders_sent: [],
            price: null,
        })),
    };
    await mutateJson(cfg.QUOTE_REQUESTS_FILE, [], (list) => { list.push(request); return list; });
    return request;
}

// ── Leg state updates ────────────────────────────────────────────────────────
// extra: optional fields merged onto the leg alongside sent_at — used for
// email legs to stash the Gmail threadId (returned by sendEmail) so
// pollEmailReplies can look up "did this specific thread get a reply" by id
// instead of re-searching the whole mailbox by name every poll.
async function markLegSent(requestId, truckerName, extra = {}) {
    let updated = null;
    await mutateJson(cfg.QUOTE_REQUESTS_FILE, [], (list) => {
        const request = list.find((r) => r.id === requestId);
        if (!request) return list;
        const leg = request.legs.find((l) => l.trucker_name === truckerName);
        if (!leg) return list;
        Object.assign(leg, extra, { sent_at: new Date().toISOString() });
        updated = leg;
        return list;
    });
    return updated;
}

async function recordReminderSent(requestId, truckerName, stage) {
    await mutateJson(cfg.QUOTE_REQUESTS_FILE, [], (list) => {
        const request = list.find((r) => r.id === requestId);
        if (!request) return list;
        const leg = request.legs.find((l) => l.trucker_name === truckerName);
        if (!leg) return list;
        leg.reminders_sent.push({ stage, at: new Date().toISOString() });
        return list;
    });
}

// REAL BUG (found 2026-08-06, live — the owner: "if request is rejected, it is
// still in queue. only successful request should be queued"): a leg is
// created with status 'awaiting_reply' at request-creation time (see
// createQuoteRequest above), BEFORE anything is actually sent. When the
// actual send then fails (dispatchLeg returns false — bad number, no
// WhatsApp/email channel, Gmail error, etc.), the caller only tracked that
// in a local `failed` array for the one-time confirmation message text —
// the LEG ITSELF was never updated, so it stayed 'awaiting_reply' forever.
// Knock-on effects, both matching what the owner actually saw: (1) the
// dashboard's active/awaiting-reply view keeps showing a request that never
// went anywhere, indistinguishable from one still genuinely waiting on a
// price: (2) scheduleFirstReminder is only ever called for legs that DID
// send successfully, so a stuck 'awaiting_reply' leg from a failed send has
// no reminder task behind it at all — it just sits there silently, which is
// almost certainly also what "reminder failed" on a previous request was
// really describing. Also means maybeCloseRequest could never close a
// request with a permanently-stuck failed leg, since its check is "every leg
// left awaiting_reply".
async function markLegFailed(requestId, truckerName, reason) {
    await mutateJson(cfg.QUOTE_REQUESTS_FILE, [], (list) => {
        const request = list.find((r) => r.id === requestId);
        if (!request) return list;
        const leg = request.legs.find((l) => l.trucker_name === truckerName);
        if (!leg) return list;
        leg.status = 'send_failed';
        leg.failed_reason = reason || null;
        leg.failed_at = new Date().toISOString();
        return list;
    });
}

async function markLegEscalated(requestId, truckerName) {
    await mutateJson(cfg.QUOTE_REQUESTS_FILE, [], (list) => {
        const request = list.find((r) => r.id === requestId);
        if (!request) return list;
        const leg = request.legs.find((l) => l.trucker_name === truckerName);
        if (!leg) return list;
        leg.status = 'no_response_escalated';
        return list;
    });
}

// Records an incoming reply on a leg. If it's a price, marks the leg
// resolved (price_received) so the reminder chain stops nagging that
// trucker; if not, just records it for visibility — the reminder schedule
// keeps running on its original fixed timing (the owner's spec is a fixed
// 30/60/90-minute schedule, not one that resets every time the trucker says
// something other than a number).
async function recordLegReply(requestId, truckerName, text) {
    const classification = classifyQuoteReply(text);
    let updatedLeg = null;
    await mutateJson(cfg.QUOTE_REQUESTS_FILE, [], (list) => {
        const request = list.find((r) => r.id === requestId);
        if (!request) return list;
        const leg = request.legs.find((l) => l.trucker_name === truckerName);
        if (!leg) return list;
        leg.last_reply_at = new Date().toISOString();
        leg.last_reply_text = text;
        if (classification.isPrice) {
            leg.status = 'price_received';
            leg.price = { amount: classification.amount, raw_text: classification.matchedText, received_at: leg.last_reply_at };
        }
        updatedLeg = leg;
        return list;
    });
    return { leg: updatedLeg, classification };
}

// Finds the request+leg an incoming message is a reply to — a chat is only
// ever "awaiting a price" for ONE active leg at a time in practice (a
// trucker doesn't usually have two live quote asks running simultaneously),
// so the first match wins; still returns ALL matches so the caller can warn
// instead of guessing if that assumption ever breaks.
function findActiveLegByTarget(target) {
    const requests = loadQuoteRequests();
    const matches = [];
    for (const request of requests) {
        if (request.status !== 'active') continue;
        for (const leg of request.legs) {
            if (leg.target === target && leg.status === 'awaiting_reply') matches.push({ request, leg });
        }
    }
    return matches;
}

// Every awaiting-reply email leg across every active request — what
// pollEmailReplies iterates each cron tick.
function findActiveEmailLegs() {
    const requests = loadQuoteRequests();
    const out = [];
    for (const request of requests) {
        if (request.status !== 'active') continue;
        for (const leg of request.legs) {
            if (leg.channel === 'email' && leg.status === 'awaiting_reply' && leg.email_thread_id) {
                out.push({ request, leg });
            }
        }
    }
    return out;
}

function getRequestById(requestId) {
    return loadQuoteRequests().find((r) => r.id === requestId) || null;
}

// Marks a request 'closed' once every leg has left 'awaiting_reply' (either
// got a price or was escalated as unresponsive) — purely a display/filter
// convenience for the dashboard comparison table (active requests surface
// first); doesn't affect reminder/escalation logic, which is entirely
// leg-status-driven already.
async function maybeCloseRequest(requestId) {
    let closed = false;
    await mutateJson(cfg.QUOTE_REQUESTS_FILE, [], (list) => {
        const request = list.find((r) => r.id === requestId);
        if (!request || request.status !== 'active') return list;
        if (request.legs.every((l) => l.status !== 'awaiting_reply')) {
            request.status = 'closed';
            closed = true;
        }
        return list;
    });
    return closed;
}

module.exports = {
    loadQuoteRequests,
    resolveLaneEntry, expandLaneQuery,
    resolveTruckerChannel,
    classifyQuoteReply,
    buildQuoteMessage, buildReminderMessage,
    LaneResolutionError,
    createQuoteRequest,
    markLegSent, recordReminderSent, markLegFailed, markLegEscalated, recordLegReply,
    findActiveLegByTarget, findActiveEmailLegs, getRequestById, maybeCloseRequest,
};
