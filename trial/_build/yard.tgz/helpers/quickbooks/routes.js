// ── helpers/quickbooks/routes.js — everything QuickBooks, on one page ──────
//
// the owner, 2026-09-24: "i want to have a separate page where i can view
// everything related to qb especially these Supplier specific things…If i
// keep on creating a separate page for each supplier,then it increases
// exponentially.so find a way to keep it beautiful,clean,compact yet
// knowledgeable."
//
// So: ONE page, one party at a time, picked from a list — never a page per
// supplier. This module is the data behind it and nothing else; it is mounted
// from api.js with a single line so the 235 routes there are untouched.
//
// What it will and will not do:
//   · reads are open to anyone who can open Jarvis
//   · anything that CHANGES something needs the padlock open AND an admin
//     session, because this page can reach her live books
//   · the chat answers and explains; it never writes (her choice, 2026-09-24)
const path = require('path');

const mapping = require('./mapping');
const books = require('./books');
const { normalizeName } = require('../nameMatch');
const journal = require('./journal');
const push = require('./push');
const pushInvoice = require('./pushInvoice');
const pushPayments = require('./pushPayments');
const sync = require('./sync');
const auth = require('./auth');

const r2 = (n) => Math.round(Number(n || 0) * 100) / 100;
const norm = (v) => String(v || '').trim().toUpperCase();
const KEY = (v) => norm(v).replace(/[^A-Z0-9]/g, '');

// QuickBooks is slow and this page is clicked a lot. Balances change by the
// hour, not the second; five minutes is fresh enough and keeps the page snappy.
const CACHE_MS = 5 * 60 * 1000;
let qbCache = { at: 0, data: null };

async function qbParties(env) {
    if (qbCache.data && Date.now() - qbCache.at < CACHE_MS) return qbCache.data;
    const client = require('./client');
    const pull = async (t) => {
        let all = [], s = 1;
        for (;;) {
            const q = `select Id, DisplayName, Active, Balance from ${t} where Active in (true, false) startposition ${s} maxresults 1000`;
            const r = (await client.query(q, { env }))[t] || [];
            all = all.concat(r); if (r.length < 1000) break; s += 1000;
        }
        return all;
    };
    const data = { vendor: await pull('Vendor'), customer: await pull('Customer') };
    qbCache = { at: Date.now(), data };
    return data;
}

// ── the party list ─────────────────────────────────────────────────────────
// Every name Jarvis's own ledgers use, with what it owes/is owed and what
// QuickBooks thinks, side by side. The disagreement is the point of the page.
function jarvisParties() {
    const bills = require('../bills');
    const sales = require('../sales');
    const billPayments = require('../billPayments');
    const out = {};
    const touch = (kind, name) => {
        if (!String(name || '').trim()) return null;
        const k = kind + '|' + KEY(name);
        return (out[k] = out[k] || { kind, name: String(name).trim(), bills: 0, billsValue: 0, invoices: 0, invoicesValue: 0,
            advances: 0, advancesValue: 0, lastActivity: null, linked: 0 });
    };
    const seen = (p, date) => { const d = push.isoDate(date); if (d && (!p.lastActivity || d > p.lastActivity)) p.lastActivity = d; };
    for (const b of bills.list()) {
        const p = touch('vendor', b.supplier); if (!p) continue;
        p.bills++; p.billsValue = r2(p.billsValue + (Number(bills.withTotals(b).amount) || 0)); seen(p, b.date);
    }
    for (const s of sales.list()) {
        const p = touch('customer', s.customer); if (!p) continue;
        p.invoices++; p.invoicesValue = r2(p.invoicesValue + (Number(sales.withTotals(s).receivable ?? sales.withTotals(s).amount) || 0)); seen(p, s.date);
    }
    for (const a of billPayments.list()) {
        if (a.kind !== 'advance') continue;
        const p = touch('vendor', a.supplier); if (!p) continue;
        p.advances++; p.advancesValue = r2(p.advancesValue + (Number(a.amount) || 0)); seen(p, a.date);
    }
    return Object.values(out);
}

// ── ONE READING OF A MAPPING, FOR THE WHOLE PAGE (2026-09-26) ──────────────
// the owner, 2026-09-26: "i have matched the supplier name just now ... yet it
// shows no match in qb." It was matched. The page could not read it.
//
// matchParty() answers with the QuickBooks record under `qb: { Id,
// DisplayName }`. Two places here read `m.qbId` and `m.qbName` instead, which
// are undefined on that object — so the party header said "no QuickBooks match
// yet" for EVERY party no matter what she confirmed, and the balance beside it
// (looked up by that undefined id) always read "—". The party list was right
// the whole time because it reads the stored map directly. One reader now, so
// the two halves of the screen cannot disagree again.
function readMapping(kind, name, qbList = []) {
    const hit = mapping.matchParty(name, qbList, kind);
    if (!hit) return { qbId: null, qbName: null, status: 'none' };
    if (hit.status === 'confirmed' || hit.status === 'exact') {
        return { qbId: hit.qb ? String(hit.qb.Id) : null, qbName: hit.qb ? hit.qb.DisplayName : null, status: hit.status };
    }
    // 'skip' = she said this is not a party in this role; 'new' = not in
    // QuickBooks at all. Both are answers, not gaps, and the page says so.
    return { qbId: hit.status === 'skip' ? 'SKIP' : null, qbName: null, status: hit.status, note: hit.note || null,
        candidates: hit.candidates || [] };
}

function mappedTo(kind, name, map) {
    const m = (map[kind] || {})[KEY(name).toLowerCase()] || null;
    if (m) return m;
    // mapping.js normalises its own way; ask it properly rather than guess
    const hit = readMapping(kind, name);
    return hit.qbId ? { qbId: hit.qbId, qbName: hit.qbName } : null;
}

async function partyRows({ env, withQb = true }) {
    const map = mapping.loadMap();
    const rows = jarvisParties();
    let qb = null;
    if (withQb) { try { qb = await qbParties(env); } catch { qb = null; } }
    const links = push.loadLinks();
    const linkedIds = new Set(Object.keys(links));
    for (const p of rows) {
        const m = mappedTo(p.kind, p.name, map);
        p.qbId = m ? m.qbId : null;
        p.qbName = m ? m.qbName : null;
        p.mapped = !!(m && m.qbId && m.qbId !== 'SKIP');
        p.skipped = !!(m && m.qbId === 'SKIP');
        if (qb) {
            const list = p.kind === 'vendor' ? qb.vendor : qb.customer;
            const found = p.qbId ? list.find((x) => String(x.Id) === String(p.qbId)) : null;
            p.qbBalance = found ? r2(found.Balance) : null;
            p.qbActive = found ? found.Active !== false : null;
        }
        p.inQuickBooks = [...linkedIds].filter((k) => k.includes(`|${p.kind === 'vendor' ? 'bill' : 'invoice'}|`)).length ? undefined : undefined;
    }
    return rows.sort((a, b) => (b.billsValue + b.invoicesValue) - (a.billsValue + a.invoicesValue));
}

// ── one party, everything about it ─────────────────────────────────────────
function partyDetail(kind, name, env) {
    const bills = require('../bills');
    const sales = require('../sales');
    const billPayments = require('../billPayments');
    const links = push.loadLinks();
    const linkOf = (k, id) => links[push.linkKey(env, k, id)] || null;
    const same = (a) => KEY(a) === KEY(name);

    const rows = { bills: [], invoices: [], advances: [], journal: [] };
    if (kind === 'vendor') {
        for (const b of bills.list().filter((x) => same(x.supplier))) {
            const t = bills.withTotals(b);
            const l = linkOf('bill', b.id);
            rows.bills.push({ id: b.id, date: push.isoDate(b.date) || b.date, container: b.container_no || '', no: b.invoice_no || '',
                amount: r2(t.amount), items: (b.items || []).length || 1, qbId: l ? l.qbId : null,
                note: b.note || '', blocked: !l && !(Number(t.amount) > 0) ? 'no supplier price yet' : null });
        }
        for (const a of billPayments.list().filter((x) => same(x.supplier))) {
            const l = linkOf(a.kind === 'advance' && !(a.allocations || []).some((x) => x.amount > 0) ? 'prepayment' : 'billpayment', a.id);
            rows.advances.push({ id: a.id, date: push.isoDate(a.date) || a.date, amount: r2(a.amount), mode: a.mode, bank: a.bank,
                kind: a.kind, applied: r2((a.allocations || []).reduce((s, x) => s + (Number(x.amount) || 0), 0)), qbId: l ? l.qbId : null });
        }
    } else {
        const byNo = {};
        for (const s of sales.list().filter((x) => same(x.customer))) {
            const no = push.docNumberFor(s) || `(no number) ${s.id}`;
            (byNo[no] = byNo[no] || []).push(s);
        }
        for (const [no, group] of Object.entries(byNo)) {
            const first = group[0];
            const l = linkOf('invoice', first.id) || group.map((g) => linkOf('invoice', g.id)).find(Boolean);
            const total = r2(group.reduce((s, g) => s + (Number(sales.withTotals(g).receivable ?? sales.withTotals(g).amount) || 0), 0));
            rows.invoices.push({ id: first.id, date: push.isoDate(first.date) || first.date, container: first.container_no || '',
                no: no.startsWith('(no number)') ? '' : no, amount: total, items: group.length, qbId: l ? l.qbId : null,
                blocked: no.startsWith('(no number)') ? 'no invoice number yet' : null });
        }
    }
    const ids = new Set([...rows.bills, ...rows.invoices, ...rows.advances].map((x) => x.id));
    rows.journal = journal.list({ env }).filter((e) => e.jarvis && (ids.has(e.jarvis.id)
        || KEY(e.jarvis.supplier || e.jarvis.customer || '') === KEY(name)))
        .slice(-60).reverse();
    const sum = (a, f) => r2(a.reduce((s, x) => s + (Number(x[f]) || 0), 0));
    const billTotal = sum(rows.bills, 'amount');
    const advanceTotal = sum(rows.advances.filter((a) => a.kind === 'advance'), 'amount');
    rows.totals = {
        bills: billTotal, invoices: sum(rows.invoices, 'amount'),
        advances: advanceTotal,
        advancesUnapplied: r2(rows.advances.filter((a) => a.kind === 'advance').reduce((s, a) => s + (a.amount - a.applied), 0)),
        // ── WHO IS AHEAD ─────────────────────────────────────────────────
        // Bills and advances read side by side invite the wrong answer: on
        // 2026-09-24 the chat told her she owed Hugo $144,792.91 while he was
        // holding $806,619.75 of her money. One number, with its sign.
        owedToSupplier: kind === 'vendor' ? r2(billTotal - advanceTotal) : null,
        // A bill with no amount is a container whose price is not agreed yet.
        // It is NOT zero cost, and a total that silently includes it as zero
        // is a lie of omission — so it is counted separately and said aloud.
        unpricedBills: rows.bills.filter((b) => !(Number(b.amount) > 0)).length,
        inQuickBooks: [...rows.bills, ...rows.invoices, ...rows.advances].filter((x) => x.qbId).length,
        notInQuickBooks: [...rows.bills, ...rows.invoices, ...rows.advances].filter((x) => !x.qbId).length,
    };
    return rows;
}


// ── WHAT IS STILL WAITING ON HER ───────────────────────────────────────────
// the owner, 2026-09-26: "i basically want my website to handle whatever we can
// do from qb from here." The first thing the terminal was still needed for is
// simply KNOWING what is outstanding — a blocked row sat blocked until
// somebody ran a script and read a list.
//
// The last word wins: a bill blocked on Monday and entered on Tuesday is not
// a question any more, and a row whose link exists is in the books whatever
// the journal said on the way there.
function openQuestions(env) {
    const links = push.loadLinks();
    const latest = new Map();
    for (const e of journal.list({ env })) {
        const id = (e.jarvis && e.jarvis.id) || e.linkKey || '';
        if (!id) continue;
        latest.set(`${e.kind}|${id}`, e);
    }
    const out = [];
    for (const e of latest.values()) {
        if (e.action !== 'blocked' && e.action !== 'asked') continue;
        if (e.linkKey && links[e.linkKey]) continue;
        out.push({ id: e.id, kind: e.kind, action: e.action, when: e.at,
            who: (e.jarvis && (e.jarvis.supplier || e.jarvis.customer)) || '',
            what: (e.jarvis && (e.jarvis.container || e.jarvis.id)) || '',
            jarvisId: (e.jarvis && e.jarvis.id) || null,
            why: e.reason || '' });
    }
    return out.sort((a, b) => String(b.when).localeCompare(String(a.when)));
}

// ── the routes ─────────────────────────────────────────────────────────────
// Mounted from api.js with one line. Reads are open; every mutation needs the
// padlock open (`unlock: true`) AND an admin session — two deliberate acts,
// because a mis-click here lands in her live books.
function mount(app, cfg) {
    const envOf = () => auth.qbEnv();
    const who = (req) => (req.isSuper ? 'super admin' : (req.role || 'admin'));
    const locked = (req, res) => {
        if (req.role !== 'admin') { res.status(403).json({ error: 'changing QuickBooks needs an admin session' }); return true; }
        if (!(req.body && req.body.unlock === true)) { res.status(400).json({ error: 'the page is locked — open the padlock first' }); return true; }
        return false;
    };

    app.get('/quickbooks', (req, res) => res.sendFile(path.join(cfg.ROOT, 'dashboard', 'quickbooks.html')));

    app.get('/api/qb/status', async (req, res) => {
        const env = envOf();
        const map = mapping.loadMap();
        // Same misreading as the party header had: these chips said "unmapped"
        // for accounts that were mapped, because matchParty answers under
        // `qb`, not `qbId`.
        const roles = Object.keys(mapping.ACCOUNT_ROLES).map((role) => {
            const m = readMapping('account', role);
            return { role, qbId: m.qbId, qbName: m.qbName, why: mapping.ACCOUNT_ROLES[role] };
        });
        const j = journal.list({ env });
        res.json({
            env,
            writes: String(process.env.QB_PROD_WRITES || 'off').toLowerCase() === 'on',
            autoSync: String(process.env.QB_SYNC || 'off').toLowerCase() === 'on',
            cutover: { bills: push.cutoverFor('bill', env), invoices: push.cutoverFor('invoice', env),
                billsFrom: push.cutoverSource('bill'), invoicesFrom: push.cutoverSource('invoice'),
                billsRolling: push.cutoverIsRolling('bill'), invoicesRolling: push.cutoverIsRolling('invoice'),
                today: push.todayISO(),
                history: (push.cutoverStore().history || []).slice(0, 5) },
            nightly: { at: '00:00 Los Angeles', writes: require('../quickbooksNightly').enabled() },
            connected: auth.status(env).connected,
            roles,
            counts: { mapped: Object.keys(map.vendor || {}).length + Object.keys(map.customer || {}).length,
                items: Object.keys(map.item || {}).length, journal: j.length, standing: journal.active(env).length },
            lastWrites: j.filter((e) => e.action === 'created').slice(-8).reverse()
                .map((e) => ({ at: e.at, kind: e.kind, qbId: e.qb && e.qb.id, total: e.qb && e.qb.total,
                    who: (e.jarvis && (e.jarvis.supplier || e.jarvis.customer)) || '', container: e.jarvis && e.jarvis.container })),
        });
    });

    app.get('/api/qb/parties', async (req, res) => {
        try {
            const rows = await partyRows({ env: envOf(), withQb: String(req.query.qb || '1') !== '0' });
            const q = KEY(req.query.q || '');
            res.json({ parties: q ? rows.filter((p) => KEY(p.name).includes(q) || KEY(p.qbName || '').includes(q)) : rows });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.get('/api/qb/party', async (req, res) => {
        const kind = req.query.kind === 'customer' ? 'customer' : 'vendor';
        const name = String(req.query.name || '').trim();
        if (!name) return res.status(400).json({ error: 'which party?' });
        try {
            const env = envOf();
            const detail = partyDetail(kind, name, env);
            let qbBalance = null, list = [];
            try {
                const qb = await qbParties(env);
                list = (kind === 'vendor' ? qb.vendor : qb.customer) || [];
            } catch { /* QuickBooks unreachable — the Jarvis side still shows */ }
            // The live list goes in, so a vendor she renamed in QuickBooks to
            // match Jarvis's spelling reads as matched here too, not just at
            // push time.
            const m = readMapping(kind, name, list);
            if (m.qbId && m.qbId !== 'SKIP') {
                const found = list.find((x) => String(x.Id) === String(m.qbId));
                qbBalance = found ? r2(found.Balance) : null;
            }
            res.json({ kind, name, mapping: { qbId: m.qbId || null, qbName: m.qbName || null, status: m.status, note: m.note || null }, qbBalance, ...detail });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // unmapped names, so she can answer them from here instead of the terminal
    app.get('/api/qb/candidates', async (req, res) => {
        const kind = req.query.kind === 'customer' ? 'customer' : 'vendor';
        try {
            const client = require('./client');
            const all = await mapping.fetchParties(kind, client, { env: envOf() });
            const m = mapping.matchParty(String(req.query.name || ''), all, kind);
            // An EXACT hit comes back under `qb` with candidates empty — so
            // the easiest case of all showed "(no near matches)" in the match
            // dialog (2026-09-25, FMC METALS, which exists verbatim as #561).
            // Put it at the head of the list, marked, so one keystroke does it.
            const exact = m.qb ? [{ Id: m.qb.Id || m.qb.qbId, DisplayName: m.qb.DisplayName || m.qb.name || m.qb.qbName, exact: true }] : [];
            const rest = (m.candidates || []).filter((c) => !exact.length || String(c.Id) !== String(exact[0].Id));
            res.json({ status: m.status, candidates: exact.concat(rest.slice(0, 8)),
                all: all.map((x) => ({ Id: x.Id, name: x.DisplayName })).slice(0, 2000) });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    app.post('/api/qb/map', async (req, res) => {
        if (locked(req, res)) return;
        const { kind, jarvisName, qbId, qbName, reason } = req.body || {};
        if (!['vendor', 'customer', 'item', 'bank', 'account'].includes(kind)) return res.status(400).json({ error: 'kind?' });
        if (!jarvisName) return res.status(400).json({ error: 'which Jarvis name?' });
        try {
            const saved = mapping.confirm(kind, jarvisName, qbId === 'SKIP' ? 'SKIP' : (qbId || null), qbName || null, 'owner', reason || 'set from the QuickBooks page');
            qbCache = { at: 0, data: null };
            res.json({ ok: true, saved, note: 'saved in qb-settings — commit it so the other machine has it too' });
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // push ONE record. Same checks as every other write: mapping, duplicate
    // search, same-money, journal. Never a bulk button — that is what the
    // sweep is for, from a terminal, with a dry run first.
    app.post('/api/qb/push', async (req, res) => {
        if (locked(req, res)) return;
        const { kind, id, dryRun } = req.body || {};
        if (!['bill', 'invoice', 'advance'].includes(kind)) return res.status(400).json({ error: 'kind must be bill, invoice or advance' });
        if (!id) return res.status(400).json({ error: 'which record?' });
        const env = envOf();
        try {
            if (dryRun) {
                const snaps = await sync.snapshots(env);
                if (kind === 'bill') {
                    const bills = require('../bills'); const b = bills.list().find((x) => x.id === id);
                    if (!b) return res.status(404).json({ error: 'no such bill' });
                    return res.json(await push.pushBill(bills.withTotals(b), snaps, { env, dryRun: true }));
                }
                if (kind === 'invoice') {
                    const sales = require('../sales'); const s = sales.getSale(id);
                    if (!s) return res.status(404).json({ error: 'no such sale' });
                    const no = push.docNumberFor(s);
                    const group = sales.list().filter((x) => push.docNumberFor(x) === no).map((x) => sales.withTotals(x));
                    return res.json(await pushInvoice.pushInvoice(group, snaps, { env, dryRun: true }));
                }
                const p = require('../billPayments').list().find((x) => x.id === id);
                if (!p) return res.status(404).json({ error: 'no such payment' });
                return res.json(await pushPayments.pushBillPayment(p, snaps, { env, dryRun: true }));
            }
            const out = kind === 'bill' ? await sync.syncBill(id, env)
                : kind === 'invoice' ? await sync.syncSale(id, env)
                : await sync.syncBillPayment(id, env);
            res.json(out);
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // ── the cutover ────────────────────────────────────────────────────────
    // the owner, 2026-09-26: "I want nightly report to run everyday to upload all
    // the bills and invoices." This is now a PERIOD LOCK, not a date rule: it
    // is normally unset, and unset means 2026 is open. It takes a date, the
    // word "today" (which then moves every day — and so blocks everything
    // back-dated, which the page says out loud), or "none" to unlock.
    app.post('/api/qb/cutover', async (req, res) => {
        if (locked(req, res)) return;
        const { bills, invoices } = req.body || {};
        if (!bills && !invoices) return res.status(400).json({ error: 'give a bills date, an invoices date, or both — or "none" to unlock' });
        try {
            const { changed } = push.saveCutover({ bills, invoices }, who(req));
            const env = envOf();
            const pinned = ['bill', 'invoice'].filter((k) => push.cutoverSource(k) === 'env');
            res.json({ ok: true, changed,
                cutover: { bills: push.cutoverFor('bill', env), invoices: push.cutoverFor('invoice', env),
                    billsFrom: push.cutoverSource('bill'), invoicesFrom: push.cutoverSource('invoice'),
                    billsRolling: push.cutoverIsRolling('bill'), invoicesRolling: push.cutoverIsRolling('invoice'),
                    today: push.todayISO() },
                note: pinned.length
                    ? `saved, but ${pinned.map((k) => k === 'bill' ? 'QB_CUTOVER_BILLS' : 'QB_CUTOVER_INVOICES').join(' and ')} in .env still wins — remove that line and restart for this to take effect`
                    : 'saved — the next run uses it, no restart needed' });
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // The nightly run, on demand. Same sweep, same checks, same journal — the
    // only difference is who started it. Dry run by default: nothing reaches
    // her books unless the body says dryRun: false.
    app.post('/api/qb/run', async (req, res) => {
        if (locked(req, res)) return;
        const job = require('../quickbooksNightly');
        const dryRun = (req.body || {}).dryRun !== false || !job.enabled();
        try {
            const out = await job.run({ dryRun });
            // ── report IS AN EMAIL BODY; THE PAGE NEEDS THE PIECES ────────
            // the owner, 2026-10-02, with a screenshot of the run result: "on
            // clicking run now in qb,its coming like this ugly".
            //
            // She was right, and it was not her browser. `report` is built by
            // reportText() for the NIGHTLY EMAIL — plain text, newline
            // separated — and the page was dropping it into a 132px box with
            // textContent and no white-space rule, so every newline collapsed
            // and forty stuck containers arrived as one grey paragraph.
            //
            // reportText is deliberately NOT changed: the nightly email is
            // the right shape already and scheduler.js prints it too. The
            // page gets the same facts as DATA and draws them itself, in the
            // table idiom the "what needs you" panel already uses — which is
            // the panel she has never complained about.
            //
            // Additive. `report` still goes out exactly as before, so a
            // caller reading only that is untouched.
            res.json({ ok: out.ok, dryRun: out.dryRun, error: out.error, env: out.env,
                summary: job.summarise(out.result || {}), report: job.reportText(out),
                kinds: out.result || {},
                // NOTE: run() only reads the journal for these when the run
                // was live — a dry run genuinely has no per-row reasons, and
                // the page says so rather than drawing an empty table.
                blocked: out.blocked || [], asked: out.asked || [],
                leftAlone: (out.result || {}).leftAlone || null });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // ── everything waiting on her, in one answer ───────────────────────────
    // Unmatched names first and by value, because "which of these 60 names
    // matters" is the question the terminal never answered.
    app.get('/api/qb/todo', async (req, res) => {
        const env = envOf();
        try {
            // withQb false: this is the page's first paint and must not wait
            // on QuickBooks. Balances come with the party she opens.
            const rows = await partyRows({ env, withQb: false });
            const unmatched = rows.filter((p) => !p.mapped && !p.skipped)
                .map((p) => ({ kind: p.kind, name: p.name, bills: p.bills, invoices: p.invoices,
                    value: r2(p.billsValue + p.invoicesValue), lastActivity: p.lastActivity }))
                .sort((a, b) => b.value - a.value);
            const roles = Object.keys(mapping.ACCOUNT_ROLES)
                .map((role) => ({ role, why: mapping.ACCOUNT_ROLES[role], ...readMapping('account', role) }))
                .filter((r) => !r.qbId);
            const q = openQuestions(env);
            // ── WHERE EACH STUCK ROW IS FIXED ────────────────────────────
            // Computed on the SERVER so the page and the nightly mail cannot
            // disagree about the same row. The page used to send every stuck
            // row to openParty() — the supplier's QuickBooks name mapping —
            // when 21 of the 24 on 4 October were a price missing on a bill,
            // where the mapping is correct and irrelevant.
            const { stuckFix } = require('./stuckFix');
            const withFix = (rows) => rows.map((x) => ({ ...x, fix: stuckFix(x) }));
            res.json({ unmatched, roles,
                stuck: withFix(q.filter((x) => x.action === 'blocked')),
                asked: withFix(q.filter((x) => x.action === 'asked')),
                counts: { unmatched: unmatched.length, roles: roles.length,
                    stuck: q.filter((x) => x.action === 'blocked').length,
                    asked: q.filter((x) => x.action === 'asked').length } });
        } catch (e) { res.status(500).json({ error: e.message }); }
    });

    // Her chart of accounts, for the role picker.
    app.get('/api/qb/accounts', async (req, res) => {
        try {
            const all = await mapping.fetchParties('account', require('./client'), { env: envOf() });
            const like = KEY(req.query.like || '');
            const rows = (like ? all.filter((a) => KEY(a.DisplayName).includes(like)) : all)
                .filter((a) => a.Active !== false)
                .map((a) => ({ id: String(a.Id), name: a.DisplayName, type: a.AccountType, sub: a.AccountSubType, balance: a.Balance }));
            res.json({ accounts: rows.slice(0, 300), total: rows.length, roles: mapping.ACCOUNT_ROLES });
        } catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    // Which account answers a role. Was scripts/qb-accounts.js role.
    app.post('/api/qb/role', async (req, res) => {
        if (locked(req, res)) return;
        const { role, qbId, qbName } = req.body || {};
        if (!mapping.ACCOUNT_ROLES[role]) return res.status(400).json({ error: `role must be one of: ${Object.keys(mapping.ACCOUNT_ROLES).join(', ')}` });
        if (!qbId) return res.status(400).json({ error: 'which account?' });
        try {
            const saved = mapping.confirm('account', role, String(qbId), qbName || null, who(req),
                `role "${role}" — ${mapping.ACCOUNT_ROLES[role]}`);
            res.json({ ok: true, role, saved, note: 'saved — the next write uses it' });
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── a name that is not in QuickBooks at all ────────────────────────────
    // Jarvis never invents a party on its own (mapping.js: a new name is a
    // question for her). This is her answering it without the terminal. It
    // refuses to make a twin: a second "Mazariegos Recycling" splits one
    // supplier's balance across two records and nothing tells you it happened.
    app.post('/api/qb/create-party', async (req, res) => {
        if (locked(req, res)) return;
        const { kind, name, jarvisName, contact, company } = req.body || {};
        if (!['vendor', 'customer'].includes(kind)) return res.status(400).json({ error: 'kind must be vendor or customer' });
        const wanted = String(name || '').trim();
        if (!wanted) return res.status(400).json({ error: 'what should it be called in QuickBooks?' });
        const jName = String(jarvisName || wanted).trim();
        const env = envOf();
        const client = require('./client');
        try {
            // ── ONE NAME LIST FOR EVERYBODY (2026-09-26) ───────────────────
            // the owner hit: "Duplicate Name Exists Error … Id=505" creating a
            // supplier. #505 was a CUSTOMER, "nur metals". QuickBooks keeps
            // ONE display-name list across customers, vendors and employees,
            // so a company she both buys from and sells to cannot carry the
            // same name twice. Checking only the same kind found nothing and
            // walked into Intuit's refusal — so both lists are checked, and
            // the answer explains it instead of repeating a 400.
            const other = kind === 'vendor' ? 'customer' : 'vendor';
            const [all, others] = await Promise.all([
                mapping.fetchParties(kind, client, { env }),
                mapping.fetchParties(other, client, { env }).catch(() => []),
            ]);
            const twin = all.filter((x) => normalizeName(x.DisplayName) === normalizeName(wanted));
            if (twin.length) {
                mapping.confirm(kind, jName, twin[0].Id, twin[0].DisplayName, who(req), 'already in QuickBooks — linked, not created');
                return res.json({ status: 'already-there', qbId: String(twin[0].Id), qbName: twin[0].DisplayName,
                    note: `"${twin[0].DisplayName}" (#${twin[0].Id}) is already there — linked to it instead of making a second one.` });
            }
            const clash = others.find((x) => normalizeName(x.DisplayName) === normalizeName(wanted));
            if (clash) {
                const suggestion = `${wanted} (${kind === 'vendor' ? 'supplier' : 'customer'})`;
                return res.status(409).json({ status: 'name-taken', takenBy: other, qbId: String(clash.Id), qbName: clash.DisplayName,
                    suggestion,
                    note: `QuickBooks keeps one name list for customers, vendors and employees, and "${clash.DisplayName}" is already a ${other} (#${clash.Id}). A company you both buy from and sell to needs two records with different names — try "${suggestion}".` });
            }
            const table = kind === 'vendor' ? 'Vendor' : 'Customer';
            const body = { DisplayName: wanted };
            if (company) body.CompanyName = String(company).trim();
            if (contact) {
                const parts = String(contact).trim().split(/\s+/);
                body.GivenName = parts[0];
                if (parts.length > 1) body.FamilyName = parts.slice(1).join(' ');
            }
            const made = (await client.request('POST', '/' + table.toLowerCase(), body, { env }))[table];
            mapping.confirm(kind, jName, made.Id, made.DisplayName, who(req), 'created from the QuickBooks page');
            if (jName !== wanted) mapping.confirm(kind, wanted, made.Id, made.DisplayName, who(req), 'same party under the name QuickBooks uses');
            res.json({ status: 'created', qbId: String(made.Id), qbName: made.DisplayName,
                note: `Created ${kind} #${made.Id} "${made.DisplayName}" and matched "${jName}" to it.` });
        } catch (e) {
            // Intuit's own duplicate refusal, in case the name belongs to an
            // employee or something else the two lists above do not cover.
            const m = /Duplicate Name Exists.*?Id=(\d+)/is.exec(e.message || '');
            if (m) {
                return res.status(409).json({ status: 'name-taken', qbId: m[1],
                    suggestion: `${wanted} (${kind === 'vendor' ? 'supplier' : 'customer'})`,
                    note: `QuickBooks already has record #${m[1]} under that name — it keeps one name list for customers, vendors and employees. Give this one a different display name, for example "${wanted} (${kind === 'vendor' ? 'supplier' : 'customer'})".` });
            }
            res.status(400).json({ error: e.message });
        }
    });

    // ── HER BOOKS, WITHOUT OPENING QUICKBOOKS (2026-09-26) ─────────────────
    // the owner: "user should able to feel content with jarvis quickbook without
    // needing to open qb … jarvis should be supreme of qb." Until now the page
    // showed the Jarvis side and one balance per party; everything else meant
    // going to QuickBooks. These three are that side, read live and read-only.
    app.get('/api/qb/books', async (req, res) => {
        try {
            const year = /^\d{4}$/.test(String(req.query.year || '')) ? Number(req.query.year) : undefined;
            const out = await books.overview(envOf(), { year });
            // Partial books are worth showing; books that are partly missing
            // must SAY so, or a zero reads as a fact.
            const why = out.error || (out.pl && out.pl.error) || null;
            res.json({ ...out, unreadable: why ? `QuickBooks: ${why}` : null });
        } catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    // Every document QuickBooks holds for one party — the tab that means she
    // does not have to go and look.
    app.get('/api/qb/party-docs', async (req, res) => {
        const kind = req.query.kind === 'customer' ? 'customer' : 'vendor';
        const name = String(req.query.name || '').trim();
        if (!name) return res.status(400).json({ error: 'which party?' });
        const m = readMapping(kind, name);
        if (!m.qbId || m.qbId === 'SKIP') return res.json({ mapped: false, mapping: m, docs: [], totals: null,
            note: 'no QuickBooks match yet — match it and this fills in' });
        try {
            const out = await books.partyDocs(kind, m.qbId, envOf());
            res.json({ mapped: true, qbId: m.qbId, qbName: m.qbName, ...out });
        } catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    // A ticket number, an invoice number, a container or an amount — whatever
    // she has in her hand when the question comes up.
    app.get('/api/qb/find', async (req, res) => {
        const q = String(req.query.q || '').trim();
        if (!q) return res.status(400).json({ error: 'search for what?' });
        try { res.json(await books.find(q, envOf())); }
        catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    // ── her live sheet against her live books ──────────────────────────────
    // scripts/qb-vs-sheet.js, on the page. Read-only: it says what is missing
    // and never enters it, because most of what is missing sits before the
    // cutover in the period her accountant owns.
    let missingCache = { at: 0, key: '', data: null };
    app.get('/api/qb/missing', async (req, res) => {
        const since = /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.since || '')) ? req.query.since : '2026-01-01';
        const env = envOf();
        const key = `${env}|${since}`;
        // Both sides of this are slow (the whole workbook, then the year's
        // documents), and it is the kind of screen she reopens.
        if (missingCache.data && missingCache.key === key && Date.now() - missingCache.at < 10 * 60 * 1000) {
            return res.json({ ...missingCache.data, cached: true });
        }
        try {
            const data = await require('./vsSheet').compare({ since, env });
            missingCache = { at: Date.now(), key, data };
            res.json(data);
        } catch (e) { res.status(502).json({ error: e.message }); }
    });

    // ── connecting QuickBooks ──────────────────────────────────────────────
    // Was scripts/qb-connect.js on the laptop. The consent screen has to
    // happen in a browser, so the page does what the script did: hand her the
    // link, take back the address the browser landed on. Nothing is stored
    // until Intuit has answered.
    app.post('/api/qb/connect-url', async (req, res) => {
        if (locked(req, res)) return;
        try {
            const env = envOf();
            res.json({ env, url: auth.buildAuthUrl(env), status: auth.status(env),
                note: env === 'production'
                    ? 'This connects your LIVE books. Sign in, pick Sample Yard Co Metals, then paste the whole address the browser lands on — it may say "can\'t connect", which is fine.'
                    : 'Sandbox. Sign in, then paste the whole address the browser lands on.' });
        } catch (e) { res.status(400).json({ error: e.message }); }
    });
    app.post('/api/qb/connect', async (req, res) => {
        if (locked(req, res)) return;
        const url = String((req.body || {}).redirectedUrl || '').trim();
        if (!/^https?:\/\//.test(url) || !/code=/.test(url)) {
            return res.status(400).json({ error: 'paste the WHOLE address the browser landed on — it carries the code' });
        }
        const env = envOf();
        try {
            const t = await auth.exchangeRedirect(url, { env });
            const ci = await require('./client').companyInfo({ env }).catch(() => ({}));
            books.forget();
            res.json({ ok: true, env, realmId: t.realmId, company: ci.CompanyName || null, status: auth.status(env) });
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── a reviewed list of older rows ──────────────────────────────────────
    // The one place the cutover steps aside, for the rows she has just looked
    // at and nothing else. Dry run unless she says otherwise IN WORDS, and a
    // reason is required — it goes in the journal beside every row.
    app.post('/api/qb/push-list', async (req, res) => {
        if (locked(req, res)) return;
        const b = req.body || {};
        const really = b.really === true;
        if (really && String(b.confirm || '').trim().toUpperCase() !== 'ENTER') {
            return res.status(400).json({ error: 'to enter these for real, type ENTER — this is the one path that goes behind the cutover' });
        }
        try {
            const out = await require('./pushList').run({
                kind: String(b.kind || 'invoice').toLowerCase(),
                since: String(b.since || '2026-01-01'), until: String(b.until || '2026-12-31'),
                party: b.party ? String(b.party) : null,
                reason: b.reason, really, env: envOf(),
            });
            if (really) books.forget();
            res.json(out);
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── VOID, DELETE, MERGE (2026-09-26) ───────────────────────────────────
    // the owner: "Merging two parties, voiding or deleting anything should be
    // there on qb. Ensure the impact before changing any section."
    //
    // The impact comes first and is not optional: every change carries the
    // stamp of the version she was shown, and is refused if the document
    // moved in the meantime. None of this can be taken back, so the reason
    // and the impact both go in the journal.
    app.get('/api/qb/impact', async (req, res) => {
        try { res.json(await require('./riskyOps').impact(req.query.type, req.query.id, { env: envOf() })); }
        catch (e) { res.status(400).json({ error: e.message }); }
    });

    app.post('/api/qb/void', async (req, res) => {
        if (locked(req, res)) return;
        const b = req.body || {};
        const op = b.op === 'delete' ? 'delete' : 'void';
        // The typed word is the document's own number — she cannot confirm
        // this one by reflex, and she cannot confirm the wrong document.
        const risky = require('./riskyOps');
        try {
            const now = await risky.impact(b.type, b.id, { env: envOf() });
            const expect = now.doc.doc || `#${now.id}`;
            if (String(b.confirm || '').trim() !== expect) {
                return res.status(400).json({ error: `to ${op} this, type its number exactly: ${expect}`, impact: now });
            }
            res.json(await risky.apply({ type: b.type, id: b.id, op, reason: b.reason, stamp: b.stamp, by: who(req), env: envOf() }));
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    app.get('/api/qb/merge-impact', async (req, res) => {
        try { res.json(await require('./riskyOps').mergeImpact(req.query.kind, req.query.loser, req.query.winner, { env: envOf() })); }
        catch (e) { res.status(400).json({ error: e.message }); }
    });

    // "I merged them in QuickBooks" — Jarvis proves the old record is gone,
    // then re-points every name that was aimed at it.
    app.post('/api/qb/merged', async (req, res) => {
        if (locked(req, res)) return;
        const b = req.body || {};
        if (!b.deadId || !b.survivorId) return res.status(400).json({ error: 'which two? give the old id and the surviving id' });
        try {
            res.json(await require('./riskyOps').adoptMerge(b.kind, b.deadId, b.survivorId,
                { env: envOf(), by: who(req), reason: b.reason || '' }));
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── the same money, twice ──────────────────────────────────────────────
    // "check qb for any duplicate record/amount entry per customer and
    // supplier." Read-only; it names them, it never deletes one — that is the
    // void button, one document at a time, with its impact shown.
    app.get('/api/qb/duplicates', async (req, res) => {
        const year = /^\d{4}$/.test(String(req.query.year || '')) ? Number(req.query.year) : new Date().getFullYear();
        try { res.json(await books.duplicates(envOf(), { year })); }
        catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    // ── THE CHEQUES THAT WENT STRAIGHT TO COST OF GOODS ───────────────────
    // agent.js has computed these on every run since it was written: 16
    // cheques, $411,276.27, each with its date, payee, amount and the
    // containers named on it. The page did exactly one thing with all of it:
    //
    //     ['Miscoded', money(i.miscoded && i.miscoded.number), 'warn'],
    //
    // A number in a chip. Sixteen rows computed every morning and thrown
    // away, while the mail says "One approval, never silent" about an
    // approval that does not exist anywhere.
    //
    // READ-ONLY, DELIBERATELY. Re-coding moves money out of cost of goods
    // sold and changes reported profit — that is a write against her books
    // and a decision she has not made. This route only shows her what the
    // agent already knows, which is the half that was missing.
    app.get('/api/qb/miscoded', async (req, res) => {
        const year = /^\d{4}$/.test(String(req.query.year || '')) ? Number(req.query.year) : new Date().getFullYear();
        try {
            const m = await require('./agent').miscodedCheques(year, envOf());
            // Named first and biggest first inside each group: the ones with a
            // payee are the ones she can do something about today, and the
            // nameless ones are usually the larger pile — which is exactly why
            // they must not sit at the top looking like the job.
            const by = (a, b) => b.amount - a.amount;
            res.json({
                year, env: envOf(),
                total: m.number, count: m.count, span: m.span,
                named: { ...m.fixable, rows: (m.fixable.rows || []).slice().sort(by) },
                nameless: { ...m.noPayee, rows: (m.noPayee.rows || []).slice().sort(by) },
            });
        } catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    // ── money paid, money matched ──────────────────────────────────────────
    // The single biggest thing wrong with her books: $4.96M of payments with
    // no allocation, so every bill reads open. Allocating moves nothing —
    // no bank entry, no profit and loss, no change to the payable total — it
    // only says which bill the money already spent belongs to. Read-only
    // until she says otherwise, and never a bulk button without a dry run.
    app.get('/api/qb/allocate-plan', async (req, res) => {
        try {
            res.json(await require('./applyPayments').plan({
                vendor: req.query.vendor || null,
                since: /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.since || '')) ? req.query.since : '2024-01-01',
                env: envOf(),
            }));
        } catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    app.post('/api/qb/allocate', async (req, res) => {
        if (locked(req, res)) return;
        const b = req.body || {};
        const really = b.really === true;
        if (really && String(b.confirm || '').trim().toUpperCase() !== 'APPLY') {
            return res.status(400).json({ error: 'to place these for real, type APPLY' });
        }
        const ap = require('./applyPayments');
        try {
            // the plan is made again here, from live data — never trusted
            // from the browser, where it may be minutes old
            const planned = await ap.plan({ vendor: b.vendor || null,
                since: /^\d{4}-\d{2}-\d{2}$/.test(String(b.since || '')) ? b.since : '2024-01-01', env: envOf() });
            res.json(await ap.apply(planned, { reason: b.reason, really, by: who(req), env: envOf() }));
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── THE BOOKS, ON DISK, FOR THE QUESTION CHANNEL ───────────────────────
    // "How much do we owe Inesh" on WhatsApp used to be answered from Jarvis's
    // own bills ledger. It is answered from her BOOKS now, through a snapshot
    // the nightly run writes (helpers/quickbooks/snapshot.js) — a phone cannot
    // wait for 610 bills over the API. This refreshes it on demand and says
    // how old the current one is.
    app.get('/api/qb/snapshot', (req, res) => {
        const snap = require('./snapshot');
        const s = snap.read();
        if (!s) return res.json({ snapshot: null, note: 'QuickBooks has never been read for the question channel — POST here to take one' });
        res.json({ at: s.at, env: s.env, since: s.since, minutes_old: snap.ageMinutes(), totals: s.totals,
            over_applied: (s.over_applied || []).slice(0, 10) });
    });

    app.post('/api/qb/snapshot', async (req, res) => {
        if (locked(req, res)) return;
        try {
            const s = await require('./snapshot').write({ env: envOf(),
                since: /^\d{4}-\d{2}-\d{2}$/.test(String((req.body || {}).since || '')) ? req.body.since : '2026-01-01' });
            // The mirror keys off the snapshot's mtime, but dropping the cache
            // here means the next question does not wait for the next rebuild
            // check to notice.
            try { require('../data/dataMirror').invalidate(); } catch { /* the mtime still catches it */ }
            res.json({ ok: true, at: s.at, totals: s.totals });
        } catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    // ── CUSTOMER MONEY, PLACED ─────────────────────────────────────────────
    // The mirror of /api/qb/allocate on the receivables side: $131,763.84 is
    // in the bank against no invoice, and every one of those invoices reads
    // open. Placing moves no money. The plan is always remade here from live
    // data — the browser's copy may be minutes old.
    app.get('/api/qb/receipts', async (req, res) => {
        try {
            res.json(await require('./applyReceipts').plan({
                customer: String(req.query.customer || '').trim() || null,
                since: /^\d{4}-\d{2}-\d{2}$/.test(String(req.query.since || '')) ? req.query.since : '2026-01-01',
                env: envOf(), limit: Number(req.query.limit) || 60,
            }));
        } catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    app.post('/api/qb/receipts/apply', async (req, res) => {
        if (locked(req, res)) return;
        const b = req.body || {};
        const really = b.really === true;
        if (really && String(b.confirm || '').trim().toUpperCase() !== 'APPLY') {
            return res.status(400).json({ error: 'to place these for real, type APPLY' });
        }
        const ar = require('./applyReceipts');
        try {
            const planned = await ar.plan({ customer: b.customer || null,
                since: /^\d{4}-\d{2}-\d{2}$/.test(String(b.since || '')) ? b.since : '2026-01-01', env: envOf(), limit: 200 });
            const only = Array.isArray(b.ids) && b.ids.length ? new Set(b.ids.map(String)) : null;
            const narrowed = only ? { ...planned, receipts: (planned.receipts || []).filter((r) => only.has(r.id)) } : planned;
            res.json(await ar.apply(narrowed, { reason: b.reason, really, by: who(req), env: envOf(),
                certainOnly: b.certainOnly === true }));
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── ONE PAYABLES ACCOUNT, NOT TWO ──────────────────────────────────────
    // the owner, 2026-09-30. QuickBooks refuses an account merge over the API, so
    // the documents move instead. The hard limit, proved in sandbox on
    // 2026-10-05 (scripts/qb-payables-proof.js): moving a bill that has been
    // paid is ACCEPTED and silently unapplies the payment. Only untouched
    // bills move, and the plan is always remade here from live data.
    app.get('/api/qb/payables', async (req, res) => {
        try { res.json(await require('./payables').survey({ env: envOf() })); }
        catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    app.post('/api/qb/payables/plan', async (req, res) => {
        const b = req.body || {};
        try { res.json(await require('./payables').plan({ from: b.from, to: b.to, env: envOf(), limit: Number(b.limit) || 500 })); }
        catch (e) { res.status(400).json({ error: e.message }); }
    });

    app.post('/api/qb/payables/apply', async (req, res) => {
        if (locked(req, res)) return;
        const b = req.body || {};
        const really = b.really === true;
        if (really && String(b.confirm || '').trim().toUpperCase() !== 'MOVE') {
            return res.status(400).json({ error: 'to move these for real, type MOVE' });
        }
        const pay = require('./payables');
        try {
            // Remade from live data, and then narrowed to what she picked —
            // the browser's list may be minutes old, and a payment landing in
            // between is exactly the case the guard exists for.
            const planned = await pay.plan({ from: b.from, to: b.to, env: envOf(), limit: 1000 });
            const movable = new Set(planned.move.map((x) => x.id));
            const asked = (Array.isArray(b.ids) && b.ids.length ? b.ids.map(String) : planned.move.map((x) => x.id));
            const ids = asked.filter((id) => movable.has(id));
            const dropped = asked.filter((id) => !movable.has(id));
            const out = await pay.apply({ from: b.from, to: b.to, ids, env: envOf(), dryRun: !really, who: who(req) });
            res.json({ ...out, dropped, plan: { move: planned.move.length, held: planned.held.length, note: planned.note } });
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    app.post('/api/qb/payables/undo', async (req, res) => {
        if (locked(req, res)) return;
        const b = req.body || {};
        try { res.json(await require('./payables').undo({ qbId: b.qbId, back: b.back, env: envOf(), who: who(req) })); }
        catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── THE BANK'S "FOR REVIEW" LIST ───────────────────────────────────────
    // the owner, 2026-09-26: "i need it." QuickBooks does not expose that queue
    // to ANY app — verified against her own books: there is no BankTransaction
    // entity, /olb is an unsupported operation, and no report carries an
    // un-reviewed line, because it is not a transaction yet. What Intuit does
    // allow is the CSV the Banking screen exports. So she exports once, and
    // this does the thinking: every line matched to the open bill or invoice
    // it pays, with the same conservative rules as the script.
    //
    // It writes NOTHING to QuickBooks. The output is a worklist she or the
    // accountant clicks down in the Banking screen.
    app.post('/api/qb/bank-review', async (req, res) => {
        const b = req.body || {};
        // ── ONE PAGE AT A TIME (2026-09-26) ────────────────────────────────
        // the owner: "Right now it shows only one page for download." The
        // Banking screen exports what is ON SCREEN, so 661 lines come out as
        // several files. Send them all: they are read together, and a line
        // that appears in two overlapping exports is counted once.
        const decode = (v) => (b.base64 ? Buffer.from(String(v), 'base64').toString('utf8') : String(v));
        const files = Array.isArray(b.csvs) ? b.csvs.map(decode)
            : (typeof b.csv === 'string' && b.csv.length ? [decode(b.csv)] : []);
        if (!files.length || !files.some((f) => f.trim())) return res.status(400).json({ error: 'send the CSV exported from the Banking screen' });
        const since = /^\d{4}-\d{2}-\d{2}$/.test(String(b.since || '')) ? b.since : `${new Date().getFullYear()}-01-01`;
        const bank = require('../../scripts/qb-bank-match.js');
        const env = envOf();
        try {
            let columns = null; const lines = []; const seen = new Set(); let duplicates = 0;
            const problems = [];
            for (const text of files) {
                let part;
                try { part = bank.readBankLines({ text }); }
                catch (e) { problems.push(e.message); continue; }
                columns = columns || part.columns;
                for (const l of part.lines) {
                    // the same line in two overlapping exports: one date, one
                    // description, one amount, one direction
                    const key = `${l.date}|${l.amount}|${l.direction}|${String(l.desc).trim().toUpperCase()}`;
                    if (seen.has(key)) { duplicates++; continue; }
                    seen.add(key); lines.push(l);
                }
            }
            if (!lines.length) return res.status(400).json({ error: problems[0] || 'no bank lines found in those files — check they are the export, not a screenshot' });
            // If QuickBooks cannot be reached, she still gets her lines read
            // and counted — with every row marked unchecked and the reason
            // said out loud, rather than a 400 that throws the file away.
            let docs = null, qbError = null;
            try { docs = await bank.openDocs(env, since); }
            catch (e) { qbError = e.message; docs = { out: [], in: [] }; }
            const tally = {};
            const rows = lines.map((line) => {
                const m = qbError ? { how: 'unchecked', why: `QuickBooks could not be read: ${qbError}`, docs: [] } : bank.matchLine(line, docs);
                tally[m.how] = (tally[m.how] || 0) + 1;
                return { ...line, how: m.how, why: m.why,
                    docs: m.docs.map((d) => ({ type: d.type, id: String(d.id), doc: d.doc, date: d.date, party: d.party, balance: d.balance, containers: d.containers })) };
            });
            const money = (how) => r2(rows.filter((x) => x.how === how).reduce((s, x) => s + x.amount, 0));
            res.json({ env, since, columns, counted: rows.length, files: files.length, duplicates,
                unreadable: problems.length ? problems : null, quickbooks: qbError, tally,
                totals: { exact: money('exact'), group: money('group'), near: money('near'), none: money('none'), notTrade: money('not-trade') },
                open: { bills: docs.out.length, invoices: docs.in.length },
                rows });
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── QB AGENT ───────────────────────────────────────────────────────────
    // the owner, 2026-10-02: "auto resolves discrepancy … whose only job is to
    // make qb perfect." The survey is the scoreboard; the queue is what it
    // would do, ask, propose or cannot touch; the run does only the `do`
    // items, and dry unless she says otherwise.
    app.get('/api/qb/agent', async (req, res) => {
        const year = /^\d{4}$/.test(String(req.query.year || '')) ? Number(req.query.year) : new Date().getFullYear();
        try {
            const agent = require('./agent');
            const surveyed = await agent.survey({ year, env: envOf() });
            res.json({ ...surveyed, queue: agent.queue(surveyed), invariantList: agent.INVARIANTS });
        } catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    app.post('/api/qb/agent/run', async (req, res) => {
        if (locked(req, res)) return;
        const b = req.body || {};
        const really = b.really === true;
        if (really && String(b.confirm || '').trim().toUpperCase() !== 'RUN') {
            return res.status(400).json({ error: 'to let the agent write, type RUN' });
        }
        try {
            res.json(await require('./agent').run({
                year: /^\d{4}$/.test(String(b.year || '')) ? Number(b.year) : new Date().getFullYear(),
                env: envOf(), really, reason: b.reason }));
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── what she is owed, and who to write to ──────────────────────────────
    // Intuit's Payments agent predicts late payers and sends reminders. This
    // does the same with what they cannot see — the container, the shipment,
    // the customer's own habit, and above all the money already received and
    // applied to nothing. It drafts; she sends.
    app.get('/api/qb/receivables', async (req, res) => {
        try { res.json(await require('./receivables').survey({ env: envOf() })); }
        catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    app.get('/api/qb/receivables/draft', async (req, res) => {
        const who = String(req.query.customer || '').trim();
        if (!who) return res.status(400).json({ error: 'which customer?' });
        try {
            const r = require('./receivables');
            const all = await r.survey({ env: envOf() });
            const c = all.customers.find((x) => x.customer === who);
            if (!c) return res.status(404).json({ error: `nothing open for ${who}` });
            res.json({ ...r.draft(c), verdict: c.verdict, why: c.why });
        } catch (e) { res.status(502).json({ error: `QuickBooks: ${e.message}` }); }
    });

    // ── what she has already answered ──────────────────────────────────────
    // An agent that asks the same question twice is a cron job with manners.
    // These are her answers, kept in qb-settings so they travel in git, and
    // revocable: a wrong rule must be as easy to take back as a wrong entry.
    app.get('/api/qb/decisions', (req, res) => {
        const d = require('./decisions');
        res.json({ kinds: d.ABOUT, decisions: d.list({ about: req.query.about || null }) });
    });

    app.post('/api/qb/decisions', (req, res) => {
        if (locked(req, res)) return;
        try { res.json(require('./decisions').remember({ ...(req.body || {}), by: who(req) })); }
        catch (e) { res.status(400).json({ error: e.message }); }
    });

    app.post('/api/qb/decisions/forget', (req, res) => {
        if (locked(req, res)) return;
        const id = String((req.body || {}).id || '').trim();
        if (!id) return res.status(400).json({ error: 'which decision?' });
        const gone = require('./decisions').forget(id);
        if (!gone) return res.status(404).json({ error: `no decision ${id}` });
        res.json({ ok: true, ...gone, note: 'it will be asked about again from the next run' });
    });

    app.post('/api/qb/undo', async (req, res) => {
        if (locked(req, res)) return;
        const { journalId, reason, dryRun } = req.body || {};
        if (!journalId) return res.status(400).json({ error: 'which journal entry?' });
        if (!reason || String(reason).trim().length < 4) return res.status(400).json({ error: 'an undo needs a reason — it goes in the journal' });
        try {
            res.json(await journal.undo(journalId, { env: envOf(), dryRun: dryRun !== false, reason: String(reason).trim() }));
        } catch (e) { res.status(400).json({ error: e.message }); }
    });

    // ── Ask Jarvis ─────────────────────────────────────────────────────────
    // Answers and explains; it does not write (her choice). It is handed the
    // real numbers for the party on screen, so it never has to invent one,
    // and it always comes back with one follow-up question.
    app.post('/api/qb/ask', async (req, res) => {
        const { question, kind, name } = req.body || {};
        if (!String(question || '').trim()) return res.status(400).json({ error: 'ask something' });
        const env = envOf();
        let context = {};
        try {
            if (name) {
                const d = partyDetail(kind === 'customer' ? 'customer' : 'vendor', name, env);
                const m = mapping.matchParty(name, [], kind === 'customer' ? 'customer' : 'vendor');
                let qbBalance = null;
                try { const qb = await qbParties(env); const f = (kind === 'customer' ? qb.customer : qb.vendor).find((x) => String(x.Id) === String(m.qbId)); qbBalance = f ? r2(f.Balance) : null; } catch {}
                context = { party: name, kind, mappedTo: m.qbName || null, qbBalance, totals: d.totals,
                    bills: d.bills.slice(-25), invoices: d.invoices.slice(-25), advances: d.advances.slice(-25),
                    recentJarvisWrites: d.journal.slice(0, 10).map((e) => ({ at: e.at, action: e.action, kind: e.kind, qbId: e.qb && e.qb.id, reason: e.reason })) };
                // ── AND WHAT QUICKBOOKS ITSELF SAYS (2026-09-26) ───────────
                // the owner: "jarvis should be supreme of qb". Answering only
                // from Jarvis's ledgers meant the chat could not see a
                // payment her accountant entered by hand — so it is handed
                // her books too, for the same party, read live.
                if (m.qbId && m.qbId !== 'SKIP') {
                    try {
                        const q = await books.partyDocs(kind === 'customer' ? 'customer' : 'vendor', m.qbId, env);
                        context.inQuickBooks = { totals: q.totals, documents: q.docs.slice(0, 25).map((x) => ({ kind: x.kind, doc: x.doc, date: x.date, total: x.total, open: x.balance, containers: x.containers })) };
                    } catch (e) { context.inQuickBooks = { error: e.message }; }
                }
            } else {
                context = { overview: (await partyRows({ env, withQb: false })).slice(0, 40) };
                try {
                    const b = await books.overview(env);
                    context.books = { year: b.year, profitAndLoss: b.pl,
                        owedToYou: b.ar && { count: b.ar.count, total: b.ar.total, aging: b.ar.aging },
                        youOwe: b.ap && { count: b.ap.count, total: b.ap.total, aging: b.ap.aging },
                        banks: (b.banks || []).map((a) => ({ name: a.name, balance: a.balance })) };
                } catch (e) { context.books = { error: e.message }; }
            }
        } catch (e) { context = { error: e.message }; }

        const prompt = [
            'You are Jarvis, answering the owner about her QuickBooks bookkeeping inside her own app.',
            'Answer ONLY from the DATA below. If the data does not cover it, say exactly what is missing.',
            'She writes fast and loosely — work out what she means; never ask her to rephrase.',
            'Money: always give the figure and what it is (an advance, an open bill, a Jarvis row not yet in QuickBooks).',
            'Be short: three sentences at most, plain words, no jargon, no bullet lists.',
            'You cannot change anything — if an action is needed, name the button on the page.',
            'DATA.inQuickBooks and DATA.books are her REAL books, read live. Where they disagree with the',
            'Jarvis side, say both figures and which is which — the disagreement is usually the answer she',
            'is after (a payment her accountant entered by hand, a consolidated invoice, a bill paid another way).',
            'She should never have to open QuickBooks to check what you just said, so quote the document',
            'number and the date when you name one.',
            'For a SUPPLIER, never read out bills and advances as two separate piles: totals.owedToSupplier is',
            'the one number that matters — positive means she owes him that much, negative means he is holding',
            'that much of her money. Say which way round it is, in those words.',
            'If totals.unpricedBills is above zero, say so: those containers have no agreed price yet, so the',
            'bill total is lower than the real position and no figure here is final until they are priced.',
            'Return JSON: {"answer": "...", "followUp": "one short question that moves this forward"}',
            'The followUp is never optional and never generic — it must be about THIS party or THIS number.',
            '',
            'QUESTION: ' + String(question).trim(),
            'DATA: ' + JSON.stringify(context).slice(0, 12000),
        ].join('\n');

        try {
            const gemini = require('../gemini');
            // Best model: this answers "what does this party owe" off a
            // 12k-character slab of her real ledger, and the follow-up it
            // writes is acted on. See config.GEMINI_MODEL_QB.
            const out = await gemini.callGeminiJSON(prompt, 1, null,
                { model: require('../../config').GEMINI_MODEL_QB });
            if (out && out.answer) return res.json({ answer: String(out.answer), followUp: String(out.followUp || 'What would you like to check next on this account?'), context: !!name });
            throw new Error('no answer');
        } catch (e) {
            // Jarvis without the model still answers from the numbers.
            const t = context.totals;
            const who = t && t.owedToSupplier !== null && t.owedToSupplier !== undefined
                ? (t.owedToSupplier > 0 ? `you owe ${name} $${t.owedToSupplier}` : `${name} is holding $${r2(-t.owedToSupplier)} of your money`)
                : null;
            const qbT = context.inQuickBooks && context.inQuickBooks.totals;
            const plain = t
                ? `${name}: ${who ? who + '. ' : ''}$${t.bills} of bills against $${t.advances} advanced${t.unpricedBills ? `, and ${t.unpricedBills} container${t.unpricedBills > 1 ? 's have' : ' has'} no price yet` : ''}. ${t.inQuickBooks} records are in QuickBooks, ${t.notInQuickBooks} are not.${qbT ? ` Your books hold ${qbT.documents} documents for this party, ${qbT.open ? `$${qbT.open} still open` : 'nothing open'}.` : ''}`
                : 'I can see the ledgers but the language model is not answering right now.';
            res.json({ answer: plain, followUp: name ? `Do you want the bills for ${name}, or the wires?` : 'Which supplier or customer shall I open?', degraded: true });
        }
    });
}

module.exports = { mount, partyRows, partyDetail, jarvisParties, qbParties, r2, KEY };
