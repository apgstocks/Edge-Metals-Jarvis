// ── helpers/quickbooks/sync.js — Jarvis saves, QuickBooks follows ───────────
// the owner, 2026-09-22: "Why none of this change is reflected in qb?" — because
// nothing called the push code. This is the caller.
//
// ── HOW IT IS WIRED ─────────────────────────────────────────────────────────
// api.js calls after('bill', id) etc. AFTER a save has succeeded and after the
// response is decided. after() never throws and never waits: the push runs
// on the next tick, so a slow or down QuickBooks can never fail, slow, or
// change a save in Jarvis. Whatever happens is in the journal.
//
// ── THREE SWITCHES, ALL OFF BY DEFAULT ──────────────────────────────────────
//   QB_SYNC=on          the hooks do anything at all. Off: deploying this file
//                       changes nothing — the save routes behave as today.
//   QB_ENV=production   which company. Anything else is the sandbox.
//   QB_PROD_WRITES=on   client.js lets a write reach the live books.
// Plus the cutover dates (push.js) — nothing before them, ever.
//
// ── WHAT IT DOES NOT DO YET ─────────────────────────────────────────────────
// An EDIT or DELETE in Jarvis of something already in QuickBooks is not
// pushed as an update/delete. It is journalled as 'asked' with what changed,
// so `qb-journal check` lists it and she decides (undo + re-push, or fix by
// hand). Updating her books on every edit is a separate, riskier step.

const fs = require('fs');
const path = require('path');
const { DATA_DIR } = require('../../config');
const auth = require('./auth');
const client = require('./client');
const mapping = require('./mapping');
const push = require('./push');
const pushInvoice = require('./pushInvoice');
const pushPayments = require('./pushPayments');
const journal = require('./journal');

const on = () => String(process.env.QB_SYNC || '').trim().toLowerCase() === 'on';
const SNAP_TTL_MS = 60 * 60 * 1000;

// Name lists from her books, refreshed hourly (a new vendor she adds in
// QuickBooks becomes matchable within the hour). Falls back to the snapshot
// files so a QuickBooks outage does not block matching of known names.
let snapCache = { at: 0, env: null, data: null };
//
// Names are ALWAYS matched against her LIVE books (read-only), whichever
// company is being written to: every mapping she confirmed is a production
// name, and the sandbox only mirrors those names. Found by the end-to-end
// test 2026-09-22 — against the sandbox's own list, "MK Trading" (an exact
// live match) was unknown and the invoice was blocked.
async function snapshots() {
    const env = auth.status('production').connected ? 'production' : auth.qbEnv();
    if (snapCache.data && snapCache.env === env && Date.now() - snapCache.at < SNAP_TTL_MS) return snapCache.data;
    const opts = { env };
    try {
        const data = {};
        for (const k of ['vendor', 'customer', 'item', 'bank', 'account']) data[k] = await mapping.fetchParties(k, client, opts);
        snapCache = { at: Date.now(), env, data };
        return data;
    } catch (e) {
        const f = (n) => { try { return JSON.parse(fs.readFileSync(path.join(DATA_DIR, n), 'utf8')); } catch { return []; } };
        const p = f('qb-snapshot-parties.json');
        return { vendor: p.vendor || [], customer: p.customer || [], item: f('qb-snapshot-items.json'), bank: f('qb-snapshot-banks.json'), account: f('qb-snapshot-accounts.json') };
    }
}

// ── one record ──────────────────────────────────────────────────────────────
async function syncBill(id, env) {
    const bills = require('../bills');
    const raw = bills.list().find((b) => b.id === id);
    if (!raw) return { status: 'gone' };
    return push.pushBill(bills.withTotals(raw), await snapshots(env), { env, dryRun: false });
}

// one invoice = every sales row carrying that invoice number
async function syncSale(id, env) {
    const sales = require('../sales');
    const one = sales.getSale(id);
    if (!one) return { status: 'gone' };
    const no = push.docNumberFor(one);
    if (!no) return { status: 'waiting', problems: ['no invoice number yet — entered once it has one'] };
    const rows = sales.list().filter((s) => push.docNumberFor(s) === no).map((s) => sales.withTotals(s));
    return pushInvoice.pushInvoice(rows, await snapshots(env), { env, dryRun: false });
}

async function syncBillPayment(id, env) {
    const p = require('../billPayments').list().find((x) => x.id === id);
    if (!p) return { status: 'gone' };
    // a payment waits for every bill it pays
    for (const a of (p.allocations || [])) await syncBill(a.bill_id, env).catch(() => {});
    return pushPayments.pushBillPayment(p, await snapshots(env), { env, dryRun: false });
}

async function syncReceipt(id, env) {
    const sales = require('../sales');
    const r = require('../salesReceipts').list().find((x) => x.id === id);
    if (!r) return { status: 'gone' };
    for (const a of (r.allocations || [])) await syncSale(a.sale_id, env).catch(() => {});
    return pushPayments.pushCustomerPayment(r, await snapshots(env), { env, dryRun: false,
        saleInvoiceNo: (saleId) => { const s = sales.getSale(saleId); return s && push.docNumberFor(s); } });
}

const SYNC = { bill: syncBill, sale: syncSale, billpayment: syncBillPayment, receipt: syncReceipt };
const LINK_KIND = { bill: 'bill', sale: 'invoice', billpayment: 'billpayment', receipt: 'payment' };

// An edit or delete of something already entered: recorded, not pushed.
function noteChange(kind, id, what, env) {
    const links = push.loadLinks();
    let key = push.linkKey(env, LINK_KIND[kind], id);
    if (kind === 'sale') {
        const s = require('../sales').getSale(id);
        if (s && push.docNumberFor(s)) key = push.linkKey(env, 'invoice', push.docNumberFor(s));
    }
    const l = links[key];
    if (!l) return false;
    journal.record({ env, kind: LINK_KIND[kind] === 'invoice' ? 'invoice' : LINK_KIND[kind], action: 'asked', linkKey: key,
        jarvis: { id, change: what }, qb: { id: l.qbId },
        reason: `${what} in Jarvis after it was entered in QuickBooks (#${l.qbId}) — QuickBooks was NOT changed; undo and re-push, or fix it there` });
    return true;
}

// ── the hook ────────────────────────────────────────────────────────────────
// change: 'saved' (new or edited) | 'deleted'
function after(kind, id, change = 'saved') {
    if (!on() || !id || !SYNC[kind]) return;
    setImmediate(async () => {
        const env = auth.qbEnv();
        try {
            if (change === 'deleted') { noteChange(kind, id, 'deleted', env); return; }
            const r = await SYNC[kind](String(id), env);
            if (r && r.status === 'already-linked') noteChange(kind, id, 'edited', env);
            if (r && !['created', 'exists', 'already-linked', 'before-cutover', 'waiting', 'gone'].includes(r.status)) {
                console.warn(`[QB] ${kind} ${id}: ${r.status}${r.problems ? ' — ' + r.problems.join('; ') : ''}`);
            }
        } catch (e) {
            console.warn(`[QB] ${kind} ${id} failed: ${e.message}`);
            try { journal.record({ env, kind: LINK_KIND[kind] === 'invoice' ? 'invoice' : LINK_KIND[kind], action: 'blocked', jarvis: { id }, qb: {}, reason: `error: ${e.message}` }); } catch { /* the save already stood; nothing more to do */ }
        }
    });
}

// ── the sweep: everything since the cutover, in dependency order ────────────
// Catches saves that arrived another way (imports, the invoice flow, a time
// QB_SYNC was off or QuickBooks was down). Idempotent: linked records are
// skipped, everything else goes through the same checks as a hook.
// ── A NIGHT'S WORK, NOT A YEAR'S ──────────────────────────────────────────
// With the date rule gone the sweep sees every unlinked row in the ledgers —
// 610 bills and 742 sales on her books the night this changed. Linked rows
// cost nothing (the link is checked before any call), but the backlog does,
// so a run takes the oldest `limit` of what is left and the next run takes
// the next. The backlog drains over a few nights instead of one run timing
// out and achieving nothing.
async function sweep({ env = auth.qbEnv(), dryRun = false, limit = 200 } = {}) {
    const res = { bill: {}, sale: {}, billpayment: {}, receipt: {} };
    // ── PER-ROW DETAIL, ON A DRY RUN ONLY (2026-10-01) ─────────────────────
    // the owner: "Assign one agent for quickbook next".
    //
    // count() keeps the status and throws away WHICH row and WHY. So the
    // nightly QuickBooks email can say "7 blocked" and never say which seven
    // or what they are missing, and she has to run a terminal script to find
    // out. An agent cannot work from a count either.
    //
    // So a dry run also keeps the rows. ADDITIVE: quickbooksNightly's
    // summarise() reads res[kind][status] and is untouched; nothing else
    // reads this object. Dry run only, because that is the path with no
    // writes and no journal entries — the live path's detail already goes to
    // the journal, which is the record that has to survive.
    res.rows = [];
    const keep = (k, row, r) => {
        if (!r) return;
        res.rows.push({
            kind: k,
            // Both, because push.js links by `id || container_no` and the
            // consumer needs whichever one identifies the row.
            id: (row && row.id) || null,
            container_no: (row && row.container_no) || null,
            party: (row && (row.supplier || row.customer)) || null,
            invoice_no: (row && row.invoice_no) || null,
            date: (row && row.date) || null,
            status: r.status || 'error',
            problems: Array.isArray(r.problems) ? r.problems.slice() : [],
        });
    };
    const count = (k, r) => { const s = (r && r.status) || 'error'; res[k][s] = (res[k][s] || 0) + 1; };
    // ── WHAT THE CUTOVER LEFT BEHIND (2026-09-26) ───────────────────────────
    // Rows older than the cutover are dropped here, before any push. That was
    // invisible: with the cutover set to today, a night's sheet sync could
    // write 11 bills and the run would report nothing at all — no error, no
    // count, nothing to act on. So the sweep now counts what it walked past,
    // with the oldest and newest date, and the report says it out loud.
    const left = { bill: 0, sale: 0, billpayment: 0, receipt: 0, from: null, to: null, why: {} };
    const noteLeft = (k, kind, d, reason) => {
        left[k]++;
        const iso = push.isoDate(d);
        if (iso) { if (!left.from || iso < left.from) left.from = iso; if (!left.to || iso > left.to) left.to = iso; }
        const why = String(reason || '').replace(/\(\d{4}-\d{2}-\d{2}\)/, '').trim();
        left.why[why] = (left.why[why] || 0) + 1;
    };
    // keep a row if the boundary allows it OR its date is simply wrong (can't
    // be read, or in the future) — the push functions then report it as blocked
    // instead of it vanishing. Only a real period lock takes a row out.
    const since = (k, kind, d) => {
        const c = push.beforeCutover(kind, d, env);
        if (!c || push.NEEDS_FIX.test(c)) return true;
        noteLeft(k, kind, d, c);
        return false;
    };
    const oldestFirst = (rows) => rows.sort((a, b) => String(push.isoDate(a.date) || '').localeCompare(String(push.isoDate(b.date) || '')));
    const cap = (rows, kind) => {
        const all = oldestFirst(rows);
        if (all.length <= limit) return all;
        res[kind].waiting = all.length - limit;
        return all.slice(0, limit);
    };
    const bills = cap(require('../bills').list().filter((b) => since('bill', 'bill', b.date)), 'bill');
    const sales = cap(require('../sales').list().filter((s) => since('sale', 'invoice', s.date)), 'sale');
    const bps = cap(require('../billPayments').list().filter((p) => since('billpayment', 'bill', p.date)), 'billpayment');
    const recs = cap(require('../salesReceipts').list().filter((r) => since('receipt', 'invoice', r.date)), 'receipt');
    const snaps = await snapshots(env);
    if (dryRun) {
        const B = require('../bills'), S = require('../sales');
        for (const b of bills) {
            const r = await push.pushBill(B.withTotals(b), snaps, { env, dryRun: true }).catch((e) => ({ status: 'error: ' + e.message }));
            count('bill', r); keep('bill', b, r);
        }
        const byInv = {};
        for (const s of sales) { const n = push.docNumberFor(s); if (n) (byInv[n] = byInv[n] || []).push(S.withTotals(s)); }
        for (const rows of Object.values(byInv)) {
            const r = await pushInvoice.pushInvoice(rows, snaps, { env, dryRun: true }).catch((e) => ({ status: 'error: ' + e.message }));
            // One invoice can cover several grade rows; the first carries the
            // identifying invoice_no and container, which is what she looks
            // the invoice up by.
            count('sale', r); keep('sale', rows[0], r);
        }
        // payments too — they only find their bill/invoice once it is linked
        for (const p of bps) {
            const r = await pushPayments.pushBillPayment(p, snaps, { env, dryRun: true }).catch((e) => ({ status: 'error: ' + e.message }));
            count('billpayment', r); keep('billpayment', p, r);
        }
        for (const rec of recs) {
            const r = await pushPayments.pushCustomerPayment(rec, snaps, { env, dryRun: true,
                saleInvoiceNo: (saleId) => { const s = S.getSale(saleId); return s && push.docNumberFor(s); } })
                .catch((e) => ({ status: 'error: ' + e.message }));
            count('receipt', r); keep('receipt', rec, r);
        }
        res.leftAlone = left;
        return res;
    }
    for (const b of bills) count('bill', await syncBill(b.id, env).catch((e) => ({ status: 'error: ' + e.message })));
    const seen = new Set();
    for (const s of sales) { const no = push.docNumberFor(s); if (no && seen.has(no)) continue; seen.add(no); count('sale', await syncSale(s.id, env).catch((e) => ({ status: 'error: ' + e.message }))); }
    for (const p of bps) count('billpayment', await syncBillPayment(p.id, env).catch((e) => ({ status: 'error: ' + e.message })));
    for (const r of recs) count('receipt', await syncReceipt(r.id, env).catch((e) => ({ status: 'error: ' + e.message })));
    res.leftAlone = left;
    return res;
}

module.exports = { after, sweep, syncBill, syncSale, syncBillPayment, syncReceipt, on, snapshots };
