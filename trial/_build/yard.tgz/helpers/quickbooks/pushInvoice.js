// ── helpers/quickbooks/pushInvoice.js — a Jarvis sale, as her invoice ───────
// Split from push.js by what it does: bills there, invoices here.
//
// Her invoices, read from Sample Yard Co Metals Inc 2026-09-21/22 (e.g. #38877, TAEWON,
// TXGU8942580, 5 Aug 2026):
//   one invoice per CONTAINER; one line per GRADE (Jarvis keeps one sales row
//   per grade — see memory: ledger-data)
//   line = item (grade), Qty × UnitPrice in the unit she priced in — MT at
//          645/MT, or lbs at 1.88/lb — description = container number
//   terms "Due on receipt" on all 125 of her June–Sept invoices
//   total = Jarvis `receivable` (amount + charges the customer pays). Charges
//   Sample pays (freight out, commission) are costs, not invoice lines — which
//   is why 148 of her 150 recent invoices carry no freight line.

const push = require('./push');
const client = require('./client');
const auth = require('./auth');

const round2 = (n) => Math.round(n * 100) / 100;

// Pure. rows = the sales rows of ONE invoice, after sales.withTotals().
// refs = { customerId, itemIds: {grade|chargeName: id}, termId? }
function buildInvoice(rows, refs) {
    const problems = [];
    if (!rows || !rows.length) return { problems: ['no sales rows'] };
    const first = rows[0];
    const same = (k) => rows.every((r) => String(r[k] || '').trim().toUpperCase() === String(first[k] || '').trim().toUpperCase());
    if (!rows.every((r) => push.docNumberFor(r) === push.docNumberFor(first))) problems.push('rows carry different invoice numbers');
    if (!same('customer')) problems.push('rows carry different customers');
    if (!same('container_no')) problems.push('rows carry different containers — one invoice is one container');
    const doc = push.docNumberFor(first);
    const container = String(first.container_no || '').trim().toUpperCase();
    const date = first.date;
    if (!doc) problems.push('no invoice number');
    if (doc.length > push.DOC_MAX) problems.push(`invoice number longer than QuickBooks allows (${push.DOC_MAX})`);
    if (!date) problems.push('no invoice date');

    const Line = [];
    for (const r of rows) {
        const grades = (r.items && r.items.length)
            ? r.items.map((i) => ({ grade: i.description, unit: i.price_unit, lb: i.weight, mt: i.weight_mt, price: i.price, amount: i.amount }))
            : [{ grade: r.item, unit: r.price_unit, lb: r.weight_lb, mt: r.weight_mt, price: r.invoice_price, amount: r.amount }];
        for (const g of grades) {
            const id = refs.itemIds[g.grade];
            if (!id) { problems.push(`grade "${g.grade}" has no QuickBooks item`); continue; }
            if (typeof g.amount !== 'number' || !(g.amount > 0)) { problems.push(`grade "${g.grade}" has no amount`); continue; }
            const detail = { ItemRef: { value: String(id) } };
            const qty = g.unit === 'mt' ? g.mt : g.lb;
            if (push.pairFits(qty, g.price, g.amount)) {
                detail.Qty = qty; detail.UnitPrice = g.price;
            }
            Line.push({ DetailType: 'SalesItemLineDetail', Amount: round2(g.amount), Description: container || undefined, SalesItemLineDetail: detail });
        }
        for (const c of (r.charges || []).filter((c) => c.direction === 'in')) {
            const id = refs.itemIds[c.what];
            if (!id) { problems.push(`charge "${c.what}" has no QuickBooks item`); continue; }
            Line.push({ DetailType: 'SalesItemLineDetail', Amount: round2(c.amount), Description: [container, c.why].filter(Boolean).join(' — '), SalesItemLineDetail: { ItemRef: { value: String(id) } } });
        }
    }
    const total = round2(Line.reduce((s, l) => s + l.Amount, 0));
    const receivable = round2(rows.reduce((s, r) => s + (Number(r.receivable) || 0), 0));
    if (!problems.length && total !== receivable) problems.push(`lines add to ${total} but Jarvis says ${receivable} is receivable`);
    if (problems.length) return { problems };
    const inv = {
        CustomerRef: { value: String(refs.customerId) },
        TxnDate: push.isoDate(date),
        DocNumber: doc,
        PrivateNote: [container && `Container ${container}`, first.booking_no && `Booking ${first.booking_no}`, first.hbl_no && `HBL ${first.hbl_no}`, `Jarvis sale ${rows.map((r) => r.id).filter(Boolean).join(',')}`].filter(Boolean).join(' · '),
        Line,
    };
    if (refs.termId) inv.SalesTermRef = { value: String(refs.termId) };
    return { invoice: inv, total };
}

async function resolveRefs(rows, snapshots, opts) {
    const env = opts.env || auth.qbEnv();
    const problems = [];
    const cust = push.confirmedName('customer', rows[0].customer, snapshots.customer);
    if (cust.problem) problems.push(cust.problem);
    const names = {};
    for (const r of rows) {
        for (const g of (r.items && r.items.length ? r.items.map((i) => i.description) : [r.item])) {
            const x = push.confirmedName('item', g, snapshots.item); if (x.problem) problems.push(x.problem); else names[g] = x.name;
        }
        for (const c of (r.charges || []).filter((c) => c.direction === 'in')) {
            const x = push.confirmedName('item', c.what, snapshots.item); if (x.problem) problems.push(x.problem); else names[c.what] = x.name;
        }
    }
    if (problems.length) return { problems };
    const get = async (kind, table, field, name) => (await push.idByName(table, field, name, opts))
        || (env === 'sandbox' ? push.ensureSandbox(kind, name, opts) : null);
    const refs = { customerId: await get('customer', 'Customer', 'DisplayName', cust.name), itemIds: {} };
    for (const [g, n] of Object.entries(names)) refs.itemIds[g] = await get('item', 'Item', 'Name', n);
    refs.termId = await get('term', 'Term', 'Name', 'Due on receipt');
    if (!refs.customerId) problems.push(`customer "${cust.name}" not found in QuickBooks ${env}`);
    for (const [g, id] of Object.entries(refs.itemIds)) if (!id) problems.push(`item "${names[g]}" not found in QuickBooks ${env}`);
    return problems.length ? { problems } : { refs, customerName: cust.name };
}

async function pushInvoice(rows, snapshots, { env = auth.qbEnv(), dryRun = true, fetchImpl } = {}) {
    const opts = { env, fetchImpl };
    const first = rows[0] || {};
    const cut = push.beforeCutover('invoice', first.date, env);
    if (cut) {
        if (push.NEEDS_FIX.test(cut) && !dryRun) require('./journal').record({ env, kind: 'invoice', action: 'blocked',
            jarvis: { ids: rows.map((x) => x.id), container: first.container_no, invoice_no: push.docNumberFor(first), customer: first.customer, date: first.date }, qb: {}, reason: cut });
        return { status: push.NEEDS_FIX.test(cut) ? 'blocked' : 'before-cutover', problems: [cut] };
    }
    const key = push.linkKey(env, 'invoice', push.docNumberFor(first) || first.container_no);
    const linked = push.loadLinks()[key];
    if (linked) return { status: 'already-linked', qbId: linked.qbId };

    const journal = require('./journal');
    const jarvis = { ids: rows.map((r) => r.id), container: first.container_no, invoice_no: push.docNumberFor(first), customer: first.customer, date: first.date,
        receivable: rows.reduce((s, r) => s + (Number(r.receivable) || 0), 0) };
    const note = (action, extra) => { if (!dryRun) journal.record({ env, kind: 'invoice', action, jarvis, qb: {}, ...extra }); };

    const res = await resolveRefs(rows, snapshots, opts);
    if (res.problems) { note('blocked', { reason: res.problems.join('; ') }); return { status: 'blocked', problems: res.problems }; }
    const built = buildInvoice(rows, res.refs);
    if (built.problems) { note('blocked', { reason: built.problems.join('; ') }); return { status: 'blocked', problems: built.problems }; }

    const hits = await push.findExistingDoc('Invoice', { date: first.date, container: first.container_no, doc: push.docNumberFor(first) }, opts);
    const j = push.judgeExisting(hits, res.refs.customerId, built.total);
    if (j.sure) {
        if (!dryRun) push.saveLink(key, { qbId: j.sure.Id, how: 'matched-existing', at: new Date().toISOString() });
        note('linked-existing', { linkKey: key, jarvisTotal: built.total, qb: { id: j.sure.Id, total: j.sure.TotalAmt, partyId: j.sure.partyId, party: j.sure.party }, reason: 'same customer, same total, found by container/invoice no' });
        return { status: 'exists', qbId: j.sure.Id, note: 'already in QuickBooks — linked, nothing entered' };
    }
    if (j.ask) { note('asked', { candidates: j.ask, reason: j.why.join('; ') }); return { status: 'ask', candidates: j.ask, why: j.why, invoice: built.invoice, note: 'this container is already in QuickBooks but not exactly as Jarvis has it — she decides' }; }
    if (dryRun) return { status: 'would-create', invoice: built.invoice, total: built.total };
    const out = await client.request('POST', '/invoice', built.invoice, opts);
    push.saveLink(key, { qbId: out.Invoice.Id, syncToken: out.Invoice.SyncToken, how: 'created', total: out.Invoice.TotalAmt, at: new Date().toISOString() });
    const je = journal.record({ env, kind: 'invoice', action: 'created', jarvis, linkKey: key, jarvisTotal: built.total,
        qb: { id: out.Invoice.Id, syncToken: out.Invoice.SyncToken, fp: journal.fingerprint(out.Invoice), total: out.Invoice.TotalAmt, partyId: res.refs.customerId, party: res.customerName } });
    return { status: 'created', qbId: out.Invoice.Id, total: out.Invoice.TotalAmt, invoice: out.Invoice, journalId: je.id };
}

module.exports = { buildInvoice, resolveRefs, pushInvoice };
