// ── helpers/tools.js — what the assistant can actually do ─────────────────
//
// the owner, 2026-09-05, on wanting Jarvis to stop feeling like a template:
// "dynamically it should act ... mimicing a assistant behaviour not just
// restricted to standard template."
//
// THE PROBLEM THIS REPLACES
// -------------------------
// The vocabulary was written down TWICE. Once as English prose in
// yardAsk.js's SYSTEM_RULES — a numbered rule listing record_payment,
// create_load and edit_load with their parameters — and once as real code in
// yardActions.js's ACTIONS object. Two files, hand-synced. There is even a
// comment in yardActions.js claiming they are "kept next to the
// implementations so the two cannot drift"; they are not, and only the NAMES
// were ever shared, never the parameter documentation.
//
// That duplication is the template. Every new capability meant editing
// English in one file and JavaScript in another, and when the two disagreed
// the model confidently proposed something that did not exist — which reads
// to the person as the assistant being broken rather than out of date. Six
// features have shipped since those three actions were written (trucker
// bills, expenses, petty cash, the spend report, the inventory drill-down,
// sales) and the assistant knows about none of them.
//
// ONE REGISTRY, AND THE PROMPT IS GENERATED FROM IT
// -------------------------------------------------
// A tool is one object: name, description, parameter schema, handler. The
// text the model reads is built by describeTools() from these same objects,
// so the prompt cannot lag behind the code. Adding a capability is adding an
// entry.
//
// READ RUNS, WRITE PROPOSES
// -------------------------
// The split is the whole safety story, and it is what lets the assistant feel
// dynamic without becoming dangerous:
//
//   kind: 'read'   — runs IMMEDIATELY, no confirmation. Looking something up
//                    changes nothing, and making someone confirm a lookup is
//                    what made this feel like a form to fill in.
//   kind: 'write'  — builds a proposal and returns it. Nothing is written
//                    until the person confirms, exactly as before.
//
// The dangerous class is not "actions", it is IRREVERSIBLE actions. Reading
// the spend report is free to get wrong. Sending a supplier an email is not.
// So the boundary is drawn there rather than around the word "action".
//
// WHAT IS DELIBERATELY ABSENT
// ---------------------------
// No delete tool, of any kind. No send-email or send-WhatsApp tool. Those are
// the two categories with no undo — a deleted payment cannot be recovered
// from a screen, and a sent message cannot be unsent from a yard. They stay
// out of the assistant's reach entirely rather than behind a confirmation,
// because a confirmation is one mistaken tap and voice input mishears names.
// Adding either should be a decision someone makes on purpose, with this
// paragraph in front of them.

const money = (n) => `$${(Math.round(Number(n) * 100) / 100).toFixed(2)}`;
// A price per pound is a fraction of a dollar: money() would show 0.159 as "$0.16" on a confirm card
// while the total is worked out from 0.159. Show what will be saved, to 4 places, trimmed to at least 2.
const perLb = (n) => { const v = Math.round(Number(n) * 10000) / 10000; return `$${v.toFixed(4).replace(/(\.\d\d)0+$/, '$1').replace(/(\.\d\d\d)0$/, '$1')}`; };
const isYmd = (v) => /^\d{4}-\d{2}-\d{2}$/.test(String(v || ''));
const str = (v) => String(v == null ? '' : v).trim();
const num = (v) => { const n = Number(v); return Number.isFinite(n) ? n : null; };

// A read tool's answer is fed back into a prompt, so it has to be small. An
// unbounded list is a slow, expensive turn and gives the model more room to
// drift; it is also almost never what the question needed.
const MAX_ROWS = 40;
const cap = (rows) => {
    const list = Array.isArray(rows) ? rows : [];
    return list.length > MAX_ROWS
        ? { rows: list.slice(0, MAX_ROWS), truncated: true, total: list.length }
        : { rows: list, truncated: false, total: list.length };
};

// ── the registry ──────────────────────────────────────────────────────────
// `params` is documentation AND validation in one place. Each entry:
//   type      — 'string' | 'number' | 'date' | 'boolean' | 'array'
//   required  — refuse without it, naming what is missing
//   describe  — the sentence the model reads
const TOOLS = {

    // ══ READ ═══════════════════════════════════════════════════════════════
    // These are the ones that make it an assistant rather than a form. Until
    // now the model was handed one pre-computed digest and could not go and
    // look at anything else — so a question the digest did not anticipate got
    // "that is not in the data I have", which is true and useless.

    // ── NO BOOKINGS TOOL HERE, DELIBERATELY ──────────────────────────────
    // One was added on 2026-09-06 and removed the same day. It was the wrong
    // fix in the wrong file, and the reasoning that produced it — "it cannot
    // answer about bookings, so give it a bookings tool" — is the reasoning
    // that will produce it again, which is why this note replaces it rather
    // than the code simply disappearing.
    //
    // the owner: "yard ask is a different assistant restricted only to yard
    // (restrict it to yard data). Jarvis knows everything."
    //
    // That split already existed. TWO assistants sit behind /api/voice/ask,
    // chosen by helpers/voiceRouter.js:
    //
    //   Scout  — this registry. Loads, sellers, stock, payments, petty cash,
    //            trucker bills. A narrow assistant over the yard ledger.
    //   Jarvis — workflow/brain.js. Bookings, containers, ports, cutoffs,
    //            suppliers, truckers, WhatsApp, email. It has answered
    //            location booking questions for weeks, through
    //            bookings_list_query and queryBookingsByLocation.
    //
    // Her question failed because dashboard/voice.js called /api/yard/ask
    // directly and bypassed the router, so every spoken question reached
    // Scout. Scout saying it did not know about bookings was CORRECT — it is
    // not the assistant that knows. Teaching it bookings would have
    // dissolved a boundary that exists on purpose and left two assistants
    // able to give different answers about the same container.
    //
    // The boundary is enforced in tests/yard-ask-tools.js, not just here.


    // ── REMOVED 2026-11-07, BY OWNER ───────────────────────────────────
    // find_claims, claim_detail and record_pickup lived here. This file IS
    // the YARD assistant's registry, and two guards went red when they
    // appeared in it:
    //
    //   tests/voice-router.js            Scout must advertise no freight
    //   tests/yard-assistant-knowledge.js  and its WRITE list must not grow
    //
    // Both guards exist for CLAUDE.md rule 5 — "Sample Yard Co Yard and Sample Yard Co Metals
    // are different companies ... the separation is most of what this app
    // is for". Claims are raised against SUPPLIERS on CONTAINERS and
    // pickups are booked with logistics companies: both are the export
    // side, and neither belongs to the yard.
    //
    // Asked whether to narrow the guards or remove the tools, the owner chose
    // to remove them. Her words: "Neither — take both back out." So the
    // guards stay exactly as strict as they were.
    //
    // NOTHING IN PRODUCTION CALLED THEM. Every reference outside this file
    // was a test. The Follow-up Agent keeps its routes and its screen; what
    // it loses is the ability to record a pickup by TALKING to the yard
    // assistant. If that is wanted back, it belongs in Jarvis proper
    // (workflow/brain.js), not here.

    find_loads: {
        kind: 'read',
        description: 'Search purchase loads by seller, date range, item description, or payment state. Use this before answering anything about specific loads.',
        params: {
            seller: { type: 'string', describe: 'part of a seller name; matched loosely' },
            from: { type: 'date', describe: 'earliest load date, YYYY-MM-DD' },
            to: { type: 'date', describe: 'latest load date, YYYY-MM-DD' },
            item: { type: 'string', describe: 'part of an item description, e.g. "sealed units"' },
            unpaid_only: { type: 'boolean', describe: 'true to return only loads with something still outstanding' },
        },
        run: async (p) => {
            const { loadLoads } = require('./loads');
            const { paymentSummary } = require('./payments');
            const seller = str(p.seller).toLowerCase();
            const item = str(p.item).toLowerCase();
            const rows = loadLoads()
                .filter((l) => !seller || String(l.seller || '').toLowerCase().includes(seller))
                .filter((l) => !p.from || String(l.date || '') >= p.from)
                .filter((l) => !p.to || String(l.date || '') <= p.to)
                .filter((l) => !item || (l.items || []).some((it) => String(it.description || '').toLowerCase().includes(item)))
                // net_payable alongside amount, and the payment measured
                // against the payable — a load with haulage deducted owes the
                // seller less than the metal came to, and "what do we still
                // owe Sam" is the question this tool exists to answer.
                .map((l) => ({ id: l.id, date: l.date, seller: l.seller, amount: l.amount,
                               trucking_amount: l.trucking_amount ?? null,
                               net_payable: require('./loads').payableOf(l),
                               payment: paymentSummary(l.id, require('./loads').payableOf(l)) }))
                .filter((l) => !p.unpaid_only || (l.payment && l.payment.pending > 0))
                .sort((a, b) => String(b.date).localeCompare(String(a.date)));
            return cap(rows);
        },
    },

    load_detail: {
        kind: 'read',
        description: 'Everything about one load: its items, weights, prices and every payment recorded against it.',
        params: { load_id: { type: 'string', required: true, describe: 'the load id, e.g. SAMPLE_42' } },
        run: async (p) => {
            const { getLoad } = require('./loads');
            const { paymentsForLoad, paymentSummary } = require('./payments');
            const id = str(p.load_id);
            const load = await getLoad(id);
            // Not found is a RESULT, not an error. The model asked a
            // reasonable question and the honest answer is "no such load" —
            // throwing would turn that into an apology about a failure.
            if (!load) return { found: false, load_id: id };
            return {
                found: true,
                // amount AND net_payable, both named, because the difference
                // between them is the whole point of the deduction and an
                // assistant handed only one of them will state it as though
                // it were the other.
                load: { id: load.id, date: load.date, seller: load.seller, amount: load.amount,
                        trucking_company: load.trucking_company ?? null,
                        trucking_amount: load.trucking_amount ?? null,
                        net_payable: require('./loads').payableOf(load),
                        items: load.items || [], signed: !!load.seller_signature },
                payments: paymentsForLoad(id),
                summary: paymentSummary(id, require('./loads').payableOf(load)),
            };
        },
    },

    inventory: {
        kind: 'read',
        description: 'Stock on hand by item type — what has come in, net of what has been sold.',
        params: { from: { type: 'date' }, to: { type: 'date' } },
        run: async (p) => {
            const { loadLoads, getInventoryReport } = require('./loads');
            return getInventoryReport(loadLoads(), { from: p.from, to: p.to });
        },
    },

    item_lines: {
        kind: 'read',
        description: 'Every individual line of one material across all loads, with gross, tare, net, price and which load it came from.',
        params: {
            description: { type: 'string', required: true, describe: 'the item type, e.g. "sealed units"' },
            from: { type: 'date' }, to: { type: 'date' },
        },
        run: async (p) => {
            const { loadLoads, getItemLines } = require('./loads');
            const r = getItemLines(loadLoads(), { description: str(p.description), from: p.from, to: p.to });
            return { count: r.count, totals: r.totals, ...cap(r.lines) };
        },
    },

    // the owner, 2026-11-15: "why did the number become -12290 ... no guesses, only proper reasoning". Read-only; Sample Yard Co Yard's
    // own loads and sales only. See helpers/stockExplain.js.
    explain_stock: {
        kind: 'read',
        description: 'EXPLAIN why one item\'s stock on hand is what it is, especially when it is negative: lines up every purchase and every sale of that item with a running balance, finds the day it went below zero, and checks its total against the Inventory screen. Use for "why is X negative", "why did the number become -N", "how is on-hand worked out". Say ONLY what its findings state. If it says the books cannot tell, say that. Never guess a cause.',
        params: { item: { type: 'string', required: true, describe: 'the item name exactly as on the Inventory screen' } },
        run: async (p) => {
            const { loadLoads, getInventoryReport } = require('./loads');
            const { loadOutboundLoads } = require('./outboundLoads');
            const inbound = loadLoads();
            return require('./stockExplain').explainStock({ inbound, outbound: loadOutboundLoads(), item: str(p.item), screenRows: getInventoryReport(inbound).byType });
        },
    },

    // ── THE HALF OF THE YARD IT COULD NOT SEE ────────────────────────────
    // the owner, 2026-09-16: "Yard assistant should have complete knowledge abou
    // yard."
    //
    // It did not, and the gap was not a rough edge — it was structural. Every
    // read above this point looks at PURCHASES. find_loads calls loadLoads()
    // and says so in its own description; nothing in this file had ever opened
    // helpers/outboundLoads.js. So "who did we sell to this month", "what did
    // Eccomelt take", "are we making anything" all reached an assistant that
    // had no way to look, and the honest answer it could give was that it did
    // not know.
    //
    // Three reads, matching the three reports she named for the phone on the
    // same day (Sales, Stock, Profit — Stock already had `inventory`):

    find_sales: {
        kind: 'read',
        description: 'Search SALES — material shipped OUT of the yard — by buyer, date range or item description. Use this for anything about what was sold, to whom, or for how much. find_loads only covers purchases coming IN.',
        params: {
            buyer: { type: 'string', describe: 'match part of a buyer name, case-insensitive' },
            from: { type: 'date' }, to: { type: 'date' },
            item: { type: 'string', describe: 'match part of an item description' },
            unpaid_only: { type: 'boolean', describe: 'true to return only sales the customer has not fully paid for' },
            limit: { type: 'number', describe: 'defaults to 25' },
        },
        run: async (p) => {
            const { loadOutboundLoads } = require('./outboundLoads');
            const q = (v) => String(v || '').trim().toLowerCase();
            const buyer = q(p.buyer), item = q(p.item);
            const inRange = (d) => !!d && (!p.from || d >= p.from) && (!p.to || d <= p.to);
            const rows = loadOutboundLoads().filter((l) => {
                if (!l) return false;
                if ((p.from || p.to) && !inRange(l.date)) return false;
                if (buyer && !q(l.buyer).includes(buyer)) return false;
                if (item && !(l.items || []).some((it) => q(it && it.description).includes(item))) return false;
                return true;
            }).sort((a, b) => String(b.date || '').localeCompare(String(a.date || '')));
            const limit = Math.max(1, Math.min(100, Number(p.limit) || 25));
            // ── WHAT THE CUSTOMER STILL OWES ─────────────────────────────
            // Attached here rather than left to a second call. Once sales are
            // visible at all, "who still owes me" is the next question anyone
            // asks, and an assistant that can list sales but not say which are
            // unpaid can only answer half of it.
            //
            // paymentSummary is the SAME arithmetic the screens use — a
            // second implementation in this file would eventually disagree
            // with the ledger, on money.
            const { paymentSummary } = require('./payments');
            // receivableOf, not l.amount — these rows are SALES, and since
            // 2026-11-04 a sale can carry trucking charged on to the buyer.
            // Asking Jarvis "which sales are unpaid" off the gross amount
            // would call a sale settled while the freight on it is still
            // outstanding. The voice path is the caller CLAUDE.md records
            // breaking twice, both times because it has no form to put a
            // field on; it needs no new field here, only the right reader.
            const { receivableOf } = require('./outboundLoads');
            const withPay = rows.map((l) => ({ ...l, payment: paymentSummary(l.id, receivableOf(l)) }));
            const shown = p.unpaid_only
                ? withPay.filter((l) => l.payment && l.payment.pending > 0)
                : withPay;
            // The COUNT comes back alongside the page, so an answer built on
            // the first 25 of 300 sales can say so instead of sounding
            // complete. A truncated list presented as the whole is how a
            // confident wrong total gets spoken aloud.
            return { total: shown.length, showing: Math.min(limit, shown.length), sales: shown.slice(0, limit) };
        },
    },

    sales_report: {
        kind: 'read',
        description: 'Who the yard sold to over a period — loads, weight, amount, and margin where the material is linked back to the loads it came from. Use for "how much did we sell", "who bought what".',
        params: { from: { type: 'date' }, to: { type: 'date' } },
        run: async (p) => {
            const { loadOutboundLoads, getOutboundReport } = require('./outboundLoads');
            return getOutboundReport(loadOutboundLoads(), { from: p.from, to: p.to });
        },
    },

    yard_profit: {
        kind: 'read',
        description: 'Sample Yard Co Yard profit: margin on what was actually sold, plus a separate cash in/out picture. SAMPLE YARD CO YARD ONLY — never add this to Sample Yard Co Metals figures.',
        params: { from: { type: 'date' }, to: { type: 'date' } },
        run: async (p) => {
            const out = require('./yardProfit').yardProfit({ from: p.from, to: p.to });
            // ── THE CAVEAT TRAVELS WITH THE NUMBER ───────────────────────
            // helpers/yardProfit.js returns `coverage_pct` and a `caveat` in
            // words precisely so a client cannot render the figure without it
            // by simply forgetting to. An assistant is the client most likely
            // to forget: it reads the JSON, finds `margin`, and says a
            // number. So the instruction is hoisted to the top level of the
            // reply where it cannot be missed, rather than left nested two
            // keys deep beside the figure it qualifies.
            //
            // The cash block is already named NOT PROFIT in its own note. It
            // is repeated here for the same reason.
            return {
                ...out,
                _how_to_answer: out.margin && out.margin.caveat
                    ? `Say the margin AND this, in the same breath: ${out.margin.caveat}`
                    : 'Margin covers essentially all sales in this range.',
                _never: 'The cash block is money in and out over the period. It is NOT profit — do not call it profit, and do not add it to the margin.',
            };
        },
    },

    // ── AND THE REST OF IT ───────────────────────────────────────────────
    // the owner, 2026-09-16, on being told the assistant could not see sales:
    // "it should see everything".
    //
    // So this is the rest of the yard, audited store by store against
    // config.js rather than guessed at. What was still invisible after the
    // sales reads landed: WhatsApp scale tickets, unfinished loads, the
    // material catalogue and her own decisions about which names mean the same
    // metal — and, on the money side, what customers still owe HER.
    //
    // ── "EVERYTHING" MEANS EVERYTHING *YARD* ─────────────────────────────
    // Sample Yard Co Metals is a different company and its stores stay out of this file:
    // bills, sales (invoices), sales receipts, settlements, metals trucking,
    // Yard Inventory, BOLs, packing lists. Not an oversight — an assistant
    // that can read both is one answer away from a figure that describes
    // neither company, which is the mistake this whole app is arranged to
    // prevent. tests/yard-assistant-knowledge.js holds the line.

    scale_tickets: {
        kind: 'read',
        description: 'Scale-ticket photos sent in over WhatsApp — the quick weight captures, separate from full load records. Use when asked about a weight that was photographed but may never have become a load.',
        params: {
            from: { type: 'date' }, to: { type: 'date' },
            limit: { type: 'number', describe: 'defaults to 25' },
        },
        run: async (p) => {
            const { loadScaleTickets } = require('./scaleTickets');
            const day = (t) => String((t && (t.received_at || t.created_at)) || '').slice(0, 10);
            const rows = (loadScaleTickets() || []).filter((t) => {
                if (!t) return false;
                if (p.from && day(t) < p.from) return false;
                if (p.to && day(t) > p.to) return false;
                return true;
            });
            const limit = Math.max(1, Math.min(100, Number(p.limit) || 25));
            return {
                total: rows.length, showing: Math.min(limit, rows.length),
                // The PHOTO is not sent — only that there is one, and its link.
                // A base64 image in a tool result is a huge payload for a
                // question the link already answers.
                tickets: rows.slice(0, limit).map((t) => ({
                    id: t.id, received_at: t.received_at, from: t.from || t.sender || null,
                    weight: t.weight ?? null, unit: t.unit || null,
                    description: t.description || t.note || null,
                    has_photo: !!(t.drive_link || t.drive_file_id), drive_link: t.drive_link || null,
                })),
            };
        },
    },

    load_drafts: {
        kind: 'read',
        description: 'Loads that were started and never finished. Use for "is there anything half-entered", or when a load someone remembers recording cannot be found.',
        params: {},
        run: async () => {
            const { listDrafts } = require('./loadDrafts');
            const rows = listDrafts();
            return {
                total: rows.length,
                // Summarised, not dumped. A draft carries the whole half-typed
                // form including photo links; what answers the question is
                // whose it is, when, and how far it got.
                drafts: rows.map((d) => ({
                    id: d.id, updated_at: d.updated_at || d.created_at || null,
                    kind: d.kind || 'purchase', seller: d.seller || d.buyer || null,
                    date: d.date || null,
                    items: Array.isArray(d.items) ? d.items.filter((i) => i && i.description).length : 0,
                })),
            };
        },
    },

    item_catalogue: {
        kind: 'read',
        description: 'Every material description the yard uses, and which different spellings she has confirmed mean the same metal. Use before answering about a material by name — "Al combo" and "Aluminium combo" may be one pile.',
        params: {},
        run: async () => {
            const { loadCustomItemTypes } = require('./itemTypes');
            const aliases = require('./itemAliases');
            return {
                descriptions: loadCustomItemTypes(),
                // ── ONLY THE ONES SHE SETTLED ────────────────────────────
                // helpers/itemAliases.js stores AI verdicts alongside her
                // answers and never lets a machine verdict settle anything.
                // Passing the unfiltered list here would let one wrong guess
                // become a merged pile in every answer the assistant gives.
                //
                // source === 'user' AND same === true. A "no, these are
                // different" is also hers and also stored, and shipping it in
                // a list called same_metal would invert her answer.
                //
                // NOT aliases.settled() — that takes a PAIR and answers about
                // that one pair. Calling it with no arguments returned null
                // and crashed this tool on its first run.
                same_metal: aliases.list()
                    .filter((r) => r && r.source === 'user' && r.same === true)
                    .map((r) => [r.a, r.b]),
                _note: 'Two descriptions are the same metal ONLY if they appear together in same_metal. Never merge two materials because their names look alike — "Al 6061" and "Al 6063" are different alloys worth different money.',
            };
        },
    },

    spend_report: {
        kind: 'read',
        description: 'What the business has paid out, split into loads, haulage and expenses, by month and by payment method. Also reports money received from sales separately.',
        params: {
            from: { type: 'date' }, to: { type: 'date' },
            method: { type: 'string', describe: 'narrow to one of Cash, Zelle, Wire, Cheque, Card' },
        },
        run: async (p) => {
            const { buildSpendReport } = require('./spendReport');
            const { listPayments } = require('./payments');
            const { loadExpenses } = require('./expenses');
            const petty = require('./pettyCash');
            const r = buildSpendReport({
                payments: listPayments(), expenses: loadExpenses(),
                pettyEntries: petty.listEntries(), from: p.from, to: p.to, method: p.method,
            });
            // The row-level drill-down is dropped: the totals answer the
            // question and the rows would dominate the prompt. find_expenses
            // is the drill-down beside this, for anything that needs a name.
            const { rows, received, ...totals } = r;

            // ── BY CATEGORY, WHICH WAS MISSING ENTIRELY ──────────────────
            // the owner, 2026-09-15, pushing back on "it should be able to show
            // that na" after being told the deployed build lacked
            // find_expenses. She was right, and about more than that: this
            // report handed over byMethod, byBank and months, and NO category
            // breakdown at all. So "how much salary did we pay" was
            // unanswerable even in the summary, despite
            // expenses.getExpenseReport computing byCategory for the Expenses
            // tab all along.
            //
            // It is an AGGREGATE, one line per category, so the reasoning
            // above about rows dominating the prompt does not apply to it.
            // This makes the ordinary summary question — what did we spend on
            // labour, on fuel, on repairs — answerable without a row search.
            let byCategory = [];
            try {
                const { getExpenseReport, loadExpenses } = require('./expenses');
                byCategory = (getExpenseReport(loadExpenses(), { from: p.from, to: p.to }).byCategory) || [];
            } catch (e) { /* a report that cannot be built must not break the rest */ }

            return { ...totals, byCategory, received: { total: received.total, count: received.count, byMethod: received.byMethod } };
        },
    },

    // ── EXPENSES, ROW BY ROW ─────────────────────────────────────────────
    // the owner, 2026-09-15, asking the assistant "How much did we pay
    // Santiago?" and then "check in expenses", and being told twice that
    // there is no record of it.
    //
    // It was answering honestly. The only expense tool it had was
    // spend_report, which deliberately DROPS the rows — "the totals answer
    // the question and the rows would dominate the prompt" — so the
    // assistant could see what August cost by method and month and could not
    // see a single expense, a vendor name, or a description. Every question
    // about WHO was paid or WHAT FOR was unanswerable, and the honest "I
    // cannot find any record" was indistinguishable from "there are none".
    //
    // spend_report keeps dropping its rows; that reasoning still holds for a
    // whole-business report. This is the drill-down beside it, filtered
    // before it is returned so only what was asked for reaches the prompt.
    find_expenses: {
        kind: 'read',
        description: 'Search recorded expenses by vendor, category, description or date range. Use this for any question about who was paid, what was bought, or what an expense was for — spend_report gives totals only and cannot name anyone.',
        params: {
            // ── ONE SEARCH BOX, NOT TWO ──────────────────────────────────
            // This was `vendor` and `text` as separate parameters, and her
            // own data broke it: one expense has Santiago in the VENDOR
            // field ($240) and another names him only in the DESCRIPTION —
            // "Weekly salary Santiago", $900. The model had to pick one, so
            // "how much did we pay Santiago" answered $240 and left out the
            // $900 without saying so.
            //
            // An undercount is the dangerous direction: nobody questions a
            // figure that is lower than they feared. So one parameter that
            // looks everywhere a name or a thing can be written. `vendor`
            // and `text` are still accepted as aliases, because the prompt
            // and any half-finished tool call may still use them, and they
            // now mean the same thing rather than half the answer.
            match: { type: 'string', describe: 'a person, company or thing — matched loosely against the vendor, the description AND the notes. Use this for "how much did we pay X" and for "what did we spend on Y".' },
            vendor: { type: 'string', describe: 'alias for match' },
            text: { type: 'string', describe: 'alias for match' },
            category: { type: 'string', describe: 'part of a category, e.g. "fuel" or "labour"' },
            method: { type: 'string', describe: 'one of Cash, Zelle, Wire, Cheque, Card, Other' },
            from: { type: 'date', describe: 'earliest expense date, YYYY-MM-DD' },
            to: { type: 'date', describe: 'latest expense date, YYYY-MM-DD' },
        },
        run: async (p) => {
            const { loadExpenses } = require('./expenses');
            const like = (hay, needle) => String(hay || '').toLowerCase().includes(String(needle).trim().toLowerCase());
            // Whichever the model reached for, they mean the same thing.
            const needle = p.match || p.vendor || p.text || '';
            const rows = loadExpenses().filter((e) => {
                // Vendor, description AND notes. A person can be recorded in
                // any of the three — hers are in two — and searching one of
                // them answers a money question with part of the answer.
                if (needle && !(like(e.vendor, needle) || like(e.description, needle) || like(e.notes, needle))) return false;
                if (p.category && !like(e.category, p.category)) return false;
                if (p.method && String(e.payment_method || '').toLowerCase() !== String(p.method).trim().toLowerCase()) return false;
                if (p.from && String(e.date || '') < p.from) return false;
                if (p.to && String(e.date || '') > p.to) return false;
                return true;
            });
            // The TOTAL of what matched, computed here rather than left to the
            // model to add up. "How much did we pay Santiago" is a sum, and a
            // sum a language model does in its head is a sum nobody checked.
            const total = Math.round(rows.reduce((t, e) => t + (Number(e.amount) || 0), 0) * 100) / 100;
            return { matched_total: total, ...cap(rows) };
        },
    },

    trucker_bills: {
        kind: 'read',
        description: 'Haulage bills owed to trucking companies, with what has been paid against each.',
        params: { company: { type: 'string' }, from: { type: 'date' }, to: { type: 'date' } },
        run: async (p) => {
            const t = require('./truckerBills');
            const bills = t.listBillsWithPayments({ from: p.from, to: p.to, company: p.company });
            return { report: t.billsReport(bills), ...cap(bills) };
        },
    },

    petty_cash: {
        kind: 'read',
        description: 'The cash box: current balance and recent movements.',
        params: {},
        run: async () => {
            const petty = require('./pettyCash');
            const entries = petty.listEntries();
            return { balance: petty.balance(), ...cap(entries.slice(-20).reverse()) };
        },
    },

    // ══ THE BANK AND THE CLAIMS, WHICH THE BOT COULD NOT SEE ═══════════════
    // the owner, 2026-11-05: "what about our own bot" — then, on finding it had
    // no way in: "give door access".
    //
    // Eighteen tools covered loads, inventory, sales, expenses, petty cash
    // and trucker bills. None touched the bank and none touched claims —
    // the two newest and most expensive subsystems in the app. So the
    // QuickBooks Ask box could answer about Intuit's data while her own bot
    // could not answer "who is that deposit from" or "which claims are
    // open". That is the wrong way round, and it is the whole argument for
    // Jarvis over QuickBooks.
    //
    // ALL FOUR ARE READ. The writes stay on the screens, because confirming
    // a receipt asks about fees, discounts and the payment mode, and
    // CLAUDE.md records the voice path breaking twice for exactly this
    // reason — it is the caller with no form to put a field on. A write
    // tool here is a separate decision, asked for one at a time.

    // ── THE PICKUP, BY TALKING (2026-11-06) ─────────────────────────────
    // the owner: "Have a followup agent", and before that the pickup she books
    // with a logistics company. She chose BOTH entry points — Jarvis
    // arranges it, and she records one — so the voice path gets the same
    // door the screen has.
    //
    // CLAUDE.md rule 1 names this caller twice: the voice path is the one
    // that breaks, because it is the caller with no form to put a field on.
    // So it is built from the store's OWN requirements (company and date,
    // nothing else) rather than from whatever the screen happens to collect.
    // A field the screen adds later cannot break this.

    // Read, so it answers at once — "is anyone chasing the carrier pickup?"
    // is a question, and making her confirm a lookup is what made this feel
    // like a form.
    pickup_status: {
        kind: 'read',
        description: 'Pickups arranged, what Jarvis has already asked the logistics company, '
            + 'and whether they have given an ETA yet.',
        params: { company: { type: 'string' }, container: { type: 'string' }, open: { type: 'boolean' } },
        run: async (p) => {
            const pk = require('./pickups');
            const agent = require('./pickupAgent');
            const norm = (v) => String(v == null ? '' : v).trim().toLowerCase();
            let rows = pk.list();
            if (norm(p.company)) rows = rows.filter((r) => norm(r.company).includes(norm(p.company)));
            if (norm(p.container)) rows = rows.filter((r) => norm(r.container_no) === norm(p.container));
            if (p.open) rows = rows.filter((r) => r.status === 'arranged' && !String(r.eta || '').trim());
            const nowD = new Date();
            return {
                pickups: rows.length,
                rows: rows.map((r) => {
                    const next = agent.nextAction(r, nowD);
                    return {
                        company: r.company, container_no: r.container_no,
                        pickup_date: r.pickup_date, status: r.status,
                        // Her actual question is "has anyone chased them",
                        // so the answer leads with that rather than a status.
                        eta: r.eta || null,
                        asked: (r.sent || []).filter((s) => s && s.step !== 'escalate').length,
                        team_told: (r.sent || []).some((s) => s && s.step === 'escalate'),
                        next_step: next.step, next_why: next.why,
                    };
                }),
            };
        },
    },

    bank_unmatched: {
        kind: 'read',
        description: 'Money in the bank that is not yet explained — deposits with no invoice '
            + 'against them and withdrawals with no bill. Says what Jarvis read each line as.',
        params: { direction: { type: 'string' }, limit: { type: 'number' } },
        run: async (p) => {
            const ledger = require('./bankLedger');
            const { payeeOf } = require('./bankPayee');
            const want = String(p.direction || '').toLowerCase();
            const rows = (ledger.worklist ? ledger.worklist() : ledger.list()) || [];
            const open = rows.filter((r) => !ledger.actedOn || !ledger.actedOn(r))
                .filter((r) => (want === 'in' ? Number(r.amount) > 0
                              : want === 'out' ? Number(r.amount) < 0 : true));
            // read_as is the point of the answer: a bank line is unreadable
            // out loud, and the company name is the only part she wants said.
            const said = open.map((r) => ({
                date: r.date || r.posted_at || null,
                amount: r.amount,
                read_as: payeeOf(r.descriptor || r.name || '') || null,
                descriptor: r.descriptor || r.name || '',
                bank: (ledger.bankOf ? ledger.bankOf(r) : null) || null,
            }));
            const total = said.reduce((t, r) => t + (Number(r.amount) || 0), 0);
            return { unexplained_rows: said.length, unexplained_total: Math.round(total * 100) / 100,
                     ...cap(said.slice(0, Math.max(1, Math.min(Number(p.limit) || 25, MAX_ROWS)))) };
        },
    },

    bank_who_is: {
        kind: 'read',
        description: 'Who a bank line is from. Reads the company name out of the bank\'s own '
            + 'description and says whether it matches anyone in the ledger.',
        params: { descriptor: { type: 'string', required: true } },
        run: async (p) => {
            const { payeeOf } = require('./bankPayee');
            const bankLearn = require('./bankLearn');
            const read = payeeOf(p.descriptor);
            // The same two steps the screen takes, in the same order, so the
            // bot and the Bank page can never disagree about one line.
            const customers = (() => {
                try { return require('./bankMatchRoutes').openReceivables().map((d) => d.party)
                    .filter(Boolean); } catch (e) { return []; }
            })();
            const names = [...new Set(customers)];
            const resolved = bankLearn.resolverFrom(bankLearn.listAliases(), names)(p.descriptor);
            const hints = resolved ? [] : (bankLearn.suggestParty(p.descriptor, names) || []);
            return {
                read_as: read || null,
                matched: resolved || null,
                // Never a single guess dressed as an answer: nameMatch.js
                // refuses near-misses because a wrong one pays the wrong
                // company. Two candidates come back as two.
                suggestions: hints.slice(0, 3),
                needs_you: !resolved,
            };
        },
    },



    // ══ WRITE ══════════════════════════════════════════════════════════════
    // Each returns a PROPOSAL — a summary, the details worth checking, any
    // warnings, and a run() that is only ever called after the person
    // confirms. None of these writes anything when it is called.

    // ── RECORD A SUPPLIER PREPAYMENT BY TALKING ──────────────────────────
    // the owner: "Add a supplier prepayment option in loads" / "sample yard co yard" /
    // "Build prepayment properly".
    //
    // THIS TOOL EXISTS IN THE SAME COMMIT AS THE FEATURE, which is the whole
    // point. CLAUDE.md records four separate occasions when a requirement
    // landed in shared payment code and THIS path was the caller that could
    // not satisfy it — because it has no form to hang a field on. So every
    // field helpers/payments.addPrepayment can demand has a box here:
    // mode, bank, paid_via and cash_source. Checked by opening addPrepayment
    // and listing what it reads, not by guessing.
    //
    // A prepayment has no load_id by design, so there is no id to validate
    // against — the seller's NAME is all there is. That makes a misheard name
    // the likeliest failure, and the propose card prints it back with the
    // amount and what the supplier would then be holding, so she is agreeing
    // to a sentence rather than a tool call.
    record_prepayment: {
        kind: 'write',
        description: 'Record money paid to a supplier BEFORE there is a load for it — '
            + 'held as credit against that supplier until it is put on a load.',
        params: {
            seller: { type: 'string', required: true, describe: 'the supplier who was paid' },
            amount: { type: 'number', required: true },
            mode: { type: 'string', required: true,
                describe: require('./payments').modesForKind('purchase').join(', ') },
            bank: { type: 'string', describe: 'which bank a Wire went out of, if she said' },
            cash_source: { type: 'string', describe: 'on a CASH prepayment, which cash: '
                + require('./pettyCash').SOURCES.filter((x) => x !== 'Unassigned').join(', ')
                + ', or leave unsaid for unbanked cash' },
            paid_via: { type: 'string', describe: 'Sample Yard Co Yard, Sample Yard Co Metals or Sample Yard Co Holdings — '
                + 'whose money moved. Needed for a Wire.' },
            paid_on: { type: 'date', describe: 'defaults to today' },
            reference: { type: 'string' },
            note: { type: 'string' },
        },
        propose: async (p) => {
            const pay = require('./payments');
            const seller = str(p.seller);
            if (!seller) throw new Error('Which supplier was paid?');
            const amount = Number(p.amount);
            if (!isFinite(amount) || amount <= 0) throw new Error('How much was paid?');

            const allowed = pay.modesForKind('purchase');
            const mode = allowed.find((m) => m.toLowerCase() === str(p.mode).toLowerCase());
            if (!mode) throw new Error(`A supplier is paid by ${allowed.join(', ')}.`);

            // ── REFUSED AT PROPOSE, NOT AT RUN ───────────────────────────
            // The 2026-09-17 lesson, applied up front this time: resolve the
            // bank and the paid-via question HERE, while she can still answer
            // it. A proposal that fails after she has said yes is exactly the
            // failure propose-then-confirm exists to prevent.
            const banks = require('./banks');
            const bank = await banks.resolveForMode(mode, p.bank);
            pay.resolvePaidVia('purchase', mode, p.paid_via, bank);

            const before = pay.prepaymentCredit(seller);
            const details = [
                ['Supplier', seller],
                ['Amount', money(amount)],
                ['Mode', mode],
            ];
            if (bank) details.push(['Bank', bank]);
            if (p.paid_via) details.push(['Payment via', str(p.paid_via)]);
            if (mode === 'Cash') {
                details.push(['Cash from', str(p.cash_source) || 'unbanked cash']);
            }
            details.push(['Already held for this supplier', money(before.available)]);
            details.push(['Held after this', money(before.available + amount)]);

            const warnings = [];
            // Said out loud: a prepayment is not against any load yet, and
            // she is confirming without a screen. If she meant to pay an
            // EXISTING load, this is the sentence that catches it.
            warnings.push('This is not against any load — it sits as credit for '
                + `${seller} until you put it on one.`);
            if (banks.expectsBank(mode) && !bank) {
                warnings.push(`No bank recorded for this ${mode} — it will show as "Not recorded" on the spend report.`);
            }

            return {
                summary: `Record a ${mode} prepayment of ${money(amount)} to ${seller}`,
                details,
                warnings,
                run: async () => {
                    const rec = await pay.addPrepayment({
                        seller, amount, mode,
                        bank: p.bank, paid_via: p.paid_via, cash_source: p.cash_source,
                        paid_on: p.paid_on, reference: p.reference, note: p.note,
                        created_by: 'jarvis',
                    });
                    const after = pay.prepaymentCredit(seller);
                    return {
                        ok: true,
                        prepayment_id: rec.id,
                        said: `Recorded. ${seller} is now holding ${money(after.available)} in prepayments.`,
                    };
                },
            };
        },
    },

    record_payment: {
        kind: 'write',
        description: 'Record a payment against a purchase load.',
        params: {
            load_id: { type: 'string', required: true },
            amount: { type: 'number', required: true },
            mode: { type: 'string', required: true, describe: 'Cash or Bank transfer' },
            // Optional, and optional ON PURPOSE — she may simply not say which
            // account a Zelle left, and refusing the whole payment over it
            // would make a working feature stop working. Unsaid becomes
            // "Not recorded" on the spend report, where she can see and close
            // the gap. See helpers/banks.js.
            bank: { type: 'string', describe: 'which bank a transfer went out of, if she said' },
            // ── WHICH CASH, ON A CASH PAYMENT ──────────────────────────────
            // the owner, 2026-09-21: cash in the box is now tracked per bank.
            // NOT the same field as `bank` above, and the difference is why
            // there are two: `bank` says which account a TRANSFER left;
            // this says which trip to the bank the NOTES came from. banks.js
            // still refuses `bank` on a cash payment and is still right to.
            //
            // Optional, deliberately. She will often just say "pay Sam
            // 2,000 cash" and never mention a bank — refusing that would
            // break the thing this tool exists for. Unsaid means the payment
            // comes out of unbanked cash, which is a real bucket and an
            // honest answer rather than a placeholder.
            // Built from the ONE list rather than spelled out here. It was
            // spelled out, and the day BofA became two accounts this line
            // would have kept telling the model there were two buckets while
            // the server knew about four — so "pay Gomez cash from AAA
            // Investment" would have been proposed as unbanked cash and
            // filed against the wrong company. helpers/pettyCash.cleanSource
            // accepts a slash, a dash or plain spaces, and resolves a bare
            // "Sample Yard Co Metals" when only one bucket can mean it.
            cash_source: { type: 'string', describe: 'on a CASH payment, which cash: '
                + require('./pettyCash').SOURCES.filter((s) => s !== 'Unassigned').join(', ')
                + ', or leave unsaid for unbanked cash' },
            // ── REQUIRED FOR SOME COMBINATIONS, AND THE TOOL HAD NO BOX ─────
            // Added 2026-09-17 after a live break. The paid-via work of
            // 2026-09-16 ("on selecting wire-it should ask me Payment via Sample
            // Yard/Sample Yard Co Metals") made addPayment THROW for a Wire on a
            // purchase and a Bank transfer on a sale when no company is given.
            // That rule was written for the pay modal and applied to the
            // shared helper — and this tool, which is how she records a
            // payment by talking to Jarvis, had no way to supply one. So
            // "record a wire payment of $12,000 against load X" threw.
            //
            // Caught only because tests/yard-assistant-knowledge.js pays by
            // bank transfer on a sale, which is what she actually does. My
            // regression, not a fixture that went stale.
            paid_via: { type: 'string', describe: 'Sample Yard Co Yard, Sample Yard Co Metals or Sample Yard Co Holdings — whose money moved. BofA holds Sample Yard Co Metals and Sample Yard Co Holdings; Chase is Sample Yard Co Yard, so a Chase wire needs no answer.' },
            paid_on: { type: 'date', describe: 'defaults to today' },
            note: { type: 'string' },
        },
        propose: async (p) => {
            const { getLoad } = require('./loads');
            const { modesForKind, paymentSummary } = require('./payments');
            const loadId = str(p.load_id);
            const load = await getLoad(loadId);
            // The single most valuable check here. A hallucinated load id is
            // the likeliest way this goes wrong, and it dies at this line.
            if (!load) throw new Error(`there is no load ${loadId} in the records`);

            const amount = Math.round(num(p.amount) * 100) / 100;
            if (!Number.isFinite(amount) || amount <= 0) throw new Error('a payment needs an amount greater than zero');
            // The YARD's list, not every mode payments.js knows. This tool
            // records against yard loads, and since 2026-09-16 those take Cash
            // or Bank transfer only — per the owner, "in receive payment-i should
            // have only cash and bank transfer". Asked through modesForKind so
            // the tool and addPayment's validator cannot disagree: proposing a
            // Zelle here and having addPayment refuse it at run time would
            // show up as a confirmed action that then failed.
            // The kind of the LOAD, not a hardcoded 'purchase'. This tool
            // records against whatever row she names, and since the two kinds
            // now take different lists (receive payment is Cash or Bank
            // transfer; paying a supplier keeps Zelle and Wire), asking for
            // the wrong one would refuse a payment the server would accept.
            const loadKind = load._kind || load.load_kind || 'purchase';
            const allowed = modesForKind(loadKind);
            const mode = allowed.find((m) => m.toLowerCase() === str(p.mode).toLowerCase());
            if (!mode) throw new Error(`payment mode must be one of: ${allowed.join(', ')}`);

            // ── ASK HERE, NOT AT RUN TIME ───────────────────────────────────
            // Same reasoning as the mode check above, and the same reason it
            // is checked through payments.js rather than re-stated here: a
            // proposal this tool confirms and then fails on is worse than one
            // it refuses up front, because she has already said yes to it.
            // resolvePaidVia throws with the question in it ("a Wire on a yard
            // purchase needs \"Payment via\": Sample Yard Co Yard or Sample Yard Co Metals"), which
            // is exactly what the assistant should put to her.
            const { paidViaRequired, resolvePaidVia } = require('./payments');
            // The bank goes in too since 2026-09-24, so the voice path is
            // held to the same rule as the form: a wire out of BofA cannot be
            // filed against Sample Yard Co Yard. Passing it also means Chase resolves
            // itself, so "record a wire of $12,000 from Chase" no longer has
            // to be told whose money it was.
            // p.bank, not `bank` — the resolved one is computed sixty lines
            // further down and referencing it here is a temporal-dead-zone
            // crash on every voice payment. Found by tests/tools.js, which is
            // the third time this caller has caught a change made for the
            // form: it has no form, so it breaks differently and later.
            //
            // The raw value is enough: paidViaOptionsFor only needs the bank's
            // NAME to know which companies bank there.
            const paidVia = resolvePaidVia(loadKind, mode, p.paid_via, p.bank);

            // ── WHICH CASH, AND WHETHER IT WILL HAVE TO BORROW ───────────
            // Worked out HERE, at propose time, so the confirm card states it
            // before she says yes rather than the write failing after. The
            // pay modal refuses and re-asks; this tool has no second round,
            // so the question has to be answered on the card in front of her.
            const petty = require('./pettyCash');
            let cashSource = null;
            let borrowNote = null;
            if (mode.toLowerCase() === 'cash' && loadKind !== 'sale') {
                cashSource = petty.cleanSource(p.cash_source, { allowBlank: true });
                const buckets = petty.balanceBySource(petty.listEntries());
                const held = Number(buckets[cashSource] || 0);
                if (amount - held > 0.005) {
                    const lenders = petty.SOURCES
                        .filter((x) => x !== cashSource)
                        .map((x) => ({ source: x, available: Number(buckets[x] || 0) }))
                        .filter((l) => l.available > 0.005)
                        .sort((a, b) => b.available - a.available);
                    if (lenders.length) {
                        borrowNote = `${cashSource} holds ${money(held)} — confirming this borrows `
                            + `${money(Math.round((amount - held) * 100) / 100)} from `
                            + lenders.map((l) => l.source).join(' and ') + '.';
                        // ── AND WHETHER THAT CROSSES A COMPANY LINE ──────
                        // the owner, 2026-09-21, chose to ALLOW borrowing between
                        // Sample Yard Co Metals and Sample Yard Co Holdings and have it recorded
                        // as owed. This card is the last thing she reads
                        // before the money moves, and on this path there is no
                        // second round to ask in — so if confirming creates a
                        // balance between two companies, the card says so now.
                        const mine = petty.companyOf(cashSource);
                        const across = lenders
                            .map((l) => petty.companyOf(l.source))
                            .filter((co) => co !== petty.COMPANY_UNKNOWN && co !== mine);
                        if (mine !== petty.COMPANY_UNKNOWN && across.length) {
                            borrowNote += ` That is a loan between two companies — ${mine} would owe `
                                + Array.from(new Set(across)).join(' and ') + '.';
                        }
                    }
                }
            }

            // Recomputed from the ledger, NOT from anything the model said.
            // Against the PAYABLE: if $200 of haulage was deducted, "$2,259
            // still outstanding" is the true figure and "$2,459" would have
            // her overpay by exactly the deduction she just made.
            const before = paymentSummary(loadId, require('./loads').payableOf(load));
            const after = Math.round((before.pending - amount) * 100) / 100;
            const paidOn = isYmd(p.paid_on) ? p.paid_on : require('./time').todayLocal();

            // Validated at PROPOSE time, not only at run time. The confirm card
            // is the last thing she reads before this writes, so a bank that
            // will be refused has to fail here — refusing after she has
            // confirmed teaches her that confirming does not mean anything.
            const banks = require('./banks');
            const bank = await banks.resolveForMode(mode, p.bank);

            const warnings = [];
            // Said out loud rather than left blank. She is confirming a payment
            // she cannot see a form for, so the one field that will be missing
            // from the report has to be on the card in front of her.
            // expectsBank, NOT needsBank. Zelle and Cheque may carry a bank
            // from 2026-10-01 ("keep it as optional"), and warning here would
            // nag on every Zelle she records by talking — a path with no
            // dropdown to satisfy the warning. See helpers/banks.js.
            if (banks.expectsBank(mode) && !bank) {
                warnings.push(`No bank recorded for this ${mode} — it will show as "Not recorded" on the spend report.`);
            }
            // Said on the card, because confirming it is what authorises the
            // borrow — there is no second prompt on this path.
            if (borrowNote) warnings.push(borrowNote);
            if (after < 0) warnings.push(`This is ${money(-after)} MORE than the ${money(before.pending)} still outstanding on this load.`);
            if (before.pending === 0) warnings.push('This load is already fully paid.');

            return {
                summary: `Record a ${mode} payment of ${money(amount)} against ${loadId} (${load.seller || 'no seller'}), dated ${paidOn}.`,
                details: [
                    // The metal's figure and the payable are the SAME on every
                    // load without a deduction, so the card reads exactly as it
                    // always has until there is one — and when there is, it
                    // shows both and says why they differ. A card that printed
                    // only the payable would leave her unable to check it
                    // against the ticket in her hand; only the amount would
                    // have her paying the haulage twice.
                    ['Load', `${loadId} — ${load.seller || 'no seller'}, ${money(load.amount || 0)}`],
                    ...(load.trucking_amount
                        ? [['Less trucking', `${money(load.trucking_amount)}${load.trucking_company ? ' — ' + load.trucking_company : ''}`],
                           ['Payable to seller', money(require('./loads').payableOf(load) || 0)]]
                        : []),
                    ['Already paid', money(before.paid)],
                    ['This payment', `${money(amount)} by ${mode}${bank ? ' from ' + bank : ''}`],
                    ...(cashSource ? [['Which cash', cashSource]] : []),
                    // Shown only when it applies — a "Payment via: " line on a
                    // cash payment is noise on a card she reads at a gate.
                    ...(paidVia ? [[require('./payments').paidViaLabel(loadKind), paidVia]] : []),
                    ['Left pending after', money(Math.max(after, 0))],
                ],
                warnings,
                run: async (ctx) => require('./payments').addPayment({
                    load_id: loadId, load_kind: loadKind, amount, mode, bank, paid_via: paidVia,
                    paid_on: paidOn, note: p.note,
                    cash_source: cashSource,
                    // She confirmed a card that SAID it would borrow — see
                    // borrowNote above. Sending this without that sentence on
                    // the card would be moving money between her bank
                    // accounts on an answer she was never asked for.
                    allow_borrow: !!borrowNote,
                    created_by: ctx.role || 'yard-assistant',
                }),
            };
        },
    },

    add_trucker_bill: {
        kind: 'write',
        description: 'Record a haulage bill owed to a trucking company.',
        params: {
            company: { type: 'string', required: true },
            amount: { type: 'number', required: true },
            date: { type: 'date', describe: 'defaults to today' },
            load_ticket: { type: 'string', describe: 'optional; the load it relates to' },
        },
        propose: async (p) => {
            const company = str(p.company);
            if (!company) throw new Error('a trucker bill needs a company');
            const amount = Math.round(num(p.amount) * 100) / 100;
            if (!Number.isFinite(amount) || amount <= 0) throw new Error('a bill needs an amount greater than zero');
            const date = isYmd(p.date) ? p.date : require('./time').todayLocal();
            const ticket = str(p.load_ticket) || null;
            return {
                summary: `Record a haulage bill of ${money(amount)} from ${company}, dated ${date}${ticket ? ` against ${ticket}` : ''}.`,
                details: [['Company', company], ['Amount', money(amount)], ['Date', date], ['Load ticket', ticket || '—']],
                warnings: [],
                run: async (ctx) => require('./truckerBills').addBill({
                    company, amount, date, load_ticket: ticket, created_by: ctx.role || 'yard-assistant',
                }),
            };
        },
    },

    // ── ITEM NAME CLEAN-UP (2026-11-18) ──────────────────────────────────────
    // the owner: "Rotor and Rotors, all this cleaning should be handled by Scout automatically" and, asked how far,
    // "Scout finds, you confirm". So: a READ tool that finds likely twins (case, spacing, hyphens, a plural s) and a
    // WRITE tool that is only ever a confirm card. The merge itself is Item maintenance's apply(), journalled with
    // Undo; nothing here rewrites a record by itself. Sample Yard Co Yard only (those files are all it reads).
    find_item_variants: {
        kind: 'read',
        description: 'Sample Yard Co Yard item names that look like the same item spelled differently (Rotor / Rotors, Al-combo / Al combo): same words apart from case, spacing, hyphens or a plural s. Use when asked to clean up, tidy or merge item names, or when two item names look like one. It only LISTS; to merge, propose merge_item_names for the group the person agrees with. A group marked conflict has one name filed as ferrous and another as non-ferrous, so they may not be the same item: say so, never suggest merging it.',
        params: {},
        run: async () => {
            const groups = require('./itemMaintenance').variants();
            return { total: groups.length, groups: groups.slice(0, 20), showing: Math.min(20, groups.length) };
        },
    },

    merge_item_names: {
        kind: 'write',
        description: 'Merge item spellings that are the same item into ONE name, across Sample Yard Co Yard loads bought, loads sold and open drafts (names only: no weight, price or status changes; Undo is in Settings, Item maintenance). Only for names find_item_variants listed or the person named. Always a confirm card.',
        params: {
            from: { type: 'array', required: true, describe: 'the spellings to merge, exactly as listed, e.g. ["Rotor","Rotors"]' },
            to: { type: 'string', required: true, describe: 'the one name they should all become, normally the spelling used most' },
        },
        propose: async (p, ctx = {}) => {
            const IM = require('./itemMaintenance');
            if (ctx.role && ctx.role !== 'admin') throw new Error('Merging item names rewrites saved loads, so only the manager can confirm it. Ask the manager, or use Settings, Item maintenance.');
            const names = (Array.isArray(p.from) ? p.from : [p.from]).map(str).filter(Boolean);
            const to = str(p.to);
            if (!names.length || !to) throw new Error('which item names should be merged, and into what?');
            // Untrusted input: every name must be an item that exists today, matched exactly as the screen lists it.
            const have = IM.summary({});
            const known = new Map(have.flatMap((it) => it.spellings.map((sp) => [IM.keyOf(sp), sp])));
            const missing = names.filter((n) => !known.has(IM.keyOf(n)));
            if (missing.length) throw new Error(`I cannot find an item called ${missing.map((n) => `"${n}"`).join(', ')} on the yard's loads. Use find_item_variants to see the exact names.`);
            const from = [...new Set(names.map((n) => known.get(IM.keyOf(n))))];
            const pv = IM.preview(from, to);
            if (!pv.total_lines) throw new Error('Those names are already exactly that, so there is nothing to merge.');
            const metal = require('./itemMetal');
            const types = new Set(from.concat(to).map((n) => metal.typeOf(n)).filter(Boolean));
            const warnings = [];
            if (types.size > 1) warnings.push('These names are filed under different metal types (ferrous and non-ferrous). Check they really are the same item before confirming.');
            const where = Object.values(pv.stores).filter((x) => x.lines).map((x) => `${x.lines} line${x.lines === 1 ? '' : 's'} in ${x.loads} ${x.label}`).join(', ');
            return {
                summary: `Rename ${from.map((n) => `"${n}"`).join(' and ')} to "${to}" on ${pv.total_lines} saved line${pv.total_lines === 1 ? '' : 's'}.`,
                details: [['From', from.join(', ')], ['To', to], ['Changes', where || 'none'], ['Not changed', 'weights, prices, status, issued PDFs'], ['Undo', 'Settings, Item maintenance, Recent renames']],
                warnings,
                run: async (c = {}) => {
                    // The route is admin-only and this rewrites saved loads, so the role is re-checked at the moment of the write.
                    if (c.role !== 'admin') throw new Error('Only the manager can merge item names.');
                    const r = await IM.apply(from, to, { by: 'scout' });
                    try { await metal.carryOnRename(from, to); } catch (e) { /* the type is a convenience */ }
                    try { require('./sheetSync').scheduleSync(r.months || []); } catch (e) { /* Drive is best-effort */ }
                    return r;
                },
            };
        },
    },

    add_expense: {
        kind: 'write',
        description: 'Record a yard expense. Choosing Cash also draws it out of the petty cash box.',
        params: {
            description: { type: 'string', required: true },
            amount: { type: 'number', required: true },
            payment_method: { type: 'string', describe: 'Cash or Card; defaults to Cash' },
            category: { type: 'string', describe: 'e.g. Fuel, Repairs & maintenance, Labour' },
            date: { type: 'date', describe: 'defaults to today' },
            vendor: { type: 'string' },
        },
        propose: async (p) => {
            const expenses = require('./expenses');
            const description = str(p.description);
            if (!description) throw new Error('an expense needs a description');
            const amount = Math.round(num(p.amount) * 100) / 100;
            if (!Number.isFinite(amount) || amount <= 0) throw new Error('an expense needs an amount greater than zero');
            const method = expenses.normalizeMethod(p.payment_method) || expenses.DEFAULT_EXPENSE_METHOD;
            const date = isYmd(p.date) ? p.date : require('./time').todayLocal();

            const warnings = [];
            if (method === 'Cash') {
                // Said before it happens, not discovered after. An expense is
                // never refused for being larger than the box — see
                // helpers/expenses.js — so the only protection is telling her.
                const balance = require('./pettyCash').balance();
                if (amount > balance) {
                    warnings.push(`The cash box holds ${money(balance)}, so this will take it ${money(amount - balance)} below zero.`);
                }
            }
            return {
                summary: `Record a ${method} expense of ${money(amount)} for "${description}", dated ${date}.`,
                details: [['Description', description], ['Amount', money(amount)], ['Paid by', method],
                          ['Category', str(p.category) || 'Other'], ['Date', date]],
                warnings,
                run: async (ctx) => expenses.addExpense({
                    description, amount, payment_method: method, category: p.category,
                    vendor: p.vendor, date, created_by: ctx.role || 'yard-assistant',
                }),
            };
        },
    },
};

// ── generated, never hand-written ─────────────────────────────────────────
// The text the model reads. Built from the registry above, so the prompt
// cannot advertise a tool that does not exist or miss one that does — which
// is the exact failure the old hand-synced prose kept producing.
function describeTools() {
    const line = (name, t) => {
        const ps = Object.entries(t.params || {}).map(([k, s]) => {
            const bits = [k];
            if (s.required) bits.push('(required)');
            if (s.describe) bits.push(`— ${s.describe}`);
            return bits.join(' ');
        });
        return `  • ${name} — ${t.description}`
            + (ps.length ? `\n      params: ${ps.join('; ')}` : '\n      params: none');
    };
    const reads = Object.entries(TOOLS).filter(([, t]) => t.kind === 'read');
    const writes = Object.entries(TOOLS).filter(([, t]) => t.kind === 'write');
    return [
        'TOOLS YOU CAN CALL TO LOOK THINGS UP (these run immediately and change nothing —',
        'call them freely, and prefer calling one over saying you do not have the data):',
        ...reads.map(([n, t]) => line(n, t)),
        '',
        'TOOLS THAT CHANGE SOMETHING (these are PROPOSED — the person confirms before',
        'anything is written. Never say you have done it; say what WILL happen):',
        ...writes.map(([n, t]) => line(n, t)),
        '',
        'You cannot delete anything, and you cannot send emails or messages. Say so',
        'plainly if asked, and point them at the app.',
    ].join('\n');
}

// ── RECORD AN OUTBOUND SALE (2026-11-14) ───────────────────────────────────
// the owner typed into the yard assistant: "We have sold all rotors and drums
// before 11/13. Make changes in my inventory accordingly. We sold this to
// metalworks" — and was told it cannot record outbound sales. Asked what she
// wanted, she chose: teach the assistant, and ASK her the price and the sale
// date every time rather than guess.
//
// WHAT IT DOES: sells ALL that is still on hand of the named items, from the
// purchase lots received before a cutoff date, as one outbound load. Stock is
// netted by DRAWS (helpers/stock.js), so the sale is written with draws against
// the exact lots — that is what makes on-hand fall, and it is the same shape
// the outbound screen writes, saved through the same addOutboundLoad.
//
// WHAT IT DOES NOT DO: partial quantities (the screen does that), prices in
// anything but $/lb, or any change to Sample Yard Co Metals (bills, sales, proformas).
// Draws are written per item line, so what a lot has already given up is
// known per item; a shared lot's weight is never counted twice.
TOOLS.record_outbound_sale = {
    kind: 'write',
    description: 'Record an outbound sale of ALL the stock on hand of named items (optionally only lots received before a date). Not for part-quantities.',
    params: {
        buyer: { type: 'string', required: true, describe: 'who the yard sold to' },
        date: { type: 'date', required: true, describe: 'the sale date as YYYY-MM-DD — ASK, do not assume today' },
        price: { type: 'number', required: true, describe: 'the price in dollars, in the unit given by price_per — ASK, do not guess' },
        price_per: { type: 'string', describe: 'the unit the price is quoted in: lb (default), metric_ton (MT, tonne, 2204.62 lb), gross_ton (2240 lb) or net_ton (2000 lb). Pass the price AS SHE SAID IT and the unit — never convert it yourself; the system does the arithmetic.' },
        descriptions: { type: 'array', required: true, describe: 'item names to sell, e.g. ["Rotors","Drums"]' },
        received_before: { type: 'date', describe: 'only lots received BEFORE this date (YYYY-MM-DD); omit for every lot' },
        note: { type: 'string' },
    },
    propose: async (p, ctx = {}) => {
        const { loadLoads } = require('./loads');
        const { loadOutboundLoads } = require('./outboundLoads');
        const stock = require('./stock');
        const { keyOf } = require('./itemMaintenance');
        const buyer = str(p.buyer);
        if (!buyer) throw new Error('who did the yard sell to?');
        const quoted = num(p.price);
        if (quoted == null || quoted <= 0) throw new Error('what price? A sale needs one');
        // The sale is stored per lb. A price quoted per ton is divided HERE, in code, from what she said
        // (the owner 2026-11-15: "per mt weight is 350" - the model was asked to convert and kept asking).
        const UNITS = { lb: 1, lbs: 1, pound: 1, metric_ton: 2204.62, mt: 2204.62, tonne: 2204.62, gross_ton: 2240, long_ton: 2240, net_ton: 2000, short_ton: 2000 };
        const unitKey = str(p.price_per || 'lb').toLowerCase().replace(/[\s/-]+/g, '_').replace(/^per_/, '');
        if (!(unitKey in UNITS)) throw new Error(`I don't know the price unit "${p.price_per}" - is it per lb, per metric ton (MT), per gross ton or per net ton?`);
        // A per-lb price above $5 is a per-ton price typed without its unit; do not sell scrap at $350 a pound.
        if (UNITS[unitKey] === 1 && quoted > 5) throw new Error(`$${quoted} per lb is far too high for scrap - is that per metric ton (MT), per gross ton or per net ton?`);
        const price = quoted / UNITS[unitKey];
        const quotedText = UNITS[unitKey] === 1 ? null : `${money(quoted)} per ${unitKey === 'metric_ton' || unitKey === 'mt' || unitKey === 'tonne' ? 'metric ton (2,204.62 lb)' : (unitKey === 'gross_ton' || unitKey === 'long_ton') ? 'gross ton (2,240 lb)' : 'net ton (2,000 lb)'}`;
        if (!isYmd(p.date)) throw new Error('what date was the sale?');
        const cutoff = isYmd(p.received_before) ? p.received_before : null;
        const names = (Array.isArray(p.descriptions) ? p.descriptions : [p.descriptions]).map(str).filter(Boolean).slice(0, 12);
        if (!names.length) throw new Error('which items were sold?');

        const inbound = loadLoads();
        const outbound = loadOutboundLoads();
        const lots = stock.lotReport(inbound, outbound).filter((l) => l.remaining > 0.001 && (!cutoff || (l.date && l.date < cutoff)));
        const byId = new Map(inbound.map((l) => [l.id, l]));

        // One draw per lot (all items together), one item line per name.
        // ITEM-LEVEL, not pro rata: a draw is (load, weight), but a draw is
        // always written on an outbound ITEM LINE, so what each lot has already
        // given up PER ITEM is known from those lines. Sharing a lot's remaining
        // weight pro rata instead attributes an earlier all-rotors sale to the
        // drums too, and the item totals then disagree with stockReport (rotors
        // went 167 lb negative in the first version of this test).
        const drawnFrom = new Map();   // `${lot}|${item}` -> weight already drawn
        for (const o of outbound) {
            for (const it of (o.items || [])) {
                for (const d of (it.draws || [])) {
                    const key = `${d.load_id}|${keyOf(it.description)}`;
                    drawnFrom.set(key, (drawnFrom.get(key) || 0) + (Number(d.weight) || 0));
                }
            }
        }
        const onHandAll = new Map(stock.stockReport(inbound, outbound).map((r) => [keyOf(r.description), r.purchased - r.shipped]));
        const room = new Map(lots.map((l) => [l.id, l.remaining]));
        const lines = [];
        const drawByLot = new Map();
        for (const name of names) {
            const k = keyOf(name);
            let cap = Math.max(0, onHandAll.has(k) ? onHandAll.get(k) : 0);
            let weight = 0; const itemDraws = [];
            for (const lot of lots) {
                if (cap <= 0.001) break;
                const load = byId.get(lot.id);
                const mine = (load && load.items || []).filter((i) => keyOf(i.description) === k).reduce((a, i) => a + (Number(i.net_weight) || 0), 0);
                const avail = Math.max(0, mine - (drawnFrom.get(`${lot.id}|${k}`) || 0));
                const take = Math.round(Math.min(avail, room.get(lot.id) || 0, cap) * 100) / 100;
                if (take <= 0) continue;
                weight += take; cap -= take;
                room.set(lot.id, (room.get(lot.id) || 0) - take);
                itemDraws.push({ load_id: lot.id, weight: take });
                drawByLot.set(lot.id, (drawByLot.get(lot.id) || 0) + take);
            }
            if (weight > 0.001) lines.push({ description: (inbound.flatMap((l) => l.items || []).find((i) => keyOf(i.description) === k) || {}).description || name, weight: Math.round(weight * 100) / 100, draws: itemDraws });
        }
        if (!lines.length) {
            throw new Error(`there is no ${names.join(' or ')} on hand${cutoff ? ` from lots received before ${cutoff}` : ''} to sell`);
        }
        const missing = names.filter((n) => !lines.some((l) => keyOf(l.description) === keyOf(n)));
        const totalWeight = lines.reduce((a, l) => a + l.weight, 0);
        const amount = Math.round(totalWeight * price * 100) / 100;
        const details = [
            ['Buyer', buyer],
            ['Sale date', p.date],
            ...(cutoff ? [['From lots received', `before ${cutoff}`]] : []),
            ...lines.map((l) => [l.description, `${Math.round(l.weight).toLocaleString()} lb from ${l.draws.length} lot${l.draws.length === 1 ? '' : 's'}`]),
            ...(quotedText ? [['Quoted price', quotedText]] : []),
            ['Price', `${perLb(price)} per lb${quotedText ? ' (worked out from the quote)' : ''}`],
            ['Sale total', money(amount)],
        ];
        const warnings = [quotedText ? 'Stored per lb, divided from the quoted price. On-hand drops by exactly these weights.' : 'Priced per lb. On-hand drops by exactly these weights.'];
        if (missing.length) warnings.push(`Nothing on hand for: ${missing.join(', ')} — left out.`);
        if (!outbound.some((o) => keyOf(o.buyer) === keyOf(buyer))) warnings.push(`${buyer} has no earlier sale in the yard records — check the spelling.`);
        return {
            summary: `Record a sale to ${buyer} on ${p.date}: ${lines.map((l) => `${l.description} ${Math.round(l.weight).toLocaleString()} lb`).join(', ')} at ${perLb(price)}/lb (${money(amount)}).`,
            details, warnings,
            run: async (c = {}) => {
                const { addOutboundLoad } = require('./outboundLoads');
                const fresh = stock.validateDraws(loadLoads(), loadOutboundLoads(), [...drawByLot].map(([load_id, weight]) => ({ load_id, weight })));
                if (!fresh.ok) throw new Error(`stock changed since this was shown — ${fresh.errors.join(' ')} Ask me again.`);
                return addOutboundLoad({
                    date: p.date, buyer, description: str(p.note),
                    items: lines.map((l) => ({ description: l.description, gross_weight: l.weight, tare_weight: 0, price, unit: '', draws: l.draws })),
                    weight_unit: 'lb',
                    created_by: c.role || ctx.role || 'yard-assistant',
                });
            },
        };
    },
};

const TOOL_NAMES = Object.keys(TOOLS);
const readToolNames = () => TOOL_NAMES.filter((n) => TOOLS[n].kind === 'read');
const writeToolNames = () => TOOL_NAMES.filter((n) => TOOLS[n].kind === 'write');

// Checks a call against the declared schema BEFORE the handler sees it, so
// every tool gets the same treatment and no handler has to re-implement
// "which of my parameters are required".
function validate(name, params) {
    const t = TOOLS[name];
    if (!t) throw new Error(`there is no tool called "${name}"`);
    const p = (params && typeof params === 'object') ? params : {};
    for (const [key, spec] of Object.entries(t.params || {})) {
        const v = p[key];
        const missing = v == null || v === '';
        if (spec.required && missing) throw new Error(`${name} needs ${key}`);
        if (missing) continue;
        if (spec.type === 'number' && num(v) == null) throw new Error(`${name}: ${key} must be a number`);
        if (spec.type === 'date' && !isYmd(v)) throw new Error(`${name}: ${key} must be a date as YYYY-MM-DD`);
    }
    return p;
}

// Runs a READ tool. No confirmation, by design — see the header.
async function runRead(name, params, ctx = {}) {
    const t = TOOLS[name];
    if (!t) throw new Error(`there is no tool called "${name}"`);
    if (t.kind !== 'read') throw new Error(`${name} changes things, so it has to be proposed rather than run`);
    return t.run(validate(name, params), ctx);
}

// Builds a WRITE tool's proposal. Writes nothing.
async function buildWrite(name, params, ctx = {}) {
    const t = TOOLS[name];
    if (!t) throw new Error(`there is no tool called "${name}"`);
    if (t.kind !== 'write') throw new Error(`${name} only reads — it does not need confirming`);
    return t.propose(validate(name, params), ctx);
}

module.exports = {
    TOOLS, TOOL_NAMES, readToolNames, writeToolNames,
    describeTools, validate, runRead, buildWrite, MAX_ROWS,
};
