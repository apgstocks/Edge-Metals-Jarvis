// ── helpers/invoiceVerify.js — Verification tab / carrier sub-tab ────────────
// Added per the owner: "build verification .in that create sub tab as carrier".
// Ports the carrier-freight-invoice cross-check tool that already existed as
// a separate PDF-upload page (verify.html + a Node api-server, found in the
// sample-metals-Inc project docs — a DIFFERENT repo than this one) into Jarvis
// itself, self-contained: its own Gemini extraction call
// (helpers/gemini.js's extractFreightInvoiceRecords) and its own read of the
// SAME Invoice Google Sheet helpers/invoiceSheet.js already reads, rather
// than depending on that other server being deployed/reachable.
//
// What it checks: carrier (or any carrier) bills freight per HBL on a PDF
// invoice. This sheet already has a "Freight" dollar amount recorded per
// HBL (helpers/invoiceSheet.js's buildColumnMap → freight_amt, col 21 on the
// real sheet). This cross-checks the two, both directions:
//   - a PDF line item whose HBL isn't on the sheet at all, or whose amount
//     doesn't match what's recorded → something to chase down
//   - a sheet row WITH a freight amount whose HBL never showed up in any
//     uploaded PDF this run → billed on our side but no carrier invoice to
//     back it up (or it just hasn't been uploaded yet)
//
// Commission (helpers/invoiceSheet.js's commission_rate/commission_amt) is
// surfaced alongside each match for her own visibility, but is NOT
// currently part of the pass/fail verdict — per the owner, commission's exact
// role here wasn't nailed down yet ("not ready to define" was one of the
// options offered; she picked "it's a column I haven't mapped" and this
// maps it), and carrier bills FREIGHT, not commission (commission is Sample
// Metals' own internal figure, never something a carrier invoice would
// state) — so a mismatch there would never reflect anything carrier actually
// billed. Structured as its own field specifically so a real commission
// check can be added later without reworking this.

const invoiceSheet = require('./invoiceSheet');

function safeStr(v) { return v == null ? '' : String(v).trim(); }
function normHbl(v) { return safeStr(v).toUpperCase().replace(/\s+/g, ''); }
function safeMoney(v) {
    const n = parseFloat(String(v == null ? '' : v).replace(/,/g, '').replace(/\$/g, ''));
    return Number.isFinite(n) ? n : null;
}

// M/D/YYYY (confirmed live format, e.g. "12/1/2025") — same loose parse as
// every other date field in this codebase, no external date library.
// BUG FIXED 2026-09-01 (the owner: "right now its not filtering based on month").
//
// This used to accept ONE shape — M/D/YYYY — and return null for anything
// else. Callers do `if (!parsed) continue;`, so a date this failed to read
// meant the row was DROPPED from the period-scoped index entirely, silently.
// Every row in an ISO-dated sheet therefore vanished and the period list came
// back empty, which looks identical to "the filter does nothing".
//
// The rest of this codebase already knew the Inv Date column holds more than
// one shape — helpers/proformaPdf.js's formatDate has handled YYYY-MM-DD and
// MM/DD/YYYY since it was written. This is now at least as tolerant, plus
// 2-digit years and a trailing time component (what Sheets emits when a cell
// is a real datetime rather than text).
//
// Deliberately still returns null for anything genuinely unreadable rather
// than guessing a month. A wrong month here silently moves money between
// periods on a reconciliation screen; a null is visible as an unclassified
// row. Ambiguity is NOT resolved by guessing: D/M/YYYY and M/D/YYYY cannot be
// told apart for days 1-12, and this reads the sheet as US-format because
// that is what every other date path in this codebase writes and reads.
function parseSheetDate(s) {
    const raw = String(s || '').trim();
    if (!raw) return null;
    // Drop a trailing time ("9/1/2026 0:00:00", "2026-09-01T00:00:00Z").
    const t = raw.split(/[T ]/)[0];

    let m = t.match(/^(\d{4})-(\d{1,2})-(\d{1,2})$/);           // YYYY-MM-DD
    if (m) return { month: Number(m[2]), year: Number(m[1]) };

    m = t.match(/^(\d{1,2})[\/.-](\d{1,2})[\/.-](\d{2,4})$/);   // M/D/YYYY or M/D/YY
    if (m) {
        const month = Number(m[1]);
        let year = Number(m[3]);
        if (m[3].length === 2) year += 2000;
        if (month < 1 || month > 12) return null;
        return { month, year };
    }
    return null;
}

// One entry per distinct HBL on the sheet — freight/commission are
// container-level (recorded once, usually on that container's first sheet
// row, blank on the rest) same convention buildContainerInvoiceData already
// relies on ("Only take freight/efs from first non-zero row"), so the first
// row seen per HBL that actually carries a freight amount wins.
//
// period ({year, month}, both optional) scopes which rows count toward the
// index by Invoice Date — mirrors the year/month filter the original
// verify.html tool had. Only affects the REVERSE "sheet_only" (missing
// invoice) list in crossCheckcarrierRecords below, so that list reflects just
// the period she's actually checking instead of every HBL on record; a
// forward match/mismatch always looks the HBL up regardless of period,
// since an uploaded PDF is itself already scoped to whatever she uploaded.
async function buildSheetFreightIndex(period) {
    // forceRefresh: true — see helpers/invoiceSheet.js's fetchRawSheet()
    // comment; a cross-check must never compare against a stale cached copy.
    const { headers, rows } = await invoiceSheet.fetchRawSheet(true);
    const colMap = invoiceSheet.buildColumnMap(headers);
    const byHbl = new Map();
    for (const row of rows) {
        const d = invoiceSheet.rowToDict(row, colMap);
        const hbl = normHbl(d.hbl_no);
        if (!hbl) continue;
        if (period && (period.year || period.month)) {
            const parsed = parseSheetDate(d.inv_date);
            if (!parsed) continue;
            if (period.year && parsed.year !== Number(period.year)) continue;
            if (period.month && parsed.month !== Number(period.month)) continue;
        }
        const freightAmt = safeMoney(d.freight_amt);
        const existing = byHbl.get(hbl);
        if (existing && existing.freight_amt != null) continue; // already have a real value for this HBL
        if (freightAmt == null && existing) continue; // don't overwrite a partial entry with an even emptier one
        byHbl.set(hbl, {
            hbl_no: safeStr(d.hbl_no),
            container_no: safeStr(d.container_no),
            booking_no: safeStr(d.booking_no),
            consignee: safeStr(d.consignee),
            inv_no: safeStr(d.inv_no),
            inv_date: safeStr(d.inv_date),
            freight_amt: freightAmt,
            commission_rate: safeMoney(d.commission_rate),
            commission_amt: safeMoney(d.commission_amt),
        });
    }
    return byHbl;
}

// pdfRecords: [{ hbl_no, container_no, booking_no, description, amount, source_file }]
// Returns { matched: [...], sheet_only: [...] } — see status meanings below.
// $1 tolerance absorbs rounding, not a real discrepancy worth flagging.
const AMOUNT_TOLERANCE = 1.0;

// period ({year, month}) — the owner, 2026-09-01: "right now its not filtering
// based on month".
//
// She was right, and the old comment here described the bug as if it were a
// feature: the period scoped ONLY the reverse "sheet_only" list. The main
// results table — the one she actually reads — matched every uploaded PDF
// line against the WHOLE sheet and ignored the dropdowns completely. Picking
// September changed nothing visible.
//
// WHAT IT DOES NOW, and why it is not a plain filter:
//
// Every uploaded PDF line stays in the table. Always. Hiding a row on a
// screen whose job is "did carrier bill us correctly" is the one genuinely
// dangerous option — an invoice line that quietly disappears because its
// sheet date sits a day either side of a month boundary is a charge nobody
// checks. So instead each row is CLASSIFIED against the period:
//
//   in_period: true   — the sheet row this PDF line matched is in the
//                       selected month/year.
//   in_period: false  — it matched, but the sheet says a different period.
//                       Shown, and marked, so a September upload that
//                       contains an August HBL is obvious rather than
//                       silently counted as a clean September match.
//   in_period: null   — cannot be judged: no sheet row (not_in_sheet /
//                       no_hbl_on_pdf), or a sheet date this cannot read.
//                       Never guessed at; these are exactly the rows that
//                       most need her eyes.
//
// The summary counts are scoped to the period, with out-of-period broken out
// as its own number, so the headline figures answer "how did September go"
// while the table still shows everything that was billed.
// null when the period cannot be judged — no sheet row, or a date this
// cannot read. Never guesses.
function inSelectedPeriod(sheetRow, period) {
    if (!period || (!period.year && !period.month)) return null; // no period chosen
    if (!sheetRow) return null;
    const parsed = parseSheetDate(sheetRow.inv_date);
    if (!parsed) return null;
    if (period.year && parsed.year !== Number(period.year)) return false;
    if (period.month && parsed.month !== Number(period.month)) return false;
    return true;
}

async function crossCheckcarrierRecords(pdfRecords, period) {
    const hasPeriod = !!(period && (period.year || period.month));
    const sheetIndex = await buildSheetFreightIndex();

    const tag = (row) => ({ ...row, in_period: inSelectedPeriod(row.sheet, period) });

    const matched = (pdfRecords || []).map((rec) => {
        const hbl = normHbl(rec.hbl_no);
        const pdfAmount = safeMoney(rec.amount);
        if (!hbl) {
            return tag({ ...rec, status: 'no_hbl_on_pdf', sheet: null, delta: null });
        }
        const sheetRow = sheetIndex.get(hbl);
        if (!sheetRow) {
            return tag({ ...rec, status: 'not_in_sheet', sheet: null, delta: null });
        }
        if (sheetRow.freight_amt == null) {
            return tag({ ...rec, status: 'sheet_freight_blank', sheet: sheetRow, delta: null });
        }
        if (pdfAmount == null) {
            return tag({ ...rec, status: 'pdf_amount_unreadable', sheet: sheetRow, delta: null });
        }
        const delta = Math.round((pdfAmount - sheetRow.freight_amt) * 100) / 100;
        return tag({
            ...rec,
            status: Math.abs(delta) <= AMOUNT_TOLERANCE ? 'match' : 'mismatch',
            sheet: sheetRow,
            delta,
        });
    });

    // REMOVED 2026-09-01 — the owner: "ON THE SHEET FOR THIS PERIOD, BUT NO
    // MATCHING PDF UPLOADED ---> remove this".
    //
    // This built a reverse list of sheet HBLs no uploaded PDF claimed. It was
    // only ever meaningful if she had uploaded EVERY carrier invoice for the
    // period — any partial upload filled it with rows that were not missing at
    // all, which is why its own comment called it "a hint, not an alarm". A
    // panel that cries wolf on a reconciliation screen trains you to ignore
    // it, and an ignored panel is worse than no panel.
    //
    // Removing it also removes a cost that was easy to miss: it needed a
    // SECOND period-scoped index, and buildSheetFreightIndex calls
    // fetchRawSheet(true) — forceRefresh, deliberately bypassing the cache.
    // Every carrier run therefore downloaded and parsed the entire invoice sheet
    // TWICE. Now once.
    //
    // To restore: rebuild `scopedIndex` from buildSheetFreightIndex(period),
    // re-add the seenHbls set in the match loop above, and diff the two.

    // Echo the period back so the dashboard can label what it is showing
    // rather than assuming the dropdowns still read the same as when the run
    // started, and report how many rows fell outside it.
    return {
        matched,
        period: hasPeriod ? { year: period.year ? Number(period.year) : null, month: period.month ? Number(period.month) : null } : null,
        outside_period: matched.filter((r) => r.in_period === false).length,
        unclassified_period: hasPeriod ? matched.filter((r) => r.in_period === null).length : 0,
    };
}

// ── Commission → Pan Metal ────────────────────────────────────────────────
// Added per the owner's worked example against a real file ("Comm. Debit Note
// Edge_260804.pdf"): Pan Metal's debit note bills commission per ORDER NO.
// (e.g. "26MT10"), which doesn't appear as its own sheet column — it's
// embedded as the LAST underscore-separated segment of Inv No., e.g.
// "260528_AC_26MT10" → "26MT10". Confirmed against the real sheet for all
// four orders on the sample debit note (26MT10-13, consignee "Pan
// Metal/HK"): weight(ours) × commission_rate(ours, col 15 "Commissions")
// reproduces the debit note's stated Commission dollar amount EXACTLY in
// all four cases (e.g. 21.301 × $10 = $213.01) — that's the verification.
//
// "start with 26" is the owner's own rule, tied to 2026 order numbers being
// live right now — not a hardcoded year, just the actual prefix on today's
// orders. Whenever order numbering rolls to "27..." this rule needs
// updating to match (or generalizing to "2 digits then letters+digits"),
// same kind of drift risk flagged elsewhere in this file for hardcoded
// sheet assumptions.
function extractOrderNoFromInvNo(invNo) {
    const parts = safeStr(invNo).split('_');
    const last = parts[parts.length - 1].trim().toUpperCase();
    return last.startsWith('26') ? last : null;
}

// One entry per distinct order code — same "first row that actually has a
// value wins" pattern as buildSheetFreightIndex, since weight/commission
// are recorded once per order, not repeated on every line.
async function buildSheetOrderIndex() {
    // forceRefresh: true — same reasoning as buildSheetFreightIndex above;
    // this is the fix for the owner's "i changed the weight...it didn't take
    // that" report — the 3-minute cache was serving a stale weight.
    const { headers, rows } = await invoiceSheet.fetchRawSheet(true);
    const colMap = invoiceSheet.buildColumnMap(headers);
    const byOrder = new Map();
    for (const row of rows) {
        const d = invoiceSheet.rowToDict(row, colMap);
        const orderNo = extractOrderNoFromInvNo(d.inv_no);
        if (!orderNo) continue;
        const weight = safeMoney(d.weight);
        const existing = byOrder.get(orderNo);
        if (existing && existing.weight != null) continue;
        if (weight == null && existing) continue;
        byOrder.set(orderNo, {
            order_no: orderNo,
            inv_no: safeStr(d.inv_no),
            consignee: safeStr(d.consignee),
            container_no: safeStr(d.container_no),
            weight,
            commission_rate: safeMoney(d.commission_rate),
            commission_amt: safeMoney(d.commission_amt),
        });
    }
    return byOrder;
}

// pdfRecords: [{ order_no, customer, item, weight, comm_per_mt, commission, source_file, ... }]
// (the shape helpers/gemini.js's extractCommissionDebitNoteRecords returns,
// one array entry per source_file already attached by the API route).
//
// Calculation, per the owner: "weight*commission should be calculated and it
// should be same as commission in uploaded sheet" — weight comes from OUR
// sheet (not the debit note's own weight column), multiplied by OUR
// commission RATE (col 15). "if in my excel,if commission is empty,use the
// commission column in uploaded sheet" — when OUR rate is blank for that
// order, fall back to the debit note's own Comm./MT rate instead so a
// blank rate cell doesn't just silently produce no answer. Either way the
// result is compared against the debit note's own stated Commission dollar
// figure for that order — a discrepancy there is what she wants surfaced.
const COMMISSION_TOLERANCE = 0.05; // absorbs cent-level rounding, not a real miss

async function crossCheckPanMetalRecords(pdfRecords) {
    const orderIndex = await buildSheetOrderIndex();
    const seenOrders = new Set();

    const matched = (pdfRecords || []).map((rec) => {
        const orderNo = safeStr(rec.order_no).toUpperCase();
        const stated = safeMoney(rec.commission);
        if (!orderNo) {
            return { ...rec, status: 'no_order_no_on_pdf', sheet: null, rate_used: null, rate_source: null, calculated: null, delta: null };
        }
        const sheetRow = orderIndex.get(orderNo);
        if (!sheetRow) {
            return { ...rec, status: 'not_in_sheet', sheet: null, rate_used: null, rate_source: null, calculated: null, delta: null };
        }
        seenOrders.add(orderNo);
        if (sheetRow.weight == null) {
            return { ...rec, status: 'sheet_weight_blank', sheet: sheetRow, rate_used: null, rate_source: null, calculated: null, delta: null };
        }
        // Fallback: our rate blank → use the debit note's own Comm./MT.
        const pdfRate = safeMoney(rec.comm_per_mt);
        const rateUsed = sheetRow.commission_rate != null ? sheetRow.commission_rate : pdfRate;
        const rateSource = sheetRow.commission_rate != null ? 'sheet' : (pdfRate != null ? 'pdf_fallback' : null);
        if (rateUsed == null) {
            return { ...rec, status: 'no_rate_available', sheet: sheetRow, rate_used: null, rate_source: null, calculated: null, delta: null };
        }
        if (stated == null) {
            return { ...rec, status: 'pdf_commission_unreadable', sheet: sheetRow, rate_used: rateUsed, rate_source: rateSource, calculated: null, delta: null };
        }
        const calculated = Math.round(sheetRow.weight * rateUsed * 100) / 100;
        const delta = Math.round((stated - calculated) * 100) / 100;
        return {
            ...rec,
            status: Math.abs(delta) <= COMMISSION_TOLERANCE ? 'match' : 'mismatch',
            sheet: sheetRow,
            rate_used: rateUsed,
            rate_source: rateSource,
            calculated,
            delta,
        };
    });

    // Reverse direction — per the owner: "if a invoice no there in uploaded
    // sheet but not in my original excel sheet and vice versa how does tis
    // work?" The forward pass above only ever looks at what's ON the
    // uploaded debit note; an order that's on OUR sheet but that Pan Metal
    // never billed (omitted from the PDF, whether by mistake or not) was
    // previously invisible. This lists every sheet order with a real
    // weight — i.e. an actual shipment, not a blank row — that this run's
    // PDF(s) never claimed. No year/month scoping here (the owner: "month/year
    // field i dont want" — unlike carrier's equivalent sheet_only list),
    // so this is EVERY unmatched weighed order on the whole sheet, not a
    // recent window — expect this list to be long unless the upload covers
    // every outstanding order.
    const sheetOnly = [];
    for (const [orderNo, row] of orderIndex.entries()) {
        if (row.weight == null) continue;
        if (seenOrders.has(orderNo)) continue;
        sheetOnly.push(row);
    }

    return { matched, sheet_only: sheetOnly };
}

// ── Transport → Jio ─────────────────────────────────────────────────────────
// Added per the owner: "for jio,i want a new tab to be created in edge
// metals.in that ,date(from uploaded),container,shipper,line haul,port
// fees,chassis rent,others,then net amount,last verified should be
// there.Your job is to find whether container number is there in my
// original sheet against the column Container No. on successful
// verification,create rows in jio tab of sample yard co metals" — grounded against
// two real Jio Transport invoices (Invoice_8559.pdf, Invoice_8635.pdf):
// one load per PDF, "W/O (Ref):" holds the container number, charges
// itemized under "RATES AND CHARGES" (Line Haul / PORT FEE(S) / chassis
// rent line / occasionally something else), summing to "Total Rate:".
//
// Unlike carrier (freight $ cross-checked) or Pan Metal (a calculation
// cross-checked), Jio has no dollar figure already on the Invoice sheet to
// compare against — "verification" here just means the container number
// on the invoice is a real container Sample Yard Co Metals actually shipped. That's
// intentionally the whole check: existence, not a money match.
function normContainer(v) { return safeStr(v).toUpperCase().replace(/\s+/g, ''); }

// One entry per distinct container — same "first row wins" pattern as the
// other indexes in this file.
async function buildSheetContainerIndex() {
    const { headers, rows } = await invoiceSheet.fetchRawSheet(true); // always fresh — same reasoning as the other verification indexes above
    const colMap = invoiceSheet.buildColumnMap(headers);
    const byContainer = new Map();
    for (const row of rows) {
        const d = invoiceSheet.rowToDict(row, colMap);
        const containerNo = normContainer(d.container_no);
        if (!containerNo) continue;
        if (byContainer.has(containerNo)) continue; // already recorded — same container can legitimately repeat across rows (multi-item shipments)
        byContainer.set(containerNo, {
            container_no: containerNo,
            inv_no: safeStr(d.inv_no),
            consignee: safeStr(d.consignee),
            // booking_no added for crossCheckAjTransportRecords below (a
            // container-existence check alone, like Jio's, plus AJ
            // Transport's own booking no. cross-checked against this same
            // sheet row) — harmless for Jio's own use, which never reads it.
            booking_no: normBooking(d.booking_no),
        });
    }
    return byContainer;
}

// Buckets a record's charges into the four columns the owner asked for. Gemini
// already sorts Line Haul / Port Fees / Chassis Rent into their own fields;
// "others" is OUR sum of whatever it put in other_charges, computed here in
// code rather than trusted from the model, same "money math happens in
// code, not the LLM" rule the rest of this file follows.
function sumOtherCharges(otherCharges) {
    return (otherCharges || []).reduce((sum, c) => sum + (safeMoney(c && c.amount) || 0), 0);
}

// pdfRecords: [{ invoice_no, invoice_date, container_no, shipper, line_haul,
// port_fees, chassis_rent, other_charges, net_amount, source_file }] — the
// shape helpers/gemini.js's extractJioInvoiceRecords() returns.
async function crossCheckJioRecords(pdfRecords) {
    const containerIndex = await buildSheetContainerIndex();
    const seenContainers = new Set();

    const matched = (pdfRecords || []).map((rec) => {
        const containerNo = normContainer(rec.container_no);
        const others = sumOtherCharges(rec.other_charges);
        const base = { ...rec, container_no: containerNo, others };
        if (!containerNo) {
            return { ...base, status: 'no_container_on_pdf', sheet: null };
        }
        const sheetRow = containerIndex.get(containerNo);
        if (!sheetRow) {
            return { ...base, status: 'not_in_sheet', sheet: null };
        }
        seenContainers.add(containerNo);
        return { ...base, status: 'verified', sheet: sheetRow };
    });

    // Reverse direction — per the owner: "Always ensure to check the same
    // where if container number not in sheet and vice versa case", same
    // symmetric check already built for Pan Metal. IMPORTANT CAVEAT, worth
    // reading before trusting this list: carrier/Pan Metal's reverse checks
    // are meaningful because every sheet order genuinely SHOULD have a
    // matching freight/commission entry. There's no equivalent signal here
    // — the sheet has no column saying "this container was trucked by
    // Jio" specifically (vs. AJ Transport, Sher Trucking, or anyone else).
    // So this lists EVERY container on the whole sheet this run's PDFs
    // didn't claim, which will include plenty of containers that were
    // never Jio's to begin with — it's a much noisier signal than the
    // Pan Metal/carrier version, not a real "missing invoice" alarm.
    const sheetOnly = [];
    for (const [containerNo, row] of containerIndex.entries()) {
        if (seenContainers.has(containerNo)) continue;
        sheetOnly.push(row);
    }

    return { matched, sheet_only: sheetOnly };
}

// ── Transport → Sher Trucking ────────────────────────────────────────────
// Added per the owner: "instead of container,booking number shoudl be
// compared from uplaoded sheet vs Booking No. in my original sheet.Create
// a tab called Sher in that date (from uplaoded),booking no,quantity
// ,chassis,others,Amount should be there.if quantity in uplaoded sheet is
// mentioned as 2,check whether there is two occurence of the booking no in
// my original sheet,else show error and dont put the row in sher tab."
//
// Verification here is DIFFERENT from Jio's plain existence check: a
// booking number can legitimately appear on multiple sheet rows (multiple
// containers under one booking), and Sher's invoice states how many
// containers/loads it's billing under that booking (quantity). The check
// is that the sheet's row-count for that booking matches the invoice's
// stated quantity EXACTLY — not just "booking exists somewhere."
function normBooking(v) { return safeStr(v).toUpperCase().replace(/\s+/g, ''); }

// booking_no -> { count, inv_no, consignee } — count is how many sheet rows
// carry this booking (NOT deduped the way container/order indexes above
// are — the row COUNT is the actual thing being verified here, so every
// occurrence has to be counted, not collapsed to one).
async function buildSheetBookingIndex() {
    const { headers, rows } = await invoiceSheet.fetchRawSheet(true); // always fresh — same reasoning as the other verification indexes above
    const colMap = invoiceSheet.buildColumnMap(headers);
    const byBooking = new Map();
    for (const row of rows) {
        const d = invoiceSheet.rowToDict(row, colMap);
        const bookingNo = normBooking(d.booking_no);
        if (!bookingNo) continue;
        const existing = byBooking.get(bookingNo);
        if (existing) { existing.count += 1; continue; }
        byBooking.set(bookingNo, { count: 1, inv_no: safeStr(d.inv_no), consignee: safeStr(d.consignee) });
    }
    return byBooking;
}

// pdfRecords: [{ invoice_date, booking_no, quantity, chassis, other_charges,
// amount, source_file }] — the shape helpers/gemini.js's
// extractSherTruckingInvoiceRecords() returns.
async function crossCheckSherRecords(pdfRecords) {
    const bookingIndex = await buildSheetBookingIndex();
    const seenBookings = new Set();

    const matched = (pdfRecords || []).map((rec) => {
        const bookingNo = normBooking(rec.booking_no);
        const others = sumOtherCharges(rec.other_charges);
        const qty = (rec.quantity === null || rec.quantity === undefined || rec.quantity === '') ? null : Number(rec.quantity);
        const base = { ...rec, booking_no: bookingNo, others, quantity: qty };
        if (!bookingNo) {
            return { ...base, status: 'no_booking_on_pdf', sheet: null, sheet_count: null };
        }
        const sheetRow = bookingIndex.get(bookingNo);
        if (!sheetRow) {
            return { ...base, status: 'not_in_sheet', sheet: null, sheet_count: null };
        }
        seenBookings.add(bookingNo);
        if (qty == null || !Number.isFinite(qty)) {
            return { ...base, status: 'quantity_unreadable', sheet: sheetRow, sheet_count: sheetRow.count };
        }
        if (qty !== sheetRow.count) {
            return { ...base, status: 'quantity_mismatch', sheet: sheetRow, sheet_count: sheetRow.count };
        }
        return { ...base, status: 'verified', sheet: sheetRow, sheet_count: sheetRow.count };
    });

    // Reverse direction — same symmetric check the owner asked to always
    // include (see Jio/Pan Metal above). Same noise caveat as Jio's: the
    // sheet has no "this booking is Sher's" marker, so this lists every
    // booking not claimed by this run's uploads, Sher's or not.
    const sheetOnly = [];
    for (const [bookingNo, row] of bookingIndex.entries()) {
        if (seenBookings.has(bookingNo)) continue;
        sheetOnly.push({ booking_no: bookingNo, ...row });
    }

    return { matched, sheet_only: sheetOnly };
}

// ── Transport → AJ Transport ─────────────────────────────────────────────
// Added per the owner: "Similarly for AJ Transport invoice date,invoice
// no,container no,booking no,shipper,pickup date,rate,amount in new tab
// called AJ Transport.About the logic,you know hwat to do" — grounded
// against a real file (Invoice_6405_from_AJ_Transport_Inc.pdf).
//
// Unlike Jio (container existence only) or Sher (booking row-COUNT), AJ
// Transport's invoice states BOTH a container no. AND a booking no. per
// line — the extra field is put to use, not just displayed: this verifies
// the container is on our sheet (like Jio) AND that OUR sheet's Booking
// No. for that same container matches what AJ Transport billed against.
// A container whose booking doesn't match what we have on file is exactly
// the kind of thing worth a hard stop, not a silent pass — "you know what
// to do" is read here as "hold this to the same standard as Sher's
// quantity check": a real mismatch is an error, not a warning, and never
// gets logged.
async function crossCheckAjTransportRecords(pdfRecords) {
    const containerIndex = await buildSheetContainerIndex();
    const seenContainers = new Set();

    const matched = (pdfRecords || []).map((rec) => {
        const containerNo = normContainer(rec.container_no);
        const bookingNo = normBooking(rec.booking_no);
        // Non-container charges attributed to this container by the Gemini
        // extraction prompt (see gemini.js's extractAjTransportInvoiceRecords)
        // — three named buckets, normalized the same way as any other
        // sheet-bound dollar figure so a missing/blank value logs as 0, not a
        // stray empty string. dryRunCharge/extraScaleCharge are the two known
        // real charge types (their own sheet columns); otherCharge is a
        // catch-all for anything that doesn't match either, logged into the
        // sheet's existing "Others" column so a genuinely new charge type
        // still lands somewhere instead of silently vanishing.
        const dryRunCharge = safeMoney(rec.dry_run_charge) || 0;
        const extraScaleCharge = safeMoney(rec.extra_scale_charge) || 0;
        const otherCharge = safeMoney(rec.other_charge) || 0;
        // "Line Haul" is this container's own AMOUNT column value straight off
        // the invoice (same figure the sheet used to just call "Amount") —
        // per the owner's column list, "Total amount" is the actual grand total
        // owed for this container once every attributed charge is folded in:
        // Line Haul + Others + Dry Run + Extra Scale. Computed here, not
        // extracted, since no single field on the invoice states this sum.
        const lineHaul = safeMoney(rec.amount) || 0;
        const totalAmount = lineHaul + otherCharge + dryRunCharge + extraScaleCharge;
        const base = {
            ...rec, container_no: containerNo, booking_no: bookingNo,
            dry_run_charge: dryRunCharge, extra_scale_charge: extraScaleCharge, other_charge: otherCharge,
            total_amount: totalAmount,
        };
        if (!containerNo) {
            return { ...base, status: 'no_container_on_pdf', sheet: null };
        }
        const sheetRow = containerIndex.get(containerNo);
        if (!sheetRow) {
            return { ...base, status: 'not_in_sheet', sheet: null };
        }
        seenContainers.add(containerNo);
        if (!sheetRow.booking_no) {
            return { ...base, status: 'sheet_booking_blank', sheet: sheetRow };
        }
        if (bookingNo && bookingNo !== sheetRow.booking_no) {
            return { ...base, status: 'booking_mismatch', sheet: sheetRow };
        }
        return { ...base, status: 'verified', sheet: sheetRow };
    });

    // Reverse direction — same symmetric check applied to every other
    // trucker tab, same noise caveat as Jio/Sher: no "this container is
    // AJ Transport's" marker on the sheet, so this is every container this
    // run's uploads didn't claim, not a clean "AJ Transport missed this"
    // signal.
    const sheetOnly = [];
    for (const [containerNo, row] of containerIndex.entries()) {
        if (seenContainers.has(containerNo)) continue;
        sheetOnly.push(row);
    }

    return { matched, sheet_only: sheetOnly };
}

// ── GARDUNO'S LOGISTICS ────────────────────────────────────────────────────
// the owner, 2026-10-04: "under gardunos like AJ Transport".
//
// ITS OWN FUNCTION, NOT A WIDENED crossCheckAjTransportRecords. CLAUDE.md
// rule 1: a request about one screen changes that screen. AJ Transport, Sher
// and Jio each have their own, and the day Garduno's needs a different rule
// — it already does, since its invoice bills per booking rather than per
// container — a shared one would have to grow a flag, and the flag would
// eventually be set wrong on somebody else's live invoice.
//
// Takes the records helpers/gardunosInvoice.expandInvoice() has already
// produced: one per container, with the scale tickets split. The expansion
// and the splitting are tested without Gemini in tests/gardunos-invoice.js;
// this function only answers "is each of these containers on her sheet, and
// does the booking agree".
async function crossCheckGardunosRecords(pdfRecords) {
    const containerIndex = await buildSheetContainerIndex();
    const seenContainers = new Set();

    const matched = (pdfRecords || []).map((rec) => {
        const containerNo = normContainer(rec.container_no);
        const bookingNo = normBooking(rec.booking_no);
        const lineHaul = safeMoney(rec.line_haul) || 0;
        const extraScaleCharge = safeMoney(rec.extra_scale_charge) || 0;
        const otherCharge = safeMoney(rec.other_charge) || 0;
        // Same shape the AJ Transport rows carry, so the review table and
        // anything downstream reads one kind of row rather than two.
        // dry_run_charge is always 0 here: Garduno's does not bill one, and a
        // field that is present and meaningless is worse than one that is
        // present and zero for a stated reason.
        // Math.round rather than a round2 helper: this file does not have one,
        // and inventing a second rounding convention in a file full of money is
        // how two totals start disagreeing by a cent.
        const totalAmount = Math.round((lineHaul + extraScaleCharge + otherCharge) * 100) / 100;
        const base = {
            ...rec, container_no: containerNo, booking_no: bookingNo,
            line_haul: lineHaul, dry_run_charge: 0,
            extra_scale_charge: extraScaleCharge, other_charge: otherCharge,
            total_amount: totalAmount,
        };
        if (!containerNo) return { ...base, status: 'no_container_on_pdf', sheet: null };
        const sheetRow = containerIndex.get(containerNo);
        if (!sheetRow) return { ...base, status: 'not_in_sheet', sheet: null };
        seenContainers.add(containerNo);
        if (!sheetRow.booking_no) return { ...base, status: 'sheet_booking_blank', sheet: sheetRow };
        if (bookingNo && bookingNo !== sheetRow.booking_no) {
            return { ...base, status: 'booking_mismatch', sheet: sheetRow };
        }
        return { ...base, status: 'verified', sheet: sheetRow };
    });

    // ── THE SAME CAVEAT THE OTHER TRUCKER TABS CARRY ─────────────────────
    // The sheet has no marker for which trucker hauled a container, so this
    // is every container THIS upload did not claim — not "Garduno's missed
    // these". Stated here as well as on the screen, because a list like this
    // read as an alarm is how someone chases a container that was never
    // Garduno's to begin with.
    const sheetOnly = [];
    for (const [containerNo, row] of containerIndex.entries()) {
        if (seenContainers.has(containerNo)) continue;
        sheetOnly.push(row);
    }

    return { matched, sheet_only: sheetOnly };
}

// ── EAGLE TRANS (EagleBrit) — ocean freight, one record per INVOICE ────────
// the owner, 2026-10-07: "yes.build". Takes helpers/eagleInvoice.normalize()
// records. ITS OWN FUNCTION (CLAUDE.md rule 1): it is not the carrier check (keyed
// on HBL, compares an amount) and not the trucker checks (one record per
// container). An Eagle invoice bills a booking in one total, so the question is
// "is every container it names on her sheet" — the amount cannot be compared
// because the sheet has no Eagle figure, and inventing one would look reconciled.
//
// The booking is NOT compared with the sheet's Booking No.: Eagle's EBKG number
// is the forwarder's own reference, and the sheet's column holds the carrier
// booking. They are different numbers for the same shipment, so a mismatch would
// be noise. Shown on the row for the person reading it, never judged.
async function crossCheckEagleRecords(pdfRecords) {
    const containerIndex = await buildSheetContainerIndex();
    const seen = new Set();
    const matched = (pdfRecords || []).map((rec) => {
        const containers = (rec.containers || []).map(normContainer).filter(Boolean);
        const onSheet = containers.filter((c) => containerIndex.has(c));
        const missing = containers.filter((c) => !containerIndex.has(c));
        onSheet.forEach((c) => seen.add(c));
        const base = { ...rec, containers, containers_on_sheet: onSheet, containers_missing: missing,
            sheet: onSheet.length ? containerIndex.get(onSheet[0]) : null };
        if (rec.extraction_failed) return { ...base, status: 'extraction_failed' };
        if (rec.kind === 'credit_note') return { ...base, status: 'credit_note' };
        if (!containers.length) return { ...base, status: 'no_container_on_pdf' };
        if (rec.reconciled === false) return { ...base, status: 'total_mismatch' };
        if (missing.length) return { ...base, status: onSheet.length ? 'partly_in_sheet' : 'not_in_sheet' };
        return { ...base, status: 'verified' };
    });
    // No reverse check: the sheet has no marker for which forwarder moved a
    // container, so "on the sheet, not on these invoices" would list nearly every row.
    return { matched };
}

module.exports = {
    buildSheetFreightIndex, crossCheckcarrierRecords, AMOUNT_TOLERANCE, parseSheetDate, inSelectedPeriod,
    buildSheetOrderIndex, crossCheckPanMetalRecords, extractOrderNoFromInvNo, COMMISSION_TOLERANCE,
    buildSheetContainerIndex, crossCheckJioRecords,
    buildSheetBookingIndex, crossCheckSherRecords,
    crossCheckAjTransportRecords,
    crossCheckGardunosRecords,
    crossCheckEagleRecords,
};
