// ── helpers/claims.js — the weight-shortage claim register ──────────────────
//
// the owner, 2026-09-26: "Revamp weight shortage sheet .. So it should read the
// mail with weight shortage detail and create automatically."
//
// WHY THIS IS A STORE AND NOT A SHEET TAB
// The "Weight Shortage 2025" tab on Shipments 2026 is seven different tables
// stacked down one grid — weight shortage, grade recovery, Reg/Al engine,
// steel engine and transmission, container damage, quality, and a 2025 legacy
// register — each re-labelling the same columns. Nothing can append to it
// safely: row 92's header means something different from row 117's, so an
// appended row has no defined meaning. Automation needs one row per claim with
// a fixed shape, so the record lives here and the page reads this.
//
// WHAT IS DELIBERATELY NOT AUTOMATIC
// `claim_amount` stays null until a human verifies the weights AND the unit.
// Her own tab is the argument: it already holds "ALUMINUM SCRAP 1,305.9KG
// SHORTAGE", "60661 kg" beside "58.901", "23,718" in a column headed MT, and
// the Ala International rows in pounds at a $/lb rate. A parser that guesses
// MT is wrong by a factor of 1000, and that number would land in the figure
// she shows her uncle and her customers. So the row is created from the mail;
// the money is computed by `verify()`, from figures a person confirmed.
const path = require('path');
const cfg = require('../config');
const { loadJson, mutateJson } = require('./json');

const FILE = () => cfg.CLAIMS_FILE || path.join(cfg.DATA_DIR, 'claims.json');

// Status is a closed set. 'unverified' is where every parsed claim starts.
const STATUSES = ['unverified', 'verified', 'recovery_raised', 'settled', 'rejected', 'withdrawn'];
// There is deliberately NO list of claim kinds here. the owner, 2026-09-26: "let ai
// decide dynamically". A kind is a slug the model named, recorded in
// helpers/claimKinds.js; `claim_type` is one of those slugs, or null for a claim
// nothing has been able to classify yet. Null is a real state, not a gap — it is
// flagged and shown on the page rather than defaulted to the commonest kind.
const claimKinds = require('./claimKinds');
const UNITS = ['MT', 'LB', 'KG'];

// Flags are the reasons a human still has to look. They are not errors — a
// claim with flags is a normal claim that is not yet worth money.
const FLAG_NO_UNIT = 'unit_not_stated';
const FLAG_UNKNOWN_CONTAINER = 'container_unknown';
const FLAG_FIGURE_CHANGED = 'figure_changed';
const FLAG_NO_SUPPLIER = 'supplier_unknown';
const FLAG_KIND_UNKNOWN = 'kind_unknown';

// ── HOW A CLAIM IS ASSESSED (2026-10-10) ────────────────────────────────────
// the owner: "Add like remarks if its foreign material with a downloadable claim
// report", and the Claims page "should be the most user friendly tab".
//
// A claim KIND is the model's free-form name for it (claimKinds.js) and stays
// that way. The ASSESSMENT is a different, closed question — how is the money
// worked out — and there are only three answers:
//   weight        invoiced minus received, at a rate          (verify(), unchanged)
//   contamination a share of the net weight was not the metal (assess())
//   grade         the metal arrived as a cheaper grade         (assess())
//   quality       a quantity at a rate, typed straight in — no     (assess())
//                 invoiced/received pair (the owner, 2026-10-14: "i cant give
//                 what we invoice and what they receive part")
// Keeping them apart means a kind she renames tomorrow still assesses the way
// it did today, and no kind name is ever written into the code.
// null means "never chosen" and is treated as weight, which is what every claim
// before this date was.
// 'sorted' added 2026-10-20 for the owner's "al wheel dirty" claims — a dirty
// grade sorted into several named contaminants, each weighed and valued. It is
// a new MEMBER of a closed set, not a change to one: a claim already carrying
// assessment:'contamination' assesses exactly as it did yesterday.
// 'damage' joined on 2026-10-21. the owner: "if there is any damage,quality,grade
// claim,we need to procide more details na?" — and damage had no home at all.
// It was either squeezed into 'quality', where the note can only say "N LB
// claimed" and says nothing about damage, or left unassessed, where the claim
// note printed a dollar figure with no explanation whatsoever.
//
// It shares the 'sorted' branch below rather than copying it: see there.
const ASSESSMENTS = ['weight', 'contamination', 'grade', 'quality', 'sorted', 'damage'];
// The assessments that are a LIST of lines rather than one figure. Both price
// each line as weight x (what Sample paid - what it is actually worth).
const LINE_ASSESSMENTS = ['sorted', 'damage'];
// What can be found in a container. Shown as tick boxes; `sealed_hazard` is the
// one that is not a price question at all (radioactive or explosive items —
// every scrap shipment into India carries a declaration that there are none).
const FINDINGS = ['dirt', 'rubber_plastic', 'iron_attached', 'oil_moisture', 'other_metals', 'wood_paper', 'sealed_hazard'];
// How the contamination was measured. Strength is shown on the page so a
// deduction backed only by the customer's photos is not argued as if surveyed.
const MEASURED_BY = ['surveyor', 'split_sample', 'sorted_weighed', 'photos_only'];

const newId = () => `clm_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
const norm = (s) => String(s == null ? '' : s).toUpperCase().replace(/[^A-Z0-9]/g, '');
const num = (v) => { const n = Number(String(v == null ? '' : v).replace(/[$,\s]/g, '')); return Number.isFinite(n) ? n : null; };

// The dedupe key. A claim is one customer chasing one container on one
// invoice, however many mails that takes. Container alone is not enough —
// ledger-data says a booking reference can be a TRAILER that goes out again.
function keyOf(invoice_no, container_no) { return `${norm(invoice_no)}|${norm(container_no)}`; }

function list() { return loadJson(FILE(), []) || []; }
function get(id) { return list().find((c) => c && c.id === id) || null; }
function findByKey(invoice_no, container_no) {
    const k = keyOf(invoice_no, container_no);
    return list().find((c) => c && c.key === k) || null;
}

// ── UNITS ───────────────────────────────────────────────────────────────────
// Converted only where a person has already said what the unit IS. Nothing
// here ever guesses one.
const TO_MT = { MT: 1, LB: 1 / 2204.62, KG: 1 / 1000 };
function toMT(value, unit) {
    const v = num(value);
    if (v === null || !TO_MT[unit]) return null;
    return v * TO_MT[unit];
}
function convert(value, from, to) {
    const mt = toMT(value, from);
    if (mt === null || !TO_MT[to]) return null;
    return mt / TO_MT[to];
}

function blank() {
    return {
        id: null, key: null,
        status: 'unverified', claim_type: 'weight_shortage',
        customer: '', supplier: '',
        invoice_no: '', container_no: '',
        invoice_weight: null, claimed_weight: null, weight_unit: null,
        shortage: null, shortage_pct: null,
        // Sample's SELL rate. It values what the customer is claiming and it
        // never leaves the building — printing it on a supplier statement
        // hands them Sample's margin.
        sell_price: null, sell_price_unit: null,
        // What Sample PAID this supplier, from that container's purchase bill.
        // This is the rate the recovery is argued at, because it is the only
        // one the supplier already agreed to. helpers/claimPrice.js finds it.
        supplier_price: null, supplier_price_unit: null, supplier_price_source: '',
        // HOW that rate is arrived at when the container holds several
        // materials. '' (the default, and every claim that already exists)
        // means the behaviour that has always applied: one grade, one rate,
        // matched off the bill. 'container_blend' is the auto-parts case —
        // the owner, 2026-10-21, "we will take avergae price of all the material
        // that was loaded into the container ... They will have weight slip
        // for overall container" — where the shortage is weighed once on the
        // whole box, so no grade can be matched and the rate is what the
        // container itself cost per pound. See helpers/claimPrice.js.
        price_basis: '',
        // A link to the supporting documents, pasted by her. the owner,
        // 2026-10-21: "For supoorting doc,i will just directly provide
        // gdrive link" — she shares it in Drive herself and this is only
        // printed. Separate from `evidence[].url`, the internal Shared-Drive
        // link that must never leave the building.
        docs_url: '',
        claim_amount: null, our_claim: null,
        evidence: [], mail: [], quotes: {}, flags: [], history: [],
        note: '',
        // The date ON the claim document, which is NOT created_at. A sheet
        // imported in one go gives every row the same created_at, and a
        // supplier reading that on a statement reads it as the claim date.
        claim_date: null,
        // ── added 2026-10-10, all optional; a claim without them behaves
        // exactly as before. See ASSESSMENTS above.
        assessment: null,
        findings: [], measured_by: null,
        contam_claimed_pct: null, contam_accepted_pct: null, contaminated_weight: null,
        // ── A DIRTY GRADE SORTED INTO NAMED CONTAMINANTS ─────────────────
        // One row per thing found: { type, weight, worth, worth_unit, amount
        // }. `worth` null means it is worth nothing to Sample and the line is
        // claimed in full. Empty on every claim that is not a sorted one, so
        // nothing that exists today reads differently.
        sorted_lines: [], sorted_weight: null,
        // What Sample PAID the supplier, and the unit it was priced in — the
        // basis a sorted claim is worked out from. Distinct from sell_price,
        // which is what Sample sold at and is what every other kind uses.
        paid_price: null, paid_price_unit: null,
        grade_sold: '', grade_received: '', grade_weight: null,
        grade_price_sold: null, grade_price_received: null,
        stated_qty: null, stated_qty_unit: null, stated_rate: null, stated_rate_unit: null, // as the MAIL said; prefill only
        // ── A DOWNGRADE, AS THE DOCUMENT STATED IT (2026-10-30) ──────────
        // Taewon's 26JY73 claim report: 77 combos invoiced as AL at $1,000/MT,
        // 46 of them arrived as steel, worth $645/MT, 12.972 MT affected,
        // claimed 12.972 x $355 = $4,605.06. The grade_* fields above are the
        // ASSESSED figures that produce claim_amount; these are only what the
        // paper said, so the downgrade pane opens filled in and she confirms.
        // Same split, and the same reason, as stated_qty against quality_qty.
        //
        // The piece counts are here because they are the EVIDENCE — "46 of 77"
        // is what their photographs show and what a dispute turns on — while
        // the money is worked out on weight. Jarvis stored no quantity before,
        // so that fact was lost the moment the document was filed.
        stated_grade_sold: '', stated_grade_received: '',
        stated_price_sold: null, stated_price_received: null, stated_price_unit: null,
        stated_affected_weight: null,
        stated_pieces_total: null, stated_pieces_affected: null,
        line_key: '',                // which of several claims in ONE mail this is (e.g. 'quality_claim_ms_scrap')
        quality_qty: null,           // 'quality' assessment: the quantity claimed, in weight_unit
        // Contract tolerance on a weight shortage. Blank = no allowance, which
        // is how every claim was worked out before it existed.
        tolerance_pct: null, claimable_shortage: null,
        // Her own words about the claim. Printed on the INTERNAL report only:
        // a remark is free text and can name the customer, so it never goes on
        // the document a supplier receives.
        remarks: '',
        created_at: null, created_by: '', updated_at: null,
    };
}

function withFlags(c) {
    const flags = new Set(c.flags || []);
    if (!c.weight_unit) flags.add(FLAG_NO_UNIT); else flags.delete(FLAG_NO_UNIT);
    if (!String(c.supplier || '').trim()) flags.add(FLAG_NO_SUPPLIER); else flags.delete(FLAG_NO_SUPPLIER);
    if (!c.claim_type) flags.add(FLAG_KIND_UNKNOWN); else flags.delete(FLAG_KIND_UNKNOWN);
    c.flags = [...flags];
    return c;
}

// ── CREATE ──────────────────────────────────────────────────────────────────
// strict:true on purpose. mutateJson swallows anything thrown inside its
// mutator and hands the caller plausible stale data (helpers/json.js:111), so
// without strict a claim can look created and never have been written. A lost
// claim is lost money.
async function create(input = {}, by = 'claims') {
    const now = new Date().toISOString();
    const rec = withFlags({
        ...blank(), ...input,
        id: newId(),
        key: keyOf(input.invoice_no, input.container_no),
        status: STATUSES.includes(input.status) ? input.status : 'unverified',
        claim_type: input.claim_type ? claimKinds.slugify(input.claim_type) : null,
        weight_unit: UNITS.includes(input.weight_unit) ? input.weight_unit : null,
        claim_amount: null,          // never on creation — verify() computes it
        created_at: now, updated_at: now, created_by: by,
        history: [{ at: now, what: 'created', by }],
    });
    await mutateJson(FILE(), [], (all) => { all.push(rec); return all; }, { strict: true });
    return rec;
}

async function update(id, patch = {}, by = 'claims', what = 'updated') {
    const now = new Date().toISOString();
    let out = null;
    await mutateJson(FILE(), [], (all) => {
        const i = all.findIndex((c) => c && c.id === id);
        if (i < 0) return all;
        const merged = withFlags({ ...all[i], ...patch, id: all[i].id, updated_at: now });
        merged.key = keyOf(merged.invoice_no, merged.container_no);
        merged.history = [...(all[i].history || []), { at: now, what, by }];
        all[i] = merged; out = merged; return all;
    }, { strict: true });
    return out;
}

// ── VERIFY — the only place a claim becomes money ───────────────────────────
// The caller must state the unit. Everything is computed from figures a human
// confirmed, in the unit they confirmed them in.
async function verify(id, fields = {}, by = 'manager') {
    const c = get(id);
    if (!c) throw new Error('no such claim');
    const unit = UNITS.includes(fields.weight_unit) ? fields.weight_unit : null;
    if (!unit) throw new Error('verifying a claim needs the weight unit — MT, LB or KG');

    const invoice_weight = fields.invoice_weight !== undefined ? num(fields.invoice_weight) : num(c.invoice_weight);
    const claimed_weight = fields.claimed_weight !== undefined ? num(fields.claimed_weight) : num(c.claimed_weight);
    if (invoice_weight === null || claimed_weight === null) throw new Error('verifying a claim needs both the invoiced and the received weight');

    const sell_price = fields.sell_price !== undefined ? num(fields.sell_price) : num(c.sell_price);
    const sell_price_unit = UNITS.includes(fields.sell_price_unit) ? fields.sell_price_unit
        : UNITS.includes(c.sell_price_unit) ? c.sell_price_unit : unit;

    const shortage = Math.round((invoice_weight - claimed_weight) * 1e6) / 1e6;
    const shortage_pct = invoice_weight > 0 ? Math.round((shortage / invoice_weight) * 10000) / 100 : null;

    // The rate may be quoted per a different unit than the weights — she buys
    // in pounds and the commercial invoice prints MT. Convert the SHORTAGE
    // into the rate's unit rather than converting the rate.
    // ── CONTRACT TOLERANCE, ONLY WHEN SOMEONE STATES ONE (2026-10-10) ──────
    // A blank tolerance means none — the figure is worked out exactly as it
    // always was. `shortage` stays the real difference; only the CLAIMABLE part
    // shrinks, so the page and the report can show both.
    const stated = (v) => v !== undefined && v !== null && String(v).trim() !== '';
    const tolerance_pct = stated(fields.tolerance_pct) ? num(fields.tolerance_pct)
        : (fields.tolerance_pct === undefined && stated(c.tolerance_pct) ? num(c.tolerance_pct) : null);
    if (tolerance_pct !== null && (tolerance_pct < 0 || tolerance_pct > 20)) throw new Error('a tolerance must be between 0% and 20%');
    const claimable_shortage = tolerance_pct === null ? null
        : Math.max(0, Math.round((shortage - invoice_weight * tolerance_pct / 100) * 1e6) / 1e6);
    const charged = claimable_shortage === null ? shortage : claimable_shortage;

    let claim_amount = null;
    if (sell_price !== null) {
        const shortInRateUnit = sell_price_unit === unit ? charged : convert(charged, unit, sell_price_unit);
        if (shortInRateUnit !== null) claim_amount = Math.round(shortInRateUnit * sell_price * 100) / 100;
    }

    return update(id, {
        weight_unit: unit, invoice_weight, claimed_weight, sell_price, sell_price_unit,
        shortage, shortage_pct, claim_amount, tolerance_pct, claimable_shortage,
        // verify() IS the weight arithmetic, so a claim confirmed here is a
        // weight claim, whatever it was assessed as before.
        assessment: 'weight',
        status: c.status === 'unverified' ? 'verified' : c.status,
    }, by, 'verified');
}

// ── ASSESS — contamination and grade claims (2026-10-10) ───────────────────
// The same contract as verify(): the money is computed here, from figures a
// person typed, in a unit a person chose — never on creation, never guessed.
// Weight claims still go through verify(); this refuses them so there is one
// path per kind of arithmetic.
async function assess(id, fields = {}, by = 'manager') {
    const c = get(id);
    if (!c) throw new Error('no such claim');
    const kind = fields.assessment;
    if (kind === 'weight') throw new Error('a weight shortage is confirmed through verify, not assess');
    if (!ASSESSMENTS.includes(kind)) throw new Error(`assessment must be one of: ${ASSESSMENTS.join(', ')}`);

    const unit = UNITS.includes(fields.weight_unit) ? fields.weight_unit : (UNITS.includes(c.weight_unit) ? c.weight_unit : null);
    if (!unit) throw new Error('assessing a claim needs the weight unit — MT, LB or KG');
    const given = (k) => (fields[k] !== undefined ? fields[k] : c[k]);
    const has = (v) => v !== undefined && v !== null && String(v).trim() !== '';
    const sell_price = has(given('sell_price')) ? num(given('sell_price')) : null;
    const sell_price_unit = UNITS.includes(fields.sell_price_unit) ? fields.sell_price_unit
        : UNITS.includes(c.sell_price_unit) ? c.sell_price_unit : unit;

    const patch = { assessment: kind, weight_unit: unit, status: c.status === 'unverified' ? 'verified' : c.status };
    let claim_amount = null;

    if (kind === 'contamination') {
        const invoice_weight = has(given('invoice_weight')) ? num(given('invoice_weight')) : null;
        const accepted = has(given('contam_accepted_pct')) ? num(given('contam_accepted_pct')) : null;
        if (invoice_weight === null || invoice_weight <= 0) throw new Error('assessing contamination needs the net weight that was invoiced');
        if (accepted === null) throw new Error('assessing contamination needs the share Sample accepts was not metal — a percentage');
        if (accepted < 0 || accepted > 100) throw new Error('a contamination share must be between 0% and 100%');
        const claimedPct = has(given('contam_claimed_pct')) ? num(given('contam_claimed_pct')) : null;
        const contaminated_weight = Math.round(invoice_weight * accepted / 100 * 1e6) / 1e6;
        if (sell_price !== null) {
            const q = sell_price_unit === unit ? contaminated_weight : convert(contaminated_weight, unit, sell_price_unit);
            if (q !== null) claim_amount = Math.round(q * sell_price * 100) / 100;
        }
        const findings = Array.isArray(given('findings')) ? given('findings').filter((f) => FINDINGS.includes(f)) : [];
        const measured_by = MEASURED_BY.includes(given('measured_by')) ? given('measured_by') : null;
        Object.assign(patch, { invoice_weight, contam_accepted_pct: accepted, contam_claimed_pct: claimedPct,
            contaminated_weight, findings, measured_by, sell_price, sell_price_unit });
    } else if (kind === 'quality') {
        // Quantity x rate, both typed. The rate is the sale rate on the claim
        // (it never leaves the building); the supplier is argued at THEIR rate
        // later, exactly as for every other kind.
        const qty = has(given('quality_qty')) ? num(given('quality_qty')) : null;
        if (qty === null || qty <= 0) throw new Error('assessing a quality claim needs the quantity claimed');
        if (sell_price === null || sell_price <= 0) throw new Error('assessing a quality claim needs the rate');
        const q = sell_price_unit === unit ? qty : convert(qty, unit, sell_price_unit);
        if (q === null) throw new Error('assessing a quality claim needs a rate unit that can be compared with the quantity');
        claim_amount = Math.round(q * sell_price * 100) / 100;
        // ── WHAT WAS WRONG WITH IT (2026-10-21) ──────────────────────────
        // the owner: "wh about quality claim?" — asked after damage got its own
        // type. The answer was that there was no quality assessment at all:
        // this branch stored a quantity and a rate and nothing else, so the
        // note said "quality: 2,215.64 LB claimed" and demanded $1,971.92
        // without ever saying what was wrong with the material. A supplier's
        // first reply to that is "what was wrong with it", and she was
        // answering it by email, outside the document.
        //
        // `findings` and `measured_by` have been on every claim record since
        // the first version (blank() above) and the contamination branch has
        // always filled them. This branch simply never read them.
        //
        // BOTH STAY OPTIONAL. A quality claim created from a mail or by
        // voice has no chips to tick, and making either required would break
        // exactly the callers CLAUDE.md records breaking twice — the ones
        // without a form to put a field on. A claim with no findings assesses
        // precisely as it did before this existed; the note just says less.
        const qFindings = Array.isArray(given('findings'))
            ? given('findings').filter((f) => FINDINGS.includes(f)) : c.findings;
        const qMeasured = MEASURED_BY.includes(given('measured_by')) ? given('measured_by') : c.measured_by;
        // ── WHAT WE SENT, WHAT THEY RECEIVED (2026-10-30) ────────────────
        // the owner: "What we sent, what they received item type can be optional
        // in quality claim". The two names already exist on the record and
        // the downgrade branch fills them; quality simply never asked.
        //
        // OPTIONAL, for the same reason findings and measured_by above are:
        // a quality claim read off a mail or taken by voice has no item type
        // to give, and making either required would break the callers with
        // no form to put a field on — the break CLAUDE.md records twice.
        // Read through given(), NOT off `fields`. given() falls back to the
        // record (line 314), so an edit about the quantity that never mentions
        // the item types keeps the ones she typed. Reading fields.grade_sold
        // directly would blank them on every such edit — and my first version
        // of this wrapped given() in its own undefined check, which was dead
        // code: the mutation that removed it could not change the answer.
        const qSent = String(given('grade_sold') || '').slice(0, 80);
        const qRecv = String(given('grade_received') || '').slice(0, 80);
        Object.assign(patch, { quality_qty: qty, sell_price, sell_price_unit,
            findings: qFindings, measured_by: qMeasured,
            grade_sold: qSent, grade_received: qRecv });
    } else if (LINE_ASSESSMENTS.includes(kind)) {
        // ── SORTED *AND* DAMAGE, ONE BRANCH ──────────────────────────────
        // 'damage' joined on 2026-10-21 and reuses this branch rather than
        // copying it. They are the same question with different nouns: part
        // of the load is worth less than what Sample paid, and here are the
        // parts. Everything below that makes it dangerous — the rate-unit
        // conversion, the "that looks like a WEIGHT, not a rate" guard, the
        // refusal of a line priced ABOVE what Sample paid — is dangerous for
        // both, and fixing it in two copies is how one of them stays broken.
        //
        // What differs is WORDING only, and it differs because a damage claim
        // that said "sorted out of the load" would describe something that
        // did not happen. The strings are chosen here and nothing else in the
        // branch knows which kind it is running for.
        //
        // The lines are STORED in sorted_lines for both. The field is the
        // line list for any line-by-line assessment; `assessment` is what
        // says whether they were sorted out or damaged, and the claim note
        // reads that to choose its wording. Renaming the field would reach
        // the report, the screen, the route whitelist, the sheet import and
        // every test and mutation that names it — a migration, not a feature.
        const isDamage = kind === 'damage';
        const noun = isDamage ? 'damage' : 'sorted';
        // ── SORTED BY TYPE, WEIGHED, AND CLAIMED LINE BY LINE ────────────
        // the owner, 2026-10-20: "we buy al wheel dirty.there would be claim on
        // that like clad wheel,chrome wheel,truck wheel".
        //
        // She buys a dirty grade, it gets sorted, and what comes out is not
        // one contaminant but several — each with its own weight and its own
        // real value. The 'contamination' assessment above cannot say that:
        // it carries ONE accepted percentage and ONE rate, so three named
        // contaminants collapse into a single figure she cannot defend line
        // by line to the supplier who sold it to her.
        //
        // ── THE ARITHMETIC IS HERS, CONFIRMED ON A WORKED EXAMPLE ───────
        // Asked how the money works she first answered "both 1,2", which had
        // three readings differing by more than $1,000 on the same material.
        // Shown 40,000lb of Al wheel dirty at $0.85 sorted into 2,000lb clad
        // (worth $0.30), 1,200lb chrome ($0.40) and 800lb truck wheel (no
        // rate), she chose the difference:
        //
        //     clad    2,000 x (0.85 - 0.30) = 1,100.00
        //     chrome  1,200 x (0.85 - 0.40) =   540.00
        //     truck     800 x (0.85 - 0.00) =   680.00
        //                                    ─────────
        //                                     2,320.00
        //
        // A line with no rate is worth NOTHING to her and is claimed in
        // full. That is not a default standing in for a missing number — it
        // is the answer she gave.
        //
        // Note this is the same shape as the downgrade branch below:
        // weight x (what it should have been worth - what it was worth).
        // That arithmetic is already proven in this file; the new part is
        // that there are several lines and the basis is the purchase price.
        //
        // ── THE BASIS IS WHAT SHE PAID, NOT WHAT SHE SOLD FOR ───────────
        // Every other kind here values the claim at `sell_price`, because
        // every other kind starts with a CUSTOMER claiming on Sample. This one
        // does not: she bought contaminated material, and the claim goes to
        // the supplier who sold it. So the rate is what Sample paid HIM —
        // which is also the answer she gave on 2026-10-03 when asked whether
        // recovery is valued at the supplier's price or the customer's.
        // helpers/claimPrice.js already finds that figure from the
        // container's purchase bill, and `supplier_price` on the record is
        // where it lands.
        //
        // So `claim_amount` on a sorted claim means something slightly
        // different from `claim_amount` on the others, and that is written
        // here rather than left to be discovered: on a sorted claim it is
        // already the figure the supplier is being asked for. `our_claim` is
        // deliberately NOT set — raiseRecovery still owns it, so the
        // recovery to-do that routes.js raises behaves exactly as before.
        // Read from whichever field the kind owns, so the screen posts the
        // name that matches what it is showing. Falling back to the other
        // is deliberate: the voice path and the sheet import both send
        // sorted_lines, and a damage claim arriving that way should work
        // rather than be refused on a field name.
        const given_lines = isDamage
            ? (Array.isArray(given('damage_lines')) ? given('damage_lines') : given('sorted_lines'))
            : given('sorted_lines');
        const lines = Array.isArray(given_lines) ? given_lines : null;
        if (!lines || !lines.length) {
            throw new Error(`a ${noun} claim needs at least one line — what was found, and how much of it`);
        }
        if (lines.length > 40) throw new Error(`a ${noun} claim is capped at 40 lines`);

        const paid = has(given('paid_price')) ? num(given('paid_price'))
            : has(c.supplier_price) ? num(c.supplier_price) : null;
        const paidUnit = UNITS.includes(fields.paid_price_unit) ? fields.paid_price_unit
            : UNITS.includes(c.supplier_price_unit) ? c.supplier_price_unit : unit;
        if (paid === null || paid <= 0) {
            throw new Error(`a ${noun} claim needs the price Sample paid this supplier — it is what the claim is `
                + 'worked out from. helpers/claimPrice.js can find it from the container’s purchase bill.');
        }

        // A rate per LB is not a rate per MT. Converted through the SAME
        // weight helper the rest of this file uses, inverted — convert(1, to,
        // from) is how many `from` units are in one `to` unit, which is
        // exactly the factor a per-unit price scales by. Pinned in
        // tests/claims-sorted.js at 2204.62262 in both directions, because a
        // price unit guessed wrong is this file's stated nightmare: "wrong by
        // a factor of 1000, and that number would land in the figure she
        // shows her uncle and her customers".
        const rateInto = (rate, from, to) => {
            if (rate === null) return null;
            if (!from || from === to) return rate;
            const factor = convert(1, to, from);
            return factor === null ? null : rate * factor;
        };

        const clean = [];
        let total = 0;
        let claimedWeight = 0;
        for (const raw of lines) {
            const type = String((raw && raw.type) || '').trim().slice(0, 80);
            if (!type) {
                throw new Error(isDamage
                    ? 'every line on a damage claim needs a name — "bent rims", "cracked housings"'
                    : 'every line on a sorted claim needs a name — "clad wheel", "chrome wheel"');
            }
            const w = has(raw && raw.weight) ? num(raw.weight) : null;
            if (w === null || w <= 0) {
                throw new Error(`"${type}" needs the weight that was ${isDamage ? 'damaged' : 'sorted out of the load'}`);
            }

            // null worth is a real answer — see above — and is kept as null
            // rather than written as 0, so the page can show "claimed in
            // full" instead of a rate she never typed.
            const worthRaw = has(raw && raw.worth) ? num(raw.worth) : null;
            if (worthRaw !== null && worthRaw < 0) throw new Error(`"${type}" cannot be worth less than nothing`);
            const worthUnit = UNITS.includes(raw && raw.worth_unit) ? raw.worth_unit : paidUnit;
            const worth = rateInto(worthRaw, worthUnit, paidUnit);
            if (worthRaw !== null && worth === null) {
                throw new Error(`"${type}" has a rate in ${worthUnit} that cannot be compared with a price in ${paidUnit}`);
            }
            // Mirrors "that is not a downgrade" on the grade branch. A
            // contaminant worth MORE than the grade she paid for is not a
            // loss, and a negative line would quietly reduce the total.
            if (worth !== null && worth > paid) {
                // ── SAY WHAT IT ACTUALLY LOOKS LIKE ──────────────────────
                // the owner, 2026-10-21, hit this on her real screen: "AL
                // WHEELS DIRTY is priced above what Sample paid (1.38 per LB)
                // — that is not a loss". True, and useless: she had typed
                // 38,169 — the WEIGHT — into the rate box, because the
                // table header named the wrong unit and sat over the wrong
                // column.
                //
                // 38,169 against $1.38 is not a pricing judgement, it is
                // twenty-seven THOUSAND times the rate. A figure that far
                // out is a field mix-up, and the message should say which
                // field rather than describe the arithmetic. The weight is
                // named back to her so the swap is obvious.
                const ratio = paid > 0 ? worth / paid : 0;
                if (ratio > 20) {
                    throw new Error(`"${type}": ${worth} looks like a WEIGHT, not a rate — it is `
                        + `${Math.round(ratio)}x the ${paid} per ${paidUnit} Sample paid. The boxes are `
                        + `how much came out of the load, then what that material is worth per ${paidUnit}`
                        + (w !== null ? ` — did you mean ${worth} ${unit} at some rate?` : '.'));
                }
                throw new Error(`"${type}" is priced above what Sample paid (${paid} per ${paidUnit}) — that is not a loss`);
            }

            const wInPaidUnit = paidUnit === unit ? w : convert(w, unit, paidUnit);
            if (wInPaidUnit === null) {
                throw new Error(`"${type}" is weighed in ${unit}, which cannot be compared with a price in ${paidUnit}`);
            }
            const amount = Math.round(wInPaidUnit * (paid - (worth === null ? 0 : worth)) * 100) / 100;
            total = Math.round((total + amount) * 100) / 100;
            claimedWeight = Math.round((claimedWeight + w) * 1e6) / 1e6;
            clean.push({ type, weight: w, worth: worthRaw, worth_unit: worthRaw === null ? null : worthUnit, amount });
        }

        // The invoiced weight is not required — she may be claiming on a
        // sorted sample long before the invoice is argued — but when it IS
        // known, sorting out more than arrived is an arithmetic she wants
        // stopped at the door rather than printed.
        const invoice_weight = has(given('invoice_weight')) ? num(given('invoice_weight')) : null;
        if (invoice_weight !== null && invoice_weight > 0 && claimedWeight - invoice_weight > 1e-6) {
            throw new Error(`the lines add up to ${claimedWeight} ${unit}, more than the ${invoice_weight} ${unit} invoiced`);
        }

        claim_amount = total;
        Object.assign(patch, {
            sorted_lines: clean, sorted_weight: claimedWeight,
            paid_price: paid, paid_price_unit: paidUnit,
            invoice_weight: invoice_weight !== null ? invoice_weight : c.invoice_weight,
            measured_by: MEASURED_BY.includes(given('measured_by')) ? given('measured_by') : c.measured_by,
        });
    } else if (kind === 'grade') {
        // WAS A CATCH-ALL `else`. Adding 'sorted' to ASSESSMENTS above would
        // otherwise have landed here and demanded grade prices for a claim
        // that has none — a new assessment silently becoming a downgrade. No
        // behaviour changes: the ASSESSMENTS guard already rejected anything
        // that is not in the list, so this branch only ever ran for 'grade'.
        const w = has(given('grade_weight')) ? num(given('grade_weight')) : null;
        const sold = has(given('grade_price_sold')) ? num(given('grade_price_sold')) : null;
        const recv = has(given('grade_price_received')) ? num(given('grade_price_received')) : null;
        if (w === null || w <= 0) throw new Error('assessing a downgrade needs the weight that was affected');
        if (sold === null || recv === null) throw new Error('assessing a downgrade needs both prices — the grade sold and the grade received');
        if (recv > sold) throw new Error('the received grade is priced above the grade sold — that is not a downgrade');
        // Both prices are per the claim's weight unit; the page labels them so.
        claim_amount = Math.round(w * (sold - recv) * 100) / 100;
        Object.assign(patch, { grade_weight: w, grade_price_sold: sold, grade_price_received: recv,
            grade_sold: String(given('grade_sold') || '').slice(0, 80), grade_received: String(given('grade_received') || '').slice(0, 80) });
    } else {
        // Unreachable while ASSESSMENTS and these branches agree, and that is
        // the point: the next assessment added to the list fails HERE, loudly,
        // instead of being written with claim_amount silently null.
        throw new Error(`assessment '${kind}' is in ASSESSMENTS but helpers/claims.js has no branch for it`);
    }
    patch.claim_amount = claim_amount;
    const NOTES = {
        contamination: 'contamination assessed',
        quality: 'quality claim assessed',
        sorted: 'sorted contaminants assessed',
        grade: 'downgrade assessed',
    };
    return update(id, patch, by, NOTES[kind] || `${kind} assessed`);
}

// ── DELETE (2026-10-14) ────────────────────────────────────────────────────
// the owner: "Option to delete a claim add it". A claim is a money record, so it
// is never just dropped: the whole record is written to claims-deleted.json
// FIRST (and the delete refused if that write fails), then taken out of the
// register. The archive is what makes a mistaken delete recoverable by hand.
// Documents already filed on Drive are left where they are.
const ARCHIVE = () => path.join(cfg.DATA_DIR, 'claims-deleted.json');
async function remove(id, by = 'manager') {
    const c = get(id);
    if (!c) throw new Error('no such claim');
    const now = new Date().toISOString();
    await mutateJson(ARCHIVE(), [], (all) => { all.push({ deleted_at: now, deleted_by: by, claim: c }); return all; }, { strict: true });
    await mutateJson(FILE(), [], (all) => all.filter((x) => !(x && x.id === id)), { strict: true });
    return c;
}

// Recovery from the supplier. This is the half of a claim that is actually
// actionable, and the half that keeps not happening: most of what Sample has
// absorbed is a recovery nobody raised.
async function raiseRecovery(id, { our_claim, note } = {}, by = 'manager') {
    const patch = { status: 'recovery_raised' };
    if (our_claim !== undefined) patch.our_claim = num(our_claim);
    if (note) patch.note = note;
    return update(id, patch, by, 'recovery raised on supplier');
}

async function setStatus(id, status, by = 'manager', note) {
    if (!STATUSES.includes(status)) throw new Error(`status must be one of ${STATUSES.join(', ')}`);
    return update(id, note ? { status, note } : { status }, by, `status → ${status}`);
}

// Append a mail to a claim's trail. Returns {added, changed} — `changed` is
// true when the customer's own figure moved, which is a negotiation event
// somebody has to see, not an overwrite to apply silently.
async function addMail(id, mail = {}, seen = {}) {
    const c = get(id);
    if (!c) return { added: false, changed: false };
    const already = (c.mail || []).some((m) => m && m.message_id && m.message_id === mail.message_id);
    if (already) return { added: false, changed: false };

    const changed = seen.claimed_weight != null && num(c.claimed_weight) != null
        && Math.abs(num(seen.claimed_weight) - num(c.claimed_weight)) > 1e-6;
    const patch = { mail: [...(c.mail || []), mail] };
    if (changed) {
        patch.flags = [...new Set([...(c.flags || []), FLAG_FIGURE_CHANGED])];
        patch.note = `${c.note ? c.note + ' | ' : ''}customer figure moved ${c.claimed_weight} → ${seen.claimed_weight}`;
    }
    await update(id, patch, 'claims', changed ? 'another mail — figure changed' : 'another mail on this claim');
    return { added: true, changed };
}

// ── THE NUMBERS THE PAGE LEADS WITH ─────────────────────────────────────────
// Net is what Sample actually absorbs: claimed against it, less what it got back
// from the supplier. That is the figure the sheet could never produce, because
// no formula could total seven stacked tables.
function stats(rows) {
    const all = (rows || list()).filter(Boolean);
    const live = all.filter((c) => !['rejected', 'withdrawn'].includes(c.status));
    const sum = (f) => live.reduce((t, c) => t + (num(c[f]) || 0), 0);
    const claimed = sum('claim_amount');
    const recovered = sum('our_claim');
    const unverified = all.filter((c) => c.status === 'unverified');
    return {
        total: all.length,
        claimed, recovered, net: Math.round((claimed - recovered) * 100) / 100,
        recovery_rate: claimed > 0 ? Math.round((recovered / claimed) * 1000) / 10 : 0,
        unverified: unverified.length,
        awaiting_recovery: live.filter((c) => c.status === 'verified' && !num(c.our_claim)).length,
        open: live.filter((c) => !['settled'].includes(c.status)).length,
        by_status: STATUSES.reduce((o, s) => { o[s] = all.filter((c) => c.status === s).length; return o; }, {}),
        // Grouped by whatever kinds actually turned up, not by a fixed set.
        by_kind: live.reduce((o, c) => {
            const k = c.claim_type || '(not classified)';
            if (!o[k]) o[k] = { claims: 0, claimed: 0 };
            o[k].claims += 1; o[k].claimed += num(c.claim_amount) || 0;
            return o;
        }, {}),
        unclassified: all.filter((c) => !c.claim_type).length,
    };
}

module.exports = {
    list, get, findByKey, keyOf, create, update, verify, assess, raiseRecovery, setStatus, addMail, stats, remove,
    ASSESSMENTS, FINDINGS, MEASURED_BY,
    convert, toMT, newId, blank,
    STATUSES, UNITS,
    FLAG_NO_UNIT, FLAG_UNKNOWN_CONTAINER, FLAG_FIGURE_CHANGED, FLAG_NO_SUPPLIER, FLAG_KIND_UNKNOWN,
    FILE,
};
