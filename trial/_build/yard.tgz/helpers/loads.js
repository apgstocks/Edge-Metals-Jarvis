const { mutateJson: mutateJsonRaw, loadJson, loadSettings } = require('./json');

// ── EVERY WRITE HERE IS STRICT ────────────────────────────────────────────
//
// the owner, 2026-09-21: "i have a load added on 21-sep in yard but in website
// ,latest load is 19-sep" — and the load was gone from the app too after a
// restart. It was never on the server.
//
// helpers/json.js's mutateJson defaults to strict:false, which LOGS a failed
// write and RETURNS THE FILE'S PREVIOUS CONTENTS. For a store that self-heals
// on the next change that is the right default. For this one it means: the
// write fails, addLoad returns the record anyway, the route answers 200, the
// app shows the load, and the next read has never heard of it. She weighs a
// truck, prices it, the seller signs, and the load is gone.
//
// The money stores were fixed for exactly this on 2026-09-xx — payments,
// expenses, petty cash, trucker bills, bills, sales all opt in. loads.json
// was missed, and it is the yard's PRIMARY ledger: every amount, every
// weight, every seller signature hangs off it.
//
// Wrapped once rather than passing the option at each call site, the same
// way helpers/pettyCash.js does it, so a new write cannot be added without
// it. `getInventoryReport` and the other readers are untouched — reads were
// never the danger.
const mutateJson = (file, dflt, fn) => mutateJsonRaw(file, dflt, fn, { strict: true });
const cfg = require('../config');

function loadLoads() {
    return loadJson(cfg.LOADS_FILE, []);
}

function round2(n) {
    return typeof n === 'number' && isFinite(n) ? Math.round(n * 100) / 100 : null;
}
function toNum(v) {
    const n = typeof v === 'number' ? v : parseFloat(v);
    return isFinite(n) ? n : null;
}

// REAL BUG, found 2026-08-17 from production logs: "[SEND] Failed ->
// 15550100100@c.us: No LID for user". That looked at first like purely the
// unresolved upstream whatsapp-web.js "LID" bug (see api.js's send-to-seller
// route comment) — but15550100100 is the SAME number already on file
// elsewhere in this app as 15550100100 (data/truckers.json,
// data/suppliers.json, the manager number placeholder — every working
// WhatsApp number in this codebase carries India's "91" country code
// prefix). The old normalization here only stripped non-digits; a seller
// phone typed the natural local way ("15550100100", no country code) was
// stored exactly like that — 10 raw digits isn't a real WhatsApp ID at
// all, so of course WhatsApp can't resolve a LID for it. That's on us,
// not (only) the upstream bug. Assumes India (91) for a bare 10-digit
// number, matching the one country code convention already used
// everywhere else in this app; anything already carrying a country code
// (11+ digits) is left alone. Not a perfect general solution (a genuine
// non-Indian 10-digit number would get mis-prefixed), but it matches every
// other number already in this system and fixes the actual failure mode
// seen in production.
function normalizeSellerPhone(raw) {
    const digits = String(raw || '').replace(/\D/g, '');
    if (!digits) return null;
    // 2026-11-18: the owner — "to whatever i type 9 is getting auto appended". A 10-digit number used to get India's 91
    // put in front, which broke US sellers. She chose: add nothing, the number is kept exactly as typed (digits only).
    return digits;
}

// Gross/tare/net/price/amount are captured PER ITEM now (a load is often
// several items, each weighed separately, not one shared load-level
// weight) — this is the one place that's the source of truth for those
// numbers; the client sends its own live-computed net/amount too, but they
// get recomputed here from gross/tare/price rather than trusted as-is, same
// as it always has been for the whole-load version of this math.
// ── THE CONSTANT MOVED, 2026-10-10 ──────────────────────────────────────
// It used to live here as `LB_PER_MT = 2204.62`, with a comment promising
// that "if it ever changes it changes in all of them" across the four
// copies. That promise is what helpers/priceUnits.js now keeps mechanically,
// and three more units arrived today — so the copy here would have been a
// dead constant still claiming to be authoritative, which is worse than no
// comment at all. The divisors are in priceUnits.LB_PER.

function computeItem(it) {
    const gross = toNum(it.gross_weight);
    const tare  = toNum(it.tare_weight);
    const net   = (gross != null && tare != null) ? round2(gross - tare) : null;
    const price = toNum(it.price);
    // ── PRICED PER POUND OR PER TONNE, ROW BY ROW (2026-09-24) ──────────────
    // the owner: "IN SAMPLE YARD CO YARD LOAD APP,IT SHOULD HAVE A PROVISION TO CALCULATE
    // AMOUNT BY USING MT OR LBS ROWISE.BY DEFAULT LBS SHOULD BE ENABLED".
    //
    // `unit` was already being STORED here and ignored by the arithmetic,
    // which is the dangerous half of the pair: this function is the source of
    // truth — the client's own figures are recomputed here rather than
    // trusted — so a row the screen priced per tonne would have been
    // overwritten with the per-pound answer on save, silently, and the ticket
    // would print a number nobody chose. That is the shape of the invoice bug
    // that billed 260831_SU_26EM05 at $13.09 instead of $28,860.80.
    //
    // THE NET IS NOT CONVERTED. It is what the weighbridge said, in pounds,
    // and it goes on the ticket the seller signs. Only the QUANTITY the price
    // multiplies changes, so a pound row is arithmetically untouched — 'lb'
    // and a missing unit both take the same branch, which is what makes every
    // load already on file safe.
    //
    // ── AND SINCE 2026-10-10, FIVE UNITS RATHER THAN TWO ────────────────────
    // the owner: "in sample yard co yard app,in addition to lbs-MT-Item can be /piece as
    // well. and gross ton and net ton as well." Net ton is 2,000 lb and gross
    // ton is 2,240 — twelve per cent apart, and both are called "a ton" in
    // conversation, which is the whole reason they are separate codes here
    // rather than one.
    //
    // The divisors moved to helpers/priceUnits.js because this arithmetic
    // existed in FOUR places and three units in four copies is how they
    // drift. /piece is not a divisor at all — it multiplies a COUNT, which is
    // the `pieces` field below, new today.
    //
    // priceUnits.qtyFor THROWS on a unit it does not recognise instead of
    // treating it as pounds. That is deliberate and it is the point: a row
    // marked /piece that fell through to the pound branch would price 46,560
    // lb at $5 a piece as $232,800, and nobody would see it. The throw
    // reaches addLoad's caller as a 500 with the unit named in it, which is
    // noisy and recoverable; the silent version is neither.
    const PU = require('./priceUnits');
    const pieces = toNum(it.pieces);
    const unit = PU.normalise(it.unit);
    if (unit === null) {
        throw new Error(`"${it.unit}" is not a unit Jarvis prices in — a load item takes `
            + PU.ORDER.map((k) => PU.LABEL[k]).join(', '));
    }
    const amount = PU.amountFor({ unit, net, pieces, price });
    return {
        description: it.description || '',
        // Ferrous / non-ferrous (2026-11-17): 'ferrous', 'non-ferrous' or null (Unsorted). Never guessed here;
        // addLoad/updateLoad fill it from the learned map first. See helpers/itemMetal.js.
        metal_type: require('./itemMetal').normType(it.metal_type),
        gross_weight: gross, tare_weight: tare, net_weight: net,
        // STORED AS '' WHEN IT IS POUNDS AND WAS ALREADY ''. Writing 'lb'
        // into every historic row on its next edit would be a migration
        // nobody asked for, performed one row at a time by whoever happened
        // to open a load — and the sheet sync compares these fields, so it
        // would report disagreements she did not cause.
        price, unit: unit === 'lb' ? (it.unit || '') : unit,
        // Only ever set for a counted unit. A pieces value left on a row
        // whose unit was changed back to a weight is dropped rather than
        // carried, so it cannot come back to life if the unit changes again.
        pieces: PU.isCounted(unit) ? pieces : null,
        amount,
        // Carried forward from the incoming item if present — matters for
        // EDITS, where the client sends back photo links an item already
        // has so they aren't lost just because that item wasn't
        // re-photographed this time. Defaults to null for a brand-new item,
        // same as before. api.js overwrites these after upload when a NEW
        // photo (gross_photo_base64/tare_photo_base64) came in for this item.
        gross_photo_drive_id: it.gross_photo_drive_id || null, gross_photo_link: it.gross_photo_link || null,
        tare_photo_drive_id : it.tare_photo_drive_id  || null, tare_photo_link : it.tare_photo_link  || null,
    };
}

// ── HAULAGE DEDUCTED FROM WHAT THE SELLER IS PAID ───────────────────────
//
// the owner, 2026-09-20, asked "in yard app,what if my load includes trucking?"
// and then said BOTH things happen depending on the seller: sometimes she
// pays an outside hauler separately and the seller still gets his full
// price, and sometimes she collects the metal herself and pays the seller
// LESS by the haulage. The first case already worked — helpers/truckerBills.js
// is a payables ledger of its own and its payments reach the spend report.
// The second had nowhere to live: the only ways to record it were to drop
// the price per lb, which puts a figure on the signed ticket the seller never
// agreed to and then flows into Inventory as a false cost, or to pay him in
// full and book the haulage separately, which shows the whole amount leaving
// petty cash and makes the deduction invisible.
//
// THREE FIELDS, NOT FIVE. helpers/bills.js splits trucking into Line Haul,
// Port Fees, Chassis Rent, Dry Run and Extra Scale. Those are drayage words —
// a container coming off a ship. A truck collecting scrap from a seller's
// shop has no port fee and no chassis to rent, and a form full of boxes that
// are always blank is a form people stop reading. My call, not hers: if the
// yard ever needs the breakdown it can be added, but it should be added
// because a real charge had nowhere to go, not for symmetry with Metals.
//
// `amount` IS NOT REDUCED. Same rule bills.js states for a supplier invoice:
// amount stays what the metal came to, which is the figure printed on the
// ticket the seller signs, and the deduction lands in a separate net_payable.
// Netting it in place would mean her record and his copy never agree again.
function cleanTrucking(entry) {
    const company = String(entry.trucking_company || '').trim();
    const note    = String(entry.trucking_note || '').trim();
    return {
        trucking_company: company || null,
        trucking_amount : toNum(entry.trucking_amount),
        trucking_note   : note || null,
    };
}

// amount less haulage. null amount stays null — a load with no priced items
// has no payable, and 0 - trucking would invent a debt the seller owes HER.
// ── AND A CLAIM, WHEN SHE HAS CHOSEN TO ADJUST ONE IN ────────────────────
// the owner, 2026-10-01: "if load payment not already made,ask user whether it
// can be adjusted in load invoice?"
//
// A THIRD, OPTIONAL argument rather than a new function. Every existing
// caller passes two and keeps the exact arithmetic it had — the deduction is
// zero when nothing is passed, so a load with no claim is byte-identical to
// before. helpers/yardActions.js:187 and the two call sites in this file all
// read correctly unchanged.
//
// It folds into net_payable at WRITE time, exactly as trucking does, which
// is the important part: payableOf stays a pure read of the record. Making
// it consult the claims store instead would put a file read inside a
// function with twenty callers, several of them in loops — yardBrief.js
// calls it per load — and turn one figure into N reads.
//
// Only an ADJUSTED claim belongs here. A claim she is chasing separately
// must NOT reduce what he is owed: she is going to pay him in full and get
// the money back, and deducting it as well would pay him twice less.
// helpers/yardClaims.js keeps those apart, and openAmountForLoad counts only
// the unsettled ones for exactly this reason.
function payableFrom(amount, trucking, claim) {
    const amt = toNum(amount);
    if (amt === null) return null;
    return round2(amt - (toNum(trucking) || 0) - (toNum(claim) || 0));
}

// THE SINGLE READER. Every place that asks "what is this seller owed" goes
// through here rather than reaching for `.amount` itself, because there are
// twenty of them and a figure that disagrees between the load card, the
// ticket, the pay sheet and what Jarvis says out loud is worse than no
// figure at all. Falls back to `amount` for every load recorded before this
// existed — those have no net_payable key and must read as "no deduction".
function payableOf(load) {
    if (!load) return null;
    return load.net_payable !== undefined && load.net_payable !== null
        ? load.net_payable : (load.amount ?? null);
}

// Load-level gross/tare/net/amount are SUMS across items — kept on the
// record too so the card deck and PDF summary don't have to re-derive them
// every time they're displayed.
function sumItems(items) {
    const sum = (key) => {
        const vals = items.map(it => it[key]).filter(v => v != null);
        return vals.length ? round2(vals.reduce((a, b) => a + b, 0)) : null;
    };
    return { gross_weight: sum('gross_weight'), tare_weight: sum('tare_weight'), net_weight: sum('net_weight'), amount: sum('amount') };
}

// Sequential, human-readable load IDs (SAMPLE_01, SAMPLE_02, ...) instead of the
// old LOAD-<timestamp>-<random> — per the owner, easier to read off a ticket or
// say out loud on the yard floor than a random string. Computed from the
// current MAX existing SAMPLE_N suffix (ignores old LOAD-... records, which
// just means numbering starts fresh at SAMPLE_01 the first time this runs — no
// migration needed, old records keep their old ids). This MUST run inside
// the mutateJson callback below (i.e. under the file lock), not before it —
// computing it earlier would let two concurrent saves both read the same
// "current max" and mint the same ID.
// next_load_number (Settings > Yard, dashboard-editable — see helpers/json.js's
// loadSettings) is a FLOOR, not a one-shot override: added per the owner
// 2026-08-15 ("add that admin setting under yard... so next time it will
// start from this, unless explicitly mentioned it should run in sequence").
// Whichever is higher — the scanned max+1 above, or this floor — wins, so
// setting it once (e.g. to skip ahead to SAMPLE_500 for a new ticket book)
// naturally keeps sequencing from there on every SUBSEQUENT call without
// needing to be cleared or re-applied: once a load using the floor exists,
// the scan above finds IT as the new max and takes over. No extra state to
// go stale. "Unless explicitly mentioned" = renumberLoad (see below) lets
// any single load jump anywhere regardless of this floor.
function nextLoadId(loads) {
    let max = 0;
    for (const l of loads) {
        const m = /^SAMPLE_(\d+)$/.exec(l.id || '');
        if (m) max = Math.max(max, parseInt(m[1], 10));
    }
    const floor = parseInt(loadSettings().next_load_number, 10);
    if (isFinite(floor) && floor > max + 1) max = floor - 1;
    return `SAMPLE_${String(max + 1).padStart(2, '0')}`;
}

// Enforced at save time for BOTH create and edit — per the owner, once an item
// row has any data in it at all, description + gross weight + tare weight
// are all mandatory before the load can be saved. This is a hard block, not
// a warning: she explicitly confirmed a load should NOT be saveable with an
// item that's only gross-weighed and waiting on tare (e.g. truck hasn't
// returned yet) — that item must be completed (or removed) before Save
// works at all, no partial saves.
//
// FIELD MAPPING (corrected 2026-08-15 per the owner, "no. buyer should be edge
// trading"): `seller`/`seller_address` are the free-text, EDITABLE fields —
// the outside company Sample Yard Co Trading is buying scrap FROM, entered by
// dashboard/mobile-app staff (with Address Book autocomplete). `buyer`/
// `buyer_address` are the FIXED constant, always "Sample Yard Co Trading" — Sample
// Trading is the one buying the material, so it's the buyer. Required here
// is `entry.seller`, not `entry.buyer`: a load must have a real counterparty
// name, while the buyer side is always the same and never blank anyway.
// This is a real, non-bypassable gate rather than trusted from the request
// body — this function is the single choke point both POST /api/loads and
// PUT /api/loads/:id run through (via addLoad/editLoad below), so any
// current or future client hitting the API directly is covered too, not
// just the two UIs that already validate this client-side first.
// A row with NOTHING filled in at all is treated as an unused spare row
// (e.g. "+ Add item" clicked by mistake) and silently skipped, same as the
// existing filter that drops fully-blank items before they're saved — it's
// not "an item" yet, so it isn't held to the same completeness bar.
// ── A LOAD CANNOT BE WORTH MINUS MONEY (2026-11-08) ──────────────────────
// the owner: "A mistyped tare weight creates a load worth minus money fix it".
//
// Found by tests/sample-yard-scenarios.js: gross 1,000 with tare 4,000 — the
// slip you make typing two numbers at a scale — saved happily as net_weight
// -3000, amount -3000, net_payable -3000, with no warning. That load then
// SUBTRACTS from what the seller is owed, from stock and from the day's
// totals, and nothing flags it. It is only found by someone noticing a total
// looks wrong, weeks later.
//
// ── WHY THE CHECK IS ON THE TOTAL AND NOT ON EACH ROW ───────────────────
// The obvious rule is "tare must never exceed gross". Her live data says no.
// Scanning all 233 purchases and 17 sales on 2026-11-08 found exactly one
// row that breaks it: load SAMPLE_90, 2026-09-26, Beto — a single Auto cast
// line of gross -100 / net -100 / -$105 sitting inside a perfectly healthy
// $22,938.74 load whose paperwork is already generated. That is somebody
// correcting an over-weigh, and it is legitimate.
//
// A per-row rule would have locked her out of editing that real load. The
// rule she actually asked for is about the LOAD being worth minus money, so
// that is what is checked: the totals that are about to be stored. One
// negative correction row inside a positive load still saves; a load that
// comes out negative does not.
//
// ── WHERE IT LIVES ───────────────────────────────────────────────────────
// Called from addLoad and editLoad, right after sumItems, so it judges the
// EXACT numbers being written rather than recomputing them a second way and
// risking the two disagreeing.
//
// updateLoad is deliberately NOT touched. It is a plain patch merge that
// never recomputes totals, and two of its callers send no items at all —
// the seller-signature stamp (routes/yard.js:740) and the PDF stamp
// (helpers/loadsPdf.js:161). Putting a totals rule there would have broken
// both, which is exactly the shape of mistake CLAUDE.md rule 1 describes.
function assertLoadNotNegative(totals, items) {
    const neg = [];
    if (Number(totals.net_weight) < 0) neg.push(`net weight ${totals.net_weight}`);
    if (Number(totals.amount) < 0) neg.push(`value ${totals.amount}`);
    if (!neg.length) return;
    // Name the rows that look like the typo, so she can go straight to it
    // instead of hunting a long ticket for the one that is wrong.
    const culprits = (items || [])
        .filter((it) => Number(it.net_weight) < 0)
        .map((it) => `${it.description || 'row'} (gross ${it.gross_weight}, tare ${it.tare_weight})`);
    throw new Error(
        `This load comes out at ${neg.join(' and ')}, which cannot be right. `
        + (culprits.length
            ? `Check the weights on ${culprits.join('; ')} — a tare heavier than the gross `
              + 'usually means the two were typed the wrong way round.'
            : 'Check the weights.'));
}

function validateLoadForSave(entry) {
    if (!entry.seller || !String(entry.seller).trim()) {
        throw new Error('Validation: seller is required.');
    }
    const items = Array.isArray(entry.items) ? entry.items : [];
    items.forEach((it, i) => {
        // Tare EXCLUDED from this check, per the owner 2026-08-15 ("by default
        // tare should be zero, unless user overrides") — the dashboard/mobile
        // forms now pre-fill every new item row's tare with "0" rather than
        // leaving it blank, which would otherwise make hasAnyData true for
        // an untouched spare row (a non-empty "0" is truthy) and wrongly
        // force it through full validation just for existing. A row only
        // counts as "an item" once description, gross weight, or price is
        // actually entered.
        const hasAnyData = it.description || it.gross_weight || it.price;
        if (!hasAnyData) return;
        const label = it.description ? `"${it.description}"` : `#${i + 1}`;
        if (!it.description || !String(it.description).trim()) {
            throw new Error(`Validation: item ${label} is missing a description.`);
        }
        if (it.gross_weight === null || it.gross_weight === undefined || it.gross_weight === '' || !isFinite(parseFloat(it.gross_weight))) {
            throw new Error(`Validation: item ${label} is missing a gross weight.`);
        }
        if (it.tare_weight === null || it.tare_weight === undefined || it.tare_weight === '' || !isFinite(parseFloat(it.tare_weight))) {
            throw new Error(`Validation: item ${label} is missing a tare weight.`);
        }
    });
}

async function addLoad(entry) {
    validateLoadForSave(entry);
    // ── ONE METAL, ONE SPELLING ──────────────────────────────────────
    // the owner, 2026-09-16: "if i saved description say HMS and when i type
    // ike hms in small,it i considering that as a new item." Case only —
    // see helpers/itemSpelling.js for why this is not the alias feature and
    // must never grow into it.
    const _known = require('./itemSpelling').knownSpellings();
    const items = Array.isArray(entry.items)
        ? require('./itemMetal').fill(require('./itemSpelling').canonicaliseItems(entry.items, _known)).map(computeItem) : [];
    await require('./itemMetal').learnFromItems(items);
    const totals = sumItems(items);
    assertLoadNotNegative(totals, items);

    const rec = {
        id            : null, // assigned below, under the lock — see nextLoadId
        created_at    : new Date().toISOString(),
        created_by    : entry.created_by || 'unknown',
        date          : entry.date || null,
        seller        : entry.seller || null,
        seller_address: entry.seller_address || null,
        // Optional — per the owner 2026-08-17 ("add phone number option in
        // application for seller"). Not run through validateLoadForSave;
        // unlike seller (a hard-required counterparty name), a load should
        // still save fine without a phone on file. Digits only, same
        // normalization as helpers/pricelist.js's contact numbers — kept
        // raw here (not @c.us-suffixed) since this is a data field, not a
        // chat id; the send-to-seller route builds the chat id from it.
        seller_phone  : normalizeSellerPhone(entry.seller_phone),
        // A label, not a ledger: see helpers/loadCompany.js.
        buyer         : require('./loadCompany').chooseBuyer(entry, null),
        buyer_address : entry.buyer_address || null,
        description   : entry.description || '',
        items,
        gross_weight  : totals.gross_weight,
        tare_weight   : totals.tare_weight,
        net_weight    : totals.net_weight,
        amount        : totals.amount,
        // Optional haulage deducted from what the seller is paid — see
        // cleanTrucking above. A create has no prior state to preserve, so
        // these come straight off the request; editLoad is where absence has
        // to mean "leave it alone".
        ...cleanTrucking(entry),
        // ── A CLAIM SHE CHOSE TO ADJUST IN ──────────────────────────────
        // the owner 2026-10-01. Always null on a CREATE: a claim is raised
        // against a load that already exists, never typed on the form that
        // makes one. Present as a key from the start so no reader has to
        // treat its absence as a special case.
        claim_amount  : null,
        net_payable   : payableFrom(totals.amount, entry.trucking_amount, null),
        weight_unit   : entry.weight_unit || 'lb',
        pdf_drive_id  : null, pdf_link: null,
        weights_pdf_drive_id: null, weights_pdf_link: null,
        receipt_pdf_drive_id: null, receipt_pdf_link: null,
        // Seller signature (data URL from the app's signature pad) — per
        // the owner 2026-08-17. Reset here alongside the PDF links on an edit:
        // a signature attests to specific numbers, so once those numbers
        // change the old signature no longer means anything and must not
        // silently carry over onto a re-generated ticket.
        seller_signature: null, seller_signed_at: null,
        status        : 'open',
    };

    // ── ONE SAVE, ONE RECORD ─────────────────────────────────────────────
    // The same guard as addOutboundLoad's, added at the same time and for
    // the same reason. the owner hit this on a SALE ("I just added one.But two
    // ones are created"), but nothing about the cause was specific to sales
    // — a purchase is saved by the same button, in the same modal, through
    // the same api() helper. Fixing only the screen where it was noticed
    // would leave the identical hole open on the side of the business that
    // records money going OUT, which is the worse one to double.
    //
    // See helpers/oncePerSave.js for what was ruled out. The lookup runs
    // inside the mutator so it is under the file lock.
    rec.client_request_id = require('./oncePerSave').normTicket(entry.client_request_id);
    // ── ONE DRAFT, ONE LOAD ──────────────────────────────────────────────
    // the owner, 2026-09-29: "ALWAYS ONE LOAD SHOULD BE CREATED". The ticket
    // above is per save ATTEMPT and cannot carry that; this is per draft and
    // never expires. See helpers/oncePerSave.js. Absent (voice path, a save
    // that never autosaved) behaves exactly as before.
    rec.draft_id = require('./oncePerSave').normDraftId(entry.draft_id);
    let already = null;
    await mutateJson(cfg.LOADS_FILE, [], (loads) => {
        const once = require('./oncePerSave');
        already = once.findSpent(loads, rec.client_request_id)
            || once.findByDraft(loads, rec.draft_id);
        if (already) return loads;   // unchanged — nothing written
        // ── ONE SELLER, ONE SPELLING ─────────────────────────────────────
        // the owner, 2026-09-16: "Sellers name/bUyers name-make it case
        // insensitive". Grouping the REPORTS case-insensitively fixes the
        // totals; it does not fix a printed ticket, and two tickets for the
        // same man carrying two spellings of his name is the part she sees
        // on paper. So a name that already exists under a different case is
        // stored the way SHE established it.
        //
        // Nothing is invented — no title-casing. "MK Metal Trading", "d.c.
        // scrap", "JB's" are real names and a rule that rewrites them is a
        // rule that gets fought. A genuinely new name is stored exactly as
        // typed and becomes the established one. Same rule
        // helpers/vendorFromText.js already applies to expense vendors.
        //
        // Inside the lock, so it reads the list this record is about to join.
        rec.seller = require('./canonicalName').canonicalName(loads.map((l) => l.seller), rec.seller);
        rec.id = nextLoadId(loads);
        loads.unshift(rec);
        if (loads.length > 5000) loads.length = 5000;
        return loads;
    });

    return already || rec;
}

async function updateLoad(id, patch) {
    return mutateJson(cfg.LOADS_FILE, [], (loads) => {
        const l = loads.find(x => x.id === id);
        if (l) Object.assign(l, patch, { updated_at: new Date().toISOString() });
        return loads;
    });
}

// Edits an EXISTING load's core fields + items — used by the dashboard's
// Edit button, distinct from the generic patch-only updateLoad above (which
// is for narrower things like stamping pdf_link after generation and
// shouldn't run the full item recompute). Items go through the SAME
// computeItem/sumItems math as addLoad so gross/tare/net/price/amount stay
// internally consistent after an edit rather than trusting whatever the
// client sent. Deliberately clears any previously generated PDF links and
// resets status to 'open': a PDF generated before this edit no longer
// reflects the edited numbers, so leaving "View PDF" showing as if it's
// still current would be actively misleading — the card falls back to a
// fresh "Generate PDF" button until it's regenerated.
async function editLoad(id, entry) {
    validateLoadForSave(entry);
    // ── ONE METAL, ONE SPELLING ──────────────────────────────────────
    // the owner, 2026-09-16: "if i saved description say HMS and when i type
    // ike hms in small,it i considering that as a new item." Case only —
    // see helpers/itemSpelling.js for why this is not the alias feature and
    // must never grow into it.
    const _known = require('./itemSpelling').knownSpellings();
    const items = Array.isArray(entry.items)
        ? require('./itemMetal').fill(require('./itemSpelling').canonicaliseItems(entry.items, _known)).map(computeItem) : [];
    await require('./itemMetal').learnFromItems(items);
    const totals = sumItems(items);
    assertLoadNotNegative(totals, items);

    const patch = {
        date          : entry.date || null,
        seller        : entry.seller || null,
        seller_address: entry.seller_address || null,
        seller_phone  : normalizeSellerPhone(entry.seller_phone),
        buyer         : entry.buyer || null, // settled against what is on file inside the lock, below
        buyer_address : entry.buyer_address || null,
        description   : entry.description || '',
        items,
        gross_weight  : totals.gross_weight,
        tare_weight   : totals.tare_weight,
        net_weight    : totals.net_weight,
        amount        : totals.amount,
        weight_unit   : entry.weight_unit || 'lb',
        pdf_drive_id  : null, pdf_link: null,
        weights_pdf_drive_id: null, weights_pdf_link: null,
        receipt_pdf_drive_id: null, receipt_pdf_link: null,
        // Seller signature (data URL from the app's signature pad) — per
        // the owner 2026-08-17. Reset here alongside the PDF links on an edit:
        // a signature attests to specific numbers, so once those numbers
        // change the old signature no longer means anything and must not
        // silently carry over onto a re-generated ticket.
        seller_signature: null, seller_signed_at: null,
        status        : 'open',
    };

    // ── A MISSING TRUCKING FIELD MEANS LEAVE IT, NOT CLEAR IT ────────────
    //
    // Every other field above is in the patch unconditionally, which is right
    // for them: both forms always send all of them, so an absent one means
    // blank. Trucking cannot work that way, and the reason is her phone. The
    // APK installed on it was built before this field existed and will keep
    // posting edits without it for as long as it takes to ship a new build —
    // under the usual rule, every edit she makes on the phone would silently
    // wipe a deduction she entered at the desk, and she would find out by
    // paying a seller $200 too much. So absence PRESERVES.
    //
    // Clearing still works from either form, because both send the key with
    // an empty value once they know about it, and an empty value is null.
    const truckingGiven = ('trucking_amount' in entry) || ('trucking_company' in entry)
        || ('trucking_note' in entry);
    const truckingPatch = truckingGiven ? cleanTrucking(entry) : null;

    const loads = await mutateJson(cfg.LOADS_FILE, [], (loads) => {
        const l = loads.find(x => x.id === id);
        if (l) {
            const priorBuyer = l.buyer;
            Object.assign(l, patch, { updated_at: new Date().toISOString() });
            l.buyer = require('./loadCompany').chooseBuyer(entry, priorBuyer);
            if (truckingPatch) Object.assign(l, truckingPatch);
            // Recomputed here, inside the lock, from whatever SURVIVED the
            // two assignments above — not from `entry`. The items can change
            // on an edit that never mentions trucking, and a net_payable left
            // over from the old amount is a wrong number that looks right.
            // ── AND THE CLAIM, OR AN EDIT WIPES IT ──────────────────────
            // l.claim_amount, NOT entry's: a claim is not on this form, so an
            // edit never mentions it. Leave it out of this call and
            // correcting a typo on a load silently hands the supplier back
            // money she had deducted — the same trap this file already
            // records springing on pdf_link, and outboundLoads.js on
            // delivery_status and draft_id. Third time on this shape.
            l.net_payable = payableFrom(l.amount, l.trucking_amount, l.claim_amount);
        }
        return loads;
    });
    return loads.find(l => l.id === id) || null;
}

// Removes a load record entirely. Deliberately does NOT touch anything in
// Drive (item photos, previously generated PDFs) — those stay put as an
// audit trail rather than silently vanishing just because the dashboard
// entry was deleted; only the loads.json record itself goes away.
async function deleteLoad(id) {
    let found = false;
    await mutateJson(cfg.LOADS_FILE, [], (loads) => {
        const idx = loads.findIndex(x => x.id === id);
        if (idx === -1) return loads;
        found = true;
        loads.splice(idx, 1);
        return loads;
    });
    return found;
}

function getLoad(id) {
    return loadLoads().find(l => l.id === id) || null;
}

// Changes an existing load's id (e.g. "SAMPLE_07" -> "SAMPLE_12") — added per
// the owner 2026-08-15 ("there should be a way to adjust the load number").
// Validation runs BEFORE mutateJson, not by throwing inside its mutator.
//
// UPDATED 2026-09-21, because the reason changed and a stale reason is worse
// than none. It used to say mutateJson SWALLOWS a throw from the mutator and
// returns the unmodified data, so a thrown "not found" would look like
// success. That was true of this file until today; it is not any more —
// every write here is now strict (see the top of this file) and a throw
// propagates.
//
// The pattern stays, for a different and still-good reason: these are not
// write failures, they are "you asked for something that is not there".
// Checking first and capturing a result keeps the distinction between a
// REFUSAL and a CRASH, which is the difference between "that number is
// already taken" and a 500. Same reasoning as deleteLoad's `found` flag.
// Does NOT touch Drive — the caller (api.js's PUT /:id/renumber route) is
// responsible for renaming the load's Drive subfolder to match, since this
// file has no Drive dependency and shouldn't grow one just for this.
async function renumberLoad(oldId, newId) {
    newId = String(newId || '').trim();
    if (!newId) throw new Error('New load number is required.');
    if (newId === oldId) throw new Error('That\'s already this load\'s number.');

    const existing = loadLoads();
    if (!existing.some(x => x.id === oldId)) throw new Error(`Load ${oldId} not found.`);
    if (existing.some(x => x.id === newId)) throw new Error(`Load ${newId} already exists — choose a different number.`);

    let renamed = null;
    await mutateJson(cfg.LOADS_FILE, [], (loads) => {
        const l = loads.find(x => x.id === oldId);
        if (!l) return loads;
        if (loads.some(x => x.id === newId)) return loads; // race guard, belt & suspenders
        l.id = newId;
        l.updated_at = new Date().toISOString();
        renamed = l;
        return loads;
    });
    if (!renamed) throw new Error(`Could not renumber ${oldId} — it may have just changed. Try again.`);
    return renamed;
}

// Item-type inventory + per-day load rollup across a set of loads —
// computed FRESH from whatever's currently in loads.json every call, never
// a separately maintained running counter. Per the owner 2026-08-15 ("it keeps
// on adding inventory as per the load creation. if a load gets deleted it
// should also get modified"): the only way a deleted load automatically
// disappears from the inventory with zero extra bookkeeping is if nothing
// was ever incrementally accumulated in the first place — this just
// re-scans current loads every time it's called (same approach already
// used for the yard report's all-time section), so a delete is reflected on
// the very next read, no separate cleanup step needed anywhere.
// `from`/`to` are optional 'YYYY-MM-DD' strings (inclusive) — a load with no
// date is excluded whenever a filter is active (can't place it in range),
// but included when no filter is applied at all.
function getInventoryReport(allLoads, { from, to } = {}) {
    const { groupItemsByDescription } = require('./pdf');
    const filtered = (from || to)
        ? allLoads.filter(l => l.date && (!from || l.date >= from) && (!to || l.date <= to))
        : allLoads;

    const items = filtered.flatMap(l => Array.isArray(l.items) ? l.items : []);
    let byType = items.length ? groupItemsByDescription(items) : [];

    // ── HOW MANY LOADS CARRIED THIS ITEM ────────────────────────────────
    // the owner, 2026-10-17: "If user wants to see say item basis what how much
    // loads we bought from this date to that date,it shpuld able to show na"
    // / "Build it properly so as sales".
    //
    // `count` on these rows is the number of item LINES, which is not the
    // same question: one load can weigh alternators across four lines, and
    // the same item appears in many loads. "How many loads had alternator in
    // them" needs distinct loads, so it is counted here rather than inferred
    // from count.
    //
    // Keyed by the SAME canonicalKey the alias merge below uses, and held as
    // a SET of load ids. A load carrying both "Al combo" and "Aluminium
    // combo" is ONE load, and summing two merged rows' counts would say two.
    // Declared HERE rather than further down, where it used to live: the
    // loop below runs immediately and would have hit the temporal dead zone
    // on the first load that has items.
    const aliases = require('./itemAliases');
    const aliasRowsForCount = aliases.list();
    const loadIdsByKey = new Map();
    for (const l of filtered) {
        for (const it of (Array.isArray(l.items) ? l.items : [])) {
            const raw = (it && it.description) ? String(it.description).trim() : 'Other';
            const k = aliases.canonicalKey(raw, aliasRowsForCount);
            if (!loadIdsByKey.has(k)) loadIdsByKey.set(k, new Set());
            loadIdsByKey.get(k).add(l.id);
        }
    }
    const loadCountFor = (description) => {
        const set = loadIdsByKey.get(aliases.canonicalKey(String(description || 'Other').trim(), aliasRowsForCount));
        return set ? set.size : 0;
    };

    // ── ONE METAL, ONE ROW — HER DECISIONS, NOT A GUESS ──────────────────
    // the owner, 2026-09-16: "Warn me if al combo and aluminium combo,remember
    // my selection-then next time let ai decide based on knowldge".
    //
    // groupItemsByDescription keys on the text, so "Al combo" and "Aluminium
    // combo" were two rows — and once a sale was recorded against the second
    // one, the tab showed 600 lb on hand of one and MINUS 300 of the other
    // for a single pile of aluminium. The figure was not just split, it was
    // impossible.
    //
    // Folded AFTER grouping rather than by changing groupItemsByDescription,
    // which also builds the load-ticket PDF: a document already issued to a
    // seller should not silently start combining his lines because a decision
    // was made weeks later about two words.
    //
    // Nothing is folded by resemblance. Only pairs SHE confirmed — see
    // helpers/itemAliases.js for why similarity is the wrong instrument here
    // ("Al 6061" and "Al 6063" differ by one character and are different
    // money).
    const aliasRows = aliases.list();
    if (aliasRows.length && byType.length) {
        const merged = new Map();
        for (const g of byType) {
            const key = aliases.canonicalKey(g.description, aliasRows);
            const cur = merged.get(key);
            if (!cur) { merged.set(key, { ...g, _members: [g.description] }); continue; }
            cur.count += g.count || 0;
            cur.gross = round2((cur.gross || 0) + (g.gross || 0));
            cur.tare = round2((cur.tare || 0) + (g.tare || 0));
            cur.net = round2((cur.net || 0) + (g.net || 0));
            cur.amount = round2((cur.amount || 0) + (g.amount || 0));
            cur._members.push(g.description);
        }
        byType = [...merged.values()].map((g) => {
            const label = aliases.displayName(g.description, items.map((it) => it && it.description), aliasRows);
            const out = { ...g, description: label };
            // Kept so the tab can say "counted with Aluminium combo" rather
            // than a row silently changing name between two visits.
            out.also_known_as = (g._members || []).filter((d) => aliases.norm(d) !== aliases.norm(label));
            delete out._members;
            out.loadCount = loadCountFor(label);
            return out;
        });
    }
    // The un-merged path (no aliases saved yet) needs it too — otherwise the
    // column is present for some of her yards and missing for others.
    byType = byType.map((g) => (g.loadCount === undefined
        ? { ...g, loadCount: loadCountFor(g.description) } : g));

    // ── On-hand (2026-08-24) ────────────────────────────────────────────────
    // the owner: "when this outbound gets updated — inventory should also get
    // decreased na?" Correct, and it overrides her earlier "keep them
    // separate": a figure that only ever grows is a purchase log, not
    // inventory.
    //
    // `net` is deliberately LEFT ALONE, still meaning "how much came in".
    // helpers/pdf.js's inventory PDF and helpers/inventoryExcel.js both read
    // it, and quietly changing what it means would alter two documents nobody
    // asked to change. onHand/shipped are added alongside; the UI shows
    // on-hand, the exports keep reporting purchases.
    //
    // ONLY MEANINGFUL WITHOUT A DATE FILTER, and this matters. On-hand is a
    // point in time, not a range: "bought this week minus shipped ever" is a
    // nonsense figure that would read as authoritative. So a filtered report
    // returns onHand null and the UI falls back to showing purchases, which
    // is the honest answer to "what came in this week".
    const wholeHistory = !from && !to;
    if (wholeHistory) {
        let shippedByType = new Map();
        try {
            const outbound = require('./outboundLoads').loadOutboundLoads();
            for (const o of outbound) {
                const aliasRowsOut = require('./itemAliases').list();
                for (const it of (o.items || [])) {
                    const raw = String(it.description || 'Other').trim();
                    // Keyed the same way the rows above are, or a sale
                    // recorded under a confirmed alias would fail to find its
                    // stock and print as a negative row of its own — which is
                    // the exact symptom this change exists to end.
                    const k = require('./itemAliases').canonicalKey(raw, aliasRowsOut) || raw.toLowerCase();
                    // The KEY is lower-cased so "Al combo" and "al combo"
                    // are one material; the SPELLING she typed is kept
                    // beside it, because the row pushed below used to be
                    // labelled with the key and printed an all-lowercase
                    // "al combo" among properly-cased rows. Grouping is
                    // case-insensitive; displaying is not the same job.
                    const cur = shippedByType.get(k) || { label: raw, net: 0 };
                    cur.net += (Number(it.net_weight) || 0);
                    shippedByType.set(k, cur);
                }
            }
        } catch (e) {
            // Outbound unreadable — report purchases rather than a wrong
            // on-hand. A missing subtrahend must not become zero.
            shippedByType = null;
        }
        if (shippedByType) {
            byType = byType.map((g) => {
                const hit = shippedByType.get(require('./itemAliases').canonicalKey(g.description, aliasRows)
                                              || String(g.description).trim().toLowerCase());
                const shipped = hit ? hit.net : 0;
                return { ...g, shipped: round2(shipped), onHand: round2((g.net || 0) - shipped) };
            });
            // Material shipped that was never recorded as bought still has to
            // appear, or the tab shows nothing while the yard shows a hole.
            for (const [k, hit] of shippedByType) {
                if (byType.some((g) => (require('./itemAliases').canonicalKey(g.description, aliasRows)
                                        || String(g.description).trim().toLowerCase()) === k)) continue;
                // hit.label, not k: labelling this row with the lower-cased
                // grouping key made a sold-only item render as "al combo"
                // next to bought items reading "Al combo" — one material
                // looking like two conventions on one screen.
                byType.push({ description: hit.label, count: 0, loadCount: 0, gross: 0, tare: 0, net: 0, amount: 0, shipped: round2(hit.net), onHand: round2(-hit.net) });
            }
        }
    }

    const dayMap = new Map();
    for (const l of filtered) {
        const key = l.date || 'Unknown date';
        if (!dayMap.has(key)) dayMap.set(key, { date: key, loadCount: 0, net: 0, amount: 0 });
        const d = dayMap.get(key);
        d.loadCount += 1;
        d.net += l.net_weight || 0;
        d.amount += l.amount || 0;
    }
    // round2 here — per the owner 2026-08-15 ("in per day, round off the amount
    // to 2 decimal"). The running sums above can pick up float noise summing
    // several loads' amounts (e.g. 250 + 40 + 60 -> 350.00000000000006), and
    // unlike byType/bySeller (built via groupItemsByDescription, which
    // already round2()s) this map was never rounded on the way out.
    const byDay = Array.from(dayMap.values())
        .map(d => ({ ...d, net: round2(d.net), amount: round2(d.amount) }))
        .sort((a, b) => (a.date < b.date ? 1 : -1));

    // Grouped by SELLER — per the owner 2026-08-15 ("group by seller as well so
    // that we will know how much we bought overall from that seller").
    // l.seller/l.seller_address hold the outside party's name+address —
    // l.buyer is the fixed "Sample Yard Co Trading" constant (see helpers/loads.js's
    // top-of-file note and pdf.js's comment on the 2026-08-15 field swap).
    // ── ONE SELLER, ONE ROW ──────────────────────────────────────────────
    // the owner, 2026-09-16: "Sellers name/bUyers name-make it case
    // insensitive". This used to group on the RAW trimmed name, so "Sam"
    // and "sam" were two sellers with two sets of totals — and the person
    // reading the tab has no way to know the two lines are one man.
    //
    // groupByName keys case- AND punctuation-insensitively (so "M K Metal"
    // and "MK Metal" meet too) and labels each group with the spelling used
    // most, never the lower-cased key. Labelling with the key is the mistake
    // that put "al combo" beside "Al combo" on this same screen.
    const { groupByName } = require('./canonicalName');
    const sellerMap = new Map();
    for (const [key, grp] of groupByName(filtered, (l) => l.seller, 'Unknown seller')) {
        sellerMap.set(key, { seller: grp.label, loadCount: 0, net: 0, amount: 0, items: [], loads: [] });
    }
    for (const l of filtered) {
        const key = require('./canonicalName').normalizeName(String(l.seller || '').trim()) || '~blank';
        const s = sellerMap.get(key);
        if (!s) continue;
        s.loadCount += 1;
        s.net += l.net_weight || 0;
        s.amount += l.amount || 0;
        if (Array.isArray(l.items)) s.items.push(...l.items);
        // The individual loads behind the seller's totals — added 2026-08-24
        // per the owner ("in inventory per seller tab, when i click it, it should
        // open my load ticket"). Deliberately only the four fields the two
        // clients need to render a link: this report is fetched on every
        // Inventory visit and there is no reason to ship whole load records,
        // photos and signatures included, to draw a list of tickets.
        s.loads.push({
            id: l.id,
            date: l.date || null,
            amount: l.amount != null ? round2(l.amount) : null,
            pdf_link: l.pdf_link || null,
        });
    }
    const bySeller = Array.from(sellerMap.values())
        .map(s => ({
            seller: s.seller,
            loadCount: s.loadCount,
            net: round2(s.net),
            amount: round2(s.amount),
            byType: s.items.length ? groupItemsByDescription(s.items) : [],
            // Newest first, matching how the Loads deck reads.
            loads: s.loads.slice().sort((a, b) => String(b.date || '').localeCompare(String(a.date || ''))),
        }))
        .sort((a, b) => (b.net || 0) - (a.net || 0));

    return {
        loadCount: filtered.length,
        unit: filtered.find(l => l.weight_unit)?.weight_unit || 'lb',
        // Tells the client whether byType[].onHand is a real figure or absent
        // because a date filter is on — better than inferring it from an
        // undefined, which reads the same as "nothing shipped".
        onHandAvailable: wholeHistory && byType.some((g) => g.onHand !== undefined),
        byType,
        byDay,
        bySeller,
    };
}

// ── every line of one material, across every load ─────────────────────────
//
// Per the owner 2026-09-02: "in inventory say if i select sealed units, i want
// the matching loads that contain sealed units to be displayed .. matching
// sealed units from every load in rows with gross tare net price amount. on
// clicking that row, that load ticket should open."
//
// The Inventory tab already GROUPS by description; this is the layer beneath
// it — the individual weighings that add up to that group's total. "We have
// 12,400 lb of sealed units" is only useful if you can then ask which loads
// it came in on and what each was paid at.
//
// A SEPARATE CALL, not folded into getInventoryReport. That report is fetched
// on every visit to the tab, and it exists to summarise: attaching every item
// line to every group would ship the whole item history to draw a summary. One
// yard-year is tens of thousands of lines. So the summary stays a summary and
// the detail is fetched when a type is actually opened.
//
// MATCHED THE SAME WAY THE GROUPING MATCHES — trimmed and case-insensitive,
// exactly as groupItemsByDescription does. If these two ever disagreed, a
// group would show a total with no rows to explain it, or rows that do not add
// up to their own heading, which is worse than either alone.
function getItemLines(allLoads, { description, from, to } = {}) {
    const want = String(description || '').trim().toLowerCase();
    if (!want) return { description: null, lines: [], count: 0, totals: null };

    const filtered = (from || to)
        ? (allLoads || []).filter(l => l.date && (!from || l.date >= from) && (!to || l.date <= to))
        : (allLoads || []);

    const lines = [];
    for (const l of filtered) {
        for (const it of (Array.isArray(l.items) ? l.items : [])) {
            if (String(it.description || 'Other').trim().toLowerCase() !== want) continue;
            lines.push({
                load_id: l.id,
                date: l.date || null,
                seller: l.seller || null,
                // pdf_link is what makes the row clickable. Sent as-is —
                // null when the ticket has not been generated yet, which the
                // clients show rather than hide, so "no PDF" is visibly
                // different from "nothing here".
                pdf_link: l.pdf_link || null,
                description: it.description || 'Other',
                gross_weight: it.gross_weight ?? null,
                tare_weight: it.tare_weight ?? null,
                net_weight: it.net_weight ?? null,
                price: it.price ?? null,
                amount: it.amount ?? null,
                unit: it.unit || l.weight_unit || null,
            });
        }
    }
    // Newest first, matching the Loads deck and every other list here.
    lines.sort((a, b) => String(b.date || '').localeCompare(String(a.date || ''))
        || String(b.load_id || '').localeCompare(String(a.load_id || '')));

    const sum = (k) => round2(lines.reduce((a, r) => a + (Number(r[k]) || 0), 0)) || 0;
    return {
        description: lines.length ? lines[0].description : String(description).trim(),
        count: lines.length,
        // Totals computed HERE rather than trusting the caller to re-add the
        // rows: the figure under a column must be the sum of the column above
        // it, and two places adding the same numbers is how that stops being
        // true.
        totals: {
            gross: sum('gross_weight'), tare: sum('tare_weight'),
            net: sum('net_weight'), amount: sum('amount'),
            unit: lines.find(r => r.unit)?.unit || 'lb',
        },
        lines,
    };
}

module.exports = { loadLoads, addLoad, updateLoad, editLoad, deleteLoad, getLoad, renumberLoad, getInventoryReport, getItemLines,
                   cleanTrucking, payableFrom, payableOf };
