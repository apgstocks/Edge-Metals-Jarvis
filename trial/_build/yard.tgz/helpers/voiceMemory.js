// ── helpers/voiceMemory.js — what she just asked, and what was on screen ──
//
// the owner, 2026-09-06: "I want jarvis to remember every command and its
// response as short term memory.. So that i can do follow up questions.
// Basically i am not sure how to handle his memory part."
//
// And then, concretely: three bookings on screen, "when is the next cutoff",
// "what is the ERD", "forward that to trucker". Every one of those is a
// sentence that means nothing on its own.
//
// TWO KINDS OF MEMORY, AND CONFLATING THEM IS THE MISTAKE
// -------------------------------------------------------
// 1. The TRANSCRIPT — what was said, as text. Handed to the model, which is
//    good at resolving "what about the ERD" from context.
// 2. The REFERENT SET — the rows that were actually on screen, structured
//    and ranked. "The first one" is a position in a LIST, not a phrase in a
//    sentence, and asking a language model to count rows in prose it was
//    handed is exactly the kind of thing that fails silently. On this path a
//    miscount forwards a container to the wrong trucker.
//
// That split is Centering Theory (Grosz, Joshi & Weinstein 1995): each
// utterance makes available a RANKED list of discourse entities, and the
// antecedent of a reference is predicted by rank. helpers/answerCards.js
// already builds exactly that — rows sorted by soonest cutoff, each carrying
// `n` — with a comment saying "what the first one refers to". The list was
// already a referent set. Nothing was keeping it.
//
// WHY THE ORDINAL IS RESOLVED HERE AND NOT BY THE MODEL
// -----------------------------------------------------
// Because two things downstream cannot see a transcript at all:
// answerCards.cardsFor() is a regex over the utterance, and the brain's
// policy layer is ~1200 lines of pattern matching over session state. Both
// need a sentence that stands on its own.
//
// The literature is clear that rewriting for a model that CAN see history
// makes things slightly worse, not better — Ishii et al. 2022 measured
// end-to-end at 84.5 F1 against 82.9 for a rewrite pipeline, on every
// configuration they tried. So: rewrite deterministically ONLY for the blind
// components, and hand the model the raw history to resolve the rest.
//
// WHY IT LIVES ON THE SERVER
// --------------------------
// A client that posts its own transcript can post a stale or replayed one,
// and the last step of this flow sends a WhatsApp message to a real driver.
// The referent set is minted where the rows were minted.

// Turns kept. Six matches what helpers/yardAsk.js already slices to, and
// there is no reason for two windows of different lengths. Longer is not
// better: Laban et al. (2025) measured a 39% average drop from single-turn
// to multi-turn across 200k simulated conversations, and the mechanism is
// early commitment to a wrong assumption — a failure that MORE context
// feeds rather than starves.
const TURN_CAP = 6;
const TEXT_CAP = 300;

// The referent set expires far sooner than the session does. A list of
// bookings is stale long before a conversation is, and the failure mode of
// keeping it is precise: "the first one" resolving to something that left
// the screen twenty minutes ago. workflow/brain.js already carries a comment
// about menuContext never expiring and a bare "1" days later still selecting
// from a menu she saw last week — that bug, found and named, is this one.
const REFERENT_TTL_MS = 10 * 60 * 1000;

let turns = [];
let referents = null;

function remember(role, text) {
    const t = String(text == null ? '' : text).trim();
    if (!t) return;
    turns.push({ role, text: t.slice(0, TEXT_CAP), ts: Date.now() });
    if (turns.length > TURN_CAP) turns = turns.slice(-TURN_CAP);
}

// Called only when a NEW list was rendered. answerCards returns null for
// instructions, which is what stops "forward the first one" from replacing
// the very list it refers to.
// ── THE BACKWARD-LOOKING CENTER ──────────────────────────────────────────
// the owner, 2026-09-07: "On follow up, if i ask when is the erd of that booking.
// Instead of linking the context, it just says there are 10 bookings on
// screen. which one you want me to check?"
//
// She is right and the fix has a name. Grosz, Joshi & Weinstein, "Centering:
// A Framework for Modeling the Local Coherence of Discourse" (Computational
// Linguistics 21(2), 1995) — already cited further down this file for
// pronoun resolution, and this is the half of it I had not implemented.
//
// Each utterance has a set of forward-looking centers (Cf) — everything it
// mentions — and a single BACKWARD-looking center (Cb): the one entity the
// utterance is actually ABOUT. The rule that matters here is Centering's
// Rule 1: if anything is pronominalised, the Cb is. So "that booking" does
// not mean "one of the ten on screen"; it means the one the last sentence was
// about.
//
// And the last sentence WAS about one: "Earliest cutoff is next Wednesday"
// is a statement about rows[0], not about the list. Ten rows were on screen
// and resolve() counted them and refused, because the only thing recorded was
// the Cf — the whole list — and never the Cb.
//
// Kept separate from `referents` rather than reordering them, because the
// list order means something else entirely: "the first one" is soonest
// cutoff, and moving the discussed row to the front would silently change
// what that phrase points at.
let center = null;

// A new list is a new topic. Whatever was being discussed is no longer what
// "that" means, and carrying it across is worse than having none — it would
// resolve confidently to a booking that is not even on screen.
function setCenter(row) {
    center = row && row.booking_number ? { row, at: Date.now() } : null;
    if (center) console.log(`[MEMORY] center: ${row.booking_number}`);
}

function currentCenter() {
    if (!center) return null;
    if (Date.now() - center.at > REFERENT_TTL_MS) { center = null; return null; }
    return center.row;
}

function setReferents(cards) {
    // ── CLEARED ONLY BY A NEW LIST, NOT BY EVERY CALL ────────────────────
    // `center = null` used to run BEFORE this guard, so setReferents(null) —
    // which api.js does on every INSTRUCTION, because cardsFor returns null
    // for one — wiped the discourse centre as a side effect.
    //
    // Found 2026-09-07 while fixing "forward booking to trucker": the centre
    // was correctly on HOU111 from the previous turn, and the very act of
    // handling her forward destroyed it before forwardBooking could read it.
    // She got "Which booking?" about the booking she had just been discussing.
    //
    // The rule was always "a new list is a new topic". A call with NO list is
    // not a new topic; it is a sentence that has nothing to do with lists.
    if (!cards || !Array.isArray(cards.rows) || !cards.rows.length) return;
    center = null;
    referents = { kind: cards.kind, title: cards.title, ts: Date.now(), rows: cards.rows };
}

// ── THE LAST FORM SHE FILLED IN ──────────────────────────────────────────
// Slot carryover, in the sense of Naik et al. (Interspeech 2018): when she
// says only "houston" after asking for AVAILABLE bookings, the status has to
// survive into the next turn or she gets every Houston booking and no sign
// that half her question was dropped. Their finding is that carryover decided
// over the whole context beats hand-coded rules by ~9%, so this stores the
// previous frame and hands it to the model rather than deciding here which
// fields to keep.
//
// Same lifetime as the referents. A frame older than the list it produced is
// not context, it is a stale assumption.
// ── AN OFFER IS A QUESTION, SO IT NEEDS SOMEWHERE FOR THE ANSWER ─────────
// "Want me to forward one?" was spoken for two days with nothing behind it.
// Recorded here, alongside the referents, because that is exactly what it is
// about — and cleared the moment it is answered, declined, or ignored. An
// offer that outlives the turn it was made in becomes a trap: she says "yes"
// to something else three sentences later and a truck gets a message.
let offer = null;
function setOffer(o) { offer = o ? { ...o, ts: Date.now() } : null; }
function lastOffer() {
    if (!offer) return null;
    // ONE TURN. Deliberately much shorter than the referent TTL: the rows can
    // still be on screen long after the offer has stopped being live.
    if (Date.now() - offer.ts > 120000) { offer = null; return null; }
    return offer;
}
function clearOffer() { offer = null; }

// ── THE PORT, HANDED OVER AS A FACT INSTEAD OF AS ENGLISH ────────────────
// When she accepts "want me to ask a forwarder for space?", api.js turns that
// into a sentence and re-feeds it through the whole pipeline. The load port
// has to survive that trip, and putting it in the sentence has already gone
// wrong twice: "...asking for a booking from HOUSTON" was claimed by the
// brain's own location rule, and "to carrier asking for space" made the
// recipient "carrier asking". The comment above that line in api.js is a record
// of two rounds of working around Jarvis's own parsers.
//
// So the port travels beside the sentence rather than inside it, and the
// sentence is left free to be whatever reads best.
//
// SINGLE USE, deliberately. take() clears it. A port that lingers would
// attach itself to the next unrelated email she dictates, and "need bookings
// from HOUSTON" on a mail about an invoice is exactly the kind of confident
// wrongness this app keeps having to be taught out of. It also carries the
// same 2-minute life as the offer that produced it — anything older is not
// context, it is an assumption.
let requestPort = null;
function setRequestPort(p) { requestPort = p ? { port: String(p).toUpperCase(), ts: Date.now() } : null; }
function takeRequestPort() {
    if (!requestPort) return null;
    const fresh = Date.now() - requestPort.ts <= 120000;
    const p = fresh ? requestPort.port : null;
    requestPort = null;
    return p;
}

let queryFrame = null;
function setQueryFrame(f) { queryFrame = f ? { ...f, ts: Date.now() } : null; }
function lastQueryFrame() {
    if (!queryFrame) return null;
    if (Date.now() - queryFrame.ts > REFERENT_TTL_MS) { queryFrame = null; return null; }
    const { ts, by, ...rest } = queryFrame;
    return rest;
}

function currentReferents() {
    if (!referents) return null;
    if (Date.now() - referents.ts > REFERENT_TTL_MS) { referents = null; return null; }
    return referents;
}

// The shape helpers/yardAsk.js already expects.
function history() {
    return turns.map((t) => ({ role: t.role, text: t.text }));
}

function reset() { turns = []; referents = null; center = null; }

// The sentence BEFORE the one being handled — which is what a retraction is
// about. `remember('user', asked)` runs at the top of the handler, so by the
// time helpers/repair.js asks, the current utterance is already the last
// entry and the one it wants is the previous user turn.
function previousUser() {
    const mine = turns.filter((t) => t.role === 'user');
    return mine.length > 1 ? mine[mine.length - 2].text : null;
}

// ── TAKING IT BACK MEANS IT IS NOT THERE ANY MORE ────────────────────────
// the owner, 2026-09-09, with the Iron Man reference: "say i have said something
// wrong... No no..delete that..it should delete my previously transcibed
// sentence /words na?"
//
// She is right, and until now nothing did this. helpers/repair.js has been
// classifying retractions correctly since 2026-09-07 — api.js READS the
// sentence being retracted (previousUser, the reparandum) to say it back to
// her — and then the retracted turn stayed in this array. So Jarvis agreed it
// had forgotten something it had not forgotten: "that" still resolved to it,
// and it was still handed to the model as context on the next turn.
//
// An assistant that says "taken back" and keeps the sentence is worse than
// one that cannot take anything back, because she stops checking.
//
// SCOPE, and it is hers: short-term memory only. Asked how far "delete"
// should go, she chose the working memory and not the saved day log — which
// is the right call and the one I would have argued for. The log is what
// reconstructs an incident afterwards, and a voice command that erases
// records is a bad thing to own. Nothing here touches disk.
//
// The RETRACTION ITSELF goes too. "delete that" is not a thing she wants
// remembered as a thing she said; leaving it in makes the next "that" point
// at the word "delete".
function forgetLastExchange() {
    // Walk back until TWO of her own turns are gone: the retraction itself,
    // and the sentence it retracted. Jarvis's replies in between go with them
    // — they are answers to a sentence that no longer exists.
    //
    // TWO is the whole rule, and it is what stops a single "delete that"
    // eating a third sentence she still means.
    //
    // Written this plainly on the second attempt. The first had a `break`
    // guard AND a look-ahead that popped the reparandum early — two mechanisms
    // for one job, and a mutation proved the guard was unreachable on every
    // path the tests exercise. An unreachable guard is not a safe extra; it is
    // a line that makes the function look more careful than it is.
    const dropped = [];
    let mine = 0;
    while (turns.length && mine < 2) {
        if (turns[turns.length - 1].role === 'user') mine += 1;
        dropped.push(turns.pop().text);
    }
    // The centre and the frame were about the sentence that is now gone.
    // Leaving them is the same lie one level down: "that booking" would still
    // resolve off a question she just took back.
    center = null;
    queryFrame = null;
    if (dropped.length) console.log(`[MEMORY] retracted — forgot ${dropped.length} turn(s): ${dropped.map((d) => JSON.stringify(String(d).slice(0, 40))).join(', ')}`);
    return dropped.length;
}

// ── resolving a reference ────────────────────────────────────────────────
const ORDINALS = {
    first: 1, '1st': 1, one: 1,
    second: 2, '2nd': 2, two: 2,
    third: 3, '3rd': 3, three: 3,
    fourth: 4, '4th': 4, four: 4,
    fifth: 5, '5th': 5, five: 5,
};

// "the first one", "the second booking", "the last one".
const ORDINAL_RE = new RegExp(
    '\\b(?:the\\s+)?(' + Object.keys(ORDINALS).join('|') + '|last)\\s+'
    + '(?:one|booking|row|result|container)\\b', 'i');

// "that booking", "that one", "this container". Only counts when a list is
// live — otherwise "it" is just a pronoun in an ordinary sentence.
// "the one" is NOT in here, and that omission is deliberate. It was, and it
// over-resolved: "that is the one we discussed" became "that is booking
// AAA111 we discussed", turning an ordinary sentence into a command about a
// specific container. "The one" is everyday English; "that booking" and
// "this container" are people pointing at something.
const DEICTIC_RE = /\b(?:(?:that|this)\s+(?:booking|one|container)|the\s+(?:booking|container))\b/i;

// ── AND A BARE "THAT", AFTER AN INSTRUCTION ──────────────────────────────
// the owner's actual words: "forward that to trucker". Not "that booking" —
// just "that". The pattern above requires a noun after it, so the sentence
// she would really say was not recognised as a reference at all, and the
// booking number never reached the brain.
//
// A bare "that" is far too common to treat as a reference on its own, so it
// only counts DIRECTLY AFTER AN ACTION VERB and only while a list is on
// screen. "Forward that", "send that", "assign that" are pointing at
// something; "I thought that was fine" is not.
const BARE_DEICTIC_RE = /\b(forward|send|assign|dispatch|book|do|use)\s+(that|this|it)\b/i;

// Returns { text, resolved } — `resolved` is null when nothing was changed.
// NEVER guesses: an unresolvable reference is returned untouched, so the
// assistant asks rather than acting on the wrong container. The cost of
// asking is a sentence; the cost of guessing is a truck at the wrong yard.
function resolve(text) {
    const q = String(text || '');
    const set = currentReferents();
    if (!set) return { text: q, resolved: null };

    // ── SHE ALREADY SAID WHICH ONE ───────────────────────────────────────
    // Found by tests/phrasebook.js, 2026-09-08. "forward the booking HOU111 to
    // Sher Trucking" came out as "forward booking HOU111 HOU111 to Sher
    // Trucking" — the deictic was expanded even though the number it expands
    // TO was already sitting in the sentence, and the brain understandably
    // could not read the result.
    //
    // The rule is simply that a reference is a stand-in for something not
    // said. If one of the rows on screen is named outright, nothing is
    // standing in for anything and there is no work to do here. Scoped to the
    // rows in view rather than a general booking-number pattern, so a token
    // that merely LOOKS like a number ("40HC", a weight, a seal) cannot
    // silence the resolver.
    const namesOne = set.rows.some((r) => {
        const id = String(r.booking_number || '').trim();
        return id && new RegExp(`\\b${id.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i').test(q);
    });
    if (namesOne) return { text: q, resolved: null };

    let row = null;
    let phrase = '';

    const m = ORDINAL_RE.exec(q);
    if (m) {
        phrase = m[0];
        const word = m[1].toLowerCase();
        row = (word === 'last') ? set.rows[set.rows.length - 1] : set.rows[ORDINALS[word] - 1] || null;
    } else if (DEICTIC_RE.test(q) || BARE_DEICTIC_RE.test(q)) {
        // "that booking" is unambiguous ONLY when there is one thing it
        // could mean. With three on screen it is a genuine ambiguity, and
        // the honest response is to ask — the same refusal the brain already
        // makes for a bare digit with two possible sources.
        const m2 = DEICTIC_RE.exec(q);
        // Whichever pattern matched — replacing the wrong span would leave
        // the pronoun in the sentence alongside the number.
        const span = m2 ? m2[0] : BARE_DEICTIC_RE.exec(q)[2];
        if (set.rows.length === 1) {
            row = set.rows[0];
            phrase = span;
        } else {
            // CENTERING, Rule 1. The last answer was about one of these; a
            // pronoun refers to that one. Checked against the CURRENT set, so
            // a center left over from a list that has been replaced resolves
            // to nothing rather than to a booking no longer on screen.
            const cb = currentCenter();
            const still = cb && set.rows.filter((r) => r.booking_number === cb.booking_number)[0];
            if (still) {
                row = still;
                phrase = span;
                console.log(`[MEMORY] "${span}" → ${still.booking_number} (the one just discussed)`);
            } else {
                // No center: genuinely ambiguous, and asking is right. The
                // cost of asking is a sentence; the cost of guessing is an
                // answer about the wrong booking, said with confidence.
                return { text: q, resolved: null, ambiguous: set.rows.length };
            }
        }
    }

    if (!row) return { text: q, resolved: null };

    const id = row.booking_number || '';
    if (!id) return { text: q, resolved: null };

    return {
        text: q.replace(phrase, 'booking ' + id),
        resolved: { from: phrase, to: id, n: row.n, row },
    };
}

// ── UNDERSTANDING IT, RATHER THAN MATCHING IT ────────────────────────────
// the owner, 2026-09-06: "my user doesnt know about nouns. you can try to
// understand what he says like any ai does."
//
// She is right, and it is the same objection as "i dont want any fixed
// intent" — I had kept the referent resolution on a phrasebook. The patterns
// above understand "the first one" and "that booking". A yard manager says
// "the Maersk one", "the Korea one", "the urgent one", "the one cutting off
// first", "send it". None of those match, and a reference that does not
// match means the booking number never reaches the brain.
//
// SO THE MODEL DECIDES WHICH ROW, AND THE CODE PROVES IT EXISTS
// -------------------------------------------------------------
// The safety argument for keeping this deterministic was never "models are
// bad at language". It was that a model asked to COUNT ROWS in prose fails
// silently, and the next sentence sends a truck. That argument survives
// intact under a different arrangement:
//
//   the model returns `n` — WHICH ROW, from a numbered list it was given
//   the code looks up rows[n-1] and takes the booking number from THERE
//
// So the model never writes a booking number. It picks a row, out of the
// rows actually on screen, and if it picks one that does not exist or
// declines to pick, nothing is resolved and she is asked. The identifier
// still comes from the data every time — which is the whole guarantee, and
// it is now compatible with her saying it however she likes.
const PICK_RULES = [
    'The manager is looking at this numbered list on her screen.',
    'She just said something. Work out WHICH ROW she means, if any.',
    '',
    'She will not use the words in the data. She says "the Maersk one",',
    '"the Korea one", "the urgent one", "the one cutting off first", or just',
    '"it". Understand her the way a person standing next to her would.',
    '',
    'Reply as JSON: {"n": <the row number>, "why": "<a few words>"}',
    'or {"n": null} if she did not mean a particular row, or if two rows fit',
    'equally well and you would be guessing.',
    '',
    'RETURN null RATHER THAN A GUESS. Getting this wrong sends a container to',
    'the wrong trucker. "It" with one row on screen is that row; "it" with',
    'three is a guess.',
].join('\n');

async function pickRow(text, set) {
    if (!set || !Array.isArray(set.rows) || !set.rows.length) return null;
    const q = String(text || '').trim();
    if (!q) return null;

    // Only what she can see. Sending fields that are not on screen invites a
    // pick she could not have meant.
    const rows = set.rows.map((r) => ({
        n: r.n,
        booking: r.booking_number,
        carrier: r.carrier || null,
        from: r.from || null,
        to: r.to || null,
        vessel: r.vessel || null,
        cutoff: r.cutoff || null,
    }));

    try {
        const { callGeminiJSON } = require('./gemini');
        const res = await callGeminiJSON([
            PICK_RULES, '', 'ROWS:', JSON.stringify(rows), '',
            `SHE SAID: ${q}`,
        ].join('\n'), 1);

        const n = res && res.n;
        if (n === null || n === undefined) return null;
        const num = Number(n);
        if (!Number.isFinite(num)) return null;

        // THE GUARANTEE. The row is looked up in OUR data by index; the
        // model's own words are never used as an identifier. A number
        // outside the list resolves to nothing rather than to something.
        const row = set.rows.find((r) => r.n === num) || null;
        if (!row) {
            console.warn(`[MEMORY] model picked row ${num}, which is not on screen — ignoring`);
            return null;
        }
        return { row, why: String((res && res.why) || '').slice(0, 60) };
    } catch (e) {
        console.warn('[MEMORY] model unreachable for the reference:', e.message);
        return null;
    }
}

// What the endpoint calls. Model first, patterns second — and the patterns
// remain because an assistant that cannot resolve "the first one" because
// the network blipped is worse than one that only knows six phrasings.
async function resolveSmart(text) {
    const set = currentReferents();
    if (!set) return { text: String(text || ''), resolved: null };

    // The patterns are tried FIRST when they are certain. "The second one"
    // is not a judgement call, and spending a round trip to have a model
    // agree with a counted index is latency for nothing.
    const exact = resolve(text);
    if (exact.resolved) return exact;

    const picked = await pickRow(text, set);
    if (picked && picked.row && picked.row.booking_number) {
        const id = picked.row.booking_number;
        console.log(`[MEMORY] "${text}" → booking ${id} (${picked.why})`);
        return {
            text: `${text} (booking ${id})`,
            resolved: { from: text, to: id, n: picked.row.n, row: picked.row, why: picked.why },
        };
    }

    // Unresolved, including the deliberate refusal when the patterns found
    // an ambiguity. She is asked rather than guessed at.
    return exact;
}

// ── ASKING BACK IN HER WORDS ─────────────────────────────────────────────
// When the reference cannot be pinned down, the honest response is to ask —
// but "say the first one" is me telling her which phrase I happen to parse,
// which is the thing she objected to. So find a field that actually DIFFERS
// between the rows on screen and offer that instead: "the Maersk one or the
// MSC one?".
//
// A field only helps if its values are distinct. Three bookings all on
// Maersk make the carrier useless for telling them apart, so a field with a
// repeat in it is skipped rather than offered.
const DISTINGUISH_BY = [
    { key: 'carrier', word: '' },
    { key: 'vessel', word: '' },
    { key: 'to', word: 'going to ' },
    { key: 'from', word: 'from ' },
];

function distinguishers() {
    const set = currentReferents();
    if (!set || set.rows.length < 2 || set.rows.length > 4) return null;

    for (const f of DISTINGUISH_BY) {
        const vals = set.rows.map((r) => (r[f.key] == null ? '' : String(r[f.key]).trim()));
        if (vals.some((v) => !v)) continue;             // a blank tells her nothing
        if (new Set(vals.map((v) => v.toLowerCase())).size !== vals.length) continue; // a repeat does not distinguish
        const parts = vals.map((v) => `the ${f.word}${v} one`);
        return parts.slice(0, -1).join(', ') + ' or ' + parts[parts.length - 1] + '?';
    }
    return null;
}

module.exports = {
    remember, setReferents, currentReferents, setCenter, currentCenter,
    setQueryFrame, lastQueryFrame, setOffer, lastOffer, clearOffer,
    setRequestPort, takeRequestPort, forgetLastExchange,
    history, previousUser, resolve, resolveSmart,
    pickRow, distinguishers, reset, PICK_RULES, DISTINGUISH_BY,
    TURN_CAP, REFERENT_TTL_MS,
};
