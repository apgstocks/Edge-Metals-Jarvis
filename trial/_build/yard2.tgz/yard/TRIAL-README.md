# Sample Yard Co — trial

Start:   npm install && node trial-seed.js && node trial-server.js   (then open http://<server>:39517)
Logins:  manager (everything)  FMyisFo08nIe62
         staff (loads only)    x6DHoS1z2Ib725
         team                  0xW3CSGIkYRl24
Switch off: stop the process. Reset the demo: delete the data/ folder, run node trial-seed.js again.
Not included: WhatsApp, Gmail, QuickBooks, Google Drive.
