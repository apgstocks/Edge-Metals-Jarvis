# Sample Yard Co — trial

Start:   npm install && node trial-seed.js && node trial-server.js   (then open http://<server>:39517)
Logins:  manager (everything)  CEB6Tbo3fOLS17
         staff (loads only)    2sL7lazHhhk051
         team                  UvfxI16reBUI77
Switch off: stop the process. Reset the demo: delete the data/ folder, run node trial-seed.js again.
Not included: WhatsApp, Gmail, QuickBooks, Google Drive.
