# Sample Yard Co — trial

Start:   npm install && node trial-seed.js && node trial-server.js   (then open http://<server>:39517)
Logins:  manager (everything)  FXvdu37X3hrw46
         staff (loads only)    cowIe9rQDUA182
         team                  L5cBUvRdFZml36
Switch off: stop the process. Reset the demo: delete the data/ folder, run node trial-seed.js again.
Not included: WhatsApp, Gmail, QuickBooks, Google Drive.
